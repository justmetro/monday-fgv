"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server/index.ts
var import_node_http = __toESM(require("node:http"), 1);
var import_node_crypto4 = require("node:crypto");
var import_promises = require("node:fs/promises");
var import_node_path = __toESM(require("node:path"), 1);

// server/context.ts
var import_node_async_hooks = require("node:async_hooks");
var reqCtx = new import_node_async_hooks.AsyncLocalStorage();
var currentCtx = () => reqCtx.getStore() ?? null;

// server/mongo.ts
var import_mongodb = require("mongodb");
var clientP = null;
function mongo() {
  if (!clientP) {
    const uri = process.env.MNDY_MONGODB_CONNECTION_STRING;
    if (!uri) throw new Error("Banco do app indispon\xEDvel (MNDY_MONGODB_CONNECTION_STRING ausente).");
    const client = new import_mongodb.MongoClient(uri, { maxPoolSize: 10, serverSelectionTimeoutMS: 15e3 });
    clientP = client.connect().then((c) => c.db()).catch((e) => {
      clientP = null;
      throw e;
    });
  }
  return clientP;
}

// server/oauth.ts
var import_node_crypto = require("node:crypto");
var col = async () => (await mongo()).collection("app_oauth");
var cache = null;
var TTL = 5 * 60 * 1e3;
async function tokenOAuth() {
  if (cache && Date.now() - cache.at < TTL) return cache.token;
  try {
    const d = await (await col()).findOne({ _id: "token" });
    cache = { at: Date.now(), token: typeof d?.accessToken === "string" ? d.accessToken : null };
  } catch (e) {
    console.error("[oauth] leitura do token", e);
    cache = { at: Date.now(), token: null };
  }
  return cache.token;
}
var conhecido = "";
function lembrarCliente(clientId, accountId) {
  const c = String(clientId ?? ""), a = String(accountId ?? "");
  if (!c || conhecido === `${c}|${a}`) return;
  conhecido = `${c}|${a}`;
  col().then((x) => x.updateOne({ _id: "cliente" }, { $set: { clientId: c, accountId: a } }, { upsert: true })).catch(() => {
    conhecido = "";
  });
}
function pagina(res, status, texto) {
  if (status >= 400) {
    console.error("[oauth]", status, texto);
    col().then((x) => x.updateOne({ _id: "erro" }, { $set: { status, texto, em: (/* @__PURE__ */ new Date()).toISOString() } }, { upsert: true })).catch(() => null);
  }
  res.writeHead(status, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
  res.end(`<!doctype html><meta charset="utf-8"><title>Autoriza\xE7\xE3o do app</title><body style="font-family:system-ui;padding:40px;max-width:560px">${texto}</body>`);
}
function retorno(req) {
  if (process.env.OAUTH_REDIRECT_URI) return process.env.OAUTH_REDIRECT_URI;
  let host = String(req.headers["x-forwarded-host"] ?? req.headers.host ?? "").split(",")[0].trim();
  const m = host.match(/^([a-z0-9]+)---(service-\d+-[a-z0-9]+)-[a-z0-9]+-[a-z]+\.a\.run\.app$/);
  if (m) host = `${m[1]}-${m[2]}.us.monday.app`;
  return `https://${host}/oauth/callback`;
}
async function oauthStart(req, res) {
  const c = await (await col()).findOne({ _id: "cliente" });
  if (!c?.clientId) return pagina(res, 409, "<p>Abra o app uma vez dentro do monday e depois volte a este link.</p>");
  const state = (0, import_node_crypto.randomBytes)(24).toString("hex");
  await (await col()).updateOne({ _id: "state" }, { $set: { state, at: Date.now() } }, { upsert: true });
  const url = new URL("https://auth.monday.com/oauth2/authorize");
  url.searchParams.set("client_id", String(c.clientId));
  url.searchParams.set("redirect_uri", retorno(req));
  url.searchParams.set("state", state);
  res.writeHead(302, { Location: url.toString(), "Cache-Control": "no-store" });
  res.end();
}
async function oauthCallback(req, res, url) {
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const x = await col();
  const s = await x.findOne({ _id: "state" });
  if (!code || !state || s?.state !== state || Date.now() - Number(s?.at ?? 0) > 15 * 60 * 1e3) {
    return pagina(res, 400, "<p>Link de autoriza\xE7\xE3o inv\xE1lido ou expirado. Abra /oauth/start de novo.</p>");
  }
  await x.deleteOne({ _id: "state" });
  const c = await x.findOne({ _id: "cliente" });
  const r = await fetch("https://auth.monday.com/oauth2/token", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ client_id: c?.clientId, client_secret: process.env.CLIENT_SECRET, code, redirect_uri: retorno(req) })
  });
  const j = await r.json().catch(() => null);
  if (!j?.access_token) return pagina(res, 400, `<p>O monday recusou a autoriza\xE7\xE3o: ${String(j?.error_description ?? j?.error ?? r.status).replace(/[<>]/g, "")}</p>`);
  const me = await fetch("https://api.monday.com/v2", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: j.access_token, "API-Version": "2026-10" },
    body: JSON.stringify({ query: "{ me { id name kind } }" })
  }).then((y) => y.json()).catch(() => null);
  const u = me?.data?.me;
  if (u?.kind !== "admin") {
    console.error("[oauth] me", JSON.stringify(me).slice(0, 500));
    return pagina(res, 403, "<p>S\xF3 um admin da conta FGV DGPE pode autorizar o app.</p>");
  }
  await x.updateOne({ _id: "token" }, { $set: { accessToken: j.access_token, userId: String(u.id), nome: u.name, em: (/* @__PURE__ */ new Date()).toISOString() } }, { upsert: true });
  cache = null;
  return pagina(res, 200, `<p>App autorizado por ${u.name.replace(/[<>]/g, "")}. Pode fechar esta aba e recarregar o app no monday.</p>`);
}
async function oauthStatus(res) {
  const d = await (await col()).findOne({ _id: "token" });
  const e = await (await col()).findOne({ _id: "erro" });
  res.writeHead(200, { "Content-Type": "application/json", "Cache-Control": "no-store" });
  res.end(JSON.stringify({ autorizado: !!d?.accessToken, por: d?.nome ?? null, em: d?.em ?? null, ultimoErro: e ? { status: e.status, texto: e.texto, em: e.em } : null }));
}

// server/relay.ts
var import_node_crypto2 = require("node:crypto");
var SEM_NAVEGADOR = /* @__PURE__ */ Symbol("sem-navegador");
var col2 = async () => (await mongo()).collection("app_mutacoes");
var LIMITE_MS = 12e4;
var espera = (ms) => new Promise((r) => setTimeout(r, ms));
var ultimaLimpeza = 0;
async function limpar() {
  if (Date.now() - ultimaLimpeza < 60 * 6e4) return;
  ultimaLimpeza = Date.now();
  await (await col2()).deleteMany({ at: { $lt: Date.now() - 24 * 60 * 6e4 } }).catch(() => null);
}
async function viaNavegador(query, variables) {
  const ctx = currentCtx();
  if (!ctx?.callId || ctx.viaCron || ctx.encerrada) return SEM_NAVEGADOR;
  const c = await col2();
  const _id = (0, import_node_crypto2.randomBytes)(12).toString("hex");
  await c.insertOne({ _id, callId: ctx.callId, userId: ctx.userId, query, variables: variables ?? {}, status: "pendente", at: Date.now() });
  void limpar();
  const fim = Date.now() + LIMITE_MS;
  let passo = 150;
  while (Date.now() < fim) {
    await espera(passo);
    passo = Math.min(passo + 100, 500);
    const p = await c.findOne({ _id });
    if (p?.status === "ok") return p.resposta;
    if (p?.status === "erro") return { errors: [{ message: p.erro || "Falha ao gravar no monday pelo navegador." }] };
  }
  await c.updateOne({ _id, status: { $in: ["pendente", "enviada"] } }, { $set: { status: "expirada" } });
  throw new Error("A grava\xE7\xE3o n\xE3o foi confirmada pelo navegador a tempo. Mantenha a aba aberta e tente novamente.");
}
async function pendentes(callId, userId, esperarMs = 8e3) {
  const c = await col2();
  const fim = Date.now() + esperarMs;
  for (; ; ) {
    const lista = [];
    for (; ; ) {
      const p = await c.findOneAndUpdate({ callId, userId, status: "pendente" }, { $set: { status: "enviada" } }, { sort: { at: 1 }, returnDocument: "after" });
      const doc = p && "value" in p ? p.value : p;
      if (!doc) break;
      lista.push({ id: doc._id, query: doc.query, variables: doc.variables });
    }
    if (lista.length || Date.now() >= fim) return lista;
    await espera(200);
  }
}
async function registrarResultado(id, userId, resposta, erro) {
  await (await col2()).updateOne(
    { _id: id, userId, status: "enviada" },
    { $set: erro ? { status: "erro", erro: String(erro).slice(0, 1e3) } : { status: "ok", resposta } }
  );
}

// server/monday.ts
var API = "https://api.monday.com/v2";
function serviceToken() {
  return (process.env.MONDAY_API_TOKEN ?? "").trim();
}
var ehMutacao = (query) => /^\s*mutation\b/.test(query);
async function respostaMonday(query, variables = {}, opts = {}) {
  if (!opts.tokenFixo && ehMutacao(query)) {
    const r = await viaNavegador(query, variables);
    if (r !== SEM_NAVEGADOR) return { status: 200, json: r };
  }
  const token = opts.tokenFixo ?? await tokenOAuth() ?? serviceToken();
  if (!token) throw new Error("App sem autoriza\xE7\xE3o OAuth e sem token de servi\xE7o configurado.");
  const res = await fetch(API, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: token, "API-Version": opts.versao ?? "2026-10" },
    body: JSON.stringify({ query, variables }),
    signal: opts.signal
  });
  return { status: res.status, json: await res.json().catch(() => null) };
}
async function gql(query, variables = {}, tokenFixo) {
  let wait = 1500;
  for (let attempt = 1; ; attempt++) {
    const { status, json } = await respostaMonday(query, variables, { tokenFixo });
    const err = json?.errors?.[0];
    const msg = err?.message || json?.error_message || (status >= 400 ? `HTTP ${status}` : "");
    const retryable = status === 429 || status >= 500 || /complexity|rate|limit|timeout|temporar/i.test(`${msg} ${err?.extensions?.code ?? ""}`);
    if (!msg && json?.data) return json.data;
    if (retryable && attempt < 6) {
      const s = err?.extensions?.retry_in_seconds;
      await new Promise((r) => setTimeout(r, s ? s * 1e3 + 500 : wait));
      wait = Math.min(wait * 2, 3e4);
      continue;
    }
    throw new Error(`API do monday: ${msg || "resposta vazia"}`.slice(0, 400));
  }
}

// server/communication.ts
var COMM_BOARD_ID = (process.env.COMM_BOARD_ID || "18439727709").trim();
var COMM_COLLECTION = "comm_weeks_v2";
var PROJECT_RE = /^\s*(\d{4}\/\d{3})/;
var at = (iso2) => /* @__PURE__ */ new Date(`${iso2}T12:00:00Z`);
var iso = (d) => d.toISOString().slice(0, 10);
var addDays = (s, n2) => iso(new Date(at(s).getTime() + n2 * 864e5));
var sundayOf = (s) => addDays(s, -at(s).getUTCDay());
var brDate = (s) => s.split("-").reverse().join("/");
var todayBR = () => iso(new Date(Date.now() - 3 * 36e5));
var lastCompleteWeek = () => addDays(sundayOf(todayBR()), -7);
var numOf = (g) => Number((g ?? "").match(/(\d+)/)?.[1] ?? NaN);
async function weekNumberFor(weekStart) {
  const docs = (await (await mongo()).collection("base_week_status").find({}, { projection: { group: 1, weekStart: 1, weekEnd: 1 } }).toArray()).filter((d) => d.weekStart && d.weekEnd && Number.isFinite(numOf(d.group)));
  const mid = addDays(weekStart, 3);
  const hits = docs.filter((d) => d.weekStart <= mid && mid <= d.weekEnd);
  if (hits.length) return { n: Math.max(...hits.map((d) => numOf(d.group))), source: "engajamento" };
  if (!docs.length) throw new Error("A Base do engajamento n\xE3o tem semanas com per\xEDodo definido para numerar a semana.");
  const dist = (d) => Math.abs(at(sundayOf(d.weekStart)).getTime() - at(weekStart).getTime());
  const anchor = docs.sort((a, b) => dist(a) - dist(b) || numOf(b.group) - numOf(a.group))[0];
  const diff = Math.round((at(weekStart).getTime() - at(sundayOf(anchor.weekStart)).getTime()) / (7 * 864e5));
  return { n: numOf(anchor.group) + diff, source: "calculado" };
}
async function projectWorkspaces() {
  const out = [];
  for (let page = 1; page < 50; page++) {
    const r = await gql(
      "query ($p: Int!) { workspaces(limit: 100, page: $p, state: active) { id name users_subscribers(limit: 500) { id } } }",
      { p: page }
    );
    r.workspaces.forEach((w) => {
      const m = w.name.match(PROJECT_RE);
      if (m) out.push({ id: String(w.id), name: w.name.trim(), code: m[1], members: w.users_subscribers?.length ?? 0 });
    });
    if (r.workspaces.length < 100) break;
  }
  return out;
}
async function boardsByWorkspace(wsIds) {
  const map = /* @__PURE__ */ new Map();
  for (let i = 0; i < wsIds.length; i += 10) {
    const chunk = wsIds.slice(i, i + 10);
    for (let page = 1; page < 100; page++) {
      const r = await gql(
        "query ($w: [ID], $p: Int!) { boards(workspace_ids: $w, limit: 100, page: $p, state: active) { id workspace_id columns(types: [subtasks]) { settings_str } } }",
        { w: chunk, p: page }
      );
      r.boards.forEach((b) => {
        const ws = String(b.workspace_id ?? "");
        if (!ws) return;
        const set = map.get(ws) ?? /* @__PURE__ */ new Set();
        set.add(String(b.id));
        b.columns.forEach((c) => {
          try {
            (JSON.parse(c.settings_str || "{}").boardIds ?? []).forEach((id) => set.add(String(id)));
          } catch {
          }
        });
        map.set(ws, set);
      });
      if (r.boards.length < 100) break;
    }
  }
  return new Map([...map].map(([k, v]) => [k, [...v]]));
}
async function updatesByBoard(boardIds, from, to) {
  const out = /* @__PURE__ */ new Map();
  for (let i = 0; i < boardIds.length; i += 25) {
    let pending = boardIds.slice(i, i + 25);
    for (let page = 1; pending.length && page < 200; page++) {
      const r = await gql(
        "query ($b: [ID!], $p: Int!, $f: ISO8601DateTime, $t: ISO8601DateTime) { boards(ids: $b, limit: 100) { id updates(limit: 100, page: $p, from_date: $f, to_date: $t) { id creator_id } } }",
        { b: pending, p: page, f: from, t: to }
      );
      const next = [];
      r.boards.forEach((b) => {
        const m = out.get(String(b.id)) ?? /* @__PURE__ */ new Map();
        b.updates.forEach((u) => m.set(String(u.id), u.creator_id ? String(u.creator_id) : null));
        out.set(String(b.id), m);
        if (b.updates.length === 100) next.push(String(b.id));
      });
      pending = next;
    }
  }
  return new Map([...out].map(([k, m]) => [k, [...m].map(([id, creator_id]) => ({ id, creator_id }))]));
}
async function repliesOf(boardIds, from, to) {
  const seen = /* @__PURE__ */ new Map();
  for (let i = 0; i < boardIds.length; i += 100) {
    const b = boardIds.slice(i, i + 100);
    for (let page = 1; page < 200; page++) {
      const r = await gql(
        "query ($b: [ID!]!, $f: String!, $t: String!, $p: Int!) { replies(board_ids: $b, created_at_from: $f, created_at_to: $t, limit: 100, page: $p) { id creator_id } }",
        { b, f: from, t: to, p: page }
      );
      const before = seen.size;
      r.replies.forEach((x) => seen.set(String(x.id), x.creator_id ? String(x.creator_id) : null));
      if (r.replies.length < 100 || seen.size === before) break;
    }
  }
  return [...seen].map(([id, creator_id]) => ({ id, creator_id }));
}
async function consolidateWeek(weekStartArg) {
  const weekStart = sundayOf(weekStartArg || lastCompleteWeek());
  const weekEnd = addDays(weekStart, 6);
  const { n: n2, source } = await weekNumberFor(weekStart);
  const week = `Semana ${n2}`;
  const from = `${weekStart}T03:00:00Z`;
  const to = `${addDays(weekEnd, 1)}T02:59:59Z`;
  const wss = await projectWorkspaces();
  const boards = await boardsByWorkspace(wss.map((w) => w.id));
  const allBoards = [...new Set([...boards.values()].flat())];
  const ups = await updatesByBoard(allBoards, from, to);
  const computedAt = (/* @__PURE__ */ new Date()).toISOString();
  const rows = [];
  for (const w of wss) {
    const bids = boards.get(w.id) ?? [];
    const u = bids.flatMap((b) => ups.get(b) ?? []);
    const uniq = new Map(u.map((x) => [x.id, x.creator_id]));
    const reps = bids.length ? await repliesOf(bids, from.replace("Z", "+00:00"), to.replace("Z", "+00:00")) : [];
    const authors = new Set([...uniq.values(), ...reps.map((r) => r.creator_id)].filter(Boolean));
    const total = uniq.size + reps.length;
    rows.push({
      _id: `${weekStart}|${w.id}`,
      weekStart,
      weekEnd,
      week,
      weekNumber: n2,
      workspaceId: w.id,
      project: w.name,
      code: w.code,
      updates: uniq.size,
      replies: reps.length,
      total,
      authors: authors.size,
      members: w.members,
      msgsPerMember: w.members ? Math.round(total / w.members * 100) / 100 : 0,
      computedAt
    });
  }
  const col3 = (await mongo()).collection(COMM_COLLECTION);
  await col3.deleteMany({ weekStart });
  if (rows.length) await col3.insertMany(rows);
  await (await mongo()).collection("comm_runs").insertOne({ at: computedAt, week, weekStart });
  const board = COMM_BOARD_ID === "0" ? { created: 0, updated: 0 } : await writeToBoard(rows, week, weekStart, weekEnd);
  return {
    week,
    weekStart,
    weekEnd,
    numberSource: source,
    projects: rows.length,
    updates: rows.reduce((s, r) => s + r.updates, 0),
    replies: rows.reduce((s, r) => s + r.replies, 0),
    board
  };
}
async function writeToBoard(rows, week, weekStart, weekEnd) {
  const title = `${week} \xB7 ${brDate(weekStart)} a ${brDate(weekEnd)}`;
  const g = await gql("query ($b: [ID!]) { boards(ids: $b) { groups { id title } } }", { b: [COMM_BOARD_ID] });
  const groups = g.boards[0]?.groups ?? [];
  let groupId = groups.find((x) => x.title === title || x.title.startsWith(`${week} \xB7`))?.id;
  if (!groupId) {
    const c = await gql("mutation ($b: ID!, $t: String!) { create_group(board_id: $b, group_name: $t, position_relative_method: before_at, relative_to: null) { id } }", { b: COMM_BOARD_ID, t: title }).catch(() => gql("mutation ($b: ID!, $t: String!) { create_group(board_id: $b, group_name: $t) { id } }", { b: COMM_BOARD_ID, t: title }));
    groupId = c.create_group.id;
  } else {
    const cur = groups.find((x) => x.id === groupId);
    if (cur && cur.title !== title) await gql("mutation ($b: ID!, $g: String!, $v: String!) { update_group(board_id: $b, group_id: $g, group_attribute: title, new_value: $v) { id } }", { b: COMM_BOARD_ID, g: groupId, v: title });
  }
  const existing = /* @__PURE__ */ new Map();
  let cursor = null;
  do {
    const r = cursor ? await gql('query ($c: String!) { next_items_page(cursor: $c, limit: 200) { cursor items { id column_values(ids: ["chave"]) { text } } } }', { c: cursor }) : await gql('query ($b: [ID!], $g: [String]) { boards(ids: $b) { groups(ids: $g) { items_page(limit: 200) { cursor items { id column_values(ids: ["chave"]) { text } } } } } }', { b: [COMM_BOARD_ID], g: [groupId] });
    const page = cursor ? r.next_items_page : r.boards[0].groups[0].items_page;
    page.items.forEach((it) => existing.set(it.column_values[0]?.text ?? "", String(it.id)));
    cursor = page.cursor;
  } while (cursor);
  let created = 0, updated = 0;
  for (const r of rows) {
    const vals = JSON.stringify({
      semana: week,
      inicio: { date: r.weekStart },
      updates: r.updates,
      respostas: r.replies,
      total_msgs: r.total,
      autores: r.authors,
      membros: r.members,
      msgs_membro: r.msgsPerMember,
      fonte_equipe: "Assinantes do workspace",
      workspace_id: r.workspaceId,
      chave: r._id
    });
    const id = existing.get(r._id);
    if (id) {
      await gql("mutation ($b: ID!, $i: ID!, $v: JSON!) { change_multiple_column_values(board_id: $b, item_id: $i, column_values: $v) { id } }", { b: COMM_BOARD_ID, i: id, v: vals });
      updated++;
    } else {
      await gql("mutation ($b: ID!, $g: String!, $n: String!, $v: JSON!) { create_item(board_id: $b, group_id: $g, item_name: $n, column_values: $v) { id } }", { b: COMM_BOARD_ID, g: groupId, n: r.project.slice(0, 250), v: vals });
      created++;
    }
  }
  return { created, updated };
}

// server/jobs.ts
var JOBS = {
  weekly: (arg) => consolidateWeek(arg),
  // Agendamento antigo de acessos diários: o % da equipe agora vem da Base do engajamento
  "daily-activity": async () => ({ skipped: true })
};
var running = null;
async function jobState() {
  return (await mongo()).collection("app_jobs").findOne({ _id: "current" });
}
async function startJob(kind, arg) {
  const fn = JOBS[kind];
  if (!fn) throw new Error(`Job desconhecido: ${kind}`);
  const col3 = (await mongo()).collection("app_jobs");
  const cur = await col3.findOne({ _id: "current" });
  if (running || cur?.status === "rodando" && Date.now() - Date.parse(cur.startedAt) < 20 * 6e4) {
    if (cur) return cur;
  }
  const state = { _id: "current", kind, status: "rodando", startedAt: (/* @__PURE__ */ new Date()).toISOString(), ...arg ? { arg } : {} };
  await col3.replaceOne({ _id: "current" }, state, { upsert: true });
  running = (async () => {
    try {
      const result = await fn(arg);
      await col3.updateOne({ _id: "current" }, { $set: { status: "concluido", finishedAt: (/* @__PURE__ */ new Date()).toISOString(), result } });
    } catch (e) {
      const error = e instanceof Error ? e.message : String(e);
      await col3.updateOne({ _id: "current" }, { $set: { status: "erro", finishedAt: (/* @__PURE__ */ new Date()).toISOString(), error } }).catch(() => null);
      console.error(`[job ${kind}]`, error);
    } finally {
      running = null;
    }
  })();
  return state;
}

// src/generated/server/apus.ts
var apus_exports = {};
__export(apus_exports, {
  getApus: () => getApus
});

// server/serverFn.ts
function createServerFn(_opts) {
  let validator = null;
  const b = {
    validator(v) {
      validator = v;
      return b;
    },
    inputValidator(v) {
      validator = v;
      return b;
    },
    middleware(_m) {
      return b;
    },
    handler(h) {
      const run = async (raw) => {
        let data = raw;
        if (validator) data = typeof validator === "function" ? validator(raw) : validator.parse(raw);
        return h({ data });
      };
      const fn = ((opts) => run(opts?.data));
      fn.__serverFn = true;
      fn.run = run;
      return fn;
    }
  };
  return b;
}

// node_modules/zod/v3/external.js
var external_exports = {};
__export(external_exports, {
  BRAND: () => BRAND,
  DIRTY: () => DIRTY,
  EMPTY_PATH: () => EMPTY_PATH,
  INVALID: () => INVALID,
  NEVER: () => NEVER,
  OK: () => OK,
  ParseStatus: () => ParseStatus,
  Schema: () => ZodType,
  ZodAny: () => ZodAny,
  ZodArray: () => ZodArray,
  ZodBigInt: () => ZodBigInt,
  ZodBoolean: () => ZodBoolean,
  ZodBranded: () => ZodBranded,
  ZodCatch: () => ZodCatch,
  ZodDate: () => ZodDate,
  ZodDefault: () => ZodDefault,
  ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
  ZodEffects: () => ZodEffects,
  ZodEnum: () => ZodEnum,
  ZodError: () => ZodError,
  ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
  ZodFunction: () => ZodFunction,
  ZodIntersection: () => ZodIntersection,
  ZodIssueCode: () => ZodIssueCode,
  ZodLazy: () => ZodLazy,
  ZodLiteral: () => ZodLiteral,
  ZodMap: () => ZodMap,
  ZodNaN: () => ZodNaN,
  ZodNativeEnum: () => ZodNativeEnum,
  ZodNever: () => ZodNever,
  ZodNull: () => ZodNull,
  ZodNullable: () => ZodNullable,
  ZodNumber: () => ZodNumber,
  ZodObject: () => ZodObject,
  ZodOptional: () => ZodOptional,
  ZodParsedType: () => ZodParsedType,
  ZodPipeline: () => ZodPipeline,
  ZodPromise: () => ZodPromise,
  ZodReadonly: () => ZodReadonly,
  ZodRecord: () => ZodRecord,
  ZodSchema: () => ZodType,
  ZodSet: () => ZodSet,
  ZodString: () => ZodString,
  ZodSymbol: () => ZodSymbol,
  ZodTransformer: () => ZodEffects,
  ZodTuple: () => ZodTuple,
  ZodType: () => ZodType,
  ZodUndefined: () => ZodUndefined,
  ZodUnion: () => ZodUnion,
  ZodUnknown: () => ZodUnknown,
  ZodVoid: () => ZodVoid,
  addIssueToContext: () => addIssueToContext,
  any: () => anyType,
  array: () => arrayType,
  bigint: () => bigIntType,
  boolean: () => booleanType,
  coerce: () => coerce,
  custom: () => custom,
  date: () => dateType,
  datetimeRegex: () => datetimeRegex,
  defaultErrorMap: () => en_default,
  discriminatedUnion: () => discriminatedUnionType,
  effect: () => effectsType,
  enum: () => enumType,
  function: () => functionType,
  getErrorMap: () => getErrorMap,
  getParsedType: () => getParsedType,
  instanceof: () => instanceOfType,
  intersection: () => intersectionType,
  isAborted: () => isAborted,
  isAsync: () => isAsync,
  isDirty: () => isDirty,
  isValid: () => isValid,
  late: () => late,
  lazy: () => lazyType,
  literal: () => literalType,
  makeIssue: () => makeIssue,
  map: () => mapType,
  nan: () => nanType,
  nativeEnum: () => nativeEnumType,
  never: () => neverType,
  null: () => nullType,
  nullable: () => nullableType,
  number: () => numberType,
  object: () => objectType,
  objectUtil: () => objectUtil,
  oboolean: () => oboolean,
  onumber: () => onumber,
  optional: () => optionalType,
  ostring: () => ostring,
  pipeline: () => pipelineType,
  preprocess: () => preprocessType,
  promise: () => promiseType,
  quotelessJson: () => quotelessJson,
  record: () => recordType,
  set: () => setType,
  setErrorMap: () => setErrorMap,
  strictObject: () => strictObjectType,
  string: () => stringType,
  symbol: () => symbolType,
  transformer: () => effectsType,
  tuple: () => tupleType,
  undefined: () => undefinedType,
  union: () => unionType,
  unknown: () => unknownType,
  util: () => util,
  void: () => voidType
});

// node_modules/zod/v3/helpers/util.js
var util;
(function(util2) {
  util2.assertEqual = (_) => {
  };
  function assertIs(_arg) {
  }
  util2.assertIs = assertIs;
  function assertNever(_x) {
    throw new Error();
  }
  util2.assertNever = assertNever;
  util2.arrayToEnum = (items) => {
    const obj = {};
    for (const item of items) {
      obj[item] = item;
    }
    return obj;
  };
  util2.getValidEnumValues = (obj) => {
    const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
    const filtered = {};
    for (const k of validKeys) {
      filtered[k] = obj[k];
    }
    return util2.objectValues(filtered);
  };
  util2.objectValues = (obj) => {
    return util2.objectKeys(obj).map(function(e) {
      return obj[e];
    });
  };
  util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
    const keys = [];
    for (const key in object) {
      if (Object.prototype.hasOwnProperty.call(object, key)) {
        keys.push(key);
      }
    }
    return keys;
  };
  util2.find = (arr, checker) => {
    for (const item of arr) {
      if (checker(item))
        return item;
    }
    return void 0;
  };
  util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
  function joinValues(array, separator = " | ") {
    return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
  }
  util2.joinValues = joinValues;
  util2.jsonStringifyReplacer = (_, value) => {
    if (typeof value === "bigint") {
      return value.toString();
    }
    return value;
  };
})(util || (util = {}));
var objectUtil;
(function(objectUtil2) {
  objectUtil2.mergeShapes = (first, second) => {
    return {
      ...first,
      ...second
      // second overwrites first
    };
  };
})(objectUtil || (objectUtil = {}));
var ZodParsedType = util.arrayToEnum([
  "string",
  "nan",
  "number",
  "integer",
  "float",
  "boolean",
  "date",
  "bigint",
  "symbol",
  "function",
  "undefined",
  "null",
  "array",
  "object",
  "unknown",
  "promise",
  "void",
  "never",
  "map",
  "set"
]);
var getParsedType = (data) => {
  const t = typeof data;
  switch (t) {
    case "undefined":
      return ZodParsedType.undefined;
    case "string":
      return ZodParsedType.string;
    case "number":
      return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
    case "boolean":
      return ZodParsedType.boolean;
    case "function":
      return ZodParsedType.function;
    case "bigint":
      return ZodParsedType.bigint;
    case "symbol":
      return ZodParsedType.symbol;
    case "object":
      if (Array.isArray(data)) {
        return ZodParsedType.array;
      }
      if (data === null) {
        return ZodParsedType.null;
      }
      if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
        return ZodParsedType.promise;
      }
      if (typeof Map !== "undefined" && data instanceof Map) {
        return ZodParsedType.map;
      }
      if (typeof Set !== "undefined" && data instanceof Set) {
        return ZodParsedType.set;
      }
      if (typeof Date !== "undefined" && data instanceof Date) {
        return ZodParsedType.date;
      }
      return ZodParsedType.object;
    default:
      return ZodParsedType.unknown;
  }
};

// node_modules/zod/v3/ZodError.js
var ZodIssueCode = util.arrayToEnum([
  "invalid_type",
  "invalid_literal",
  "custom",
  "invalid_union",
  "invalid_union_discriminator",
  "invalid_enum_value",
  "unrecognized_keys",
  "invalid_arguments",
  "invalid_return_type",
  "invalid_date",
  "invalid_string",
  "too_small",
  "too_big",
  "invalid_intersection_types",
  "not_multiple_of",
  "not_finite"
]);
var quotelessJson = (obj) => {
  const json = JSON.stringify(obj, null, 2);
  return json.replace(/"([^"]+)":/g, "$1:");
};
var ZodError = class _ZodError extends Error {
  get errors() {
    return this.issues;
  }
  constructor(issues) {
    super();
    this.issues = [];
    this.addIssue = (sub) => {
      this.issues = [...this.issues, sub];
    };
    this.addIssues = (subs = []) => {
      this.issues = [...this.issues, ...subs];
    };
    const actualProto = new.target.prototype;
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(this, actualProto);
    } else {
      this.__proto__ = actualProto;
    }
    this.name = "ZodError";
    this.issues = issues;
  }
  format(_mapper) {
    const mapper = _mapper || function(issue) {
      return issue.message;
    };
    const fieldErrors = { _errors: [] };
    const processError = (error) => {
      for (const issue of error.issues) {
        if (issue.code === "invalid_union") {
          issue.unionErrors.map(processError);
        } else if (issue.code === "invalid_return_type") {
          processError(issue.returnTypeError);
        } else if (issue.code === "invalid_arguments") {
          processError(issue.argumentsError);
        } else if (issue.path.length === 0) {
          fieldErrors._errors.push(mapper(issue));
        } else {
          let curr = fieldErrors;
          let i = 0;
          while (i < issue.path.length) {
            const el = issue.path[i];
            const terminal = i === issue.path.length - 1;
            if (!terminal) {
              curr[el] = curr[el] || { _errors: [] };
            } else {
              curr[el] = curr[el] || { _errors: [] };
              curr[el]._errors.push(mapper(issue));
            }
            curr = curr[el];
            i++;
          }
        }
      }
    };
    processError(this);
    return fieldErrors;
  }
  static assert(value) {
    if (!(value instanceof _ZodError)) {
      throw new Error(`Not a ZodError: ${value}`);
    }
  }
  toString() {
    return this.message;
  }
  get message() {
    return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
  }
  get isEmpty() {
    return this.issues.length === 0;
  }
  flatten(mapper = (issue) => issue.message) {
    const fieldErrors = {};
    const formErrors = [];
    for (const sub of this.issues) {
      if (sub.path.length > 0) {
        const firstEl = sub.path[0];
        fieldErrors[firstEl] = fieldErrors[firstEl] || [];
        fieldErrors[firstEl].push(mapper(sub));
      } else {
        formErrors.push(mapper(sub));
      }
    }
    return { formErrors, fieldErrors };
  }
  get formErrors() {
    return this.flatten();
  }
};
ZodError.create = (issues) => {
  const error = new ZodError(issues);
  return error;
};

// node_modules/zod/v3/locales/en.js
var errorMap = (issue, _ctx) => {
  let message;
  switch (issue.code) {
    case ZodIssueCode.invalid_type:
      if (issue.received === ZodParsedType.undefined) {
        message = "Required";
      } else {
        message = `Expected ${issue.expected}, received ${issue.received}`;
      }
      break;
    case ZodIssueCode.invalid_literal:
      message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
      break;
    case ZodIssueCode.unrecognized_keys:
      message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
      break;
    case ZodIssueCode.invalid_union:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_union_discriminator:
      message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
      break;
    case ZodIssueCode.invalid_enum_value:
      message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
      break;
    case ZodIssueCode.invalid_arguments:
      message = `Invalid function arguments`;
      break;
    case ZodIssueCode.invalid_return_type:
      message = `Invalid function return type`;
      break;
    case ZodIssueCode.invalid_date:
      message = `Invalid date`;
      break;
    case ZodIssueCode.invalid_string:
      if (typeof issue.validation === "object") {
        if ("includes" in issue.validation) {
          message = `Invalid input: must include "${issue.validation.includes}"`;
          if (typeof issue.validation.position === "number") {
            message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
          }
        } else if ("startsWith" in issue.validation) {
          message = `Invalid input: must start with "${issue.validation.startsWith}"`;
        } else if ("endsWith" in issue.validation) {
          message = `Invalid input: must end with "${issue.validation.endsWith}"`;
        } else {
          util.assertNever(issue.validation);
        }
      } else if (issue.validation !== "regex") {
        message = `Invalid ${issue.validation}`;
      } else {
        message = "Invalid";
      }
      break;
    case ZodIssueCode.too_small:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "bigint")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.too_big:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "bigint")
        message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.custom:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_intersection_types:
      message = `Intersection results could not be merged`;
      break;
    case ZodIssueCode.not_multiple_of:
      message = `Number must be a multiple of ${issue.multipleOf}`;
      break;
    case ZodIssueCode.not_finite:
      message = "Number must be finite";
      break;
    default:
      message = _ctx.defaultError;
      util.assertNever(issue);
  }
  return { message };
};
var en_default = errorMap;

// node_modules/zod/v3/errors.js
var overrideErrorMap = en_default;
function setErrorMap(map) {
  overrideErrorMap = map;
}
function getErrorMap() {
  return overrideErrorMap;
}

// node_modules/zod/v3/helpers/parseUtil.js
var makeIssue = (params) => {
  const { data, path: path2, errorMaps, issueData } = params;
  const fullPath = [...path2, ...issueData.path || []];
  const fullIssue = {
    ...issueData,
    path: fullPath
  };
  if (issueData.message !== void 0) {
    return {
      ...issueData,
      path: fullPath,
      message: issueData.message
    };
  }
  let errorMessage = "";
  const maps = errorMaps.filter((m) => !!m).slice().reverse();
  for (const map of maps) {
    errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
  }
  return {
    ...issueData,
    path: fullPath,
    message: errorMessage
  };
};
var EMPTY_PATH = [];
function addIssueToContext(ctx, issueData) {
  const overrideMap = getErrorMap();
  const issue = makeIssue({
    issueData,
    data: ctx.data,
    path: ctx.path,
    errorMaps: [
      ctx.common.contextualErrorMap,
      // contextual error map is first priority
      ctx.schemaErrorMap,
      // then schema-bound map if available
      overrideMap,
      // then global override map
      overrideMap === en_default ? void 0 : en_default
      // then global default map
    ].filter((x) => !!x)
  });
  ctx.common.issues.push(issue);
}
var ParseStatus = class _ParseStatus {
  constructor() {
    this.value = "valid";
  }
  dirty() {
    if (this.value === "valid")
      this.value = "dirty";
  }
  abort() {
    if (this.value !== "aborted")
      this.value = "aborted";
  }
  static mergeArray(status, results) {
    const arrayValue = [];
    for (const s of results) {
      if (s.status === "aborted")
        return INVALID;
      if (s.status === "dirty")
        status.dirty();
      arrayValue.push(s.value);
    }
    return { status: status.value, value: arrayValue };
  }
  static async mergeObjectAsync(status, pairs) {
    const syncPairs = [];
    for (const pair of pairs) {
      const key = await pair.key;
      const value = await pair.value;
      syncPairs.push({
        key,
        value
      });
    }
    return _ParseStatus.mergeObjectSync(status, syncPairs);
  }
  static mergeObjectSync(status, pairs) {
    const finalObject = {};
    for (const pair of pairs) {
      const { key, value } = pair;
      if (key.status === "aborted")
        return INVALID;
      if (value.status === "aborted")
        return INVALID;
      if (key.status === "dirty")
        status.dirty();
      if (value.status === "dirty")
        status.dirty();
      if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
        finalObject[key.value] = value.value;
      }
    }
    return { status: status.value, value: finalObject };
  }
};
var INVALID = Object.freeze({
  status: "aborted"
});
var DIRTY = (value) => ({ status: "dirty", value });
var OK = (value) => ({ status: "valid", value });
var isAborted = (x) => x.status === "aborted";
var isDirty = (x) => x.status === "dirty";
var isValid = (x) => x.status === "valid";
var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

// node_modules/zod/v3/helpers/errorUtil.js
var errorUtil;
(function(errorUtil2) {
  errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
  errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
})(errorUtil || (errorUtil = {}));

// node_modules/zod/v3/types.js
var ParseInputLazyPath = class {
  constructor(parent, value, path2, key) {
    this._cachedPath = [];
    this.parent = parent;
    this.data = value;
    this._path = path2;
    this._key = key;
  }
  get path() {
    if (!this._cachedPath.length) {
      if (Array.isArray(this._key)) {
        this._cachedPath.push(...this._path, ...this._key);
      } else {
        this._cachedPath.push(...this._path, this._key);
      }
    }
    return this._cachedPath;
  }
};
var handleResult = (ctx, result) => {
  if (isValid(result)) {
    return { success: true, data: result.value };
  } else {
    if (!ctx.common.issues.length) {
      throw new Error("Validation failed but no issues detected.");
    }
    return {
      success: false,
      get error() {
        if (this._error)
          return this._error;
        const error = new ZodError(ctx.common.issues);
        this._error = error;
        return this._error;
      }
    };
  }
};
function processCreateParams(params) {
  if (!params)
    return {};
  const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
  if (errorMap2 && (invalid_type_error || required_error)) {
    throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
  }
  if (errorMap2)
    return { errorMap: errorMap2, description };
  const customMap = (iss, ctx) => {
    const { message } = params;
    if (iss.code === "invalid_enum_value") {
      return { message: message ?? ctx.defaultError };
    }
    if (typeof ctx.data === "undefined") {
      return { message: message ?? required_error ?? ctx.defaultError };
    }
    if (iss.code !== "invalid_type")
      return { message: ctx.defaultError };
    return { message: message ?? invalid_type_error ?? ctx.defaultError };
  };
  return { errorMap: customMap, description };
}
var ZodType = class {
  get description() {
    return this._def.description;
  }
  _getType(input) {
    return getParsedType(input.data);
  }
  _getOrReturnCtx(input, ctx) {
    return ctx || {
      common: input.parent.common,
      data: input.data,
      parsedType: getParsedType(input.data),
      schemaErrorMap: this._def.errorMap,
      path: input.path,
      parent: input.parent
    };
  }
  _processInputParams(input) {
    return {
      status: new ParseStatus(),
      ctx: {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      }
    };
  }
  _parseSync(input) {
    const result = this._parse(input);
    if (isAsync(result)) {
      throw new Error("Synchronous parse encountered promise.");
    }
    return result;
  }
  _parseAsync(input) {
    const result = this._parse(input);
    return Promise.resolve(result);
  }
  parse(data, params) {
    const result = this.safeParse(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  safeParse(data, params) {
    const ctx = {
      common: {
        issues: [],
        async: params?.async ?? false,
        contextualErrorMap: params?.errorMap
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const result = this._parseSync({ data, path: ctx.path, parent: ctx });
    return handleResult(ctx, result);
  }
  "~validate"(data) {
    const ctx = {
      common: {
        issues: [],
        async: !!this["~standard"].async
      },
      path: [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    if (!this["~standard"].async) {
      try {
        const result = this._parseSync({ data, path: [], parent: ctx });
        return isValid(result) ? {
          value: result.value
        } : {
          issues: ctx.common.issues
        };
      } catch (err) {
        if (err?.message?.toLowerCase()?.includes("encountered")) {
          this["~standard"].async = true;
        }
        ctx.common = {
          issues: [],
          async: true
        };
      }
    }
    return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
      value: result.value
    } : {
      issues: ctx.common.issues
    });
  }
  async parseAsync(data, params) {
    const result = await this.safeParseAsync(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  async safeParseAsync(data, params) {
    const ctx = {
      common: {
        issues: [],
        contextualErrorMap: params?.errorMap,
        async: true
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
    const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
    return handleResult(ctx, result);
  }
  refine(check, message) {
    const getIssueProperties = (val) => {
      if (typeof message === "string" || typeof message === "undefined") {
        return { message };
      } else if (typeof message === "function") {
        return message(val);
      } else {
        return message;
      }
    };
    return this._refinement((val, ctx) => {
      const result = check(val);
      const setError = () => ctx.addIssue({
        code: ZodIssueCode.custom,
        ...getIssueProperties(val)
      });
      if (typeof Promise !== "undefined" && result instanceof Promise) {
        return result.then((data) => {
          if (!data) {
            setError();
            return false;
          } else {
            return true;
          }
        });
      }
      if (!result) {
        setError();
        return false;
      } else {
        return true;
      }
    });
  }
  refinement(check, refinementData) {
    return this._refinement((val, ctx) => {
      if (!check(val)) {
        ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
        return false;
      } else {
        return true;
      }
    });
  }
  _refinement(refinement) {
    return new ZodEffects({
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "refinement", refinement }
    });
  }
  superRefine(refinement) {
    return this._refinement(refinement);
  }
  constructor(def) {
    this.spa = this.safeParseAsync;
    this._def = def;
    this.parse = this.parse.bind(this);
    this.safeParse = this.safeParse.bind(this);
    this.parseAsync = this.parseAsync.bind(this);
    this.safeParseAsync = this.safeParseAsync.bind(this);
    this.spa = this.spa.bind(this);
    this.refine = this.refine.bind(this);
    this.refinement = this.refinement.bind(this);
    this.superRefine = this.superRefine.bind(this);
    this.optional = this.optional.bind(this);
    this.nullable = this.nullable.bind(this);
    this.nullish = this.nullish.bind(this);
    this.array = this.array.bind(this);
    this.promise = this.promise.bind(this);
    this.or = this.or.bind(this);
    this.and = this.and.bind(this);
    this.transform = this.transform.bind(this);
    this.brand = this.brand.bind(this);
    this.default = this.default.bind(this);
    this.catch = this.catch.bind(this);
    this.describe = this.describe.bind(this);
    this.pipe = this.pipe.bind(this);
    this.readonly = this.readonly.bind(this);
    this.isNullable = this.isNullable.bind(this);
    this.isOptional = this.isOptional.bind(this);
    this["~standard"] = {
      version: 1,
      vendor: "zod",
      validate: (data) => this["~validate"](data)
    };
  }
  optional() {
    return ZodOptional.create(this, this._def);
  }
  nullable() {
    return ZodNullable.create(this, this._def);
  }
  nullish() {
    return this.nullable().optional();
  }
  array() {
    return ZodArray.create(this);
  }
  promise() {
    return ZodPromise.create(this, this._def);
  }
  or(option) {
    return ZodUnion.create([this, option], this._def);
  }
  and(incoming) {
    return ZodIntersection.create(this, incoming, this._def);
  }
  transform(transform) {
    return new ZodEffects({
      ...processCreateParams(this._def),
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "transform", transform }
    });
  }
  default(def) {
    const defaultValueFunc = typeof def === "function" ? def : () => def;
    return new ZodDefault({
      ...processCreateParams(this._def),
      innerType: this,
      defaultValue: defaultValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodDefault
    });
  }
  brand() {
    return new ZodBranded({
      typeName: ZodFirstPartyTypeKind.ZodBranded,
      type: this,
      ...processCreateParams(this._def)
    });
  }
  catch(def) {
    const catchValueFunc = typeof def === "function" ? def : () => def;
    return new ZodCatch({
      ...processCreateParams(this._def),
      innerType: this,
      catchValue: catchValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodCatch
    });
  }
  describe(description) {
    const This = this.constructor;
    return new This({
      ...this._def,
      description
    });
  }
  pipe(target) {
    return ZodPipeline.create(this, target);
  }
  readonly() {
    return ZodReadonly.create(this);
  }
  isOptional() {
    return this.safeParse(void 0).success;
  }
  isNullable() {
    return this.safeParse(null).success;
  }
};
var cuidRegex = /^c[^\s-]{8,}$/i;
var cuid2Regex = /^[0-9a-z]+$/;
var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
var nanoidRegex = /^[a-z0-9_-]{21}$/i;
var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
var emojiRegex;
var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
var dateRegex = new RegExp(`^${dateRegexSource}$`);
function timeRegexSource(args) {
  let secondsRegexSource = `[0-5]\\d`;
  if (args.precision) {
    secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
  } else if (args.precision == null) {
    secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
  }
  const secondsQuantifier = args.precision ? "+" : "?";
  return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
}
function timeRegex(args) {
  return new RegExp(`^${timeRegexSource(args)}$`);
}
function datetimeRegex(args) {
  let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
  const opts = [];
  opts.push(args.local ? `Z?` : `Z`);
  if (args.offset)
    opts.push(`([+-]\\d{2}:?\\d{2})`);
  regex = `${regex}(${opts.join("|")})`;
  return new RegExp(`^${regex}$`);
}
function isValidIP(ip, version) {
  if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
    return true;
  }
  return false;
}
function isValidJWT(jwt, alg) {
  if (!jwtRegex.test(jwt))
    return false;
  try {
    const [header] = jwt.split(".");
    if (!header)
      return false;
    const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
    const decoded = JSON.parse(atob(base64));
    if (typeof decoded !== "object" || decoded === null)
      return false;
    if ("typ" in decoded && decoded?.typ !== "JWT")
      return false;
    if (!decoded.alg)
      return false;
    if (alg && decoded.alg !== alg)
      return false;
    return true;
  } catch {
    return false;
  }
}
function isValidCidr(ip, version) {
  if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
    return true;
  }
  return false;
}
var ZodString = class _ZodString extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = String(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.string) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.string,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.length < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.length > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "length") {
        const tooBig = input.data.length > check.value;
        const tooSmall = input.data.length < check.value;
        if (tooBig || tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          if (tooBig) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          } else if (tooSmall) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          }
          status.dirty();
        }
      } else if (check.kind === "email") {
        if (!emailRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "email",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "emoji") {
        if (!emojiRegex) {
          emojiRegex = new RegExp(_emojiRegex, "u");
        }
        if (!emojiRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "emoji",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "uuid") {
        if (!uuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "uuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "nanoid") {
        if (!nanoidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "nanoid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid") {
        if (!cuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid2") {
        if (!cuid2Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid2",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ulid") {
        if (!ulidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ulid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "url") {
        try {
          new URL(input.data);
        } catch {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "regex") {
        check.regex.lastIndex = 0;
        const testResult = check.regex.test(input.data);
        if (!testResult) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "regex",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "trim") {
        input.data = input.data.trim();
      } else if (check.kind === "includes") {
        if (!input.data.includes(check.value, check.position)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { includes: check.value, position: check.position },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "toLowerCase") {
        input.data = input.data.toLowerCase();
      } else if (check.kind === "toUpperCase") {
        input.data = input.data.toUpperCase();
      } else if (check.kind === "startsWith") {
        if (!input.data.startsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { startsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "endsWith") {
        if (!input.data.endsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { endsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "datetime") {
        const regex = datetimeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "datetime",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "date") {
        const regex = dateRegex;
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "date",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "time") {
        const regex = timeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "time",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "duration") {
        if (!durationRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "duration",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ip") {
        if (!isValidIP(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ip",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "jwt") {
        if (!isValidJWT(input.data, check.alg)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "jwt",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cidr") {
        if (!isValidCidr(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cidr",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64") {
        if (!base64Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64url") {
        if (!base64urlRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _regex(regex, validation, message) {
    return this.refinement((data) => regex.test(data), {
      validation,
      code: ZodIssueCode.invalid_string,
      ...errorUtil.errToObj(message)
    });
  }
  _addCheck(check) {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  email(message) {
    return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
  }
  url(message) {
    return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
  }
  emoji(message) {
    return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
  }
  uuid(message) {
    return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
  }
  nanoid(message) {
    return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
  }
  cuid(message) {
    return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
  }
  cuid2(message) {
    return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
  }
  ulid(message) {
    return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
  }
  base64(message) {
    return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
  }
  base64url(message) {
    return this._addCheck({
      kind: "base64url",
      ...errorUtil.errToObj(message)
    });
  }
  jwt(options) {
    return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
  }
  ip(options) {
    return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
  }
  cidr(options) {
    return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
  }
  datetime(options) {
    if (typeof options === "string") {
      return this._addCheck({
        kind: "datetime",
        precision: null,
        offset: false,
        local: false,
        message: options
      });
    }
    return this._addCheck({
      kind: "datetime",
      precision: typeof options?.precision === "undefined" ? null : options?.precision,
      offset: options?.offset ?? false,
      local: options?.local ?? false,
      ...errorUtil.errToObj(options?.message)
    });
  }
  date(message) {
    return this._addCheck({ kind: "date", message });
  }
  time(options) {
    if (typeof options === "string") {
      return this._addCheck({
        kind: "time",
        precision: null,
        message: options
      });
    }
    return this._addCheck({
      kind: "time",
      precision: typeof options?.precision === "undefined" ? null : options?.precision,
      ...errorUtil.errToObj(options?.message)
    });
  }
  duration(message) {
    return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
  }
  regex(regex, message) {
    return this._addCheck({
      kind: "regex",
      regex,
      ...errorUtil.errToObj(message)
    });
  }
  includes(value, options) {
    return this._addCheck({
      kind: "includes",
      value,
      position: options?.position,
      ...errorUtil.errToObj(options?.message)
    });
  }
  startsWith(value, message) {
    return this._addCheck({
      kind: "startsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  endsWith(value, message) {
    return this._addCheck({
      kind: "endsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  min(minLength, message) {
    return this._addCheck({
      kind: "min",
      value: minLength,
      ...errorUtil.errToObj(message)
    });
  }
  max(maxLength, message) {
    return this._addCheck({
      kind: "max",
      value: maxLength,
      ...errorUtil.errToObj(message)
    });
  }
  length(len, message) {
    return this._addCheck({
      kind: "length",
      value: len,
      ...errorUtil.errToObj(message)
    });
  }
  /**
   * Equivalent to `.min(1)`
   */
  nonempty(message) {
    return this.min(1, errorUtil.errToObj(message));
  }
  trim() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "trim" }]
    });
  }
  toLowerCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toLowerCase" }]
    });
  }
  toUpperCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toUpperCase" }]
    });
  }
  get isDatetime() {
    return !!this._def.checks.find((ch) => ch.kind === "datetime");
  }
  get isDate() {
    return !!this._def.checks.find((ch) => ch.kind === "date");
  }
  get isTime() {
    return !!this._def.checks.find((ch) => ch.kind === "time");
  }
  get isDuration() {
    return !!this._def.checks.find((ch) => ch.kind === "duration");
  }
  get isEmail() {
    return !!this._def.checks.find((ch) => ch.kind === "email");
  }
  get isURL() {
    return !!this._def.checks.find((ch) => ch.kind === "url");
  }
  get isEmoji() {
    return !!this._def.checks.find((ch) => ch.kind === "emoji");
  }
  get isUUID() {
    return !!this._def.checks.find((ch) => ch.kind === "uuid");
  }
  get isNANOID() {
    return !!this._def.checks.find((ch) => ch.kind === "nanoid");
  }
  get isCUID() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid");
  }
  get isCUID2() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid2");
  }
  get isULID() {
    return !!this._def.checks.find((ch) => ch.kind === "ulid");
  }
  get isIP() {
    return !!this._def.checks.find((ch) => ch.kind === "ip");
  }
  get isCIDR() {
    return !!this._def.checks.find((ch) => ch.kind === "cidr");
  }
  get isBase64() {
    return !!this._def.checks.find((ch) => ch.kind === "base64");
  }
  get isBase64url() {
    return !!this._def.checks.find((ch) => ch.kind === "base64url");
  }
  get minLength() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxLength() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodString.create = (params) => {
  return new ZodString({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodString,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
function floatSafeRemainder(val, step) {
  const valDecCount = (val.toString().split(".")[1] || "").length;
  const stepDecCount = (step.toString().split(".")[1] || "").length;
  const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
  const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
  const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
  return valInt % stepInt / 10 ** decCount;
}
var ZodNumber = class _ZodNumber extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
    this.step = this.multipleOf;
  }
  _parse(input) {
    if (this._def.coerce) {
      input.data = Number(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.number) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.number,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "int") {
        if (!util.isInteger(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: "integer",
            received: "float",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (floatSafeRemainder(input.data, check.value) !== 0) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "finite") {
        if (!Number.isFinite(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_finite,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodNumber({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodNumber({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  int(message) {
    return this._addCheck({
      kind: "int",
      message: errorUtil.toString(message)
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  finite(message) {
    return this._addCheck({
      kind: "finite",
      message: errorUtil.toString(message)
    });
  }
  safe(message) {
    return this._addCheck({
      kind: "min",
      inclusive: true,
      value: Number.MIN_SAFE_INTEGER,
      message: errorUtil.toString(message)
    })._addCheck({
      kind: "max",
      inclusive: true,
      value: Number.MAX_SAFE_INTEGER,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
  get isInt() {
    return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
  }
  get isFinite() {
    let max = null;
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
        return true;
      } else if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      } else if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return Number.isFinite(min) && Number.isFinite(max);
  }
};
ZodNumber.create = (params) => {
  return new ZodNumber({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodNumber,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodBigInt = class _ZodBigInt extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
  }
  _parse(input) {
    if (this._def.coerce) {
      try {
        input.data = BigInt(input.data);
      } catch {
        return this._getInvalidInput(input);
      }
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.bigint) {
      return this._getInvalidInput(input);
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            type: "bigint",
            minimum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            type: "bigint",
            maximum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (input.data % check.value !== BigInt(0)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _getInvalidInput(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.bigint,
      received: ctx.parsedType
    });
    return INVALID;
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodBigInt({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodBigInt({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodBigInt.create = (params) => {
  return new ZodBigInt({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodBigInt,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
var ZodBoolean = class extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = Boolean(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.boolean) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.boolean,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodBoolean.create = (params) => {
  return new ZodBoolean({
    typeName: ZodFirstPartyTypeKind.ZodBoolean,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodDate = class _ZodDate extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = new Date(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.date) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.date,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    if (Number.isNaN(input.data.getTime())) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_date
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.getTime() < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            message: check.message,
            inclusive: true,
            exact: false,
            minimum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.getTime() > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            message: check.message,
            inclusive: true,
            exact: false,
            maximum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return {
      status: status.value,
      value: new Date(input.data.getTime())
    };
  }
  _addCheck(check) {
    return new _ZodDate({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  min(minDate, message) {
    return this._addCheck({
      kind: "min",
      value: minDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  max(maxDate, message) {
    return this._addCheck({
      kind: "max",
      value: maxDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  get minDate() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min != null ? new Date(min) : null;
  }
  get maxDate() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max != null ? new Date(max) : null;
  }
};
ZodDate.create = (params) => {
  return new ZodDate({
    checks: [],
    coerce: params?.coerce || false,
    typeName: ZodFirstPartyTypeKind.ZodDate,
    ...processCreateParams(params)
  });
};
var ZodSymbol = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.symbol) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.symbol,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodSymbol.create = (params) => {
  return new ZodSymbol({
    typeName: ZodFirstPartyTypeKind.ZodSymbol,
    ...processCreateParams(params)
  });
};
var ZodUndefined = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.undefined,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodUndefined.create = (params) => {
  return new ZodUndefined({
    typeName: ZodFirstPartyTypeKind.ZodUndefined,
    ...processCreateParams(params)
  });
};
var ZodNull = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.null) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.null,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodNull.create = (params) => {
  return new ZodNull({
    typeName: ZodFirstPartyTypeKind.ZodNull,
    ...processCreateParams(params)
  });
};
var ZodAny = class extends ZodType {
  constructor() {
    super(...arguments);
    this._any = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodAny.create = (params) => {
  return new ZodAny({
    typeName: ZodFirstPartyTypeKind.ZodAny,
    ...processCreateParams(params)
  });
};
var ZodUnknown = class extends ZodType {
  constructor() {
    super(...arguments);
    this._unknown = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodUnknown.create = (params) => {
  return new ZodUnknown({
    typeName: ZodFirstPartyTypeKind.ZodUnknown,
    ...processCreateParams(params)
  });
};
var ZodNever = class extends ZodType {
  _parse(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.never,
      received: ctx.parsedType
    });
    return INVALID;
  }
};
ZodNever.create = (params) => {
  return new ZodNever({
    typeName: ZodFirstPartyTypeKind.ZodNever,
    ...processCreateParams(params)
  });
};
var ZodVoid = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.void,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodVoid.create = (params) => {
  return new ZodVoid({
    typeName: ZodFirstPartyTypeKind.ZodVoid,
    ...processCreateParams(params)
  });
};
var ZodArray = class _ZodArray extends ZodType {
  _parse(input) {
    const { ctx, status } = this._processInputParams(input);
    const def = this._def;
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (def.exactLength !== null) {
      const tooBig = ctx.data.length > def.exactLength.value;
      const tooSmall = ctx.data.length < def.exactLength.value;
      if (tooBig || tooSmall) {
        addIssueToContext(ctx, {
          code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
          minimum: tooSmall ? def.exactLength.value : void 0,
          maximum: tooBig ? def.exactLength.value : void 0,
          type: "array",
          inclusive: true,
          exact: true,
          message: def.exactLength.message
        });
        status.dirty();
      }
    }
    if (def.minLength !== null) {
      if (ctx.data.length < def.minLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.minLength.message
        });
        status.dirty();
      }
    }
    if (def.maxLength !== null) {
      if (ctx.data.length > def.maxLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.maxLength.message
        });
        status.dirty();
      }
    }
    if (ctx.common.async) {
      return Promise.all([...ctx.data].map((item, i) => {
        return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      })).then((result2) => {
        return ParseStatus.mergeArray(status, result2);
      });
    }
    const result = [...ctx.data].map((item, i) => {
      return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
    });
    return ParseStatus.mergeArray(status, result);
  }
  get element() {
    return this._def.type;
  }
  min(minLength, message) {
    return new _ZodArray({
      ...this._def,
      minLength: { value: minLength, message: errorUtil.toString(message) }
    });
  }
  max(maxLength, message) {
    return new _ZodArray({
      ...this._def,
      maxLength: { value: maxLength, message: errorUtil.toString(message) }
    });
  }
  length(len, message) {
    return new _ZodArray({
      ...this._def,
      exactLength: { value: len, message: errorUtil.toString(message) }
    });
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodArray.create = (schema, params) => {
  return new ZodArray({
    type: schema,
    minLength: null,
    maxLength: null,
    exactLength: null,
    typeName: ZodFirstPartyTypeKind.ZodArray,
    ...processCreateParams(params)
  });
};
function deepPartialify(schema) {
  if (schema instanceof ZodObject) {
    const newShape = {};
    for (const key in schema.shape) {
      const fieldSchema = schema.shape[key];
      newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
    }
    return new ZodObject({
      ...schema._def,
      shape: () => newShape
    });
  } else if (schema instanceof ZodArray) {
    return new ZodArray({
      ...schema._def,
      type: deepPartialify(schema.element)
    });
  } else if (schema instanceof ZodOptional) {
    return ZodOptional.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodNullable) {
    return ZodNullable.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodTuple) {
    return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
  } else {
    return schema;
  }
}
var ZodObject = class _ZodObject extends ZodType {
  constructor() {
    super(...arguments);
    this._cached = null;
    this.nonstrict = this.passthrough;
    this.augment = this.extend;
  }
  _getCached() {
    if (this._cached !== null)
      return this._cached;
    const shape = this._def.shape();
    const keys = util.objectKeys(shape);
    this._cached = { shape, keys };
    return this._cached;
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.object) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const { status, ctx } = this._processInputParams(input);
    const { shape, keys: shapeKeys } = this._getCached();
    const extraKeys = [];
    if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
      for (const key in ctx.data) {
        if (!shapeKeys.includes(key)) {
          extraKeys.push(key);
        }
      }
    }
    const pairs = [];
    for (const key of shapeKeys) {
      const keyValidator = shape[key];
      const value = ctx.data[key];
      pairs.push({
        key: { status: "valid", value: key },
        value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (this._def.catchall instanceof ZodNever) {
      const unknownKeys = this._def.unknownKeys;
      if (unknownKeys === "passthrough") {
        for (const key of extraKeys) {
          pairs.push({
            key: { status: "valid", value: key },
            value: { status: "valid", value: ctx.data[key] }
          });
        }
      } else if (unknownKeys === "strict") {
        if (extraKeys.length > 0) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.unrecognized_keys,
            keys: extraKeys
          });
          status.dirty();
        }
      } else if (unknownKeys === "strip") {
      } else {
        throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
      }
    } else {
      const catchall = this._def.catchall;
      for (const key of extraKeys) {
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: catchall._parse(
            new ParseInputLazyPath(ctx, value, ctx.path, key)
            //, ctx.child(key), value, getParsedType(value)
          ),
          alwaysSet: key in ctx.data
        });
      }
    }
    if (ctx.common.async) {
      return Promise.resolve().then(async () => {
        const syncPairs = [];
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          syncPairs.push({
            key,
            value,
            alwaysSet: pair.alwaysSet
          });
        }
        return syncPairs;
      }).then((syncPairs) => {
        return ParseStatus.mergeObjectSync(status, syncPairs);
      });
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get shape() {
    return this._def.shape();
  }
  strict(message) {
    errorUtil.errToObj;
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strict",
      ...message !== void 0 ? {
        errorMap: (issue, ctx) => {
          const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
          if (issue.code === "unrecognized_keys")
            return {
              message: errorUtil.errToObj(message).message ?? defaultError
            };
          return {
            message: defaultError
          };
        }
      } : {}
    });
  }
  strip() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strip"
    });
  }
  passthrough() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "passthrough"
    });
  }
  // const AugmentFactory =
  //   <Def extends ZodObjectDef>(def: Def) =>
  //   <Augmentation extends ZodRawShape>(
  //     augmentation: Augmentation
  //   ): ZodObject<
  //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
  //     Def["unknownKeys"],
  //     Def["catchall"]
  //   > => {
  //     return new ZodObject({
  //       ...def,
  //       shape: () => ({
  //         ...def.shape(),
  //         ...augmentation,
  //       }),
  //     }) as any;
  //   };
  extend(augmentation) {
    return new _ZodObject({
      ...this._def,
      shape: () => ({
        ...this._def.shape(),
        ...augmentation
      })
    });
  }
  /**
   * Prior to zod@1.0.12 there was a bug in the
   * inferred type of merged objects. Please
   * upgrade if you are experiencing issues.
   */
  merge(merging) {
    const merged = new _ZodObject({
      unknownKeys: merging._def.unknownKeys,
      catchall: merging._def.catchall,
      shape: () => ({
        ...this._def.shape(),
        ...merging._def.shape()
      }),
      typeName: ZodFirstPartyTypeKind.ZodObject
    });
    return merged;
  }
  // merge<
  //   Incoming extends AnyZodObject,
  //   Augmentation extends Incoming["shape"],
  //   NewOutput extends {
  //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
  //       ? Augmentation[k]["_output"]
  //       : k extends keyof Output
  //       ? Output[k]
  //       : never;
  //   },
  //   NewInput extends {
  //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
  //       ? Augmentation[k]["_input"]
  //       : k extends keyof Input
  //       ? Input[k]
  //       : never;
  //   }
  // >(
  //   merging: Incoming
  // ): ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"],
  //   NewOutput,
  //   NewInput
  // > {
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  setKey(key, schema) {
    return this.augment({ [key]: schema });
  }
  // merge<Incoming extends AnyZodObject>(
  //   merging: Incoming
  // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
  // ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"]
  // > {
  //   // const mergedShape = objectUtil.mergeShapes(
  //   //   this._def.shape(),
  //   //   merging._def.shape()
  //   // );
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  catchall(index) {
    return new _ZodObject({
      ...this._def,
      catchall: index
    });
  }
  pick(mask) {
    const shape = {};
    for (const key of util.objectKeys(mask)) {
      if (mask[key] && this.shape[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  omit(mask) {
    const shape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (!mask[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  /**
   * @deprecated
   */
  deepPartial() {
    return deepPartialify(this);
  }
  partial(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      const fieldSchema = this.shape[key];
      if (mask && !mask[key]) {
        newShape[key] = fieldSchema;
      } else {
        newShape[key] = fieldSchema.optional();
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  required(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (mask && !mask[key]) {
        newShape[key] = this.shape[key];
      } else {
        const fieldSchema = this.shape[key];
        let newField = fieldSchema;
        while (newField instanceof ZodOptional) {
          newField = newField._def.innerType;
        }
        newShape[key] = newField;
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  keyof() {
    return createZodEnum(util.objectKeys(this.shape));
  }
};
ZodObject.create = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.strictCreate = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strict",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.lazycreate = (shape, params) => {
  return new ZodObject({
    shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
var ZodUnion = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const options = this._def.options;
    function handleResults(results) {
      for (const result of results) {
        if (result.result.status === "valid") {
          return result.result;
        }
      }
      for (const result of results) {
        if (result.result.status === "dirty") {
          ctx.common.issues.push(...result.ctx.common.issues);
          return result.result;
        }
      }
      const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return Promise.all(options.map(async (option) => {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        return {
          result: await option._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          }),
          ctx: childCtx
        };
      })).then(handleResults);
    } else {
      let dirty = void 0;
      const issues = [];
      for (const option of options) {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        const result = option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: childCtx
        });
        if (result.status === "valid") {
          return result;
        } else if (result.status === "dirty" && !dirty) {
          dirty = { result, ctx: childCtx };
        }
        if (childCtx.common.issues.length) {
          issues.push(childCtx.common.issues);
        }
      }
      if (dirty) {
        ctx.common.issues.push(...dirty.ctx.common.issues);
        return dirty.result;
      }
      const unionErrors = issues.map((issues2) => new ZodError(issues2));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
  }
  get options() {
    return this._def.options;
  }
};
ZodUnion.create = (types, params) => {
  return new ZodUnion({
    options: types,
    typeName: ZodFirstPartyTypeKind.ZodUnion,
    ...processCreateParams(params)
  });
};
var getDiscriminator = (type) => {
  if (type instanceof ZodLazy) {
    return getDiscriminator(type.schema);
  } else if (type instanceof ZodEffects) {
    return getDiscriminator(type.innerType());
  } else if (type instanceof ZodLiteral) {
    return [type.value];
  } else if (type instanceof ZodEnum) {
    return type.options;
  } else if (type instanceof ZodNativeEnum) {
    return util.objectValues(type.enum);
  } else if (type instanceof ZodDefault) {
    return getDiscriminator(type._def.innerType);
  } else if (type instanceof ZodUndefined) {
    return [void 0];
  } else if (type instanceof ZodNull) {
    return [null];
  } else if (type instanceof ZodOptional) {
    return [void 0, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodNullable) {
    return [null, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodBranded) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodReadonly) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodCatch) {
    return getDiscriminator(type._def.innerType);
  } else {
    return [];
  }
};
var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const discriminator = this.discriminator;
    const discriminatorValue = ctx.data[discriminator];
    const option = this.optionsMap.get(discriminatorValue);
    if (!option) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union_discriminator,
        options: Array.from(this.optionsMap.keys()),
        path: [discriminator]
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return option._parseAsync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    } else {
      return option._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    }
  }
  get discriminator() {
    return this._def.discriminator;
  }
  get options() {
    return this._def.options;
  }
  get optionsMap() {
    return this._def.optionsMap;
  }
  /**
   * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
   * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
   * have a different value for each object in the union.
   * @param discriminator the name of the discriminator property
   * @param types an array of object schemas
   * @param params
   */
  static create(discriminator, options, params) {
    const optionsMap = /* @__PURE__ */ new Map();
    for (const type of options) {
      const discriminatorValues = getDiscriminator(type.shape[discriminator]);
      if (!discriminatorValues.length) {
        throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
      }
      for (const value of discriminatorValues) {
        if (optionsMap.has(value)) {
          throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
        }
        optionsMap.set(value, type);
      }
    }
    return new _ZodDiscriminatedUnion({
      typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
      discriminator,
      options,
      optionsMap,
      ...processCreateParams(params)
    });
  }
};
function mergeValues(a, b) {
  const aType = getParsedType(a);
  const bType = getParsedType(b);
  if (a === b) {
    return { valid: true, data: a };
  } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
    const bKeys = util.objectKeys(b);
    const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
    const newObj = { ...a, ...b };
    for (const key of sharedKeys) {
      const sharedValue = mergeValues(a[key], b[key]);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newObj[key] = sharedValue.data;
    }
    return { valid: true, data: newObj };
  } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
    if (a.length !== b.length) {
      return { valid: false };
    }
    const newArray = [];
    for (let index = 0; index < a.length; index++) {
      const itemA = a[index];
      const itemB = b[index];
      const sharedValue = mergeValues(itemA, itemB);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newArray.push(sharedValue.data);
    }
    return { valid: true, data: newArray };
  } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
    return { valid: true, data: a };
  } else {
    return { valid: false };
  }
}
var ZodIntersection = class extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const handleParsed = (parsedLeft, parsedRight) => {
      if (isAborted(parsedLeft) || isAborted(parsedRight)) {
        return INVALID;
      }
      const merged = mergeValues(parsedLeft.value, parsedRight.value);
      if (!merged.valid) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_intersection_types
        });
        return INVALID;
      }
      if (isDirty(parsedLeft) || isDirty(parsedRight)) {
        status.dirty();
      }
      return { status: status.value, value: merged.data };
    };
    if (ctx.common.async) {
      return Promise.all([
        this._def.left._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }),
        this._def.right._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        })
      ]).then(([left, right]) => handleParsed(left, right));
    } else {
      return handleParsed(this._def.left._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }), this._def.right._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }));
    }
  }
};
ZodIntersection.create = (left, right, params) => {
  return new ZodIntersection({
    left,
    right,
    typeName: ZodFirstPartyTypeKind.ZodIntersection,
    ...processCreateParams(params)
  });
};
var ZodTuple = class _ZodTuple extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (ctx.data.length < this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_small,
        minimum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      return INVALID;
    }
    const rest = this._def.rest;
    if (!rest && ctx.data.length > this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_big,
        maximum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      status.dirty();
    }
    const items = [...ctx.data].map((item, itemIndex) => {
      const schema = this._def.items[itemIndex] || this._def.rest;
      if (!schema)
        return null;
      return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
    }).filter((x) => !!x);
    if (ctx.common.async) {
      return Promise.all(items).then((results) => {
        return ParseStatus.mergeArray(status, results);
      });
    } else {
      return ParseStatus.mergeArray(status, items);
    }
  }
  get items() {
    return this._def.items;
  }
  rest(rest) {
    return new _ZodTuple({
      ...this._def,
      rest
    });
  }
};
ZodTuple.create = (schemas, params) => {
  if (!Array.isArray(schemas)) {
    throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
  }
  return new ZodTuple({
    items: schemas,
    typeName: ZodFirstPartyTypeKind.ZodTuple,
    rest: null,
    ...processCreateParams(params)
  });
};
var ZodRecord = class _ZodRecord extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const pairs = [];
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    for (const key in ctx.data) {
      pairs.push({
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
        value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (ctx.common.async) {
      return ParseStatus.mergeObjectAsync(status, pairs);
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get element() {
    return this._def.valueType;
  }
  static create(first, second, third) {
    if (second instanceof ZodType) {
      return new _ZodRecord({
        keyType: first,
        valueType: second,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(third)
      });
    }
    return new _ZodRecord({
      keyType: ZodString.create(),
      valueType: first,
      typeName: ZodFirstPartyTypeKind.ZodRecord,
      ...processCreateParams(second)
    });
  }
};
var ZodMap = class extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.map) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.map,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    const pairs = [...ctx.data.entries()].map(([key, value], index) => {
      return {
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
        value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
      };
    });
    if (ctx.common.async) {
      const finalMap = /* @__PURE__ */ new Map();
      return Promise.resolve().then(async () => {
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status.value, value: finalMap };
      });
    } else {
      const finalMap = /* @__PURE__ */ new Map();
      for (const pair of pairs) {
        const key = pair.key;
        const value = pair.value;
        if (key.status === "aborted" || value.status === "aborted") {
          return INVALID;
        }
        if (key.status === "dirty" || value.status === "dirty") {
          status.dirty();
        }
        finalMap.set(key.value, value.value);
      }
      return { status: status.value, value: finalMap };
    }
  }
};
ZodMap.create = (keyType, valueType, params) => {
  return new ZodMap({
    valueType,
    keyType,
    typeName: ZodFirstPartyTypeKind.ZodMap,
    ...processCreateParams(params)
  });
};
var ZodSet = class _ZodSet extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.set) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.set,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const def = this._def;
    if (def.minSize !== null) {
      if (ctx.data.size < def.minSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.minSize.message
        });
        status.dirty();
      }
    }
    if (def.maxSize !== null) {
      if (ctx.data.size > def.maxSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.maxSize.message
        });
        status.dirty();
      }
    }
    const valueType = this._def.valueType;
    function finalizeSet(elements2) {
      const parsedSet = /* @__PURE__ */ new Set();
      for (const element of elements2) {
        if (element.status === "aborted")
          return INVALID;
        if (element.status === "dirty")
          status.dirty();
        parsedSet.add(element.value);
      }
      return { status: status.value, value: parsedSet };
    }
    const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
    if (ctx.common.async) {
      return Promise.all(elements).then((elements2) => finalizeSet(elements2));
    } else {
      return finalizeSet(elements);
    }
  }
  min(minSize, message) {
    return new _ZodSet({
      ...this._def,
      minSize: { value: minSize, message: errorUtil.toString(message) }
    });
  }
  max(maxSize, message) {
    return new _ZodSet({
      ...this._def,
      maxSize: { value: maxSize, message: errorUtil.toString(message) }
    });
  }
  size(size, message) {
    return this.min(size, message).max(size, message);
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodSet.create = (valueType, params) => {
  return new ZodSet({
    valueType,
    minSize: null,
    maxSize: null,
    typeName: ZodFirstPartyTypeKind.ZodSet,
    ...processCreateParams(params)
  });
};
var ZodFunction = class _ZodFunction extends ZodType {
  constructor() {
    super(...arguments);
    this.validate = this.implement;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.function) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.function,
        received: ctx.parsedType
      });
      return INVALID;
    }
    function makeArgsIssue(args, error) {
      return makeIssue({
        data: args,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_arguments,
          argumentsError: error
        }
      });
    }
    function makeReturnsIssue(returns, error) {
      return makeIssue({
        data: returns,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_return_type,
          returnTypeError: error
        }
      });
    }
    const params = { errorMap: ctx.common.contextualErrorMap };
    const fn = ctx.data;
    if (this._def.returns instanceof ZodPromise) {
      const me = this;
      return OK(async function(...args) {
        const error = new ZodError([]);
        const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
          error.addIssue(makeArgsIssue(args, e));
          throw error;
        });
        const result = await Reflect.apply(fn, this, parsedArgs);
        const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
          error.addIssue(makeReturnsIssue(result, e));
          throw error;
        });
        return parsedReturns;
      });
    } else {
      const me = this;
      return OK(function(...args) {
        const parsedArgs = me._def.args.safeParse(args, params);
        if (!parsedArgs.success) {
          throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
        }
        const result = Reflect.apply(fn, this, parsedArgs.data);
        const parsedReturns = me._def.returns.safeParse(result, params);
        if (!parsedReturns.success) {
          throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
        }
        return parsedReturns.data;
      });
    }
  }
  parameters() {
    return this._def.args;
  }
  returnType() {
    return this._def.returns;
  }
  args(...items) {
    return new _ZodFunction({
      ...this._def,
      args: ZodTuple.create(items).rest(ZodUnknown.create())
    });
  }
  returns(returnType) {
    return new _ZodFunction({
      ...this._def,
      returns: returnType
    });
  }
  implement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  strictImplement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  static create(args, returns, params) {
    return new _ZodFunction({
      args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
      returns: returns || ZodUnknown.create(),
      typeName: ZodFirstPartyTypeKind.ZodFunction,
      ...processCreateParams(params)
    });
  }
};
var ZodLazy = class extends ZodType {
  get schema() {
    return this._def.getter();
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const lazySchema = this._def.getter();
    return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
  }
};
ZodLazy.create = (getter, params) => {
  return new ZodLazy({
    getter,
    typeName: ZodFirstPartyTypeKind.ZodLazy,
    ...processCreateParams(params)
  });
};
var ZodLiteral = class extends ZodType {
  _parse(input) {
    if (input.data !== this._def.value) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_literal,
        expected: this._def.value
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
  get value() {
    return this._def.value;
  }
};
ZodLiteral.create = (value, params) => {
  return new ZodLiteral({
    value,
    typeName: ZodFirstPartyTypeKind.ZodLiteral,
    ...processCreateParams(params)
  });
};
function createZodEnum(values, params) {
  return new ZodEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodEnum,
    ...processCreateParams(params)
  });
}
var ZodEnum = class _ZodEnum extends ZodType {
  _parse(input) {
    if (typeof input.data !== "string") {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(this._def.values);
    }
    if (!this._cache.has(input.data)) {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get options() {
    return this._def.values;
  }
  get enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Values() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  extract(values, newDef = this._def) {
    return _ZodEnum.create(values, {
      ...this._def,
      ...newDef
    });
  }
  exclude(values, newDef = this._def) {
    return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
      ...this._def,
      ...newDef
    });
  }
};
ZodEnum.create = createZodEnum;
var ZodNativeEnum = class extends ZodType {
  _parse(input) {
    const nativeEnumValues = util.getValidEnumValues(this._def.values);
    const ctx = this._getOrReturnCtx(input);
    if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(util.getValidEnumValues(this._def.values));
    }
    if (!this._cache.has(input.data)) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get enum() {
    return this._def.values;
  }
};
ZodNativeEnum.create = (values, params) => {
  return new ZodNativeEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
    ...processCreateParams(params)
  });
};
var ZodPromise = class extends ZodType {
  unwrap() {
    return this._def.type;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.promise,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
    return OK(promisified.then((data) => {
      return this._def.type.parseAsync(data, {
        path: ctx.path,
        errorMap: ctx.common.contextualErrorMap
      });
    }));
  }
};
ZodPromise.create = (schema, params) => {
  return new ZodPromise({
    type: schema,
    typeName: ZodFirstPartyTypeKind.ZodPromise,
    ...processCreateParams(params)
  });
};
var ZodEffects = class extends ZodType {
  innerType() {
    return this._def.schema;
  }
  sourceType() {
    return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const effect = this._def.effect || null;
    const checkCtx = {
      addIssue: (arg) => {
        addIssueToContext(ctx, arg);
        if (arg.fatal) {
          status.abort();
        } else {
          status.dirty();
        }
      },
      get path() {
        return ctx.path;
      }
    };
    checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
    if (effect.type === "preprocess") {
      const processed2 = effect.transform(ctx.data, checkCtx);
      if (ctx.common.async) {
        return Promise.resolve(processed2).then(async (processed3) => {
          if (status.value === "aborted")
            return INVALID;
          const result = await this._def.schema._parseAsync({
            data: processed3,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        });
      } else {
        if (status.value === "aborted")
          return INVALID;
        const result = this._def.schema._parseSync({
          data: processed2,
          path: ctx.path,
          parent: ctx
        });
        if (result.status === "aborted")
          return INVALID;
        if (result.status === "dirty")
          return DIRTY(result.value);
        if (status.value === "dirty")
          return DIRTY(result.value);
        return result;
      }
    }
    if (effect.type === "refinement") {
      const executeRefinement = (acc) => {
        const result = effect.refinement(acc, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(result);
        }
        if (result instanceof Promise) {
          throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
        }
        return acc;
      };
      if (ctx.common.async === false) {
        const inner = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inner.status === "aborted")
          return INVALID;
        if (inner.status === "dirty")
          status.dirty();
        executeRefinement(inner.value);
        return { status: status.value, value: inner.value };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          return executeRefinement(inner.value).then(() => {
            return { status: status.value, value: inner.value };
          });
        });
      }
    }
    if (effect.type === "transform") {
      if (ctx.common.async === false) {
        const base = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (!isValid(base))
          return INVALID;
        const result = effect.transform(base.value, checkCtx);
        if (result instanceof Promise) {
          throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
        }
        return { status: status.value, value: result };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
          if (!isValid(base))
            return INVALID;
          return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
            status: status.value,
            value: result
          }));
        });
      }
    }
    util.assertNever(effect);
  }
};
ZodEffects.create = (schema, effect, params) => {
  return new ZodEffects({
    schema,
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    effect,
    ...processCreateParams(params)
  });
};
ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
  return new ZodEffects({
    schema,
    effect: { type: "preprocess", transform: preprocess },
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    ...processCreateParams(params)
  });
};
var ZodOptional = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.undefined) {
      return OK(void 0);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodOptional.create = (type, params) => {
  return new ZodOptional({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodOptional,
    ...processCreateParams(params)
  });
};
var ZodNullable = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.null) {
      return OK(null);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodNullable.create = (type, params) => {
  return new ZodNullable({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodNullable,
    ...processCreateParams(params)
  });
};
var ZodDefault = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    let data = ctx.data;
    if (ctx.parsedType === ZodParsedType.undefined) {
      data = this._def.defaultValue();
    }
    return this._def.innerType._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  removeDefault() {
    return this._def.innerType;
  }
};
ZodDefault.create = (type, params) => {
  return new ZodDefault({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodDefault,
    defaultValue: typeof params.default === "function" ? params.default : () => params.default,
    ...processCreateParams(params)
  });
};
var ZodCatch = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const newCtx = {
      ...ctx,
      common: {
        ...ctx.common,
        issues: []
      }
    };
    const result = this._def.innerType._parse({
      data: newCtx.data,
      path: newCtx.path,
      parent: {
        ...newCtx
      }
    });
    if (isAsync(result)) {
      return result.then((result2) => {
        return {
          status: "valid",
          value: result2.status === "valid" ? result2.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      });
    } else {
      return {
        status: "valid",
        value: result.status === "valid" ? result.value : this._def.catchValue({
          get error() {
            return new ZodError(newCtx.common.issues);
          },
          input: newCtx.data
        })
      };
    }
  }
  removeCatch() {
    return this._def.innerType;
  }
};
ZodCatch.create = (type, params) => {
  return new ZodCatch({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodCatch,
    catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
    ...processCreateParams(params)
  });
};
var ZodNaN = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.nan) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.nan,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
};
ZodNaN.create = (params) => {
  return new ZodNaN({
    typeName: ZodFirstPartyTypeKind.ZodNaN,
    ...processCreateParams(params)
  });
};
var BRAND = /* @__PURE__ */ Symbol("zod_brand");
var ZodBranded = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const data = ctx.data;
    return this._def.type._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  unwrap() {
    return this._def.type;
  }
};
var ZodPipeline = class _ZodPipeline extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.common.async) {
      const handleAsync = async () => {
        const inResult = await this._def.in._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return DIRTY(inResult.value);
        } else {
          return this._def.out._parseAsync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      };
      return handleAsync();
    } else {
      const inResult = this._def.in._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
      if (inResult.status === "aborted")
        return INVALID;
      if (inResult.status === "dirty") {
        status.dirty();
        return {
          status: "dirty",
          value: inResult.value
        };
      } else {
        return this._def.out._parseSync({
          data: inResult.value,
          path: ctx.path,
          parent: ctx
        });
      }
    }
  }
  static create(a, b) {
    return new _ZodPipeline({
      in: a,
      out: b,
      typeName: ZodFirstPartyTypeKind.ZodPipeline
    });
  }
};
var ZodReadonly = class extends ZodType {
  _parse(input) {
    const result = this._def.innerType._parse(input);
    const freeze = (data) => {
      if (isValid(data)) {
        data.value = Object.freeze(data.value);
      }
      return data;
    };
    return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodReadonly.create = (type, params) => {
  return new ZodReadonly({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodReadonly,
    ...processCreateParams(params)
  });
};
function cleanParams(params, data) {
  const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
  const p2 = typeof p === "string" ? { message: p } : p;
  return p2;
}
function custom(check, _params = {}, fatal) {
  if (check)
    return ZodAny.create().superRefine((data, ctx) => {
      const r = check(data);
      if (r instanceof Promise) {
        return r.then((r2) => {
          if (!r2) {
            const params = cleanParams(_params, data);
            const _fatal = params.fatal ?? fatal ?? true;
            ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
          }
        });
      }
      if (!r) {
        const params = cleanParams(_params, data);
        const _fatal = params.fatal ?? fatal ?? true;
        ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
      }
      return;
    });
  return ZodAny.create();
}
var late = {
  object: ZodObject.lazycreate
};
var ZodFirstPartyTypeKind;
(function(ZodFirstPartyTypeKind2) {
  ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
  ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
  ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
  ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
  ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
  ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
  ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
  ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
  ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
  ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
  ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
  ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
  ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
  ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
  ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
  ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
  ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
  ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
  ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
  ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
  ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
  ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
  ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
  ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
  ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
  ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
  ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
  ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
  ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
  ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
  ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
  ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
  ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
  ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
  ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
  ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
})(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
var instanceOfType = (cls, params = {
  message: `Input not instance of ${cls.name}`
}) => custom((data) => data instanceof cls, params);
var stringType = ZodString.create;
var numberType = ZodNumber.create;
var nanType = ZodNaN.create;
var bigIntType = ZodBigInt.create;
var booleanType = ZodBoolean.create;
var dateType = ZodDate.create;
var symbolType = ZodSymbol.create;
var undefinedType = ZodUndefined.create;
var nullType = ZodNull.create;
var anyType = ZodAny.create;
var unknownType = ZodUnknown.create;
var neverType = ZodNever.create;
var voidType = ZodVoid.create;
var arrayType = ZodArray.create;
var objectType = ZodObject.create;
var strictObjectType = ZodObject.strictCreate;
var unionType = ZodUnion.create;
var discriminatedUnionType = ZodDiscriminatedUnion.create;
var intersectionType = ZodIntersection.create;
var tupleType = ZodTuple.create;
var recordType = ZodRecord.create;
var mapType = ZodMap.create;
var setType = ZodSet.create;
var functionType = ZodFunction.create;
var lazyType = ZodLazy.create;
var literalType = ZodLiteral.create;
var enumType = ZodEnum.create;
var nativeEnumType = ZodNativeEnum.create;
var promiseType = ZodPromise.create;
var effectsType = ZodEffects.create;
var optionalType = ZodOptional.create;
var nullableType = ZodNullable.create;
var preprocessType = ZodEffects.createWithPreprocess;
var pipelineType = ZodPipeline.create;
var ostring = () => stringType().optional();
var onumber = () => numberType().optional();
var oboolean = () => booleanType().optional();
var coerce = {
  string: ((arg) => ZodString.create({ ...arg, coerce: true })),
  number: ((arg) => ZodNumber.create({ ...arg, coerce: true })),
  boolean: ((arg) => ZodBoolean.create({
    ...arg,
    coerce: true
  })),
  bigint: ((arg) => ZodBigInt.create({ ...arg, coerce: true })),
  date: ((arg) => ZodDate.create({ ...arg, coerce: true }))
};
var NEVER = INVALID;

// server/apus.ts
var APUS_BOARD_ID = (process.env.APUS_BOARD_ID || "18420326098").trim();
var WEEKS_GROUP = "group_mkzj2gt8";
var PROJECTS_GROUP = "group_mm3a6mqg";
var CACHE_MIN = 30;
var ACTIVE_STATUSES = ["Em planejamento", "Em execu\xE7\xE3o", "Em encerramento"];
async function readGroup(group, cols) {
  const fields = "{ id name column_values(ids: $c) { id text ... on FormulaValue { display_value } ... on MirrorValue { display_value } ... on BoardRelationValue { linked_item_ids } } }";
  const out = [];
  const first = await gql(
    `query ($b: [ID!], $g: [String], $c: [String!]) { boards(ids: $b) { groups(ids: $g) { items_page(limit: 500) { cursor items ${fields} } } } }`,
    { b: [APUS_BOARD_ID], g: [group], c: cols }
  );
  let page = first.boards[0]?.groups[0]?.items_page;
  while (page) {
    out.push(...page.items);
    if (!page.cursor) break;
    const r = await gql(
      `query ($k: String!, $c: [String!]) { next_items_page(cursor: $k, limit: 500) { cursor items ${fields} } }`,
      { k: page.cursor, c: cols }
    );
    page = r.next_items_page;
  }
  return out;
}
var n = (v) => {
  if (v === null || v === void 0 || String(v).trim() === "" || v === "null") return null;
  const x = Number(String(v ?? "").replace(",", "."));
  return Number.isFinite(x) ? x : null;
};
async function readBoard() {
  const [projects, items] = await Promise.all([
    readGroup(PROJECTS_GROUP, ["text_mkyg1502", "color_mm54274v", "date_mm4xh2h8"]),
    readGroup(WEEKS_GROUP, ["color_mm4wwfr5", "numeric_mm4w7f8e", "numeric_mm4wrmjz", "lookup_mm4xdrwf", "formula_mm4xx5rq", "board_relation_mm4xzvhq", "dropdown_mm6tr0v2", "numeric_mm4w3a7f"])
  ]);
  const pcv = (p, id) => (p.column_values.find((c) => c.id === id)?.text ?? "").trim();
  const proj = new Map(projects.map((p) => [String(p.id), {
    name: p.name,
    code: pcv(p, "text_mkyg1502") || (p.name.match(/(\d{4}\/\d{3})/)?.[1] ?? ""),
    status: pcv(p, "color_mm54274v"),
    startDate: pcv(p, "date_mm4xh2h8") || null
  }]));
  const all = [];
  for (const it of items) {
    const cv = (id) => it.column_values.find((c) => c.id === id);
    const weekLabel = (cv("color_mm4wwfr5")?.text ?? "").trim();
    const wn = weekLabel.match(/^(\d+)/);
    if (!wn) continue;
    const linked = proj.get(String(cv("board_relation_mm4xzvhq")?.linked_item_ids?.[0] ?? ""));
    if (!linked || !ACTIVE_STATUSES.includes(linked.status)) continue;
    const updates = n(cv("numeric_mm4w7f8e")?.text) ?? 0;
    const users = n(cv("numeric_mm4wrmjz")?.text) ?? 0;
    const fromBoard = n(cv("formula_mm4xx5rq")?.display_value);
    const weeksOnPlatform = linked.startDate ? Math.max(1, Math.round((Date.now() - (/* @__PURE__ */ new Date(`${linked.startDate}T12:00:00Z`)).getTime()) / (7 * 864e5))) : n(cv("lookup_mm4xdrwf")?.display_value);
    const apus = fromBoard ?? (users && weeksOnPlatform ? updates / users / weeksOnPlatform : null);
    all.push({
      team: it.name.trim(),
      project: linked.name,
      code: linked.code,
      status: linked.status,
      startDate: linked.startDate,
      pctEngaged: n(cv("numeric_mm4w3a7f")?.text),
      managers: (cv("dropdown_mm6tr0v2")?.text ?? "").split(",").map((s) => s.trim()).filter(Boolean),
      weekNumber: Number(wn[1]),
      weekLabel: weekLabel.replace(/\s+/g, " "),
      updates,
      users,
      weeksOnPlatform,
      apus: apus === null ? null : Math.round(apus * 100) / 100
    });
  }
  const rows = all;
  const weeks = [...new Map(rows.map((r) => [r.weekNumber, r.weekLabel])).entries()].sort((a, b) => b[0] - a[0]).map(([weekNumber, weekLabel]) => ({ weekNumber, weekLabel }));
  return { rows, weeks, boardId: APUS_BOARD_ID, readAt: (/* @__PURE__ */ new Date()).toISOString() };
}
async function apusData(force = false) {
  const col3 = (await mongo()).collection("apus_cache");
  if (!force) {
    const c = await col3.findOne({ _id: "v2" });
    if (c && Date.now() - new Date(c.data.readAt).getTime() < CACHE_MIN * 6e4) return c.data;
  }
  const data = await readBoard();
  await col3.replaceOne({ _id: "v2" }, { data }, { upsert: true });
  return data;
}

// server/vibeDb.ts
var import_node_crypto3 = require("node:crypto");
var OPS = { "==": "$eq", "!=": "$ne", ">": "$gt", ">=": "$gte", "<": "$lt", "<=": "$lte", in: "$in", "not-in": "$nin" };
function strip(d) {
  if (!d) return null;
  const { _id, ...rest } = d;
  return { id: String(_id), data: rest };
}
function clean(data) {
  const out = { ...data };
  delete out._id;
  for (const k of Object.keys(out)) if (out[k] === void 0) delete out[k];
  return out;
}
var DocRef = class {
  constructor(c, id) {
    this.c = c;
    this.id = id;
  }
  c;
  id;
  async col() {
    return (await mongo()).collection(this.c);
  }
  async get() {
    return strip(await (await this.col()).findOne({ _id: this.id }));
  }
  async set(data, opts) {
    const col3 = await this.col();
    if (opts?.merge) await col3.updateOne({ _id: this.id }, { $set: clean(data) }, { upsert: true });
    else await col3.replaceOne({ _id: this.id }, clean(data), { upsert: true });
  }
  async update(data) {
    const r = await (await this.col()).updateOne({ _id: this.id }, { $set: clean(data) });
    if (r.matchedCount === 0) throw new Error("Registro n\xE3o encontrado.");
  }
  async delete() {
    await (await this.col()).deleteOne({ _id: this.id });
  }
};
var Query = class _Query {
  constructor(c, filter = {}, sort = null, lim = 0) {
    this.c = c;
    this.filter = filter;
    this.sort = sort;
    this.lim = lim;
  }
  c;
  filter;
  sort;
  lim;
  where(field, op, value) {
    const mop = OPS[op];
    if (!mop) throw new Error(`Operador n\xE3o suportado: ${op}`);
    const key = field === "id" ? "_id" : field;
    const prev = this.filter[key];
    const cond = { ...prev && typeof prev === "object" && !Array.isArray(prev) ? prev : {}, [mop]: value };
    return new _Query(this.c, { ...this.filter, [key]: cond }, this.sort, this.lim);
  }
  orderBy(field, dir = "asc") {
    return new _Query(this.c, this.filter, { ...this.sort ?? {}, [field]: dir === "desc" ? -1 : 1 }, this.lim);
  }
  limit(n2) {
    return new _Query(this.c, this.filter, this.sort, n2);
  }
  startAfter(cursor) {
    if (!cursor) return this;
    return new _Query(this.c, { ...this.filter, _id: { $gt: cursor } }, this.sort, this.lim);
  }
  async getPage() {
    const lim = this.lim || 500;
    const col3 = (await mongo()).collection(this.c);
    const docs = (await col3.find(this.filter).sort({ _id: 1 }).limit(lim).toArray()).map((d) => strip(d));
    return { docs, cursor: docs.length === lim ? docs[docs.length - 1].id : null };
  }
  async get() {
    const col3 = (await mongo()).collection(this.c);
    let cur = col3.find(this.filter);
    if (this.sort) cur = cur.sort(this.sort);
    if (this.lim) cur = cur.limit(this.lim);
    return (await cur.toArray()).map((d) => strip(d));
  }
};
var CollRef = class extends Query {
  constructor(name) {
    super(name);
  }
  doc(id) {
    return new DocRef(this.c, id ?? (0, import_node_crypto3.randomUUID)());
  }
  async add(data) {
    const id = (0, import_node_crypto3.randomUUID)();
    await (await mongo()).collection(this.c).insertOne({ _id: id, ...clean(data) });
    return { id };
  }
};
var db = {
  collection(c) {
    return new CollRef(c.name);
  }
};

// src/shims/vibe-db.ts
function defineCollection(opts) {
  return { name: opts.name };
}

// src/generated/models.ts
var baseWeekStatusCollection = defineCollection({
  name: "base_week_status"
});
var baseWeekLogCollection = defineCollection({
  name: "base_week_log",
  indexes: ["at"]
});
var mirrorQueueCollection = defineCollection({
  name: "mirror_queue"
});
var baseSyncStatusCollection = defineCollection({
  name: "base_sync_status"
});
var legacyTeamMappingCollection = defineCollection({
  name: "team_mapping_legacy"
});
var teamMappingMetaCollection = defineCollection({
  name: "team_mapping_meta"
});
var panelUploadSettingsCollection = defineCollection({
  name: "panel_upload_settings"
});
var panelUploadRunsCollection = defineCollection({
  name: "panel_upload_runs",
  indexes: ["status", "startedAt", "analysisDate"]
});
var snapshotMetaCollection = defineCollection({
  name: "snapshot_meta"
});
var engagementChunksCollection = defineCollection({
  name: "engagement_chunks",
  indexes: ["index"]
});
var projectsDocCollection = defineCollection({
  name: "snapshot_projects"
});
var pmoConfigCollection = defineCollection({
  name: "pmo_config"
});
var boardIdsConfigCollection = defineCollection({
  name: "board_ids_config"
});
var teamProjectRowsCollection = defineCollection({
  name: "team_project_rows"
});
var absencesCollection = defineCollection({
  name: "user_absences",
  indexes: ["email", "tipo"]
});
var baseDeletionLogCollection = defineCollection({
  name: "base_deletion_log",
  indexes: ["deletedAt"]
});

// src/generated/server/vibeDbRetry.server.ts
var WAITS_MS = [400, 1200, 3e3];
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function isTransient(e) {
  const msg = e?.message?.toLowerCase() ?? "";
  return msg.includes("fetch failed") || msg.includes("econnreset") || msg.includes("timeout") || msg.includes("socket") || msg.includes("503") || msg.includes("502");
}
async function dbWriteWithRetry(label, fn) {
  for (let attempt = 0; ; attempt++) {
    try {
      return await fn();
    } catch (e) {
      const wait = WAITS_MS[attempt];
      if (!isTransient(e) || wait === void 0) {
        console.error(`Falha ao gravar no armazenamento do app (${label}).`);
        throw new Error("O armazenamento do app ficou indispon\xEDvel por um instante. Tente novamente em alguns segundos.");
      }
      await sleep(wait);
    }
  }
}
async function dbReadWithRetry(label, fn) {
  for (let attempt = 0; ; attempt++) {
    try {
      return await fn();
    } catch (e) {
      const wait = WAITS_MS[attempt];
      if (wait === void 0) {
        console.error(`Falha ao ler do armazenamento do app (${label}):`, e?.message);
        throw new Error("N\xE3o foi poss\xEDvel ler a base do aplicativo agora.");
      }
      await sleep(wait);
    }
  }
}
async function dbWriteBestEffort(label, fn) {
  try {
    await fn();
  } catch {
    try {
      await sleep(WAITS_MS[0] ?? 400);
      await fn();
    } catch {
      console.error(`Registro acess\xF3rio n\xE3o gravado (${label}).`);
    }
  }
}

// src/generated/server/session.server.ts
var OWNER_EMAIL = "davi.vale@fgv.br";
var PMO_CONFIG_DOC_ID = "main_pmo_config";
function normalizeEmail(e) {
  return (e || "").replace(/\s+/g, "").toLowerCase();
}
function domainOf(e) {
  const v = normalizeEmail(e);
  const at3 = v.indexOf("@");
  return at3 > 0 ? `...${v.slice(at3)}` : null;
}
var ME_TTL_MS = 6e4;
var meCache = /* @__PURE__ */ new Map();
async function mondayMeOnServer(_mode) {
  const ctx = currentCtx();
  if (!ctx?.userId) return { me: null, error: "sem sess\xE3o do monday" };
  const hit = meCache.get(ctx.userId);
  if (hit && hit.exp > Date.now()) return { me: hit.me };
  try {
    const r = await gql("query ($ids: [ID!]) { users(ids: $ids) { id name email kind } }", { ids: [ctx.userId] });
    const u = r.users?.[0];
    const me = u ? { id: String(u.id), name: u.name ?? "", email: normalizeEmail(u.email), isAdmin: u.kind === "admin" || ctx.isAdmin, kind: u.kind ?? "" } : null;
    if (meCache.size > 500) meCache.clear();
    meCache.set(ctx.userId, { exp: Date.now() + ME_TTL_MS, me });
    return { me };
  } catch (e) {
    return { me: null, error: (e instanceof Error ? e.message : String(e)).slice(0, 200) };
  }
}
async function readPmoEmails() {
  try {
    const doc = await dbReadWithRetry("pmo", () => db.collection(pmoConfigCollection).doc(PMO_CONFIG_DOC_ID).get());
    const emails = (doc?.data?.pmoEmails ?? []).map(normalizeEmail).filter(Boolean);
    return Array.from(/* @__PURE__ */ new Set([OWNER_EMAIL, ...emails]));
  } catch (e) {
    console.error("Erro ao ler configura\xE7\xE3o de PMO:", e);
    return [OWNER_EMAIL];
  }
}
async function resolveSession(clientClaim) {
  const appMode = "";
  const tVibe = Date.now();
  const current = null;
  const vibeMs = Date.now() - tVibe;
  const tSrv = Date.now();
  const rawServer = await mondayMeOnServer(appMode);
  const srvMs = Date.now() - tSrv;
  const server2 = rawServer.me && current?.kind === "guest" ? { me: null, error: "visitante: token do servidor n\xE3o identifica a pessoa" } : rawServer;
  const claimEmail = normalizeEmail(clientClaim?.email);
  const vibe = server2.me ? null : current;
  const email = server2.me?.email || claimEmail;
  const emailSource = server2.me?.email ? "monday (servidor)" : claimEmail ? clientClaim?.emailSource === "me" ? "monday (consulta no navegador)" : "monday (navegador)" : "nenhuma";
  const id = server2.me?.id || (clientClaim?.id ? String(clientClaim.id) : "") || vibe?.id || "";
  const name = server2.me?.name || clientClaim?.name || vibe?.name || "Usu\xE1rio";
  const mondayAdmin = server2.me ? server2.me.isAdmin : clientClaim?.isAdmin === true;
  const diag = {
    userSource: server2.me || clientClaim?.id ? "monday" : vibe ? "vibe" : "nenhuma",
    emailSource,
    appMode: appMode || "(n\xE3o informado)",
    ...server2.error && !server2.me ? { serverError: server2.error } : {},
    sources: [
      { source: "monday (servidor)", responded: Boolean(server2.me), emailDomain: domainOf(server2.me?.email), ms: srvMs, ...server2.me ? server2.me.email ? {} : { error: "resposta sem e-mail" } : { error: (server2.error || "sem resposta").slice(0, 200) } },
      { source: "usu\xE1rio do Vibe", responded: Boolean(current), emailDomain: null, ms: vibeMs, error: current ? "n\xE3o informa e-mail" : "sem usu\xE1rio" }
    ]
  };
  if (!email) {
    return { id, name, email: "", isOwner: false, isAdmin: false, isPmo: false, canManage: false, diag };
  }
  const isOwner = email === OWNER_EMAIL;
  const pmoEmails = await readPmoEmails();
  const isPmo = pmoEmails.includes(email);
  const isAdmin = isOwner || mondayAdmin;
  return { id, name, email, isOwner, isAdmin, isPmo, canManage: isOwner || mondayAdmin || isPmo, diag };
}
async function assertTokenOwner(session, _token) {
  if (!session.canManage) throw new Error("Apenas o dono, Administradores e membros do PMO podem fazer isso.");
}

// src/generated/server/apus.ts
var claim = external_exports.object({ id: external_exports.union([external_exports.string(), external_exports.number()]).optional(), email: external_exports.string().optional(), name: external_exports.string().optional(), isAdmin: external_exports.boolean().optional() }).optional();
var getApus = createServerFn({ method: "POST" }).validator(external_exports.object({ clientClaim: claim, force: external_exports.boolean().optional() })).handler(async ({ data }) => {
  const s = await resolveSession(data.clientClaim);
  return apusData(Boolean(data.force && s.canManage));
});

// src/generated/server/baseEditMirror.ts
var baseEditMirror_exports = {};
__export(baseEditMirror_exports, {
  mirrorEditedRows: () => mirrorEditedRows
});

// src/generated/lib/dates.ts
function parseDateFlexible(value) {
  if (!value) return null;
  const clean2 = String(value).trim();
  if (!clean2) return null;
  const lower = clean2.toLowerCase();
  if (lower.includes("nunca") || lower.includes("n\xE3o") || lower.includes("nao") || lower === "-" || lower === "n/a") {
    return null;
  }
  const br2 = clean2.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})(?:[ T,]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
  if (br2) {
    let year = parseInt(br2[3], 10);
    if (year < 100) year += 2e3;
    const d = new Date(
      year,
      parseInt(br2[2], 10) - 1,
      parseInt(br2[1], 10),
      br2[4] ? parseInt(br2[4], 10) : 12,
      br2[5] ? parseInt(br2[5], 10) : 0,
      br2[6] ? parseInt(br2[6], 10) : 0
    );
    return isNaN(d.getTime()) ? null : d;
  }
  const iso2 = clean2.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
  if (iso2) {
    const d = new Date(
      parseInt(iso2[1], 10),
      parseInt(iso2[2], 10) - 1,
      parseInt(iso2[3], 10),
      iso2[4] ? parseInt(iso2[4], 10) : 12,
      iso2[5] ? parseInt(iso2[5], 10) : 0,
      iso2[6] ? parseInt(iso2[6], 10) : 0
    );
    return isNaN(d.getTime()) ? null : d;
  }
  return null;
}
function toISODate(date) {
  if (!date) return "";
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

// src/generated/lib/weekdays.ts
var WEEKDAYS = [
  { key: "dom", title: "Domingo", short: "Dom", dow: 0, required: true },
  { key: "seg", title: "Segunda", short: "Seg", dow: 1, required: true },
  { key: "ter", title: "Ter\xE7a", short: "Ter", dow: 2, required: true },
  { key: "qua", title: "Quarta", short: "Qua", dow: 3, required: true },
  { key: "qui", title: "Quinta", short: "Qui", dow: 4, required: true },
  { key: "sex", title: "Sexta", short: "Sex", dow: 5, required: true },
  { key: "sab", title: "S\xE1bado", short: "S\xE1b", dow: 6, required: true }
];
var WEEKDAY_KEYS = WEEKDAYS.map((w) => w.key);
var KEY_SET = new Set(WEEKDAY_KEYS);
function isWeekdayKey(v) {
  return KEY_SET.has(v);
}
function emptyDayCounts() {
  return { seg: 0, ter: 0, qua: 0, qui: 0, sex: 0, sab: 0, dom: 0 };
}
function normText(s) {
  return (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim();
}
function extractEmail(raw) {
  if (!raw) return "";
  const match = String(raw).match(/[^\s<>"',;]+@[^\s<>"',;]+/);
  return match ? match[0].toLowerCase().trim() : "";
}
function weekdayOfIso(iso2) {
  const m = iso2.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), 12);
  if (isNaN(d.getTime())) return null;
  return WEEKDAYS.find((w) => w.dow === d.getDay())?.key ?? null;
}
function sortDays(days) {
  return WEEKDAY_KEYS.filter((k) => days.includes(k));
}
function findWeekdayColumns(columns) {
  const found = {};
  const missing = [];
  WEEKDAYS.forEach((w) => {
    const col3 = columns.find((c) => normText(c.title) === normText(w.title) && c.type === "checkbox");
    if (col3) found[w.key] = col3;
    else if (w.required) missing.push(w.title);
  });
  return missing.length > 0 ? { found: null, missing } : { found, missing };
}
function personMatchKey(name, email) {
  const e = extractEmail(email);
  if (e) return `e:${e}`;
  return `n:${normText(name)}`;
}
function isCheckedValue(value, text) {
  if (value) {
    try {
      const parsed = JSON.parse(value);
      if (parsed && (parsed.checked === true || parsed.checked === "true")) return true;
    } catch {
    }
  }
  return normText(text) === "v";
}

// src/generated/lib/baseRows.ts
function baseRowKey(r) {
  return `${personMatchKey(r.name, r.email)}|${normText(r.group)}`;
}
function isoOf(raw) {
  const d = parseDateFlexible(raw);
  return d ? toISODate(d) : null;
}
function laTime(raw) {
  return parseDateFlexible(raw)?.getTime() ?? 0;
}
function pick(next, prev) {
  return next && next.trim() ? next.trim() : (prev ?? "").trim();
}
function rowFingerprint(r) {
  return JSON.stringify([
    r.name,
    r.email.toLowerCase(),
    r.team,
    r.department,
    r.userStatus ?? "",
    isoOf(r.lastAccess) ?? r.lastAccess ?? "",
    r.refDate ?? "",
    r.weekStart ?? "",
    normText(r.group),
    sortDays(r.checkedDays ?? []).join(",")
  ]);
}
function mergeRow(existing, incoming, mode) {
  if (!existing || mode === "board") {
    return { ...incoming, checkedDays: sortDays(incoming.checkedDays ?? []) };
  }
  const checks = sortDays(Array.from(/* @__PURE__ */ new Set([...existing.checkedDays ?? [], ...incoming.checkedDays ?? []])));
  const lastAccess = mode === "rewrite" ? pick(incoming.lastAccess, existing.lastAccess) || null : laTime(incoming.lastAccess) > laTime(existing.lastAccess) ? incoming.lastAccess : existing.lastAccess ?? incoming.lastAccess;
  const refDate = mode === "rewrite" ? pick(incoming.refDate, existing.refDate) || null : [existing.refDate, incoming.refDate].filter(Boolean).sort().pop() ?? null;
  return {
    name: pick(incoming.name, existing.name),
    email: pick(incoming.email, existing.email),
    team: pick(incoming.team, existing.team),
    department: pick(incoming.department, existing.department),
    userStatus: pick(incoming.userStatus, existing.userStatus),
    lastAccess,
    refDate,
    weekStart: pick(incoming.weekStart, existing.weekStart) || null,
    weekEnd: pick(incoming.weekEnd, existing.weekEnd) || null,
    group: pick(incoming.group, existing.group),
    checkedDays: checks,
    boardValues: { ...existing.boardValues ?? {}, ...incoming.boardValues ?? {} },
    createdAt: pick(incoming.createdAt ?? "", existing.createdAt ?? "") || null
  };
}
var BASE_FILE_COLUMNS = [
  "Semana",
  "Nome",
  "E-mail",
  "Equipe",
  "Departamento",
  "Status do usu\xE1rio",
  "Ativo pela \xFAltima vez",
  "Date",
  "In\xEDcio da semana",
  ...WEEKDAYS.map((w) => w.title),
  "Valida\xE7\xE3o da semana"
];
function cleanDays(days) {
  return sortDays((days ?? []).filter(isWeekdayKey));
}

// src/generated/lib/activeProjects.ts
var ACTIVE_PROJECT_STATUSES = ["Em planejamento", "Em execu\xE7\xE3o", "Em encerramento"];
var PROJECTS_STORE_VERSION = 2;
var norm = (s) => (s ?? "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim();
var ACTIVE_SET = new Set(ACTIVE_PROJECT_STATUSES.map(norm));
function isActiveProjectStatus(status) {
  return ACTIVE_SET.has(norm(status));
}
function filterActiveProjects(projects) {
  return (projects ?? []).filter((p) => isActiveProjectStatus(p.status));
}

// src/generated/lib/weekPeriod.ts
var ISO = /^(\d{4})-(\d{2})-(\d{2})$/;
function at2(iso2) {
  const m = iso2.match(ISO);
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), 12);
  return isNaN(d.getTime()) || d.getMonth() !== Number(m[2]) - 1 ? null : d;
}
var toIso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
function saturdayAfter(startIso) {
  const d = at2(startIso);
  if (!d) return null;
  return toIso(new Date(d.getFullYear(), d.getMonth(), d.getDate() + 6, 12));
}
function periodError(weekStart, weekEnd) {
  if (!weekStart || !weekEnd) return "Informe o in\xEDcio e o fim da semana.";
  const s = at2(weekStart);
  const e = at2(weekEnd);
  if (!s || !e) return "Per\xEDodo da semana inv\xE1lido.";
  if (s.getDay() !== 0) return "O in\xEDcio da semana tem que ser um domingo e o fim, o s\xE1bado seguinte (7 dias, de domingo a s\xE1bado).";
  if (weekEnd !== saturdayAfter(weekStart)) return "O fim da semana tem que ser o s\xE1bado seguinte ao domingo de in\xEDcio (7 dias, de domingo a s\xE1bado).";
  return null;
}
var OUTSIDE_PERIOD_MESSAGE = "A Data da an\xE1lise est\xE1 fora do per\xEDodo da semana";

// src/generated/server/mondayWrite.server.ts
var MONDAY_CALL_TIMEOUT_MS = 25e3;
var WRITABLE_COLUMN_TYPES = ["text", "long_text", "numbers", "email", "link", "date", "status", "dropdown"];
function isWritableType(type) {
  return WRITABLE_COLUMN_TYPES.includes(type);
}
function scrub(message, token) {
  let out = message || "Erro desconhecido na API do monday.";
  if (token) out = out.split(token).join("[token]");
  return out.slice(0, 500);
}
async function mondayCallOnce(token, query, variables) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), MONDAY_CALL_TIMEOUT_MS);
  try {
    const r0 = await respostaMonday(query, variables, { versao: "2024-10", signal: controller.signal });
    const res = { status: r0.status, ok: r0.status < 400, json: async () => r0.json };
    if (res.status === 429) return { ok: false, retryable: true, message: "Limite de requisi\xE7\xF5es do monday atingido." };
    if (res.status === 401 || res.status === 403) {
      return { ok: false, retryable: false, message: "Token inv\xE1lido ou sem permiss\xE3o no quadro." };
    }
    if (res.status >= 500) return { ok: false, retryable: true, message: `Erro tempor\xE1rio do monday (HTTP ${res.status}).` };
    if (!res.ok) return { ok: false, retryable: false, message: `Falha na API do monday (HTTP ${res.status}).` };
    const json = await res.json();
    const err = json.errors?.[0];
    const errMsg = err?.message || json.error_message;
    if (errMsg) {
      const code = `${err?.extensions?.code ?? ""} ${json.error_code ?? ""} ${errMsg}`.toLowerCase();
      const retryable = /complexity|rate.?limit|too many|internal|timeout|temporar|fetch failed/.test(code);
      return { ok: false, retryable, message: scrub(errMsg, token) };
    }
    if (!json.data) return { ok: false, retryable: true, message: "Resposta vazia do monday." };
    return { ok: true, data: json.data };
  } catch (e) {
    const aborted = e?.name === "AbortError";
    return {
      ok: false,
      retryable: true,
      message: aborted ? "Tempo limite de 25 segundos excedido." : "Falha de conex\xE3o com o monday."
    };
  } finally {
    clearTimeout(timer);
  }
}
var MONDAY_BATCH_TIMEOUT_MS = 6e4;
function classifyMondayError(text, httpStatus) {
  const t = text.toLowerCase();
  if (/defined on operation|never used|parse error|syntax error|unknown argument|cannot query field|is not defined|expected type|argument .* (is )?required|doesn.t exist on type|graphql validation/.test(t)) return "consulta";
  if (httpStatus === 429 || /rate.?limit|too many|concurren|retry_in/.test(t)) return "limite_requisicoes";
  if (/complexity/.test(t)) return "complexidade";
  if (httpStatus === 413 || /too large|payload|query.?size|max.?size|too long/.test(t)) return "tamanho";
  if (httpStatus === 401 || httpStatus === 403 || /unauthori|not authenticated|permission/.test(t)) return "autorizacao";
  if (/columnvalue|column value|invalid value|invalid_column|label|dropdown/.test(t)) return "valor_coluna";
  if ((httpStatus ?? 0) >= 500 || /internal|temporar|server error/.test(t)) return "servidor";
  if (/timeout|aborted|tempo limite/.test(t)) return "timeout";
  if (/fetch failed|econnreset|socket|connection/.test(t)) return "rede";
  return "outro";
}
async function mondayUpsertItemsBatch(token, boardId, groupId, items) {
  if (items.length === 0) return { delivered: true, outcomes: [] };
  const lines = [];
  const hasCreate = items.some((it) => it.op === "create");
  const vars = hasCreate ? { boardId, groupId } : { boardId };
  items.forEach((it, idx) => {
    const alias = `m_${idx}`;
    const cvVar = `cv_${idx}`;
    vars[cvVar] = JSON.stringify(it.columnValues);
    if (it.op === "create") {
      const nameVar = `nm_${idx}`;
      vars[nameVar] = it.name;
      lines.push(`${alias}: create_item(board_id: $boardId, group_id: $groupId, item_name: $${nameVar}, column_values: $${cvVar}) { id }`);
    } else {
      const itemVar = `id_${idx}`;
      vars[itemVar] = it.itemId;
      lines.push(`${alias}: change_multiple_column_values(board_id: $boardId, item_id: $${itemVar}, column_values: $${cvVar}) { id }`);
    }
  });
  const varDefs = [
    "$boardId: ID!",
    ...hasCreate ? ["$groupId: String!"] : [],
    ...items.flatMap((it, idx) => it.op === "create" ? [`$nm_${idx}: String!`, `$cv_${idx}: JSON!`] : [`$id_${idx}: ID!`, `$cv_${idx}: JSON!`])
  ].join(", ");
  const query = `mutation (${varDefs}) { ${lines.join(" ")} }`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), MONDAY_BATCH_TIMEOUT_MS);
  try {
    const r0 = await respostaMonday(query, vars, { versao: "2024-10", signal: controller.signal });
    const res = { status: r0.status, ok: r0.status < 400, json: async () => r0.json };
    if (!res.ok && res.status >= 500) {
      return { delivered: false, kind: "servidor", message: `Erro tempor\xE1rio do monday (HTTP ${res.status}).` };
    }
    const json = await res.json();
    if (json.error_message && !json.data) {
      return { delivered: false, kind: classifyMondayError(json.error_message, res.status), message: scrub(json.error_message, token) };
    }
    const topLevel = (json.errors ?? []).find((e) => !e.path?.length);
    if (topLevel && (!json.data || Object.values(json.data).every((v) => !v))) {
      const msg = topLevel.message ?? json.error_message ?? "Erro na chamada ao monday.";
      return { delivered: false, kind: classifyMondayError(msg, res.status), message: scrub(msg, token) };
    }
    const data = json.data ?? {};
    const errMap = /* @__PURE__ */ new Map();
    (json.errors ?? []).forEach((e) => {
      const alias = String(e.path?.[0] ?? "");
      if (alias) errMap.set(alias, e.message ?? "Erro na opera\xE7\xE3o do item.");
    });
    const outcomes = items.map((it, idx) => {
      const alias = `m_${idx}`;
      const err = errMap.get(alias);
      if (err) return { key: it.key, error: scrub(err, token), kind: classifyMondayError(err) };
      const returnedId = data[alias]?.id;
      if (!returnedId) {
        const topErr = json.errors?.[0]?.message;
        const msg = topErr ? scrub(topErr, token) : it.op === "create" ? "Item n\xE3o criado pela API do monday." : "O monday n\xE3o confirmou a altera\xE7\xE3o do item.";
        return { key: it.key, error: msg, kind: classifyMondayError(msg) };
      }
      return { key: it.key, id: it.op === "create" ? returnedId : it.itemId };
    });
    return { delivered: true, outcomes };
  } catch (e) {
    const aborted = e?.name === "AbortError";
    return {
      delivered: false,
      kind: aborted ? "timeout" : "rede",
      message: aborted ? "Tempo limite de 60 segundos excedido." : "Falha de conex\xE3o com o monday."
    };
  } finally {
    clearTimeout(timer);
  }
}
var safeId = (id) => id.replace(/[^\w-]/g, "");
async function mondayReadGroupItems(token, boardId, groupId, columnIds) {
  const ids = columnIds.map(safeId).filter(Boolean);
  const colSel = ids.length ? `column_values(ids: [${ids.map((c) => `"${c}"`).join(", ")}]) { id text value }` : "";
  const first = `query ($board: [ID!], $group: [String]) { boards(ids: $board) { groups(ids: $group) { items_page(limit: 500) { cursor items { id name ${colSel} } } } } }`;
  const next = `query ($cursor: String!) { next_items_page(limit: 500, cursor: $cursor) { cursor items { id name ${colSel} } } }`;
  const out = [];
  const push = (p) => p?.items.forEach((it) => {
    const values = {};
    (it.column_values ?? []).forEach((cv) => {
      values[cv.id] = { text: cv.text, value: cv.value };
    });
    out.push({ id: String(it.id), name: it.name, values });
  });
  const r1 = await mondayCallOnce(token, first, { board: [boardId], group: [groupId] });
  if (!r1.ok) return { ok: false, kind: classifyMondayError(r1.message), message: r1.message };
  let page = r1.data.boards?.[0]?.groups?.[0]?.items_page;
  push(page);
  let guard = 0;
  while (page?.cursor && guard < 60) {
    const r = await mondayCallOnce(token, next, { cursor: page.cursor });
    if (!r.ok) return { ok: false, kind: classifyMondayError(r.message), message: r.message };
    page = r.data.next_items_page;
    push(page);
    guard++;
  }
  return { ok: true, items: out };
}
async function mondayListGroupItems(token, boardId, groupId, emailColumnId) {
  const res = await mondayReadGroupItems(token, boardId, groupId, emailColumnId ? [emailColumnId] : []);
  if (!res.ok) return res;
  return {
    ok: true,
    items: res.items.map((it) => ({ name: it.name, email: emailColumnId ? it.values[safeId(emailColumnId)]?.text ?? "" : "" }))
  };
}
async function mondayItemGroups(token, itemIds) {
  const res = await mondayCallOnce(
    token,
    `query ($ids: [ID!]) { items(ids: $ids, limit: 100) { id group { id } } }`,
    { ids: itemIds }
  );
  if (!res.ok) return { ok: false, kind: classifyMondayError(res.message), message: res.message };
  const groups = /* @__PURE__ */ new Map();
  (res.data.items ?? []).forEach((it) => {
    if (it.group?.id) groups.set(String(it.id), it.group.id);
  });
  return { ok: true, groups };
}
function toColumnValue(type, raw) {
  const v = raw.trim();
  if (!v) return null;
  switch (type) {
    case "text":
      return v;
    case "long_text":
      return { text: v };
    case "numbers": {
      const n2 = v.replace(/\s/g, "").replace(/\.(?=\d{3}(\D|$))/g, "").replace(",", ".");
      return /^-?\d+(\.\d+)?$/.test(n2) ? n2 : null;
    }
    case "email": {
      const email = v.match(/[^\s<>"',;]+@[^\s<>"',;]+/)?.[0];
      return email ? { email, text: email } : null;
    }
    case "link":
      return { url: v, text: v };
    case "date": {
      const d = parseDateFlexible(v);
      return d ? { date: toISODate(d) } : null;
    }
    case "status":
      return { label: v };
    case "dropdown": {
      const labels = v.split(/[,;]/).map((s) => s.trim()).filter(Boolean);
      return labels.length ? { labels } : null;
    }
    case "checkbox":
      return /^(true|1|sim|v|x)$/i.test(v) ? { checked: "true" } : null;
    default:
      return null;
  }
}

// src/generated/server/base.server.ts
function valuesFingerprint(v) {
  return JSON.stringify(Object.entries(v ?? {}).sort(([a], [b]) => a.localeCompare(b)));
}
function sameRow(a, b) {
  return rowFingerprint(a) === rowFingerprint(b) && valuesFingerprint(a.boardValues) === valuesFingerprint(b.boardValues);
}
var META_DOC_ID = "main_meta";
var PROJECTS_DOC_ID = "main_projects";
var BOARD_IDS_DOC_ID = "main_board_ids";
var CHUNK_SIZE = 150;
async function requireBaseAccess(claim3) {
  const session = await resolveSession(claim3);
  if (!(session.isOwner || session.isPmo)) {
    throw new Error("Apenas o dono do app e os membros da lista de PMOs t\xEAm acesso \xE0 Base.");
  }
  return session;
}
async function requireManager(claim3) {
  const session = await resolveSession(claim3);
  if (!session.canManage) throw new Error("Apenas o dono, Administradores e membros do PMO podem atualizar o painel.");
  return session;
}
async function loadBaseRows() {
  const metaDoc = await dbReadWithRetry("base_meta", () => db.collection(snapshotMetaCollection).doc(META_DOC_ID).get());
  const meta = metaDoc?.data ?? null;
  const count = meta?.chunkCount ?? 0;
  const docs = await Promise.all(
    Array.from(
      { length: count },
      (_, i) => dbReadWithRetry(`base_chunk_${i}`, () => db.collection(engagementChunksCollection).doc(`chunk_${i}`).get())
    )
  );
  if (docs.some((d) => !d?.data)) throw new Error("A Base salva est\xE1 incompleta no momento da leitura. Tente de novo.");
  const rows = [];
  docs.forEach((d) => rows.push(...d?.data?.rows ?? []));
  return { rows, meta };
}
async function saveBaseRows(rows, session, report) {
  const chunks = [];
  for (let i = 0; i < rows.length; i += CHUNK_SIZE) chunks.push(rows.slice(i, i + CHUNK_SIZE));
  for (let idx = 0; idx < chunks.length; idx++) {
    await dbWriteWithRetry(
      `base_chunk_${idx}`,
      () => db.collection(engagementChunksCollection).doc(`chunk_${idx}`).set({ index: idx, rows: chunks[idx] ?? [] })
    );
  }
  for (let guard = 0; guard < 20; guard++) {
    const stale = await db.collection(engagementChunksCollection).where("index", ">=", chunks.length).limit(500).get();
    if (stale.length === 0) break;
    await Promise.all(stale.map((d) => db.collection(engagementChunksCollection).doc(d.id).delete()));
  }
  const [prevMeta, projects] = await Promise.all([
    db.collection(snapshotMetaCollection).doc(META_DOC_ID).get(),
    db.collection(projectsDocCollection).doc(PROJECTS_DOC_ID).get()
  ]);
  const meta = {
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedBy: { id: session.id, name: session.name, email: session.email },
    rowsCount: rows.length,
    projectsCount: projects?.data ? filterActiveProjects(projects.data.projects).length : prevMeta?.data?.projectsCount ?? 0,
    chunkCount: chunks.length,
    importReport: report ?? prevMeta?.data?.importReport
  };
  await dbWriteWithRetry("base_meta", () => db.collection(snapshotMetaCollection).doc(META_DOC_ID).set(meta));
}
function upsertInto(base, incoming, mode) {
  const map = /* @__PURE__ */ new Map();
  base.forEach((r) => {
    const k = baseRowKey(r);
    const prev = map.get(k);
    map.set(k, prev ? mergeRow(prev, r, "analysis") : r);
  });
  const result = { created: 0, updated: 0, unchanged: 0 };
  incoming.forEach((r) => {
    const k = baseRowKey(r);
    const prev = map.get(k);
    const next = mergeRow(prev, r, mode);
    if (!prev) result.created++;
    else if (sameRow(prev, next)) {
      result.unchanged++;
      return;
    } else result.updated++;
    map.set(k, next);
  });
  return { rows: Array.from(map.values()), result };
}
var weekDocId = (group) => `w_${normText(group).replace(/[^a-z0-9]+/g, "_").slice(0, 80) || "grupo"}`;
async function getWeekRange(group) {
  const doc = await dbReadWithRetry("week_range", () => db.collection(baseWeekStatusCollection).doc(weekDocId(group)).get());
  const d = doc?.data;
  return d?.weekStart && d.weekEnd ? { weekStart: d.weekStart, weekEnd: d.weekEnd, doc: d } : null;
}
var br = (iso2) => iso2.split("-").reverse().join("/");
async function ensureWeekRange(group, analysisDate, session, want, opts) {
  const bad = periodError(want.weekStart, want.weekEnd);
  if (bad) throw new Error(`${bad} Nada foi gravado.`);
  const stored = await getWeekRange(group);
  if (stored && stored.weekStart === want.weekStart && stored.weekEnd === want.weekEnd) return stored;
  if (stored) {
    if (stored.doc.status === "validada") {
      throw new Error(`O grupo "${group}" est\xE1 validado com o per\xEDodo ${br(stored.weekStart)} a ${br(stored.weekEnd)}. Reabra a semana antes de mudar o per\xEDodo. Nada foi gravado.`);
    }
    if (!opts?.allowChange) {
      throw new Error(`O grupo "${group}" j\xE1 existe com o per\xEDodo ${br(stored.weekStart)} a ${br(stored.weekEnd)}, e voc\xEA digitou ${br(want.weekStart)} a ${br(want.weekEnd)}. Confirme a mudan\xE7a de per\xEDodo na pr\xE9via. Nada foi gravado.`);
    }
  }
  const prev = (await db.collection(baseWeekStatusCollection).doc(weekDocId(group)).get())?.data;
  const next = {
    ...prev ?? {},
    group: prev?.group ?? group,
    status: prev?.status ?? "pendente",
    updatedAt: prev?.updatedAt ?? (/* @__PURE__ */ new Date()).toISOString(),
    updatedByEmail: prev?.updatedByEmail ?? session.email,
    updatedByName: prev?.updatedByName ?? session.name,
    weekStart: want.weekStart,
    weekEnd: want.weekEnd,
    rangeFromDate: analysisDate
  };
  delete next.periodPending;
  await dbWriteWithRetry("week_range_set", () => db.collection(baseWeekStatusCollection).doc(weekDocId(group)).set(next));
  return want;
}
async function markWeekPending(group, session, reprocessed = false) {
  const ref = db.collection(baseWeekStatusCollection).doc(weekDocId(group));
  const prev = (await ref.get())?.data;
  const now = (/* @__PURE__ */ new Date()).toISOString();
  await dbWriteWithRetry(
    "week_pending",
    () => ref.set({
      ...prev ?? {},
      group: prev?.group ?? group,
      status: "pendente",
      updatedAt: now,
      updatedByEmail: session.email,
      updatedByName: session.name,
      ...reprocessed ? { lastReprocessedAt: now } : {}
    })
  );
}
function recomputeGroupChecks(rows, group, range) {
  const g = normText(group);
  let added = 0;
  let outside = 0;
  let noAccess = 0;
  const next = rows.map((r) => {
    if (normText(r.group) !== g) return r;
    const la = isoOf(r.lastAccess);
    const days = new Set(r.checkedDays ?? []);
    if (!la) noAccess++;
    else if (la < range.weekStart || la > range.weekEnd) outside++;
    else {
      const wd = weekdayOfIso(la);
      if (wd && !days.has(wd)) {
        days.add(wd);
        added++;
      }
    }
    return { ...r, weekStart: range.weekStart, weekEnd: range.weekEnd, checkedDays: sortDays(Array.from(days)) };
  });
  const byDay = emptyDayCounts();
  next.forEach((r) => {
    if (normText(r.group) !== g) return;
    (r.checkedDays ?? []).forEach((d) => {
      if (isWeekdayKey(d)) byDay[d]++;
    });
  });
  return { rows: next, added, outside, noAccess, byDay, people: next.filter((r) => normText(r.group) === g).length };
}
async function engagementBoardId() {
  const doc = await db.collection(boardIdsConfigCollection).doc(BOARD_IDS_DOC_ID).get();
  const id = doc?.data?.engagementBoardId?.trim() ?? "";
  if (!id) throw new Error("O ID do quadro de An\xE1lise de Engajamento n\xE3o est\xE1 configurado (Atualizar Painel \u2192 Sincroniza\xE7\xE3o Completa de Quadros).");
  return id;
}
async function readBoardMeta(token, boardId) {
  const res = await mondayCallOnce(
    token,
    `query ($ids: [ID!]) { boards(ids: $ids) { id name columns { id title type } groups { id title } } }`,
    { ids: [boardId] }
  );
  if (!res.ok) throw new Error(`Erro retornado pelo monday: ${res.message}`);
  const board = res.data.boards?.[0];
  if (!board) throw new Error("Quadro de An\xE1lise de Engajamento n\xE3o encontrado ou sem permiss\xE3o para o token informado.");
  return board;
}
function boardColumnRoles(columns) {
  const byTitle = (t) => columns.find((c) => normText(c.title) === normText(t));
  const weekdayCols = findWeekdayColumns(columns);
  return {
    email: columns.find((c) => c.type === "email") ?? byTitle("E-mail") ?? byTitle("Email") ?? null,
    team: byTitle("Equipes") ?? byTitle("Equipe") ?? byTitle("Times") ?? byTitle("Teams") ?? null,
    department: byTitle("Departamento") ?? null,
    lastAccess: byTitle("Ativo pela \xFAltima vez") ?? null,
    date: columns.find((c) => normText(c.title) === "date" && c.type === "date") ?? null,
    weekStart: byTitle("In\xEDcio da semana") ?? null,
    status: byTitle("Status do usu\xE1rio") ?? null,
    createdAt: byTitle("Criado em") ?? null,
    days: weekdayCols.found ?? {},
    missingDays: weekdayCols.missing
  };
}
async function readBoardAsBaseRows(token) {
  const boardId = await engagementBoardId();
  const board = await readBoardMeta(token, boardId);
  const roles = boardColumnRoles(board.columns);
  const dayCols = WEEKDAYS.map((w) => ({ key: w.key, col: roles.days[w.key] })).filter((d) => d.col);
  const valueCols = board.columns.filter((c) => isWritableType(c.type) && c.type !== "date");
  const ids = Array.from(/* @__PURE__ */ new Set([
    ...valueCols.map((c) => c.id),
    ...[roles.email, roles.lastAccess, roles.date, roles.weekStart, roles.status, roles.team, roles.department, roles.createdAt].filter(Boolean).map((c) => c.id),
    ...dayCols.map((d) => d.col.id)
  ]));
  const map = /* @__PURE__ */ new Map();
  let duplicates = 0;
  for (const g of board.groups) {
    const res = await mondayReadGroupItems(token, boardId, g.id, ids);
    if (!res.ok) throw new Error(`Erro retornado pelo monday ao ler o grupo "${g.title}": ${res.message}`);
    res.items.forEach((it) => {
      const t = (c) => c ? (it.values[c.id]?.text ?? "").trim() : "";
      const checks = dayCols.filter((d) => isCheckedValue(it.values[d.col.id]?.value, it.values[d.col.id]?.text)).map((d) => d.key);
      const boardValues = {};
      valueCols.forEach((c) => {
        const v = (it.values[c.id]?.text ?? "").trim();
        if (v) boardValues[c.title] = v;
      });
      const row = {
        name: it.name.trim(),
        email: t(roles.email),
        team: t(roles.team),
        department: t(roles.department),
        lastAccess: t(roles.lastAccess) || null,
        refDate: isoOf(t(roles.date)),
        weekStart: isoOf(t(roles.weekStart)) ?? (t(roles.weekStart) || null),
        userStatus: t(roles.status),
        group: g.title.trim(),
        checkedDays: sortDays(checks),
        boardValues,
        createdAt: isoOf(t(roles.createdAt))
      };
      const k = baseRowKey(row);
      const prev = map.get(k);
      if (prev) duplicates++;
      map.set(k, prev ? mergeRow(prev, row, "analysis") : row);
    });
  }
  return { board, rows: Array.from(map.values()), duplicates };
}

// src/generated/server/baseEditMirror.ts
var claimSchema = external_exports.object({ id: external_exports.union([external_exports.string(), external_exports.number()]).optional(), email: external_exports.string().optional(), name: external_exports.string().optional(), isAdmin: external_exports.boolean().optional() }).optional();
var queueId = (group) => `q_${normText(group).replace(/[^a-z0-9]+/g, "_").slice(0, 80) || "grupo"}`;
var teamSet = (raw) => (raw ?? "").split(/[,;]/).map((t) => normText(t)).filter(Boolean).sort().join("|");
async function enqueue(group, names, reason) {
  if (names.length === 0) return;
  const ref = db.collection(mirrorQueueCollection).doc(queueId(group));
  const cur = (await ref.get().catch(() => null))?.data;
  const merged = Array.from(/* @__PURE__ */ new Set([...cur?.pendingNames ?? [], ...names]));
  await dbWriteBestEffort(
    "editMirrorQueue",
    () => ref.set({
      group: group.trim(),
      pendingCount: Math.max(cur?.pendingCount ?? 0, merged.length),
      pendingNames: merged.slice(0, 200),
      checksPending: cur?.checksPending ?? 0,
      lastError: reason.slice(0, 500),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    })
  );
}
function findItem(items, emailCols, name, email) {
  const e = extractEmail(email);
  if (e) {
    const byEmail = items.find((it) => emailCols.some((c) => extractEmail(it.values[c.id]?.text) === e) || extractEmail(it.name) === e);
    if (byEmail) return byEmail;
  }
  return items.find((it) => normText(it.name) === normText(name));
}
var mirrorEditedRows = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    keys: external_exports.array(external_exports.string().min(1).max(800)).min(1).max(200),
    token: external_exports.unknown().optional().transform(() => "app"),
    clientClaim: claimSchema
  })
).handler(async ({ data }) => {
  await requireBaseAccess(data.clientClaim);
  const { rows } = await loadBaseRows();
  const wanted = new Set(data.keys);
  const edited = rows.filter((r) => wanted.has(baseRowKey(r)));
  const byGroup = /* @__PURE__ */ new Map();
  edited.forEach((r) => {
    const g = (r.group ?? "").trim();
    byGroup.set(g, [...byGroup.get(g) ?? [], r]);
  });
  const failures = [];
  let confirmed = 0;
  const token = data.token?.trim() ?? "";
  if (!token) {
    for (const [group, list] of byGroup) await enqueue(group, list.map((r) => r.name), "Editado na Base sem token: aguardando envio ao quadro.");
    return { confirmed: 0, failures: edited.map((r) => ({ name: r.name, group: r.group ?? "", reason: "Sem token: ficou na fila da semana." })), skipped: true };
  }
  const boardId = await engagementBoardId();
  const board = await readBoardMeta(token, boardId);
  const roles = boardColumnRoles(board.columns);
  const emailCols = board.columns.filter((c) => c.type === "email" || normText(c.title).includes("email"));
  const writable = (c) => c && (isWritableType(c.type) || c.type === "checkbox") ? c : null;
  const laCol = writable(roles.lastAccess);
  const teamCol = writable(roles.team);
  const deptCol = writable(roles.department);
  const statusCol = writable(roles.status);
  const dayCols = WEEKDAYS.map((w) => ({ key: w.key, col: roles.days[w.key] ?? null }));
  const readIds = [...emailCols, laCol, teamCol, deptCol, statusCol, ...dayCols.map((d) => d.col)].filter(Boolean).map((c) => c.id);
  for (const [group, list] of byGroup) {
    const fail = (r, reason) => failures.push({ name: r.name, group, reason });
    const g = board.groups.find((x) => normText(x.title) === normText(group));
    if (!g) {
      list.forEach((r) => fail(r, `Grupo "${group}" n\xE3o existe no quadro.`));
      await enqueue(group, list.map((r) => r.name), `Grupo "${group}" n\xE3o existe no quadro.`);
      continue;
    }
    const before = await mondayReadGroupItems(token, boardId, g.id, readIds);
    if (!before.ok) {
      list.forEach((r) => fail(r, `Erro do monday ao ler o grupo: ${before.message}`));
      await enqueue(group, list.map((r) => r.name), before.message);
      continue;
    }
    const ops = [];
    list.forEach((r) => {
      const it = findItem(before.items, emailCols, r.name, r.email);
      if (!it) {
        fail(r, "Item da pessoa n\xE3o encontrado neste grupo do quadro.");
        return;
      }
      const cv = {};
      if (laCol) cv[laCol.id] = r.lastAccess ? toColumnValue(laCol.type, r.lastAccess) : null;
      if (teamCol) cv[teamCol.id] = r.team?.trim() ? toColumnValue(teamCol.type, r.team) : null;
      if (deptCol && r.department?.trim()) cv[deptCol.id] = toColumnValue(deptCol.type, r.department);
      if (statusCol && r.userStatus?.trim()) cv[statusCol.id] = toColumnValue(statusCol.type, r.userStatus);
      dayCols.forEach(({ key, col: col3 }) => {
        if (col3) cv[col3.id] = (r.checkedDays ?? []).includes(key) ? { checked: "true" } : null;
      });
      ops.push({ key: baseRowKey(r), name: r.name, itemId: it.id, values: cv });
    });
    for (let i = 0; i < ops.length; i += 25) {
      const slice = ops.slice(i, i + 25);
      const res = await mondayUpsertItemsBatch(token, boardId, g.id, slice.map((o) => ({ key: o.key, op: "update", itemId: o.itemId, name: o.name, columnValues: o.values })));
      if (!res.delivered) console.error(`[edi\xE7\xE3o Base] lote rejeitado (${res.kind}): ${res.message}`);
    }
    const after = ops.length ? await mondayReadGroupItems(token, boardId, g.id, readIds) : { ok: true, items: [] };
    const notConfirmed = list.filter((r) => failures.some((f) => f.group === group && f.name === r.name)).map((r) => r.name);
    ops.forEach((o) => {
      const r = list.find((x) => baseRowKey(x) === o.key);
      if (!r) return;
      if (!after.ok) {
        fail(r, `Erro do monday na leitura de volta: ${after.message}`);
        notConfirmed.push(r.name);
        return;
      }
      const it = after.items.find((x) => x.id === o.itemId);
      const diffs = [];
      if (!it) diffs.push("item n\xE3o lido");
      else {
        dayCols.forEach(({ key, col: col3 }) => {
          if (!col3) return;
          const on = isCheckedValue(it.values[col3.id]?.value, it.values[col3.id]?.text);
          if (on !== (r.checkedDays ?? []).includes(key)) diffs.push(`check ${key}`);
        });
        if (laCol && (isoOf(it.values[laCol.id]?.text) ?? "") !== (isoOf(r.lastAccess) ?? "")) diffs.push("\xFAltimo acesso");
        if (teamCol && teamSet(it.values[teamCol.id]?.text) !== teamSet(r.team)) diffs.push("equipe");
        if (deptCol && r.department?.trim() && normText(it.values[deptCol.id]?.text) !== normText(r.department)) diffs.push("departamento");
        if (statusCol && r.userStatus?.trim() && normText(it.values[statusCol.id]?.text) !== normText(r.userStatus)) diffs.push("status");
      }
      if (diffs.length) {
        fail(r, `Quadro diferente da Base ap\xF3s gravar: ${diffs.join(", ")}.`);
        notConfirmed.push(r.name);
      } else confirmed++;
    });
    await enqueue(group, notConfirmed, failures.find((f) => f.group === group)?.reason ?? "");
  }
  return { confirmed, failures, skipped: false };
});

// src/generated/server/baseManagement.ts
var baseManagement_exports = {};
__export(baseManagement_exports, {
  applyBaseFromBoard: () => applyBaseFromBoard,
  applyBaseRows: () => applyBaseRows,
  clearBaseData: () => clearBaseData,
  compareBoardAndBase: () => compareBoardAndBase,
  getBaseData: () => getBaseData,
  previewBaseRows: () => previewBaseRows,
  reprocessWeekChecks: () => reprocessWeekChecks,
  setWeekValidation: () => setWeekValidation,
  updateBaseRows: () => updateBaseRows
});
var claimSchema2 = external_exports.object({ id: external_exports.union([external_exports.string(), external_exports.number()]).optional(), email: external_exports.string().optional(), name: external_exports.string().optional(), isAdmin: external_exports.boolean().optional() }).optional();
var tokenSchema = external_exports.unknown().optional().transform(() => "app");
var SYNC_DOC_ID = "main_sync";
var rowSchema = external_exports.object({
  name: external_exports.string().max(500),
  email: external_exports.string().max(500),
  team: external_exports.string().max(5e3),
  department: external_exports.string().max(2e3),
  lastAccess: external_exports.string().max(100).nullable(),
  refDate: external_exports.string().max(100).nullable(),
  weekStart: external_exports.string().max(100).nullable(),
  weekEnd: external_exports.string().max(10).nullable().optional(),
  userStatus: external_exports.string().max(200).optional(),
  group: external_exports.string().min(1).max(500),
  checkedDays: external_exports.array(external_exports.string().max(5)).max(7).optional()
});
var toRow = (r) => ({ ...r, checkedDays: cleanDays(r.checkedDays) });
var getBaseData = createServerFn({ method: "POST" }).validator(external_exports.object({ clientClaim: claimSchema2 })).handler(async ({ data }) => {
  await requireBaseAccess(data.clientClaim);
  const [{ rows, meta }, weeks, sync, queues, deletions, weekLog] = await Promise.all([
    loadBaseRows(),
    db.collection(baseWeekStatusCollection).limit(500).get(),
    db.collection(baseSyncStatusCollection).doc(SYNC_DOC_ID).get(),
    db.collection(mirrorQueueCollection).limit(200).get(),
    db.collection(baseDeletionLogCollection).orderBy("deletedAt", "desc").limit(5).get().catch(() => []),
    db.collection(baseWeekLogCollection).orderBy("at", "desc").limit(8).get().catch(() => [])
  ]);
  return {
    rows,
    updatedAt: meta?.updatedAt ?? null,
    updatedByName: meta?.updatedBy?.name ?? null,
    projectsCount: meta?.projectsCount ?? 0,
    weekStatus: weeks.map((w) => w.data),
    sync: sync?.data ?? null,
    queues: queues.map((q) => q.data),
    deletions: deletions.map((d) => d.data),
    weekLog: weekLog.map((d) => d.data)
  };
});
var setWeekValidation = createServerFn({ method: "POST" }).validator(external_exports.object({ group: external_exports.string().trim().min(1).max(500), status: external_exports.literal("validada"), clientClaim: claimSchema2 })).handler(async ({ data }) => {
  const session = await requireManager(data.clientClaim);
  const prev = (await db.collection(baseWeekStatusCollection).doc(weekDocId(data.group)).get())?.data;
  if (prev?.periodPending && !(prev.weekStart && prev.weekEnd)) throw new Error("Defina o per\xEDodo da semana antes de validar.");
  const doc = {
    ...prev ?? {},
    group: prev?.group ?? data.group,
    status: data.status,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedByEmail: session.email,
    updatedByName: session.name
  };
  await dbWriteWithRetry("setWeekValidation", () => db.collection(baseWeekStatusCollection).doc(weekDocId(data.group)).set(doc));
  return doc;
});
var reprocessWeekChecks = createServerFn({ method: "POST" }).validator(external_exports.object({ group: external_exports.string().trim().min(1).max(500), clientClaim: claimSchema2 })).handler(async ({ data }) => {
  const session = await requireBaseAccess(data.clientClaim);
  const range = await getWeekRange(data.group);
  if (!range) {
    throw new Error(`O grupo "${data.group}" n\xE3o tem per\xEDodo guardado. Defina o per\xEDodo (domingo a s\xE1bado) da semana antes de recalcular.`);
  }
  const { rows } = await loadBaseRows();
  const res = recomputeGroupChecks(rows, data.group, range);
  if (res.people === 0) throw new Error(`O grupo "${data.group}" n\xE3o tem linhas na Base.`);
  await saveBaseRows(res.rows, session);
  await markWeekPending(data.group, session, true);
  return { weekStart: range.weekStart, weekEnd: range.weekEnd, people: res.people, added: res.added, outside: res.outside, noAccess: res.noAccess, byDay: res.byDay };
});
var clearBaseData = createServerFn({ method: "POST" }).validator(external_exports.object({ token: external_exports.unknown().optional().transform(() => "app"), clientClaim: claimSchema2 })).handler(async ({ data }) => {
  const session = await requireBaseAccess(data.clientClaim);
  await assertTokenOwner(session, data.token);
  const before = await loadBaseRows().catch(() => ({ rows: [] }));
  for (let guard = 0; guard < 20; guard++) {
    const docs = await db.collection(engagementChunksCollection).limit(500).get();
    if (docs.length === 0) break;
    await Promise.all(docs.map((d) => db.collection(engagementChunksCollection).doc(d.id).delete()));
  }
  await db.collection(snapshotMetaCollection).doc(META_DOC_ID).delete().catch(() => null);
  await db.collection(projectsDocCollection).doc(PROJECTS_DOC_ID).delete().catch(() => null);
  await dbWriteWithRetry(
    "baseDeletionLog",
    () => db.collection(baseDeletionLogCollection).add({
      deletedAt: (/* @__PURE__ */ new Date()).toISOString(),
      deletedByEmail: session.email,
      deletedByName: session.name,
      rowsDeleted: before.rows.length
    })
  ).catch((e) => console.error("Erro ao registrar exclus\xE3o da Base:", e));
  return { success: true };
});
var previewBaseRows = createServerFn({ method: "POST" }).validator(external_exports.object({ rows: external_exports.array(rowSchema).max(3e4), clientClaim: claimSchema2 })).handler(async ({ data }) => {
  await requireBaseAccess(data.clientClaim);
  const { rows } = await loadBaseRows();
  return upsertInto(rows, data.rows.map(toRow), "rewrite").result;
});
var applyBaseRows = createServerFn({ method: "POST" }).validator(external_exports.object({ rows: external_exports.array(rowSchema).max(3e4), clientClaim: claimSchema2 })).handler(async ({ data }) => {
  const session = await requireBaseAccess(data.clientClaim);
  const { rows } = await loadBaseRows();
  const merged = upsertInto(rows, data.rows.map(toRow), "rewrite");
  await saveBaseRows(merged.rows, session);
  return merged.result;
});
var updateBaseRows = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    edits: external_exports.array(external_exports.object({
      key: external_exports.string().min(1).max(800),
      lastAccess: external_exports.string().max(100).nullable(),
      team: external_exports.string().max(5e3),
      department: external_exports.string().max(2e3),
      userStatus: external_exports.string().max(200),
      checkedDays: external_exports.array(external_exports.string().max(5)).max(7)
    })).min(1).max(2e3),
    token: external_exports.unknown().optional().transform(() => "app"),
    clientClaim: claimSchema2
  })
).handler(async ({ data }) => {
  const session = await requireBaseAccess(data.clientClaim);
  await assertTokenOwner(session, data.token);
  const { rows } = await loadBaseRows();
  const byKey = new Map(data.edits.map((e) => [e.key, e]));
  let updated = 0;
  const next = rows.map((r) => {
    const e = byKey.get(baseRowKey(r));
    if (!e) return r;
    updated++;
    return { ...r, lastAccess: e.lastAccess?.trim() || null, team: e.team.trim(), department: e.department.trim(), userStatus: e.userStatus.trim(), checkedDays: cleanDays(e.checkedDays) };
  });
  if (updated === 0) throw new Error("Nenhuma das linhas editadas foi encontrada na Base. Recarregue a aba e tente de novo.");
  await saveBaseRows(next, session);
  return { updated, notFound: data.edits.length - updated };
});
function compare(boardRows, baseRows) {
  const board = new Map(boardRows.map((r) => [baseRowKey(r), r]));
  const base = new Map(baseRows.map((r) => [baseRowKey(r), r]));
  const differences = [];
  const weeks = /* @__PURE__ */ new Map();
  const week = (g) => {
    const k = normText(g);
    const w = weeks.get(k) ?? { group: g, boardPeople: 0, basePeople: 0, boardChecks: 0, baseChecks: 0 };
    weeks.set(k, w);
    return w;
  };
  let toCreate = 0, toUpdate = 0, unchanged = 0;
  board.forEach((b, k) => {
    const w = week(b.group ?? "");
    w.boardPeople++;
    w.boardChecks += b.checkedDays?.length ?? 0;
    const a = base.get(k);
    const who = { group: b.group ?? "", name: b.name, email: b.email };
    if (!a) {
      toCreate++;
      differences.push({ ...who, type: "missing_in_base", detail: "Est\xE1 no quadro e n\xE3o est\xE1 na Base." });
      return;
    }
    if (rowFingerprint(a) === rowFingerprint(b)) {
      unchanged++;
      return;
    }
    toUpdate++;
    const bc = sortDays(b.checkedDays ?? []).join(", ") || "nenhum";
    const ac = sortDays(a.checkedDays ?? []).join(", ") || "nenhum";
    if (bc !== ac) differences.push({ ...who, type: "checked_days_diff", detail: `Checks no quadro: ${bc} \xB7 na Base: ${ac}` });
    else if ((isoOf(b.lastAccess) ?? b.lastAccess) !== (isoOf(a.lastAccess) ?? a.lastAccess)) {
      differences.push({ ...who, type: "last_access_diff", detail: `\xDAltimo acesso no quadro: ${b.lastAccess ?? "\u2014"} \xB7 na Base: ${a.lastAccess ?? "\u2014"}` });
    } else differences.push({ ...who, type: "last_access_diff", detail: "Outros campos diferentes (equipe, departamento, status ou datas)." });
  });
  let onlyInBase = 0;
  base.forEach((a, k) => {
    const w = week(a.group ?? "");
    w.basePeople++;
    w.baseChecks += a.checkedDays?.length ?? 0;
    if (!board.has(k)) {
      onlyInBase++;
      differences.push({ group: a.group ?? "", name: a.name, email: a.email, type: "missing_in_board", detail: "Est\xE1 na Base e n\xE3o est\xE1 no quadro." });
    }
  });
  return { differences, weeks: Array.from(weeks.values()), toCreate, toUpdate, unchanged, onlyInBase };
}
var compareBoardAndBase = createServerFn({ method: "POST" }).validator(external_exports.object({ token: tokenSchema, clientClaim: claimSchema2 })).handler(async ({ data }) => {
  const session = await requireBaseAccess(data.clientClaim);
  const [{ rows: boardRows, duplicates }, { rows: baseRows }] = await Promise.all([readBoardAsBaseRows(data.token), loadBaseRows()]);
  const c = compare(boardRows, baseRows);
  const status = {
    checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
    checkedByName: session.name,
    inSync: c.differences.length === 0,
    boardRows: boardRows.length,
    baseRows: baseRows.length,
    differencesCount: c.differences.length,
    differences: c.differences.slice(0, 300),
    weeks: c.weeks
  };
  await dbWriteWithRetry("baseSync", () => db.collection(baseSyncStatusCollection).doc(SYNC_DOC_ID).set(status));
  return { status, preview: { toCreate: c.toCreate, toUpdate: c.toUpdate, unchanged: c.unchanged, onlyInBase: c.onlyInBase, boardDuplicates: duplicates } };
});
var applyBaseFromBoard = createServerFn({ method: "POST" }).validator(external_exports.object({ token: tokenSchema, mode: external_exports.enum(["all", "diff"]), clientClaim: claimSchema2 })).handler(async ({ data }) => {
  const session = await requireBaseAccess(data.clientClaim);
  const [{ rows: boardRows }, { rows: baseRows }] = await Promise.all([readBoardAsBaseRows(data.token), loadBaseRows()]);
  let finalRows;
  let result;
  if (data.mode === "all") {
    const c = compare(boardRows, baseRows);
    finalRows = boardRows;
    result = { created: c.toCreate, updated: c.toUpdate, unchanged: c.unchanged, removed: c.onlyInBase };
  } else {
    const base = new Map(baseRows.map((r) => [baseRowKey(r), r]));
    const changed = boardRows.filter((b) => {
      const a = base.get(baseRowKey(b));
      return !a || rowFingerprint(a) !== rowFingerprint(b);
    });
    const merged = upsertInto(baseRows, changed, "board");
    finalRows = merged.rows;
    result = { ...merged.result, unchanged: boardRows.length - changed.length, removed: 0 };
  }
  await saveBaseRows(finalRows, session);
  const c2 = compare(boardRows, finalRows);
  await dbWriteWithRetry(
    "baseSync",
    () => db.collection(baseSyncStatusCollection).doc(SYNC_DOC_ID).set({
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      checkedByName: session.name,
      inSync: c2.differences.length === 0,
      boardRows: boardRows.length,
      baseRows: finalRows.length,
      differencesCount: c2.differences.length,
      differences: c2.differences.slice(0, 300),
      weeks: c2.weeks
    })
  );
  return result;
});

// src/generated/server/communication.ts
var communication_exports = {};
__export(communication_exports, {
  getCommunication: () => getCommunication,
  getCommunicationJob: () => getCommunicationJob,
  runCommunicationWeek: () => runCommunicationWeek
});
var claim2 = external_exports.object({ id: external_exports.union([external_exports.string(), external_exports.number()]).optional(), email: external_exports.string().optional(), name: external_exports.string().optional(), isAdmin: external_exports.boolean().optional() }).optional();
async function requireManager2(c) {
  const s = await resolveSession(c);
  if (!s.canManage) throw new Error("Apenas o dono, Administradores e membros do PMO podem recalcular a comunica\xE7\xE3o.");
  return s;
}
var getCommunication = createServerFn({ method: "POST" }).validator(external_exports.object({ clientClaim: claim2, weeks: external_exports.number().int().min(1).max(52).optional() })).handler(async ({ data }) => {
  await resolveSession(data.clientClaim);
  const db2 = await mongo();
  const col3 = db2.collection(COMM_COLLECTION);
  const starts = (await col3.distinct("weekStart")).sort().reverse().slice(0, data.weeks ?? 12);
  const rows = await col3.find({ weekStart: { $in: starts } }, { projection: { _id: 0 } }).toArray();
  const weeks = starts.map((s) => {
    const r = rows.find((x) => x.weekStart === s);
    return { weekStart: s, weekEnd: r.weekEnd, week: r.week, weekNumber: r.weekNumber };
  });
  const last = await db2.collection("comm_runs").find({}).sort({ at: -1 }).limit(1).toArray();
  return { rows, weeks, lastRun: last[0] ? { at: last[0].at, week: last[0].week } : null, nextWeekStart: lastCompleteWeek(), boardId: COMM_BOARD_ID };
});
var runCommunicationWeek = createServerFn({ method: "POST" }).validator(external_exports.object({ clientClaim: claim2, weekStart: external_exports.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional() })).handler(async ({ data }) => {
  await requireManager2(data.clientClaim);
  return startJob("weekly", data.weekStart);
});
var getCommunicationJob = createServerFn({ method: "POST" }).validator(external_exports.object({ clientClaim: claim2 })).handler(async ({ data }) => {
  await requireManager2(data.clientClaim);
  return jobState();
});

// src/generated/server/mirror.ts
var mirror_exports = {};
__export(mirror_exports, {
  applyLegacyWeekToBase: () => applyLegacyWeekToBase,
  applyWeekToBase: () => applyWeekToBase,
  finishMirrorRun: () => finishMirrorRun,
  getMirrorQueues: () => getMirrorQueues,
  getWeekPreviewContext: () => getWeekPreviewContext,
  mirrorWriteBatch: () => mirrorWriteBatch,
  prepareMirror: () => prepareMirror,
  resetLegacyWeekForRewrite: () => resetLegacyWeekForRewrite,
  startMirrorRun: () => startMirrorRun
});

// src/generated/lib/userStatus.ts
var ACTIVE_USER_STATUS = "Ativado";
function norm2(s) {
  return (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim();
}
function isActivatedStatus(status) {
  return norm2(status) === norm2(ACTIVE_USER_STATUS);
}
function countDistinctPeople(rows) {
  const set = /* @__PURE__ */ new Set();
  rows.forEach((r) => {
    const e = norm2(r.email).replace(/\s/g, "");
    set.add(e.includes("@") ? e : norm2(r.name));
  });
  set.delete("");
  return set.size;
}

// src/generated/lib/legacyBase.ts
function legacyAccess(lastAccess, analysisDate, range) {
  const la = toISODate(parseDateFlexible(lastAccess ?? ""));
  if (!la || la > analysisDate || la < range.weekStart) return { days: [], kind: "none" };
  if (la <= range.weekEnd) {
    const wd = weekdayOfIso(la);
    return wd ? { days: [wd], kind: "in" } : { days: [], kind: "none" };
  }
  return { days: ["sab"], kind: "after" };
}
function legacyChecks(lastAccess, analysisDate, range) {
  return cleanDays(legacyAccess(lastAccess, analysisDate, range).days);
}

// src/generated/server/weekPeriod.server.ts
var normGroupKey = (g) => normText(g);
async function logWeekAction(session, action, group, detail) {
  try {
    await dbWriteWithRetry(
      "baseWeekLog",
      () => db.collection(baseWeekLogCollection).add({
        at: (/* @__PURE__ */ new Date()).toISOString(),
        action,
        group,
        byEmail: session.email,
        byName: session.name,
        ...detail ? { detail } : {}
      })
    );
  } catch (e) {
    console.error("Erro ao registrar a a\xE7\xE3o da semana:", e);
  }
}
async function loadPendingPeriodKeys() {
  const docs = await dbReadWithRetry("semanas_pendentes", () => db.collection(baseWeekStatusCollection).limit(1e3).get());
  const out = /* @__PURE__ */ new Set();
  docs.forEach((d) => {
    if (d.data.periodPending && !(d.data.weekStart && d.data.weekEnd)) out.add(normGroupKey(d.data.group));
  });
  return out;
}
async function mirrorBoardWeeksIntoBase(session, incoming, boardGroupTitles, buildReport) {
  const [{ rows: existing }, weekDocs, queueDocs] = await Promise.all([
    loadBaseRows(),
    dbReadWithRetry("semanas_import", () => db.collection(baseWeekStatusCollection).limit(1e3).get()),
    dbReadWithRetry("fila_import", () => db.collection(mirrorQueueCollection).limit(1e3).get())
  ]);
  const boardWeeks = /* @__PURE__ */ new Map();
  boardGroupTitles.forEach((t) => {
    const k = normGroupKey(t);
    if (k && !boardWeeks.has(k)) boardWeeks.set(k, t.trim());
  });
  incoming.forEach((r) => {
    const k = normGroupKey(r.group);
    if (k && !boardWeeks.has(k)) boardWeeks.set(k, (r.group ?? "").trim());
  });
  const baseWeeks = /* @__PURE__ */ new Map();
  existing.forEach((r) => {
    const k = normGroupKey(r.group);
    if (k && !baseWeeks.has(k)) baseWeeks.set(k, (r.group ?? "").trim());
  });
  weekDocs.forEach((d) => {
    const k = normGroupKey(d.data.group);
    if (k && !baseWeeks.has(k)) baseWeeks.set(k, d.data.group);
  });
  const kept = [];
  const created = [];
  const removed = [];
  boardWeeks.forEach((title, k) => (baseWeeks.has(k) ? kept : created).push(title));
  baseWeeks.forEach((title, k) => {
    if (!boardWeeks.has(k)) removed.push(title);
  });
  const docByKey = new Map(weekDocs.map((d) => [normGroupKey(d.data.group), d.data]));
  const prevByRow = new Map(existing.map((r) => [baseRowKey(r), r]));
  const merged = /* @__PURE__ */ new Map();
  incoming.forEach((r) => {
    const gk = normGroupKey(r.group);
    if (!gk) return;
    const doc = docByKey.get(gk);
    const hasRange = Boolean(doc?.weekStart && doc.weekEnd);
    const noPeriod = !baseWeeks.has(gk) || Boolean(doc?.periodPending) && !hasRange;
    const prev = prevByRow.get(baseRowKey(r));
    const next = {
      ...r,
      group: boardWeeks.get(gk) ?? r.group,
      // Semana mantida: período guardado; semana nova (ou ainda sem período): sem período
      weekStart: noPeriod ? null : hasRange ? doc?.weekStart ?? null : r.weekStart,
      weekEnd: noPeriod ? null : hasRange ? doc?.weekEnd ?? null : prev?.weekEnd ?? null,
      createdAt: r.createdAt || prev?.createdAt || null,
      ...prev?.boardValues ? { boardValues: prev.boardValues } : {}
    };
    const key = baseRowKey(next);
    const dup = merged.get(key);
    merged.set(key, dup ? mergeRow(dup, next, "analysis") : next);
  });
  const finalRows = Array.from(merged.values());
  const peopleBy = /* @__PURE__ */ new Map();
  finalRows.forEach((r) => {
    const k = normGroupKey(r.group);
    peopleBy.set(k, (peopleBy.get(k) ?? 0) + 1);
  });
  const pendingPeriod = Array.from(boardWeeks.entries()).filter(([k]) => !baseWeeks.has(k) || docByKey.get(k)?.periodPending && !(docByKey.get(k)?.weekStart && docByKey.get(k)?.weekEnd)).map(([, t]) => t);
  const weeks = {
    kept,
    created,
    removed,
    people: Array.from(boardWeeks.entries()).map(([k, t]) => ({ group: t, people: peopleBy.get(k) ?? 0 })),
    pendingPeriod
  };
  await saveBaseRows(finalRows, session, buildReport(weeks, finalRows.length));
  const now = (/* @__PURE__ */ new Date()).toISOString();
  for (const title of created) {
    await dbWriteWithRetry(
      "semana_nova",
      () => db.collection(baseWeekStatusCollection).doc(weekDocId(title)).set({
        group: title,
        status: "pendente",
        periodPending: true,
        updatedAt: now,
        updatedByEmail: session.email,
        updatedByName: session.name
      })
    );
  }
  const removedKeys = new Set(removed.map(normGroupKey));
  for (const d of weekDocs) {
    if (removedKeys.has(normGroupKey(d.data.group))) await dbWriteWithRetry("semana_removida", () => db.collection(baseWeekStatusCollection).doc(d.id).delete());
  }
  for (const q of queueDocs) {
    if (removedKeys.has(normGroupKey(q.data.group))) await dbWriteWithRetry("fila_removida", () => db.collection(mirrorQueueCollection).doc(q.id).delete());
  }
  for (const title of removed) await logWeekAction(session, "removida_na_importacao", title, "Semana n\xE3o existe mais no quadro");
  return { weeks, report: buildReport(weeks, finalRows.length) };
}

// src/generated/server/mirror.ts
var claimSchema3 = external_exports.object({ id: external_exports.union([external_exports.string(), external_exports.number()]).optional(), email: external_exports.string().optional(), name: external_exports.string().optional(), isAdmin: external_exports.boolean().optional() }).optional();
var tokenSchema2 = external_exports.unknown().optional().transform(() => "app");
var groupSchema = external_exports.string().trim().min(1).max(255);
var RUN_LOCK_STALE_MS = 3 * 60 * 1e3;
var rowSchema2 = external_exports.object({
  name: external_exports.string().max(500),
  email: external_exports.string().max(500),
  team: external_exports.string().max(5e3),
  department: external_exports.string().max(2e3),
  lastAccess: external_exports.string().max(100).nullable(),
  refDate: external_exports.string().max(100).nullable(),
  weekStart: external_exports.string().max(100).nullable(),
  weekEnd: external_exports.string().max(10).nullable().optional(),
  userStatus: external_exports.string().max(200).optional(),
  group: external_exports.string().max(500).optional(),
  checkedDays: external_exports.array(external_exports.string().max(5)).max(7).optional(),
  boardValues: external_exports.record(external_exports.string().max(300), external_exports.string().max(5e3)).optional(),
  createdAt: external_exports.string().max(100).nullable().optional()
});
var isoSchema = external_exports.string().regex(/^\d{4}-\d{2}-\d{2}$/);
var applyLegacyWeekToBase = createServerFn({ method: "POST" }).validator(external_exports.object({ token: external_exports.unknown().optional().transform(() => "app"), groupName: groupSchema, analysisDate: isoSchema, weekStart: isoSchema, weekEnd: isoSchema, rows: external_exports.array(rowSchema2).max(2e4), rewrite: external_exports.boolean().optional(), clientClaim: claimSchema3 })).handler(async ({ data }) => {
  const session = await requireManager(data.clientClaim);
  await assertTokenOwner(session, data.token);
  const g = data.groupName.trim();
  const want = { weekStart: data.weekStart, weekEnd: data.weekEnd };
  const bad = periodError(want.weekStart, want.weekEnd);
  if (bad) throw new Error(`${bad} Nada foi gravado.`);
  const range = await ensureWeekRange(g, data.analysisDate, session, want, { allowChange: Boolean(data.rewrite) });
  const incoming = data.rows.map((r) => ({
    ...r,
    group: g,
    refDate: data.analysisDate,
    userStatus: "Ativado",
    weekStart: range.weekStart,
    weekEnd: range.weekEnd,
    checkedDays: legacyChecks(r.lastAccess, data.analysisDate, range),
    boardValues: { ...r.boardValues ?? {}, "Status do usu\xE1rio": "Ativado" }
  }));
  const { rows } = await loadBaseRows();
  const before = rows.filter((r) => normText(r.group) === normText(g)).reduce((n2, r) => n2 + (r.checkedDays?.length ?? 0), 0);
  const merged = upsertInto(rows, incoming, "analysis");
  await saveBaseRows(merged.rows, session);
  const after = merged.rows.filter((r) => normText(r.group) === normText(g)).reduce((n2, r) => n2 + (r.checkedDays?.length ?? 0), 0);
  if (after !== before && !data.rewrite) await markWeekPending(g, session);
  return { ...merged.result, weekStart: range.weekStart, weekEnd: range.weekEnd };
});
var queueId2 = (group) => `q_${normText(group).replace(/[^a-z0-9]+/g, "_").slice(0, 80) || "grupo"}`;
async function sameDateRuns(analysisDate) {
  if (!analysisDate) return [];
  const docs = await db.collection(panelUploadRunsCollection).where("analysisDate", "==", analysisDate).limit(100).get();
  return docs.filter((d) => (d.data.created ?? 0) + (d.data.updated ?? 0) + (d.data.baseCreated ?? 0) + (d.data.baseUpdated ?? 0) > 0).map((d) => d.data.groupName);
}
var getWeekPreviewContext = createServerFn({ method: "POST" }).validator(external_exports.object({ token: external_exports.unknown().optional().transform(() => "app"), groupName: groupSchema, analysisDate: external_exports.string().regex(/^\d{4}-\d{2}-\d{2}$/), clientClaim: claimSchema3 })).handler(async ({ data }) => {
  await requireManager(data.clientClaim);
  const { rows } = await loadBaseRows();
  const g = normText(data.groupName);
  const baseRows = rows.filter((r) => normText(r.group) === g);
  const sameDate = await sameDateRuns(data.analysisDate);
  const stored = await getWeekRange(data.groupName.trim());
  const weekRange = stored ? { weekStart: stored.weekStart, weekEnd: stored.weekEnd } : null;
  const statusDocs = (await db.collection(baseWeekStatusCollection).limit(500).get()).map((d) => d.data);
  const statusOf = new Map(statusDocs.map((s) => [normText(s.group), s]));
  const periods = /* @__PURE__ */ new Map();
  rows.forEach((r) => {
    const k = normText(r.group);
    if (!k || periods.has(k)) return;
    const st = statusOf.get(k);
    if (st?.periodPending) return;
    const ws = st?.weekStart ?? r.weekStart ?? "";
    const we = st?.weekEnd ?? r.weekEnd ?? "";
    if (!ws) return;
    periods.set(k, { group: r.group ?? "", weekStart: ws, weekEnd: we });
  });
  const top = Array.from(periods.values()).sort((a, b) => b.weekStart.localeCompare(a.weekStart) || b.weekEnd.localeCompare(a.weekEnd))[0];
  const reference = top ? {
    ...top,
    emails: Array.from(new Set(
      rows.filter((r) => normText(r.group) === normText(top.group)).map((r) => (r.email ?? "").toLowerCase().replace(/\s+/g, "")).filter(Boolean)
    ))
  } : null;
  let board = null;
  let boardError = null;
  if (data.token?.trim()) {
    try {
      const boardId = await engagementBoardId();
      const meta = await readBoardMeta(data.token.trim(), boardId);
      const found = meta.groups.find((x) => normText(x.title) === g);
      let groupItems = null;
      if (found) {
        const read = await mondayReadGroupItems(data.token.trim(), boardId, found.id, []);
        groupItems = read.ok ? read.items.length : null;
      }
      board = {
        name: meta.name,
        columns: meta.columns.map((c) => ({ ...c, writable: isWritableType(c.type) })),
        groupExists: Boolean(found),
        groupItems
      };
    } catch (e) {
      boardError = e.message;
    }
  }
  return {
    baseRows,
    sameGroupSameDate: sameDate.some((x) => normText(x) === g),
    otherGroupsSameDate: Array.from(new Set(sameDate.filter((x) => normText(x) !== g))),
    weekRange,
    weekStatus: stored?.doc.status ?? null,
    reference,
    board,
    boardError
  };
});
var resetLegacyWeekForRewrite = createServerFn({ method: "POST" }).validator(external_exports.object({ token: external_exports.unknown().optional().transform(() => "app"), groupName: groupSchema, analysisDate: isoSchema, weekStart: isoSchema, weekEnd: isoSchema, clientClaim: claimSchema3 })).handler(async ({ data }) => {
  const session = await requireManager(data.clientClaim);
  await assertTokenOwner(session, data.token);
  const g = data.groupName.trim();
  const want = { weekStart: data.weekStart, weekEnd: data.weekEnd };
  const bad = periodError(want.weekStart, want.weekEnd);
  if (bad) throw new Error(`${bad} Nada foi apagado.`);
  const boardId = await engagementBoardId();
  const meta = await readBoardMeta(data.token, boardId);
  const roles = boardColumnRoles(meta.columns);
  if (roles.missingDays.length > 0) throw new Error(`Faltam colunas de check no quadro: ${roles.missingDays.join(", ")}. Nada foi apagado.`);
  const found = meta.groups.find((x) => normText(x.title) === normText(g));
  let boardDeleted = false;
  if (found) {
    const del = await mondayCallOnce(
      data.token,
      `mutation ($boardId: ID!, $groupId: String!) { delete_group(board_id: $boardId, group_id: $groupId) { id } }`,
      { boardId, groupId: found.id }
    );
    if (!del.ok) throw new Error(`O monday n\xE3o apagou o grupo "${g}" (${del.message}). Nada foi apagado na Base.`);
    boardDeleted = true;
  }
  const { rows } = await loadBaseRows();
  const gk = normText(g);
  const kept = rows.filter((r) => normText(r.group) !== gk);
  const removed = rows.length - kept.length;
  const checksBefore = rows.filter((r) => normText(r.group) === gk).reduce((n2, r) => n2 + (r.checkedDays?.length ?? 0), 0);
  try {
    if (removed > 0) await saveBaseRows(kept, session);
    const ref = db.collection(baseWeekStatusCollection).doc(weekDocId(g));
    const prev = (await ref.get())?.data;
    if (prev) {
      const next = { ...prev, weekStart: want.weekStart, weekEnd: want.weekEnd, rangeFromDate: data.analysisDate, lastReprocessedAt: (/* @__PURE__ */ new Date()).toISOString() };
      delete next.counters;
      delete next.periodPending;
      await dbWriteWithRetry("semana_reescrita", () => ref.set(next));
    }
    const queues = await db.collection(mirrorQueueCollection).limit(1e3).get();
    for (const q of queues) {
      if (normText(q.data.group) === gk) await dbWriteBestEffort("fila_reescrita", () => db.collection(mirrorQueueCollection).doc(q.id).delete());
    }
  } catch (e) {
    throw new Error(`${boardDeleted ? "O grupo foi apagado no quadro, mas " : ""}a Base n\xE3o foi limpa: ${e.message}. Nada foi regravado.`);
  }
  await logWeekAction(session, "reescreveu_semana", g, `Antes: ${removed} pessoas e ${checksBefore} checks na Base${found ? "; grupo apagado no quadro" : ""}. Data da an\xE1lise ${data.analysisDate}.`);
  return { removedRows: removed, checksBefore, boardDeleted, weekStart: want.weekStart, weekEnd: want.weekEnd };
});
var applyWeekToBase = createServerFn({ method: "POST" }).validator(external_exports.object({ token: external_exports.unknown().optional().transform(() => "app"), groupName: groupSchema, analysisDate: isoSchema, weekStart: isoSchema, weekEnd: isoSchema, allowPeriodChange: external_exports.boolean().optional(), rows: external_exports.array(rowSchema2).max(2e4), deactivations: external_exports.array(external_exports.object({ name: external_exports.string().max(500), email: external_exports.string().max(500) })).max(2e4).optional(), clientClaim: claimSchema3 })).handler(async ({ data }) => {
  const session = await requireManager(data.clientClaim);
  await assertTokenOwner(session, data.token);
  const g = data.groupName.trim();
  const want = { weekStart: data.weekStart, weekEnd: data.weekEnd };
  const bad = periodError(want.weekStart, want.weekEnd);
  if (bad) throw new Error(`${bad} Nada foi gravado.`);
  if (data.analysisDate < want.weekStart || data.analysisDate > want.weekEnd) throw new Error(`${OUTSIDE_PERIOD_MESSAGE}. Nada foi gravado.`);
  const range = await ensureWeekRange(g, data.analysisDate, session, want, { allowChange: data.allowPeriodChange });
  const dayKey = weekdayOfIso(data.analysisDate);
  const incoming = data.rows.map((r) => ({
    ...r,
    group: g,
    weekStart: range.weekStart,
    weekEnd: range.weekEnd,
    checkedDays: dayKey && isoOf(r.lastAccess) === data.analysisDate ? [dayKey] : []
  }));
  const { rows } = await loadBaseRows();
  const checksOf = (list) => list.filter((r) => normText(r.group) === normText(g)).reduce((n2, r) => n2 + (r.checkedDays?.length ?? 0), 0);
  const before = checksOf(rows);
  const gk = normText(g);
  const emailKey = (e) => (e ?? "").toLowerCase().replace(/\s+/g, "");
  const wasOff = new Set(rows.filter((r) => normText(r.group) === gk && !isActivatedStatus(r.userStatus)).map(baseRowKey));
  const merged = upsertInto(rows, incoming, "analysis");
  const incomingKeys = new Set(incoming.map(baseRowKey));
  const targets = /* @__PURE__ */ new Set();
  let ignoredDeactivated = 0;
  const deactList = data.deactivations ?? [];
  const withDeact = merged.rows.map((r) => r);
  deactList.forEach((d) => {
    const ek = emailKey(d.email);
    const idx = withDeact.findIndex((r) => normText(r.group) === gk && (ek ? emailKey(r.email) === ek : baseRowKey(r) === baseRowKey({ name: d.name, email: "", group: g })));
    const found = idx >= 0 ? withDeact[idx] : void 0;
    if (!found) {
      ignoredDeactivated++;
      return;
    }
    const fk = baseRowKey(found);
    if (incomingKeys.has(fk) || !isActivatedStatus(found.userStatus)) return;
    const statusKey = Object.keys(found.boardValues ?? {}).find((k) => normText(k) === "status do usuario") ?? "Status do usu\xE1rio";
    withDeact[idx] = { ...found, userStatus: "Desativado", boardValues: { ...found.boardValues ?? {}, [statusKey]: "Desativado" } };
    targets.add(fk);
  });
  const latest = withDeact.filter((r) => normText(r.group) === gk && isActivatedStatus(r.userStatus)).map((r) => r.refDate ?? "").sort().pop() || null;
  const dated = withDeact.map(
    (r) => normText(r.group) === gk ? { ...r, ...latest && isActivatedStatus(r.userStatus) ? { refDate: latest } : {}, weekStart: range.weekStart, weekEnd: range.weekEnd } : r
  );
  await saveBaseRows(dated, session);
  if (checksOf(dated) !== before || targets.size > 0) await markWeekPending(g, session);
  const back = (await loadBaseRows()).rows.filter((r) => normText(r.group) === gk);
  const backStatus = new Map(back.map((r) => [baseRowKey(r), isActivatedStatus(r.userStatus)]));
  const reactivatedKeys = Array.from(wasOff).filter((k) => incomingKeys.has(k));
  return {
    ...merged.result,
    deactivatedExpected: targets.size,
    deactivated: Array.from(targets).filter((k) => backStatus.get(k) === false).length,
    reactivatedExpected: reactivatedKeys.length,
    reactivated: reactivatedKeys.filter((k) => backStatus.get(k) === true).length,
    ignoredDeactivated
  };
});
var startMirrorRun = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    groupName: groupSchema,
    analysisDate: external_exports.string().max(10),
    weekStart: isoSchema.optional(),
    weekEnd: isoSchema.optional(),
    fileName: external_exports.string().max(300),
    rowsRead: external_exports.number().int().min(0),
    discardedByStatus: external_exports.number().int().min(0),
    discardedByLabel: external_exports.record(external_exports.string().max(200), external_exports.number().int().min(0)).optional(),
    baseCreated: external_exports.number().int().min(0),
    baseUpdated: external_exports.number().int().min(0),
    baseUnchanged: external_exports.number().int().min(0),
    deactivated: external_exports.number().int().min(0).optional(),
    reactivated: external_exports.number().int().min(0).optional(),
    ignoredDeactivated: external_exports.number().int().min(0).optional(),
    kind: external_exports.enum(["normal", "base_antiga"]).optional(),
    legacyByStatus: external_exports.record(external_exports.string().max(200), external_exports.number().int().min(0)).optional(),
    rewrite: external_exports.object({
      before: external_exports.object({ people: external_exports.number().int().min(0), checks: external_exports.number().int().min(0), boardItems: external_exports.number().int().min(0).nullable(), analysisDate: external_exports.string().max(10).optional() }),
      after: external_exports.object({ people: external_exports.number().int().min(0), checks: external_exports.number().int().min(0) })
    }).optional(),
    clientClaim: claimSchema3
  })
).handler(async ({ data }) => {
  const session = await requireManager(data.clientClaim);
  const running2 = await db.collection(panelUploadRunsCollection).where("status", "==", "em_andamento").limit(20).get();
  const active = running2.find((r) => Date.now() - new Date(r.data.lastActivityAt).getTime() < RUN_LOCK_STALE_MS);
  if (active) throw new Error(`J\xE1 existe uma grava\xE7\xE3o em andamento (grupo "${active.data.groupName}"). Aguarde ela terminar.`);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const doc = await dbWriteWithRetry(
    "startMirrorRun",
    () => db.collection(panelUploadRunsCollection).add({
      groupName: data.groupName,
      groupId: "",
      boardId: "",
      analysisDate: data.analysisDate,
      weekday: data.analysisDate ? weekdayOfIso(data.analysisDate) ?? void 0 : void 0,
      ...data.weekStart && data.weekEnd ? { weekStart: data.weekStart, weekEnd: data.weekEnd } : {},
      fileName: data.fileName,
      startedAt: now,
      lastActivityAt: now,
      status: "em_andamento",
      toCreate: 0,
      toUpdate: 0,
      created: 0,
      updated: 0,
      checksMarked: 0,
      failed: 0,
      pending: 0,
      rowsRead: data.rowsRead,
      discardedByStatus: data.discardedByStatus,
      discardedByLabel: data.discardedByLabel ?? {},
      unchanged: data.baseUnchanged,
      baseCreated: data.baseCreated,
      baseUpdated: data.baseUpdated,
      baseUnchanged: data.baseUnchanged,
      ...data.deactivated !== void 0 ? { deactivated: data.deactivated } : {},
      ...data.reactivated !== void 0 ? { reactivated: data.reactivated } : {},
      ...data.ignoredDeactivated !== void 0 ? { ignoredDeactivated: data.ignoredDeactivated } : {},
      uploadedByEmail: session.email,
      uploadedByName: session.name,
      uploadedById: session.id,
      ignoredColumns: [],
      failures: [],
      // O token nunca é guardado no histórico
      kind: data.kind ?? "normal",
      ...data.legacyByStatus ? { legacyByStatus: data.legacyByStatus } : {},
      ...data.rewrite ? { rewrite: data.rewrite } : {}
    })
  );
  return { runId: doc.id };
});
var teamSet2 = (raw) => (raw ?? "").split(/[,;]/).map((t) => normText(t)).filter(Boolean).sort().join("|");
function sameTeams(boardText, baseTeam) {
  return teamSet2(boardText) === teamSet2(baseTeam);
}
var prepareMirror = createServerFn({ method: "POST" }).validator(external_exports.object({ token: tokenSchema2, groupName: groupSchema, createGroup: external_exports.boolean(), runId: external_exports.string().optional(), clientClaim: claimSchema3 })).handler(async ({ data }) => {
  await requireManager(data.clientClaim);
  const boardId = await engagementBoardId();
  const board = await readBoardMeta(data.token, boardId);
  const roles = boardColumnRoles(board.columns);
  if (roles.missingDays.length > 0) {
    throw new Error(`Faltam colunas de check no quadro: ${roles.missingDays.join(", ")}. A Base foi mantida; nada foi enviado ao quadro.`);
  }
  const g = normText(data.groupName);
  let group = board.groups.find((x) => normText(x.title) === g) ?? null;
  let groupCreated = false;
  if (!group && data.createGroup) {
    const created = await mondayCallOnce(
      data.token,
      `mutation ($boardId: ID!, $groupName: String!) { create_group(board_id: $boardId, group_name: $groupName) { id } }`,
      { boardId, groupName: data.groupName.trim() }
    );
    if (!created.ok) throw new Error(`Erro retornado pelo monday ao criar o grupo "${data.groupName}": ${created.message}`);
    group = { id: created.data.create_group.id, title: data.groupName.trim() };
    groupCreated = true;
  }
  const { rows } = await loadBaseRows();
  const baseRows = rows.filter((r) => normText(r.group) === g && isActivatedStatus(r.userStatus));
  const emailCols = board.columns.filter((c) => c.type === "email" || normText(c.title).includes("email"));
  const dayCols = WEEKDAYS.map((w) => ({ key: w.key, col: roles.days[w.key] ?? null }));
  const teamCol = roles.team && isWritableType(roles.team.type) ? roles.team : null;
  const statusCol = roles.status && isWritableType(roles.status.type) ? roles.status : null;
  const readIds = [...emailCols, roles.lastAccess, roles.date, teamCol, statusCol, ...dayCols.map((d) => d.col)].filter(Boolean).map((c) => c.id);
  const items = group ? await mondayReadGroupItems(data.token, boardId, group.id, readIds) : { ok: true, items: [] };
  if (!items.ok) throw new Error(`Erro retornado pelo monday ao ler o grupo: ${items.message}`);
  const byEmail = /* @__PURE__ */ new Map();
  const byName = /* @__PURE__ */ new Map();
  const seen = /* @__PURE__ */ new Map();
  items.items.forEach((it) => {
    let email = "";
    for (const c of emailCols) {
      email = extractEmail(it.values[c.id]?.text);
      if (email) break;
    }
    if (!email && it.name.includes("@")) email = extractEmail(it.name);
    if (email && !byEmail.has(email)) byEmail.set(email, it);
    const n2 = normText(it.name);
    if (n2 && !byName.has(n2)) byName.set(n2, it);
    const k = personMatchKey(it.name, email);
    seen.set(k, (seen.get(k) ?? 0) + 1);
  });
  const boardDuplicates = Array.from(seen.values()).reduce((s, n2) => s + Math.max(0, n2 - 1), 0);
  const dupKeys = new Set(Array.from(seen.entries()).filter(([, n2]) => n2 > 1).map(([k]) => k));
  const boardDuplicateNames = [];
  items.items.forEach((it) => {
    let email = "";
    for (const c of emailCols) {
      email = extractEmail(it.values[c.id]?.text);
      if (email) break;
    }
    if (!email && it.name.includes("@")) email = extractEmail(it.name);
    if (dupKeys.has(personMatchKey(it.name, email)) && boardDuplicateNames.length < 50) boardDuplicateNames.push(`${it.name}${email ? ` <${email}>` : " (sem e-mail)"} \xB7 item ${it.id}`);
  });
  const writableByTitle = /* @__PURE__ */ new Map();
  board.columns.forEach((c) => {
    if (isWritableType(c.type) && c.type !== "date" && !writableByTitle.has(normText(c.title))) writableByTitle.set(normText(c.title), c);
  });
  const laTitle = normText("Ativo pela \xFAltima vez");
  const ops = [];
  let checksExpected = 0;
  let checksConfirmed = 0;
  let checksWithoutColumn = 0;
  let teamExpected = 0;
  let teamConfirmed = 0;
  const matchedItemIds = /* @__PURE__ */ new Set();
  baseRows.forEach((r) => {
    const email = extractEmail(r.email);
    const found = email && byEmail.get(email) || byName.get(normText(r.name));
    const expected = (r.checkedDays ?? []).flatMap((d) => {
      const col3 = dayCols.find((x) => x.key === d)?.col;
      if (!col3) {
        checksWithoutColumn++;
        return [];
      }
      return [col3.id];
    });
    checksExpected += expected.length;
    const key = baseRowKey(r);
    if (!found) {
      if (teamCol && r.team?.trim()) teamExpected++;
      const values = {};
      Object.entries(r.boardValues ?? {}).forEach(([title, raw]) => {
        const col3 = writableByTitle.get(normText(title));
        if (col3 && col3.id !== teamCol?.id && normText(title) !== laTitle && raw.trim()) values[col3.id] = { type: col3.type, raw };
      });
      if (roles.email && isWritableType(roles.email.type) && email) values[roles.email.id] = { type: roles.email.type, raw: email };
      if (roles.lastAccess && isWritableType(roles.lastAccess.type) && r.lastAccess) values[roles.lastAccess.id] = { type: roles.lastAccess.type, raw: r.lastAccess };
      if (roles.date && r.refDate) values[roles.date.id] = { type: "date", raw: r.refDate };
      if (roles.createdAt && isWritableType(roles.createdAt.type) && r.createdAt) values[roles.createdAt.id] = { type: roles.createdAt.type, raw: r.createdAt };
      ops.push({ key, name: r.name || email, create: values, checks: expected });
      return;
    }
    matchedItemIds.add(found.id);
    const missing = expected.filter((id) => !isCheckedValue(found.values[id]?.value, found.values[id]?.text));
    checksConfirmed += expected.length - missing.length;
    const update = {};
    if (roles.lastAccess && isWritableType(roles.lastAccess.type) && r.lastAccess) {
      const cur = isoOf(found.values[roles.lastAccess.id]?.text) ?? "";
      const next = isoOf(r.lastAccess) ?? "";
      if (next && next > cur) update[roles.lastAccess.id] = { type: roles.lastAccess.type, raw: r.lastAccess };
    }
    if (roles.date && r.refDate) {
      const cur = isoOf(found.values[roles.date.id]?.text);
      if (!cur || r.refDate > cur) update[roles.date.id] = { type: "date", raw: r.refDate };
    }
    let team;
    if (teamCol && r.team?.trim()) {
      teamExpected++;
      if (sameTeams(found.values[teamCol.id]?.text, r.team)) teamConfirmed++;
      else team = { [teamCol.id]: { type: teamCol.type, raw: r.team.trim() } };
    }
    if (missing.length > 0 || Object.keys(update).length > 0 || team) {
      ops.push({ key, name: r.name, itemId: found.id, update: Object.keys(update).length ? update : void 0, team, checks: missing });
    }
  });
  if (statusCol) {
    rows.filter((r) => normText(r.group) === g && !isActivatedStatus(r.userStatus)).forEach((r) => {
      const email = extractEmail(r.email);
      const found = email && byEmail.get(email) || byName.get(normText(r.name));
      if (!found) return;
      matchedItemIds.add(found.id);
      if (normText(found.values[statusCol.id]?.text) === "desativado") return;
      ops.push({ key: baseRowKey(r), name: r.name, itemId: found.id, update: { [statusCol.id]: { type: statusCol.type, raw: "Desativado" } }, checks: [] });
    });
  }
  if (data.runId) {
    await dbWriteBestEffort(
      "prepareMirror",
      () => db.collection(panelUploadRunsCollection).doc(data.runId).update({ boardId, groupId: group?.id ?? "", lastActivityAt: (/* @__PURE__ */ new Date()).toISOString() })
    );
  }
  return {
    boardId,
    boardName: board.name,
    groupId: group?.id ?? "",
    groupCreated,
    ops,
    totals: {
      basePeople: baseRows.length,
      boardItems: items.items.length,
      onlyInBoard: items.items.filter((it) => !matchedItemIds.has(it.id)).length,
      boardDuplicates,
      itemsMissing: ops.filter((o) => o.create).length,
      checksExpected,
      checksConfirmed,
      checksWithoutColumn,
      teamColumn: teamCol ? `${teamCol.title} (id ${teamCol.id}, ${teamCol.type})` : null,
      fieldsPending: ops.filter((o) => o.update).length,
      boardDuplicateNames,
      teamExpected,
      teamConfirmed
    }
  };
});
var mirrorWriteBatch = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    token: tokenSchema2,
    boardId: external_exports.string().min(1),
    groupId: external_exports.string().min(1),
    runId: external_exports.string().optional(),
    items: external_exports.array(external_exports.object({
      key: external_exports.string().min(1).max(700),
      op: external_exports.enum(["create", "update"]),
      itemId: external_exports.string().optional(),
      name: external_exports.string().min(1).max(500),
      values: external_exports.record(external_exports.string(), external_exports.object({ type: external_exports.string(), raw: external_exports.string() }))
    })).min(1).max(100),
    clientClaim: claimSchema3
  })
).handler(async ({ data }) => {
  await requireManager(data.clientClaim);
  if (data.boardId !== await engagementBoardId()) {
    return { delivered: false, kind: "outro", message: "Quadro diferente do configurado. Nada foi enviado." };
  }
  const updateIds = data.items.filter((i) => i.op === "update" && i.itemId).map((i) => i.itemId);
  if (updateIds.length > 0) {
    const gc = await mondayItemGroups(data.token, updateIds);
    if (!gc.ok) return { delivered: false, kind: gc.kind, message: gc.message };
    if (updateIds.some((id) => gc.groups.get(id) !== data.groupId)) {
      return { delivered: false, kind: "outro", message: "Um dos itens n\xE3o pertence a este grupo. Envio interrompido para proteger outras semanas." };
    }
  }
  const inputs = data.items.map((it) => {
    const cv = {};
    Object.entries(it.values).forEach(([colId, v]) => {
      const val = toColumnValue(v.type, v.raw);
      if (val !== null) cv[colId] = val;
    });
    return { key: it.key, op: it.op, itemId: it.itemId, name: it.name, columnValues: cv };
  });
  const res = await mondayUpsertItemsBatch(data.token, data.boardId, data.groupId, inputs);
  if (!res.delivered) console.error(`[espelho] lote rejeitado (${res.kind}): ${res.message}`);
  else res.outcomes.filter((o) => o.error).slice(0, 3).forEach((o) => console.error(`[espelho] item rejeitado (${o.kind}): ${o.error}`));
  if (data.runId) {
    await dbWriteBestEffort(
      "mirrorWriteBatch",
      () => db.collection(panelUploadRunsCollection).doc(data.runId).update({ lastActivityAt: (/* @__PURE__ */ new Date()).toISOString() })
    );
  }
  return res;
});
var finishMirrorRun = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    runId: external_exports.string().min(1),
    groupName: groupSchema,
    status: external_exports.enum(["concluido", "concluido_com_falhas", "parado", "cancelado", "erro"]),
    stopReason: external_exports.string().max(1e3).optional(),
    toCreate: external_exports.number().int().min(0),
    toUpdate: external_exports.number().int().min(0),
    created: external_exports.number().int().min(0),
    updated: external_exports.number().int().min(0),
    checksMarked: external_exports.number().int().min(0),
    checksExpected: external_exports.number().int().min(0),
    checksWithoutColumn: external_exports.number().int().min(0),
    fieldsTodo: external_exports.number().int().min(0).optional(),
    fieldsDone: external_exports.number().int().min(0).optional(),
    teamExpected: external_exports.number().int().min(0).optional(),
    teamConfirmed: external_exports.number().int().min(0).optional(),
    failuresByStage: external_exports.record(external_exports.string().max(20), external_exports.number().int().min(0)).optional(),
    duplicateNames: external_exports.array(external_exports.string().max(700)).max(50).optional(),
    failed: external_exports.number().int().min(0),
    pending: external_exports.number().int().min(0),
    pendingNames: external_exports.array(external_exports.string().max(500)).max(200),
    checksPending: external_exports.number().int().min(0),
    failures: external_exports.array(external_exports.object({ row: external_exports.number().int().min(0), name: external_exports.string().max(500), reason: external_exports.string().max(1e3), stage: external_exports.enum(["criar", "campos", "checks", "equipes"]).optional() })).max(4e3),
    metrics: external_exports.any().optional(),
    clientClaim: claimSchema3
  })
).handler(async ({ data }) => {
  await requireManager(data.clientClaim);
  await dbWriteBestEffort(
    "finishMirrorRun",
    () => db.collection(panelUploadRunsCollection).doc(data.runId).update({
      status: data.status,
      stopReason: data.stopReason,
      toCreate: data.toCreate,
      toUpdate: data.toUpdate,
      created: data.created,
      updated: data.updated,
      checksMarked: data.checksMarked,
      checksExpected: data.checksExpected,
      checksWithoutColumn: data.checksWithoutColumn,
      failed: data.failed,
      pending: data.pending,
      fieldsTodo: data.fieldsTodo,
      fieldsDone: data.fieldsDone,
      teamExpected: data.teamExpected,
      teamConfirmed: data.teamConfirmed,
      failuresByStage: data.failuresByStage,
      duplicateNames: data.duplicateNames,
      failures: data.failures.slice(0, 500),
      metrics: data.metrics,
      finishedAt: (/* @__PURE__ */ new Date()).toISOString(),
      lastActivityAt: (/* @__PURE__ */ new Date()).toISOString()
    })
  );
  const qref = db.collection(mirrorQueueCollection).doc(queueId2(data.groupName));
  if (data.pending === 0 && data.checksPending === 0) {
    await qref.delete().catch(() => null);
  } else {
    await dbWriteBestEffort(
      "mirrorQueue",
      () => qref.set({
        group: data.groupName.trim(),
        pendingCount: data.pending,
        pendingNames: data.pendingNames.slice(0, 200),
        checksPending: data.checksPending,
        lastError: data.stopReason ?? data.failures[0]?.reason ?? "",
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      })
    );
  }
  return { ok: true };
});
var getMirrorQueues = createServerFn({ method: "POST" }).validator(external_exports.object({ clientClaim: claimSchema3 })).handler(async ({ data }) => {
  await requireManager(data.clientClaim);
  const docs = await db.collection(mirrorQueueCollection).limit(200).get();
  return docs.map((d) => ({ id: d.id, ...d.data })).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
});

// src/generated/server/panelUpdate.ts
var panelUpdate_exports = {};
__export(panelUpdate_exports, {
  createPanelItemsBatch: () => createPanelItemsBatch,
  executePanelBatch: () => executePanelBatch,
  finishPanelUpload: () => finishPanelUpload,
  getPanelBoardContext: () => getPanelBoardContext,
  getPanelUploadHistory: () => getPanelUploadHistory,
  getPanelUploadSettings: () => getPanelUploadSettings,
  listPanelGroupItems: () => listPanelGroupItems,
  resumePanelUpload: () => resumePanelUpload,
  savePanelUploadSettings: () => savePanelUploadSettings,
  startPanelUpload: () => startPanelUpload
});

// src/generated/lib/panelUploadLimits.ts
var ITEMS_PER_CALL_MIN = 1;
var ITEMS_PER_CALL_MAX = 100;
var ITEMS_PER_CALL_DEFAULT = 25;
var PARALLEL_CALLS_MIN = 1;
var PARALLEL_CALLS_MAX = 5;
var PARALLEL_CALLS_DEFAULT = 2;
var RUN_TIME_LIMIT_MS = 10 * 60 * 1e3;
function clampInt(v, min, max, fallback) {
  if (!Number.isFinite(v)) return fallback;
  return Math.min(max, Math.max(min, Math.round(v)));
}

// src/generated/server/panelUpdate.ts
var BOARD_IDS_DOC_ID2 = "main_board_ids";
var RUN_LOCK_STALE_MS2 = 3 * 60 * 1e3;
var clientClaimSchema = external_exports.object({
  id: external_exports.union([external_exports.string(), external_exports.number()]).optional(),
  email: external_exports.string().optional(),
  name: external_exports.string().optional(),
  isAdmin: external_exports.boolean().optional()
}).optional();
var tokenSchema3 = external_exports.unknown().optional().transform(() => "app");
var isoDateSchema = external_exports.string().regex(/^\d{4}-\d{2}-\d{2}$/);
async function requireManager3(claim3) {
  const session = await resolveSession(claim3);
  if (!session.canManage) throw new Error("Apenas o dono, Administradores e membros do PMO podem atualizar o painel.");
  return session;
}
async function engagementBoardId2() {
  const doc = await db.collection(boardIdsConfigCollection).doc(BOARD_IDS_DOC_ID2).get();
  const id = doc?.data?.engagementBoardId?.trim() ?? "";
  if (!id) throw new Error("O ID do quadro de An\xE1lise de Engajamento n\xE3o est\xE1 configurado. Salve-o na aba Importar.");
  return id;
}
async function readBoard2(token, boardId) {
  const res = await mondayCallOnce(
    token,
    `query ($ids: [ID!]) { boards(ids: $ids) { id name columns { id title type } groups { id title } } }`,
    { ids: [boardId] }
  );
  if (!res.ok) throw new Error(res.message);
  const board = res.data.boards?.[0];
  if (!board) throw new Error("Quadro de An\xE1lise de Engajamento n\xE3o encontrado ou sem permiss\xE3o para o token informado.");
  return board;
}
var processed = (r) => (r.created ?? 0) + (r.updated ?? 0) > 0 || r.status === "em_andamento";
async function sameDateRuns2(analysisDate) {
  const docs = await db.collection(panelUploadRunsCollection).where("analysisDate", "==", analysisDate).limit(100).get();
  return docs.filter((d) => processed(d.data)).map((d) => d.data.groupName);
}
var getPanelBoardContext = createServerFn({ method: "POST" }).validator(external_exports.object({ token: tokenSchema3, groupName: external_exports.string().trim().min(1).max(255), analysisDate: isoDateSchema, clientClaim: clientClaimSchema })).handler(async ({ data }) => {
  await requireManager3(data.clientClaim);
  if (!weekdayOfIso(data.analysisDate)) throw new Error("Data da an\xE1lise inv\xE1lida. Nada foi gravado.");
  const boardId = await engagementBoardId2();
  const board = await readBoard2(data.token, boardId);
  const weekdayCols = findWeekdayColumns(board.columns);
  if (!weekdayCols.found) {
    throw new Error(`Faltam colunas de check no quadro: ${weekdayCols.missing.join(", ")}. Crie-as no quadro; nada foi gravado.`);
  }
  const group = board.groups.find((g) => normText(g.title) === normText(data.groupName)) ?? null;
  let groupItems = null;
  if (group) {
    const relevant = board.columns.filter((c) => c.type === "email" || c.type === "date" || c.type === "checkbox" || c.type === "text" || normText(c.title).includes("email") || normText(c.title).includes("ativo")).map((c) => c.id);
    groupItems = await mondayReadGroupItems(data.token, boardId, group.id, relevant);
    if (!groupItems.ok) throw new Error(`N\xE3o foi poss\xEDvel ler o grupo "${group.title}": ${groupItems.message}`);
  }
  const sameDate = await sameDateRuns2(data.analysisDate);
  const sameGroupSameDate = sameDate.some((g) => normText(g) === normText(data.groupName));
  const otherGroupsSameDate = Array.from(new Set(sameDate.filter((g) => normText(g) !== normText(data.groupName))));
  return {
    boardName: board.name,
    columns: board.columns.map((c) => ({ ...c, writable: isWritableType(c.type) })),
    group: group ? { id: group.id, title: group.title } : null,
    groupItems: groupItems?.ok ? groupItems.items : [],
    sameGroupSameDate,
    otherGroupsSameDate
  };
});
async function assertNoRunInProgress(exceptId) {
  const running2 = await db.collection(panelUploadRunsCollection).where("status", "==", "em_andamento").limit(20).get();
  const now = Date.now();
  const active = running2.find((r) => r.id !== exceptId && now - new Date(r.data.lastActivityAt).getTime() < RUN_LOCK_STALE_MS2);
  if (active) throw new Error(`J\xE1 existe uma grava\xE7\xE3o em andamento (grupo "${active.data.groupName}"). Aguarde ela terminar.`);
}
var startPanelUpload = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    token: tokenSchema3,
    groupName: external_exports.string().trim().min(1).max(255),
    analysisDate: isoDateSchema,
    fileName: external_exports.string().max(300),
    rowsRead: external_exports.number().int().min(0),
    discardedByStatus: external_exports.number().int().min(0),
    toCreate: external_exports.number().int().min(0),
    toUpdate: external_exports.number().int().min(0),
    unchanged: external_exports.number().int().min(0),
    checksToMark: external_exports.number().int().min(0),
    checkColumnId: external_exports.string().min(1).max(100),
    updateColumnIds: external_exports.array(external_exports.string().min(1).max(100)).min(1).max(10),
    confirmOverwriteDate: external_exports.boolean().optional(),
    confirmOtherGroup: external_exports.boolean(),
    ignoredColumns: external_exports.array(external_exports.string().max(300)).max(500),
    clientClaim: clientClaimSchema
  })
).handler(async ({ data }) => {
  const session = await requireManager3(data.clientClaim);
  await assertTokenOwner(session, data.token);
  const weekday = weekdayOfIso(data.analysisDate);
  if (!weekday) return { ok: false, message: "Data da an\xE1lise inv\xE1lida. Nada foi gravado." };
  await assertNoRunInProgress();
  const sameDate = await sameDateRuns2(data.analysisDate);
  if (sameDate.some((g) => normText(g) === normText(data.groupName)) && !data.confirmOverwriteDate) {
    return { ok: false, message: `O dia ${data.analysisDate} j\xE1 foi enviado para o grupo "${data.groupName}". Confirme a reescrita na pr\xE9via para continuar.` };
  }
  if (sameDate.length > 0 && !sameDate.some((g) => normText(g) === normText(data.groupName)) && !data.confirmOtherGroup) {
    return { ok: false, message: "Esta data j\xE1 foi enviada para outro grupo. Confirme na pr\xE9via para continuar." };
  }
  const boardId = await engagementBoardId2();
  const board = await readBoard2(data.token, boardId);
  const weekdayCols = findWeekdayColumns(board.columns);
  if (!weekdayCols.found) return { ok: false, message: `Faltam colunas de check no quadro: ${weekdayCols.missing.join(", ")}.` };
  if (weekdayCols.found[weekday]?.id !== data.checkColumnId) {
    return { ok: false, message: "A coluna de check n\xE3o corresponde ao dia da data da an\xE1lise. Gere a pr\xE9via de novo." };
  }
  const existing = board.groups.find((g) => normText(g.title) === normText(data.groupName));
  let groupId = existing?.id ?? "";
  if (!existing) {
    const created = await mondayCallOnce(
      data.token,
      `mutation ($boardId: ID!, $groupName: String!) { create_group(board_id: $boardId, group_name: $groupName) { id } }`,
      { boardId, groupName: data.groupName }
    );
    if (!created.ok) return { ok: false, message: `N\xE3o foi poss\xEDvel criar o grupo "${data.groupName}": ${created.message}` };
    groupId = created.data.create_group?.id ?? "";
    if (!groupId) return { ok: false, message: `O monday n\xE3o devolveu o ID do grupo criado.` };
  }
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const doc = await dbWriteWithRetry(
    "startPanelUpload",
    () => db.collection(panelUploadRunsCollection).add({
      groupName: data.groupName,
      groupId,
      boardId,
      analysisDate: data.analysisDate,
      fileName: data.fileName,
      startedAt: now,
      lastActivityAt: now,
      status: "em_andamento",
      toCreate: data.toCreate,
      toUpdate: data.toUpdate,
      created: 0,
      updated: 0,
      checksMarked: 0,
      failed: 0,
      pending: data.toCreate + data.toUpdate,
      rowsRead: data.rowsRead,
      discardedByStatus: data.discardedByStatus,
      unchanged: data.unchanged,
      uploadedByEmail: session.email,
      uploadedByName: session.name,
      uploadedById: session.id,
      ignoredColumns: data.ignoredColumns,
      failures: []
    })
  );
  return { ok: true, runId: doc.id, groupId, boardId };
});
var createPanelItemsBatch = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    token: tokenSchema3,
    runId: external_exports.string().min(1),
    items: external_exports.array(
      external_exports.object({
        key: external_exports.string().min(1),
        op: external_exports.enum(["create", "update"]),
        itemId: external_exports.string().optional(),
        name: external_exports.string().min(1),
        values: external_exports.record(external_exports.string(), external_exports.object({ type: external_exports.string(), raw: external_exports.string() }))
      })
    ),
    clientClaim: clientClaimSchema
  })
).handler(async ({ data }) => {
  await requireManager3(data.clientClaim);
  const runDoc = await db.collection(panelUploadRunsCollection).doc(data.runId).get();
  if (!runDoc || runDoc.data.status !== "em_andamento") {
    return { delivered: false, kind: "outro", message: "A grava\xE7\xE3o n\xE3o est\xE1 em andamento." };
  }
  const { boardId, groupId } = runDoc.data;
  const updateIds = data.items.filter((i) => i.op === "update" && i.itemId).map((i) => i.itemId);
  if (updateIds.length > 0) {
    const gCheck = await mondayItemGroups(data.token, updateIds);
    if (!gCheck.ok) return { delivered: false, kind: gCheck.kind, message: gCheck.message };
    const outOfGroup = updateIds.find((id) => gCheck.groups.get(id) !== groupId);
    if (outOfGroup) {
      return {
        delivered: false,
        kind: "outro",
        message: "Um dos itens a atualizar n\xE3o pertence a este grupo. A grava\xE7\xE3o foi interrompida para proteger outras semanas."
      };
    }
  }
  const batchInputs = data.items.map((it) => {
    const cv = {};
    Object.entries(it.values).forEach(([colId, v]) => {
      const val = toColumnValue(v.type, v.raw);
      if (val !== null) cv[colId] = val;
    });
    return { key: it.key, op: it.op, itemId: it.itemId, name: it.name, columnValues: cv };
  });
  const res = await mondayUpsertItemsBatch(data.token, boardId, groupId, batchInputs);
  await dbWriteBestEffort(
    "executePanelBatch",
    () => db.collection(panelUploadRunsCollection).doc(data.runId).update({ lastActivityAt: (/* @__PURE__ */ new Date()).toISOString() })
  );
  return res;
});
var executePanelBatch = createPanelItemsBatch;
var listPanelGroupItems = createServerFn({ method: "POST" }).validator(external_exports.object({ token: tokenSchema3, runId: external_exports.string().min(1), emailColumnId: external_exports.string().nullable(), clientClaim: clientClaimSchema })).handler(async ({ data }) => {
  await requireManager3(data.clientClaim);
  const runDoc = await db.collection(panelUploadRunsCollection).doc(data.runId).get();
  if (!runDoc) throw new Error("Grava\xE7\xE3o n\xE3o encontrada.");
  const { boardId, groupId } = runDoc.data;
  return mondayListGroupItems(data.token, boardId, groupId, data.emailColumnId);
});
var finishPanelUpload = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    runId: external_exports.string().min(1),
    status: external_exports.enum(["concluido", "concluido_com_falhas", "parado", "cancelado", "erro"]),
    stopReason: external_exports.string().max(500).optional(),
    created: external_exports.number().int().min(0),
    updated: external_exports.number().int().min(0),
    checksMarked: external_exports.number().int().min(0),
    failed: external_exports.number().int().min(0),
    pending: external_exports.number().int().min(0),
    failures: external_exports.array(
      external_exports.object({
        row: external_exports.number().int().min(0),
        name: external_exports.string(),
        reason: external_exports.string()
      })
    ).max(2e3),
    metrics: external_exports.any().optional(),
    clientClaim: clientClaimSchema
  })
).handler(async ({ data }) => {
  await requireManager3(data.clientClaim);
  await dbWriteBestEffort(
    "finishPanelUpload",
    () => db.collection(panelUploadRunsCollection).doc(data.runId).update({
      status: data.status,
      stopReason: data.stopReason,
      created: data.created,
      updated: data.updated,
      checksMarked: data.checksMarked,
      failed: data.failed,
      pending: data.pending,
      failures: data.failures.slice(0, 500),
      metrics: data.metrics,
      lastActivityAt: (/* @__PURE__ */ new Date()).toISOString()
    })
  );
  return { ok: true };
});
var resumePanelUpload = createServerFn({ method: "POST" }).validator(external_exports.object({ runId: external_exports.string().min(1), clientClaim: clientClaimSchema })).handler(async ({ data }) => {
  await requireManager3(data.clientClaim);
  await assertNoRunInProgress(data.runId);
  await dbWriteBestEffort(
    "resumePanelUpload",
    () => db.collection(panelUploadRunsCollection).doc(data.runId).update({
      status: "em_andamento",
      stopReason: void 0,
      lastActivityAt: (/* @__PURE__ */ new Date()).toISOString()
    })
  );
  return { ok: true };
});
var getPanelUploadHistory = createServerFn({ method: "POST" }).validator(external_exports.object({ clientClaim: clientClaimSchema }).optional()).handler(async ({ data }) => {
  await requireManager3(data?.clientClaim);
  const docs = await db.collection(panelUploadRunsCollection).orderBy("startedAt", "desc").limit(100).get();
  return docs.map((d) => ({ id: d.id, ...d.data }));
});
var getPanelUploadSettings = createServerFn({ method: "POST" }).validator(external_exports.object({ clientClaim: clientClaimSchema }).optional()).handler(async ({ data }) => {
  const session = await resolveSession(data?.clientClaim);
  if (!session.canManage) return null;
  const doc = await db.collection(panelUploadSettingsCollection).doc(session.email).get();
  return {
    itemsPerCall: clampInt(doc?.data?.itemsPerCall ?? ITEMS_PER_CALL_DEFAULT, ITEMS_PER_CALL_MIN, ITEMS_PER_CALL_MAX, ITEMS_PER_CALL_DEFAULT),
    parallelCalls: clampInt(doc?.data?.parallelCalls ?? PARALLEL_CALLS_DEFAULT, PARALLEL_CALLS_MIN, PARALLEL_CALLS_MAX, PARALLEL_CALLS_DEFAULT)
  };
});
var savePanelUploadSettings = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    itemsPerCall: external_exports.number().int().min(ITEMS_PER_CALL_MIN).max(ITEMS_PER_CALL_MAX),
    parallelCalls: external_exports.number().int().min(PARALLEL_CALLS_MIN).max(PARALLEL_CALLS_MAX),
    clientClaim: clientClaimSchema
  })
).handler(async ({ data }) => {
  const session = await requireManager3(data.clientClaim);
  await dbWriteBestEffort(
    "savePanelUploadSettings",
    () => db.collection(panelUploadSettingsCollection).doc(session.email).set({
      itemsPerCall: data.itemsPerCall,
      parallelCalls: data.parallelCalls,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    })
  );
  return { ok: true };
});

// src/generated/server/portais.ts
var portais_exports = {};
__export(portais_exports, {
  getManualDePortais: () => getManualDePortais
});
var getManualDePortais = createServerFn({ method: "GET" }).validator(external_exports.object({ search: external_exports.string().optional() }).optional()).handler(async () => {
  return {
    success: true,
    items: []
  };
});

// src/generated/server/storage.ts
var storage_exports = {};
__export(storage_exports, {
  addTeamMapping: () => addTeamMapping,
  applyImportedSnapshot: () => applyImportedSnapshot,
  deleteAbsence: () => deleteAbsence,
  deleteTeamMapping: () => deleteTeamMapping,
  getBoardIdsConfig: () => getBoardIdsConfig,
  getPmoEmails: () => getPmoEmails,
  getStoredSnapshot: () => getStoredSnapshot,
  getUserSession: () => getUserSession,
  importSnapshotFromFiles: () => importSnapshotFromFiles,
  readImportPage: () => readImportPage,
  saveAbsence: () => saveAbsence,
  saveBoardIdsConfig: () => saveBoardIdsConfig,
  savePmoEmails: () => savePmoEmails,
  updateTeamMapping: () => updateTeamMapping,
  validateAbsence: () => validateAbsence
});

// src/generated/lib/projectMatcher.ts
var NOT_A_PROJECT_FLAG = "N\xE3o \xE9 projeto";
function normalizeName(s) {
  return (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim();
}
function hasBracketPrefix(teamName) {
  if (!teamName) return false;
  return /\[[^\]]+\]/.test(teamName);
}
function buildKnownTeamNames(projects, deParaTable) {
  const known = /* @__PURE__ */ new Set();
  Object.keys(deParaTable).forEach((k) => known.add(normalizeName(k)));
  projects.forEach((p) => {
    if (p.name) known.add(normalizeName(p.name));
    if (p.sgi) known.add(normalizeName(p.sgi));
  });
  return known;
}
function splitTeams(raw, _known) {
  if (!raw) return [];
  const results = [];
  let current = "";
  let bracketDepth = 0;
  for (let i = 0; i < raw.length; i++) {
    const char = raw[i];
    if (char === "[") {
      bracketDepth++;
      current += char;
    } else if (char === "]") {
      if (bracketDepth > 0) bracketDepth--;
      current += char;
    } else if (bracketDepth === 0 && (char === "," || char === ";" || char === "\n" || char === "\r")) {
      const trimmed = current.trim();
      if (trimmed.length > 0 && !results.includes(trimmed)) {
        results.push(trimmed);
      }
      current = "";
    } else {
      current += char;
    }
  }
  const lastTrimmed = current.trim();
  if (lastTrimmed.length > 0 && !results.includes(lastTrimmed)) {
    results.push(lastTrimmed);
  }
  return results;
}
function matchTeamToActiveProject(teamName, activeProjects, deParaTable) {
  const isBracket = hasBracketPrefix(teamName);
  if (!isBracket) {
    return { project: null, isIgnored: false, isBracketCandidate: false };
  }
  const normTeam = normalizeName(teamName);
  if (!normTeam) {
    return { project: null, isIgnored: false, isBracketCandidate: true };
  }
  const key = Object.keys(deParaTable).find((k) => normalizeName(k) === normTeam);
  if (key !== void 0) {
    const target = deParaTable[key] ?? "";
    if (normalizeName(target) === normalizeName(NOT_A_PROJECT_FLAG)) {
      return { project: null, isIgnored: true, isBracketCandidate: true };
    }
    const found = activeProjects.find((p) => normalizeName(p.name) === normalizeName(target));
    if (found) return { project: found, isIgnored: false, isBracketCandidate: true };
  }
  const byName = activeProjects.find((p) => normalizeName(p.name) === normTeam);
  if (byName) return { project: byName, isIgnored: false, isBracketCandidate: true };
  const bySgi = activeProjects.find((p) => p.sgi && normalizeName(p.sgi) === normTeam);
  if (bySgi) return { project: bySgi, isIgnored: false, isBracketCandidate: true };
  return { project: null, isIgnored: false, isBracketCandidate: true };
}

// src/generated/server/teamMapping.server.ts
var SEED_META_DOC_ID = "seed";
var LEGACY_DOC_ID = "main_team_mapping";
var SEED_ROWS = [
  ["[SE] GA", "2024/058 [SE | SEDUC SE] Gest\xE3o para aprendizagem"],
  ["Gest\xE3o GA SE", "2024/058 [SE | SEDUC SE] Gest\xE3o para aprendizagem"],
  ["[RJ] GA + GE", "2025/106 [RJ | SEEDUC Rio de Janeiro] Gest\xE3o para Aprendizagem + Gest\xE3o Estrat\xE9gica | Fase 02"],
  ["[MS] GA", "2023/037 [MS | SEDUC MS] Gest\xE3o para aprendizagem"],
  ["[BA] GA | Fase 02", "2024/013 [BA | SEC BA] Gest\xE3o para aprendizagem | Fase 02"],
  ["[RN] GA", "2026/002 [RN | SEEC RN] Gest\xE3o para Aprendizagem + Regime de Progress\xE3o Parcial | Fase 02"],
  ["[AL] EPT + GA | Fase 02", "2025/010 [AL | SEDUC AL] Educa\xE7\xE3o Profissional e Tecnol\xF3gica + Gest\xE3o para a Aprendizagem | Fase 02"],
  ["[SE] PBA", "2025/074 [SE | SEED SE] PBA | Fase 02"],
  ["[SE] CNCA Forma\xE7\xE3o", "2026/022 [SE | SEED SE] CNCA Forma\xE7\xE3o | Fase 02"],
  ["[PR] CNCA Forma\xE7\xE3o", "2025/046 [PR | SEED PR] CNCA Forma\xE7\xE3o"],
  ["[RN] CNCA Forma\xE7\xE3o", "2025/095 [RN | SEEC RN] CNCA Forma\xE7\xE3o | Fase 02"],
  ["[MS] CNCA Forma\xE7\xE3o", "2024/029 [MS | SEDUC MS] CNCA Forma\xE7\xE3o"],
  ["[SP] CNCA Forma\xE7\xE3o", "2025/030 [SP | SEDUC SP] CNCA Forma\xE7\xE3o"],
  ["[GO] CNCA Forma\xE7\xE3o", "2025/026 [GO | SEDUC GO] CNCA Forma\xE7\xE3o"],
  ["[MA] CNCA Forma\xE7\xE3o", "2025/059 [MA | SEDUC MA] CNCA Forma\xE7\xE3o | Fase 02"],
  ["[MT] CNCA Forma\xE7\xE3o", "2024/065 [MT | SEDUC MT] CNCA Forma\xE7\xE3o"],
  ["[PA] CNCA Forma\xE7\xE3o + Material", "2025/094 [PA | SEDUC PA] CNCA Forma\xE7\xE3o + Material | Fase 02"],
  ["[PI] CNCA Forma\xE7\xE3o + Material", "2025/078 [PI | SEDUC PI] CNCA Forma\xE7\xE3o + Material | RAF"],
  ["[MT] Sistema Estruturado de Ensino", "2026/056 [MT | SEDUC MT] Sistema Estruturado de Ensino | Aditivo 06"],
  ["[BR] PAR 5 | Aditivo 01", "2025/050 [BR | MEC] PAR 5 | Aditivo 01"],
  ["[BR | GIZ | MMA] Plano clima", "2026/023 [BR | MF] Coopera\xE7\xE3o t\xE9cnica para implementa\xE7\xE3o do Plano de Transforma\xE7\xE3o Ecol\xF3gica - PTE | Fase 02"],
  ["[BR | MF] Coopera\xE7\xE3o t\xE9cnica PTE", "2026/023 [BR | MF] Coopera\xE7\xE3o t\xE9cnica para implementa\xE7\xE3o do Plano de Transforma\xE7\xE3o Ecol\xF3gica - PTE | Fase 02"],
  ["[PA] Eventos Formativos", "2026/027 [PA | SEDUC PA] Eventos Formativos + Gest\xE3o de Regionais"],
  ["[SP] Forma\xE7\xE3o de Gestores", "2025/098 [SP | EFAPE SP] Escola de Gestores | Fase 02"],
  ["[SP] Forma\xE7\xE3o de Gestores - Pedag\xF3gico", "2025/098 [SP | EFAPE SP] Escola de Gestores | Fase 02"],
  ["[SP] Certifica\xE7\xE3o PECs", "2025/092 [SP | SEDUC SP] Certifica\xE7\xE3o PECs"],
  ["[PA | Parauapebas] Desenvolvimento Institucional", "2025/039 [PA | Vale | PM Parauapebas] Desenvolvimento Institucional"],
  ["[MA] Trilhos da Alfabetiza\xE7\xE3o", "2025/089 [PA | FV | SME] Trilhos da Alfabetiza\xE7\xE3o | Aditivo 02"],
  ["[PA] Trilhos da Alfabetiza\xE7\xE3o", "2025/089 [PA | FV | SME] Trilhos da Alfabetiza\xE7\xE3o | Aditivo 02"],
  ["[PA] FV EJA", "2026/009 [PA | FV | SME] Educa\xE7\xE3o de Jovens e Adultos do Ensino M\xE9dio"],
  ["[TO] Gest\xE3o de Regionais", "2024/050 [TO | SEDUC TO] Gest\xE3o de regionais"],
  ["[BR] SEBRAE", "2025/083 [BR | SEBRAE] Educa\xE7\xE3o Empreendedora | Fase 02"],
  ["[BR | CARF] Intelig\xEAncia artificial", "2026/026 [BR | CARF] Intelig\xEAncia Artificial | Aditivo"],
  ["CARF - Especialistas", "2026/026 [BR | CARF] Intelig\xEAncia Artificial | Aditivo"],
  ["[INT] Silicon Valley", "2025/086 [INT | SILICON VALLEY] Expand the strategic adoption of AI"],
  ["[BR] Pr\xEAmio Monografia Tesouro Nacional", "2025/044 [BR | STN] Pr\xEAmio Monografia Tesouro Nacional"],
  ["[BR | IU] Or\xE7amento P\xFAblico", "2024/053 [BR | IU] Or\xE7amento P\xFAblico"],
  ["[RN | IET | SEEC Rio Grande do Norte] Educa\xE7\xE3o Profissional e Tecnol\xF3gica", "2025/108 [RN | IET | SEEC Rio Grande do Norte] Educa\xE7\xE3o Profissional e Tecnol\xF3gica"],
  ["[BR | RN e PI] EPT", "2025/108 [RN | IET | SEEC Rio Grande do Norte] Educa\xE7\xE3o Profissional e Tecnol\xF3gica"]
];
async function ensureSeeded() {
  const meta = await db.collection(teamMappingMetaCollection).doc(SEED_META_DOC_ID).get();
  if (meta?.data?.seededAt) return;
  let seed = SEED_ROWS;
  try {
    const legacy = await db.collection(legacyTeamMappingCollection).doc(LEGACY_DOC_ID).get();
    const map = legacy?.data?.mapping;
    if (map && Object.keys(map).length > 0) {
      seed = Object.entries(map).map(([k, v]) => [k, v === "__NOT_A_PROJECT__" ? NOT_A_PROJECT_FLAG : v]);
    }
  } catch (e) {
    console.error("Erro ao ler de-para antigo:", e);
  }
  const now = (/* @__PURE__ */ new Date()).toISOString();
  for (const [equipe, projeto] of seed) {
    await db.collection(teamProjectRowsCollection).add({ equipe, projeto, updatedAt: now, updatedBy: "Carga inicial" });
  }
  await db.collection(teamMappingMetaCollection).doc(SEED_META_DOC_ID).set({ seededAt: now });
}
async function loadTeamMappingRows() {
  await ensureSeeded();
  const out = [];
  let cursor = void 0;
  let guard = 0;
  do {
    const base = db.collection(teamProjectRowsCollection).limit(500);
    const page = cursor ? await base.startAfter(cursor).getPage() : await base.getPage();
    page.docs.forEach((d) => out.push({ id: d.id, equipe: d.data.equipe, projeto: d.data.projeto }));
    cursor = page.cursor;
    guard++;
  } while (cursor && guard < 50);
  return out.sort((a, b) => a.equipe.localeCompare(b.equipe));
}
function rowsToTable(rows) {
  const table = {};
  rows.forEach((r) => {
    table[r.equipe] = r.projeto;
  });
  return table;
}

// src/generated/lib/vacationFlow.ts
var PROJETOS_DEPTS = ["projeto", "projetos"];
function isProjetosDepartment(dept) {
  return (dept ?? "").split(/[,;]/).some((d) => PROJETOS_DEPTS.includes(normText(d)));
}
var no = (reason) => ({ ok: false, reason });
var isSelf = (a, actor) => a.email.toLowerCase().trim() === actor.email.toLowerCase().trim();
function canValidate(a, actor) {
  if (a.fluxo !== "projetos") return no("Este per\xEDodo n\xE3o usa valida\xE7\xE3o.");
  if (a.removido) return no("Este per\xEDodo foi removido.");
  if (a.status === "validado") return no("Este per\xEDodo j\xE1 est\xE1 validado.");
  if (isSelf(a, actor)) return no("Voc\xEA n\xE3o pode validar as pr\xF3prias f\xE9rias.");
  if (!actor.isManagerOfPerson) return no("Somente o gerente dos projetos desta pessoa pode validar.");
  return { ok: true };
}
function canRemove(a, actor) {
  if (a.fluxo !== "projetos") return { ok: true };
  if (a.removido) return no("Este per\xEDodo j\xE1 foi removido.");
  if (a.status !== "validado") {
    if (isSelf(a, actor)) return { ok: true };
    return no("O gerente s\xF3 pode remover f\xE9rias que ele mesmo validou.");
  }
  if (a.validadoPor?.email && a.validadoPor.email.toLowerCase().trim() === actor.email.toLowerCase().trim()) return { ok: true };
  if (isSelf(a, actor)) return no("F\xE9rias j\xE1 validadas pelo gerente n\xE3o podem ser alteradas nem apagadas.");
  return no("Somente o gerente que validou pode remover este per\xEDodo.");
}
function canEdit(a, actor) {
  if (a.fluxo !== "projetos") return { ok: true };
  if (a.removido) return no("Este per\xEDodo foi removido.");
  if (a.status === "validado") return no("F\xE9rias j\xE1 validadas pelo gerente n\xE3o podem ser alteradas.");
  if (!isSelf(a, actor)) return no("Somente a pr\xF3pria pessoa altera um per\xEDodo pendente.");
  return { ok: true };
}

// src/generated/server/storage.ts
var META_DOC_ID2 = "main_meta";
var PROJECTS_DOC_ID2 = "main_projects";
var BOARD_IDS_DOC_ID3 = "main_board_ids";
function projectsInfoOf(doc) {
  const savedCount = doc?.projects?.length ?? 0;
  return { savedCount, importedAt: doc?.importedAt ?? null, needsReimport: savedCount > 0 && doc?.rulesVersion !== PROJECTS_STORE_VERSION };
}
var normGroup = (g) => (g ?? "").trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ");
async function loadWeekGroups(rows) {
  const statusDocs = await dbReadWithRetry("semanas", () => db.collection(baseWeekStatusCollection).limit(1e3).get());
  const byGroup = /* @__PURE__ */ new Map();
  rows.forEach((r) => {
    const k = normGroup(r.group);
    if (!k) return;
    const ref = toISODate(parseDateFlexible(r.refDate));
    const cur = byGroup.get(k);
    if (!cur) byGroup.set(k, { group: (r.group ?? "").trim(), refDate: ref });
    else if (ref > cur.refDate) cur.refDate = ref;
  });
  return Array.from(byGroup.entries()).flatMap(([k, g]) => {
    const st = statusDocs.find((d) => normGroup(d.data.group) === k)?.data;
    let weekStart = st?.weekStart ?? "";
    let weekEnd = st?.weekEnd ?? "";
    if (!weekStart || !weekEnd) {
      const ref = parseDateFlexible(g.refDate);
      if (!ref) return [];
      const sun = new Date(ref.getFullYear(), ref.getMonth(), ref.getDate() - ref.getDay());
      weekStart = toISODate(sun);
      weekEnd = toISODate(new Date(sun.getFullYear(), sun.getMonth(), sun.getDate() + 6));
    }
    return [{ group: g.group, weekStart, weekEnd, refDate: g.refDate || weekEnd }];
  });
}
async function loadLegacyGroups() {
  try {
    const docs = await db.collection(panelUploadRunsCollection).limit(1e3).get();
    return Array.from(new Set(docs.filter((d) => d.data.kind === "base_antiga").map((d) => d.data.groupName)));
  } catch (e) {
    console.error("Erro ao ler as semanas da base antiga:", e);
    return [];
  }
}
function requireManage(session) {
  if (!session.canManage) throw new Error("Apenas o dono, Administradores e membros do PMO podem fazer isso.");
}
function assertViewAsAllowed(session, viewAsManager) {
  const v = viewAsManager?.trim();
  if (!v || session.canManage) return;
  if (normalizeName(v) !== normalizeName(session.name)) {
    throw new Error("Voc\xEA n\xE3o tem permiss\xE3o para ver como outro gerente.");
  }
}
var clientClaimSchema2 = external_exports.object({
  id: external_exports.union([external_exports.string(), external_exports.number()]).optional(),
  email: external_exports.string().optional(),
  name: external_exports.string().optional(),
  isAdmin: external_exports.boolean().optional(),
  emailSource: external_exports.string().max(20).optional()
  // 'contexto' | 'me' (só para o diagnóstico)
}).optional();
var getUserSession = createServerFn({ method: "GET" }).validator(clientClaimSchema2).handler(async ({ data }) => resolveSession(data));
var getStoredSnapshot = createServerFn({ method: "GET" }).validator(
  external_exports.object({
    clientClaim: clientClaimSchema2,
    viewAsManager: external_exports.string().optional()
    // Modo "Ver como gerente" para dono/admin/PMO
  })
).handler(async ({ data }) => {
  const session = await resolveSession(data.clientClaim);
  assertViewAsAllowed(session, data.viewAsManager);
  try {
    const metaDoc = await dbReadWithRetry("meta", () => db.collection(snapshotMetaCollection).doc(META_DOC_ID2).get());
    if (!metaDoc?.data) return { hasData: false, snapshot: null };
    const meta = metaDoc.data;
    const projectsDoc = await dbReadWithRetry(
      "projetos",
      () => db.collection(projectsDocCollection).doc(PROJECTS_DOC_ID2).get()
    );
    const allProjects = filterActiveProjects(projectsDoc?.data?.projects);
    const ids = Array.from({ length: meta.chunkCount ?? 0 }, (_, i) => `chunk_${i}`);
    const chunkDocs = await Promise.all(
      ids.map((id) => dbReadWithRetry(id, () => db.collection(engagementChunksCollection).doc(id).get()))
    );
    if (chunkDocs.some((c) => !c?.data)) throw new Error("Base salva incompleta no momento da leitura.");
    const rawRows = [];
    chunkDocs.forEach((c) => {
      if (c?.data?.rows) rawRows.push(...c.data.rows);
    });
    const pendingKeys = await loadPendingPeriodKeys();
    const periodRows = pendingKeys.size > 0 ? rawRows.filter((r) => !pendingKeys.has(normGroup(r.group))) : rawRows;
    const allRows = periodRows.filter((r) => isActivatedStatus(r.userStatus));
    const excludedByStatus = countDistinctPeople(periodRows.filter((r) => !isActivatedStatus(r.userStatus)));
    const mappingRows = await dbReadWithRetry("de-para", () => loadTeamMappingRows());
    const fullTable = rowsToTable(mappingRows);
    const absenceDocs = await dbReadWithRetry(
      "afastamentos",
      () => db.collection(absencesCollection).limit(1e3).get()
    );
    const allAbsences = absenceDocs.map((d) => ({ ...d.data, id: d.id }));
    const legacyGroups = (await loadLegacyGroups()).filter((g) => !pendingKeys.has(normGroup(g)));
    const weekGroups = await loadWeekGroups(allRows);
    const userEmailNorm = normalizeEmail(session.email);
    const userProfileRecord = userEmailNorm ? allRows.find((r) => normalizeEmail(r.email) === userEmailNorm) ?? null : null;
    if (session.canManage && !data.viewAsManager) {
      const snapshot2 = {
        updatedAt: meta.updatedAt,
        updatedBy: meta.updatedBy,
        rowsCount: meta.rowsCount,
        projectsCount: meta.projectsCount,
        rows: allRows,
        projects: allProjects,
        deParaTable: fullTable,
        deParaRows: mappingRows,
        importReport: meta.importReport ?? null,
        absences: allAbsences,
        scope: "full",
        userProfileRecord,
        excludedByStatus,
        legacyGroups,
        weekGroups,
        projectsInfo: projectsInfoOf(projectsDoc?.data)
      };
      return { hasData: true, snapshot: snapshot2 };
    }
    let targetManagerName = normalizeName(session.name);
    if (data.viewAsManager && session.canManage) {
      targetManagerName = normalizeName(data.viewAsManager);
    }
    const managed = targetManagerName ? allProjects.filter((p) => p.managers.some((m) => normalizeName(m) === targetManagerName)) : [];
    const managedNames = new Set(managed.map((p) => p.name));
    const known = buildKnownTeamNames(allProjects, fullTable);
    const rows = [];
    const managedPeopleEmails = /* @__PURE__ */ new Set();
    allRows.forEach((r) => {
      const isSelf2 = userEmailNorm && normalizeEmail(r.email) === userEmailNorm;
      const kept = splitTeams(r.team, known).filter((t) => {
        const m = matchTeamToActiveProject(t, allProjects, fullTable);
        return m.project !== null && managedNames.has(m.project.name);
      });
      if (kept.length > 0) {
        rows.push({ ...r, team: kept.join(", ") });
        if (r.email) managedPeopleEmails.add(normalizeEmail(r.email));
      } else if (isSelf2) {
        rows.push(r);
      }
    });
    const allowedAbsenceEmails = new Set(managedPeopleEmails);
    if (userEmailNorm) allowedAbsenceEmails.add(userEmailNorm);
    const managerAbsences = allAbsences.filter((a) => allowedAbsenceEmails.has(normalizeEmail(a.email)));
    const table = {};
    Object.entries(fullTable).forEach(([k, v]) => {
      if (managedNames.has(v)) table[k] = v;
    });
    const snapshot = {
      updatedAt: meta.updatedAt,
      updatedBy: { id: "", name: meta.updatedBy?.name ?? "" },
      rowsCount: rows.length,
      projectsCount: managed.length,
      rows,
      projects: managed,
      deParaTable: table,
      deParaRows: [],
      importReport: null,
      absences: managerAbsences,
      scope: "manager",
      userProfileRecord,
      excludedByStatus: 0,
      legacyGroups,
      weekGroups,
      projectsInfo: projectsInfoOf(projectsDoc?.data)
    };
    return { hasData: true, snapshot };
  } catch (error) {
    console.error("Erro ao ler a base salva:", error?.message);
    throw new Error("N\xE3o foi poss\xEDvel ler a base salva agora.");
  }
});
async function absenceContext(session, targetEmail, viewAsManager) {
  const [{ rows }, projectsDoc, mappingRows] = await Promise.all([
    loadBaseRows(),
    db.collection(projectsDocCollection).doc(PROJECTS_DOC_ID2).get(),
    loadTeamMappingRows()
  ]);
  const projects = filterActiveProjects(projectsDoc?.data?.projects);
  const table = rowsToTable(mappingRows);
  const known = buildKnownTeamNames(projects, table);
  const personRows = rows.filter((r) => normalizeEmail(r.email) === targetEmail && isActivatedStatus(r.userStatus)).sort((a, b) => (b.refDate ?? "").localeCompare(a.refDate ?? ""));
  const departamento = personRows.find((r) => r.department?.trim())?.department?.trim() ?? "";
  const managerNames = /* @__PURE__ */ new Set();
  personRows.forEach(
    (r) => splitTeams(r.team, known).forEach((t) => {
      const m = matchTeamToActiveProject(t, projects, table);
      m.project?.managers.forEach((x) => managerNames.add(normalizeName(x)));
    })
  );
  let effective = normalizeName(session.name);
  if (viewAsManager && session.canManage) effective = normalizeName(viewAsManager);
  const isManagerOfPerson = Boolean(effective) && managerNames.has(effective) && normalizeEmail(session.email) !== targetEmail;
  const inBase = rows.some((r) => normalizeEmail(r.email) === targetEmail);
  return { departamento, projetos: isProjetosDepartment(departamento), isManagerOfPerson, inBase };
}
var actorOf = (session) => ({ id: session.id, name: session.name, email: session.email });
var ORIGIN_LABEL = {
  geral: "Painel Geral",
  gerente: "Painel do Gerente",
  perfil: "Meu Perfil"
};
var originSchema = external_exports.enum(["geral", "gerente", "perfil"]);
function authorizeAbsence(session, origem, viewAsManager, isSelf2, isManagerOfPerson) {
  if (origem === "geral") {
    if (!session.canManage || viewAsManager?.trim()) {
      throw new Error("Somente dono, admin ou PMO podem gerenciar afastamentos de qualquer pessoa no Painel Geral.");
    }
    return "gestao";
  }
  if (isSelf2) return "self";
  if (origem === "perfil") throw new Error("No Meu Perfil voc\xEA s\xF3 pode gerenciar o seu pr\xF3prio afastamento.");
  if (!isManagerOfPerson) {
    throw new Error("No Painel do Gerente voc\xEA s\xF3 pode gerenciar afastamentos de pessoas dos seus projetos ativos.");
  }
  return "manager";
}
var saveAbsence = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    id: external_exports.string().optional(),
    // se informado, atualiza
    email: external_exports.string().email(),
    tipo: external_exports.enum(["F\xE9rias", "Licen\xE7a"]),
    inicio: external_exports.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    volta: external_exports.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().optional(),
    origem: originSchema,
    clientClaim: clientClaimSchema2,
    viewAsManager: external_exports.string().optional()
  })
).handler(async ({ data }) => {
  const session = await resolveSession(data.clientClaim);
  assertViewAsAllowed(session, data.viewAsManager);
  const userEmail = normalizeEmail(session.email);
  const targetEmail = normalizeEmail(data.email);
  if (!userEmail) throw new Error("N\xE3o foi poss\xEDvel identificar o usu\xE1rio logado.");
  if (data.volta) {
    const dInicio = parseDateFlexible(data.inicio);
    const dVolta = parseDateFlexible(data.volta);
    if (dInicio && dVolta && dVolta.getTime() <= dInicio.getTime()) {
      throw new Error("A data de volta ao trabalho deve ser posterior \xE0 data de in\xEDcio.");
    }
  }
  const isSelf2 = userEmail === targetEmail;
  const ctx = await absenceContext(session, targetEmail, data.viewAsManager);
  const role = authorizeAbsence(session, data.origem, data.viewAsManager, isSelf2, ctx.isManagerOfPerson);
  const actor = { email: userEmail, isManagerOfPerson: ctx.isManagerOfPerson };
  const origin = ORIGIN_LABEL[data.origem];
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const existing = data.id ? await db.collection(absencesCollection).doc(data.id).get() : null;
  if (data.id && !existing) throw new Error("Per\xEDodo n\xE3o encontrado.");
  if (existing && normalizeEmail(existing.data.email) !== targetEmail) {
    throw new Error("Este per\xEDodo pertence a outra pessoa.");
  }
  if (existing?.data.removido) throw new Error("Este per\xEDodo foi removido.");
  if (existing && data.id) {
    if (role !== "gestao" && existing.data.fluxo === "projetos") {
      const allowed = canEdit(existing.data, actor);
      if (!allowed.ok) throw new Error(allowed.reason);
    }
    await db.collection(absencesCollection).doc(data.id).update({
      tipo: data.tipo,
      inicio: data.inicio,
      volta: data.volta || null,
      atualizadoEm: now,
      atualizadoPor: actorOf(session),
      atualizadoOrigem: origin
    });
    return { success: true, id: data.id, status: existing.data.status };
  }
  if (role === "gestao" && !ctx.inBase) throw new Error("Esta pessoa n\xE3o est\xE1 na Base.");
  const base = {
    email: targetEmail,
    tipo: data.tipo,
    inicio: data.inicio,
    volta: data.volta || null,
    criadoEm: now,
    criadoPor: actorOf(session),
    criadoOrigem: origin
  };
  const payload = ctx.projetos ? {
    ...base,
    fluxo: "projetos",
    departamento: ctx.departamento,
    status: role === "self" ? "pendente" : "validado",
    ...role === "self" ? {} : { validadoPor: actorOf(session), validadoEm: now }
  } : base;
  const doc = await db.collection(absencesCollection).add(payload);
  return { success: true, id: doc.id, status: payload.status };
});
var validateAbsence = createServerFn({ method: "POST" }).validator(external_exports.object({ id: external_exports.string().min(1), clientClaim: clientClaimSchema2, viewAsManager: external_exports.string().optional() })).handler(async ({ data }) => {
  const session = await resolveSession(data.clientClaim);
  assertViewAsAllowed(session, data.viewAsManager);
  const userEmail = normalizeEmail(session.email);
  if (!userEmail) throw new Error("N\xE3o foi poss\xEDvel identificar o usu\xE1rio logado.");
  const doc = await db.collection(absencesCollection).doc(data.id).get();
  if (!doc) throw new Error("Per\xEDodo n\xE3o encontrado.");
  const ctx = await absenceContext(session, normalizeEmail(doc.data.email), data.viewAsManager);
  const allowed = canValidate(doc.data, { email: userEmail, isManagerOfPerson: ctx.isManagerOfPerson });
  if (!allowed.ok) throw new Error(allowed.reason);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  await db.collection(absencesCollection).doc(data.id).update({ status: "validado", validadoPor: actorOf(session), validadoEm: now });
  return { success: true, validadoEm: now };
});
var deleteAbsence = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    id: external_exports.string().min(1),
    origem: originSchema,
    clientClaim: clientClaimSchema2,
    viewAsManager: external_exports.string().optional()
  })
).handler(async ({ data }) => {
  const session = await resolveSession(data.clientClaim);
  assertViewAsAllowed(session, data.viewAsManager);
  const userEmail = normalizeEmail(session.email);
  if (!userEmail) throw new Error("N\xE3o foi poss\xEDvel identificar o usu\xE1rio logado.");
  const doc = await db.collection(absencesCollection).doc(data.id).get();
  if (!doc) return { success: true };
  const targetEmail = normalizeEmail(doc.data.email);
  const ctx = await absenceContext(session, targetEmail, data.viewAsManager);
  const role = authorizeAbsence(session, data.origem, data.viewAsManager, userEmail === targetEmail, ctx.isManagerOfPerson);
  if (doc.data.fluxo === "projetos") {
    if (doc.data.removido) return { success: true };
    if (role !== "gestao") {
      const allowed = canRemove(doc.data, { email: userEmail, isManagerOfPerson: ctx.isManagerOfPerson });
      if (!allowed.ok) throw new Error(allowed.reason);
    }
    await db.collection(absencesCollection).doc(data.id).update({
      removido: true,
      removidoPor: actorOf(session),
      removidoEm: (/* @__PURE__ */ new Date()).toISOString(),
      removidoOrigem: ORIGIN_LABEL[data.origem]
    });
    return { success: true };
  }
  await db.collection(absencesCollection).doc(data.id).delete();
  return { success: true };
});
var getBoardIdsConfig = createServerFn({ method: "GET" }).validator(clientClaimSchema2).handler(async ({ data }) => {
  const session = await resolveSession(data);
  requireManage(session);
  try {
    const doc = await db.collection(boardIdsConfigCollection).doc(BOARD_IDS_DOC_ID3).get();
    return {
      engagementBoardId: doc?.data?.engagementBoardId ?? "",
      projectsBoardId: doc?.data?.projectsBoardId ?? ""
    };
  } catch (e) {
    console.error("Erro ao ler IDs dos quadros:", e);
    return { engagementBoardId: "", projectsBoardId: "" };
  }
});
var saveBoardIdsConfig = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    engagementBoardId: external_exports.string().max(100),
    projectsBoardId: external_exports.string().max(100),
    clientClaim: clientClaimSchema2
  })
).handler(async ({ data }) => {
  const session = await resolveSession(data.clientClaim);
  requireManage(session);
  await db.collection(boardIdsConfigCollection).doc(BOARD_IDS_DOC_ID3).set({
    engagementBoardId: data.engagementBoardId.trim(),
    projectsBoardId: data.projectsBoardId.trim(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedBy: session.name
  });
  return { success: true };
});
var getPmoEmails = createServerFn({ method: "GET" }).validator(clientClaimSchema2).handler(async ({ data }) => {
  const session = await resolveSession(data);
  requireManage(session);
  const list = await readPmoEmails();
  return { pmoEmails: Array.from(/* @__PURE__ */ new Set([OWNER_EMAIL, ...list])), ownerEmail: OWNER_EMAIL };
});
var savePmoEmails = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    emails: external_exports.array(external_exports.string()).max(1e3),
    clientClaim: clientClaimSchema2
  })
).handler(async ({ data }) => {
  const session = await resolveSession(data.clientClaim);
  requireManage(session);
  const clean2 = data.emails.map(normalizeEmail).filter((e) => e.includes("@"));
  const pmoEmails = Array.from(/* @__PURE__ */ new Set([OWNER_EMAIL, ...clean2]));
  await db.collection(pmoConfigCollection).doc(PMO_CONFIG_DOC_ID).set({
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedBy: { id: session.id, name: session.name },
    pmoEmails
  });
  return { success: true, pmoEmails };
});
function validTarget(projeto) {
  return projeto.trim().length > 0;
}
var addTeamMapping = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    equipe: external_exports.string().min(1).max(500),
    projeto: external_exports.string().min(1).max(500),
    clientClaim: clientClaimSchema2
  })
).handler(async ({ data }) => {
  const session = await resolveSession(data.clientClaim);
  requireManage(session);
  const equipe = data.equipe.trim();
  const projeto = data.projeto.trim() === NOT_A_PROJECT_FLAG ? NOT_A_PROJECT_FLAG : data.projeto.trim();
  if (!equipe || !validTarget(projeto)) throw new Error("Informe a equipe e o projeto.");
  const rows = await loadTeamMappingRows();
  const existing = rows.find((r) => normalizeName(r.equipe) === normalizeName(equipe));
  const payload = { equipe, projeto, updatedAt: (/* @__PURE__ */ new Date()).toISOString(), updatedBy: session.name };
  if (existing) {
    await db.collection(teamProjectRowsCollection).doc(existing.id).set(payload);
    return { success: true, id: existing.id };
  }
  const doc = await db.collection(teamProjectRowsCollection).add(payload);
  return { success: true, id: doc.id };
});
var updateTeamMapping = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    id: external_exports.string().min(1),
    equipe: external_exports.string().min(1).max(500),
    projeto: external_exports.string().min(1).max(500),
    clientClaim: clientClaimSchema2
  })
).handler(async ({ data }) => {
  const session = await resolveSession(data.clientClaim);
  requireManage(session);
  await db.collection(teamProjectRowsCollection).doc(data.id).set({
    equipe: data.equipe.trim(),
    projeto: data.projeto.trim(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedBy: session.name
  });
  return { success: true };
});
var deleteTeamMapping = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    id: external_exports.string().min(1),
    clientClaim: clientClaimSchema2
  })
).handler(async ({ data }) => {
  const session = await resolveSession(data.clientClaim);
  requireManage(session);
  await db.collection(teamProjectRowsCollection).doc(data.id).delete();
  return { success: true };
});
var engagementRowSchema = external_exports.object({
  name: external_exports.string().max(500),
  email: external_exports.string().max(500),
  team: external_exports.string().max(5e3),
  department: external_exports.string().max(2e3),
  lastAccess: external_exports.string().max(100),
  weekStart: external_exports.string().max(100),
  refDate: external_exports.string().max(100),
  userStatus: external_exports.string().max(200),
  // Só a importação pela API traz o grupo (semana) e os checks por dia
  group: external_exports.string().max(500).optional(),
  checkedDays: external_exports.array(external_exports.enum(["seg", "ter", "qua", "qui", "sex", "sab", "dom"])).max(7).optional(),
  createdAt: external_exports.string().max(100).optional()
});
var projectRowSchema = external_exports.object({
  name: external_exports.string().max(1e3),
  sgi: external_exports.string().max(1e3),
  sigla: external_exports.string().max(500),
  status: external_exports.string().max(200),
  managers: external_exports.string().max(2e3),
  axis: external_exports.string().max(500),
  client: external_exports.string().max(2e3),
  startDate: external_exports.string().max(100).optional().nullable()
});
function countReasons(map) {
  return Array.from(map.entries()).map(([reason, count]) => ({ reason, count })).sort((a, b) => b.count - a.count);
}
function splitList(raw) {
  return raw.split(/[,;\n]+/).map((s) => s.trim()).filter(Boolean);
}
function buildSavedProjects(projects) {
  const reasons = /* @__PURE__ */ new Map();
  const bump = (k) => reasons.set(k, (reasons.get(k) ?? 0) + 1);
  const saved = [];
  projects.forEach((p, idx) => {
    if (!p.name.trim()) return bump("Sem nome");
    const status = p.status.trim();
    const parsedStart = parseDateFlexible(p.startDate);
    saved.push({
      id: `p_${idx}`,
      name: p.name.trim(),
      sgi: p.sgi.trim(),
      sigla: p.sigla.trim(),
      status,
      managers: splitList(p.managers),
      axis: p.axis.trim(),
      client: splitList(p.client),
      startDate: parsedStart ? toISODate(parsedStart) : p.startDate?.trim() || null
    });
  });
  return { saved, reasons };
}
async function persistSnapshotData(session, engagement, projects, sourceNames) {
  const rowReasons = /* @__PURE__ */ new Map();
  const bump = (m, k) => m.set(k, (m.get(k) ?? 0) + 1);
  const rows = [];
  const excludedByStatus = engagement.filter((r) => !isActivatedStatus(r.userStatus));
  engagement.forEach((r) => {
    if (!isActivatedStatus(r.userStatus)) return bump(rowReasons, 'Status do usu\xE1rio diferente de "Ativado"');
    if (!r.name.trim() && !r.email.trim()) return bump(rowReasons, "Sem nome e sem e-mail");
    const ref = parseDateFlexible(r.refDate);
    const week = parseDateFlexible(r.weekStart);
    if (!ref && !week) return bump(rowReasons, "Sem data v\xE1lida (Date e In\xEDcio da semana)");
    rows.push({
      name: r.name.trim(),
      email: r.email.trim(),
      team: r.team.trim(),
      department: r.department.trim(),
      lastAccess: r.lastAccess.trim() || null,
      refDate: ref ? toISODate(ref) : null,
      weekStart: week ? toISODate(week) : r.weekStart.trim() || null,
      userStatus: r.userStatus.trim(),
      ...r.group?.trim() ? { group: r.group.trim() } : {},
      ...r.checkedDays && r.checkedDays.length > 0 ? { checkedDays: r.checkedDays } : {},
      ...parseDateFlexible(r.createdAt) ? { createdAt: toISODate(parseDateFlexible(r.createdAt)) } : {}
    });
  });
  const { saved: savedProjects, reasons: projReasons } = buildSavedProjects(projects);
  const existing = await loadBaseRows();
  const merged = upsertInto(existing.rows, rows, "analysis");
  await db.collection(projectsDocCollection).doc(PROJECTS_DOC_ID2).set({ projects: savedProjects, rulesVersion: PROJECTS_STORE_VERSION, importedAt: (/* @__PURE__ */ new Date()).toISOString() });
  const importReport = {
    engagementFile: sourceNames.engagement,
    projectsFile: sourceNames.projects,
    rowsRead: engagement.length,
    rowsSaved: rows.length,
    rowsDiscarded: countReasons(rowReasons),
    projectsRead: projects.length,
    projectsSaved: savedProjects.length,
    projectsActive: savedProjects.filter((p) => isActiveProjectStatus(p.status)).length,
    projectsDiscarded: countReasons(projReasons),
    peopleExcludedByStatus: countDistinctPeople(excludedByStatus)
  };
  await saveBaseRows(merged.rows, session, importReport);
  return importReport;
}
var importSnapshotFromFiles = createServerFn({ method: "POST" }).validator(
  external_exports.object({
    engagementFile: external_exports.string().max(300),
    projectsFile: external_exports.string().max(300),
    engagement: external_exports.array(engagementRowSchema).max(5e4),
    projects: external_exports.array(projectRowSchema).max(1e4),
    clientClaim: clientClaimSchema2
  })
).handler(async ({ data }) => {
  const session = await resolveSession(data.clientClaim);
  requireManage(session);
  const report = await persistSnapshotData(session, data.engagement, data.projects, {
    engagement: data.engagementFile,
    projects: data.projectsFile
  });
  return { success: true, report };
});
async function fetchMondayApi(token, query, variables = {}) {
  const maxRetries = 4;
  let delay = 1e3;
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    void token;
    const { status, json: corpo } = await respostaMonday(query, variables, { versao: "2024-10" });
    const response = { status, ok: status < 400, json: async () => corpo };
    if (response.status === 429) {
      if (attempt < maxRetries) {
        await new Promise((r) => setTimeout(r, delay));
        delay *= 2;
        continue;
      }
      throw new Error("Limite de requisi\xE7\xF5es da API do monday atingido. Tente novamente em alguns segundos.");
    }
    if (!response.ok) {
      if (response.status === 401 || response.status === 403) {
        throw new Error("Token pessoal inv\xE1lido ou sem permiss\xE3o de leitura nos quadros.");
      }
      throw new Error(`Falha na API do monday (HTTP ${response.status}).`);
    }
    const json = await response.json();
    if (json.errors && json.errors.length > 0) {
      throw new Error(json.errors[0]?.message || "Erro retornado pela API do monday.");
    }
    if (!json.data) {
      throw new Error("Resposta vazia da API do monday.");
    }
    return json.data;
  }
  throw new Error("N\xE3o foi poss\xEDvel obter resposta da API do monday.");
}
var importIdsSchema = external_exports.object({
  token: external_exports.unknown().optional().transform(() => "app"),
  engagementBoardId: external_exports.string().min(1).max(100),
  projectsBoardId: external_exports.string().min(1).max(100),
  clientClaim: clientClaimSchema2
});
async function loadImportBoards(token, engBoardId, projBoardId) {
  const meta = await fetchMondayApi(
    token,
    `query GetBoardsMeta($ids: [ID!]) { boards(ids: $ids) { id name columns { id title type } groups { title } } }`,
    { ids: [engBoardId, projBoardId] }
  );
  const engBoard = meta.boards.find((b) => String(b.id) === engBoardId);
  if (!engBoard) throw new Error(`Quadro de An\xE1lise de Engajamento (ID: ${engBoardId}) n\xE3o foi encontrado ou o token n\xE3o tem permiss\xE3o para acess\xE1-lo.`);
  const projBoard = meta.boards.find((b) => String(b.id) === projBoardId);
  if (!projBoard) throw new Error(`Quadro de Hist\xF3rico de Projetos (ID: ${projBoardId}) n\xE3o foi encontrado ou o token n\xE3o tem permiss\xE3o para acess\xE1-lo.`);
  const engColMap = /* @__PURE__ */ new Map();
  engBoard.columns.forEach((c) => engColMap.set(normalizeName(c.title), c.id));
  const missingEng = ["E-mail", "Equipe", "Departamento", "Ativo pela \xFAltima vez", "In\xEDcio da semana", "Date", "Status do usu\xE1rio"].filter((n2) => !engColMap.has(normalizeName(n2)));
  if (missingEng.length > 0) throw new Error(`Faltam colunas no quadro de Engajamento "${engBoard.name}": ${missingEng.join(", ")}.`);
  const projColMap = /* @__PURE__ */ new Map();
  projBoard.columns.forEach((c) => projColMap.set(normalizeName(c.title), c.id));
  const missingProj = ["Nome SGI", "Sigla do projeto", "Status do projeto", "Gerente atual", "Eixo de projeto", "Cliente"].filter((n2) => !projColMap.has(normalizeName(n2)));
  if (missingProj.length > 0) throw new Error(`Faltam colunas no quadro de Projetos "${projBoard.name}": ${missingProj.join(", ")}.`);
  return { engBoard, projBoard, engColMap, projColMap };
}
var colText = (item, colId) => {
  if (!colId) return "";
  const cv = item.column_values.find((c) => c.id === colId);
  return (cv?.label ?? cv?.text)?.trim() ?? "";
};
var readImportPage = createServerFn({ method: "POST" }).validator(importIdsSchema.extend({ which: external_exports.enum(["eng", "proj"]), cursor: external_exports.string().max(5e3).nullable().optional() })).handler(async ({ data }) => {
  const session = await resolveSession(data.clientClaim);
  requireManage(session);
  await assertTokenOwner(session, data.token);
  const token = data.token.trim();
  const { engBoard, projBoard, engColMap, projColMap } = await loadImportBoards(token, data.engagementBoardId.trim(), data.projectsBoardId.trim());
  const boardId = data.which === "eng" ? data.engagementBoardId.trim() : data.projectsBoardId.trim();
  const res = await fetchMondayApi(
    token,
    `query GetBoardItemsPage($boardId: [ID!], $cursor: String) { boards(ids: $boardId) { items_page(limit: 500, cursor: $cursor) { cursor items { name group { title } column_values { id text value ... on StatusValue { label } } } } } }`,
    { boardId: [boardId], cursor: data.cursor ?? null }
  );
  const page = res.boards[0]?.items_page;
  const items = page?.items ?? [];
  const engRows = [];
  const projRows = [];
  if (data.which === "eng") {
    const dayCol = (title) => engBoard.columns.find((c) => c.type === "checkbox" && normalizeName(c.title) === normalizeName(title));
    items.forEach((item) => {
      engRows.push({
        group: item.group?.title ?? "",
        checkedDays: WEEKDAYS.filter((w) => {
          const col3 = dayCol(w.title);
          const cv = col3 ? item.column_values.find((c) => c.id === col3.id) : void 0;
          return Boolean(col3) && isCheckedValue(cv?.value, cv?.text);
        }).map((w) => w.key),
        name: item.name || "",
        email: colText(item, engColMap.get(normalizeName("E-mail"))),
        team: colText(item, engColMap.get(normalizeName("Equipe"))),
        department: colText(item, engColMap.get(normalizeName("Departamento"))),
        lastAccess: colText(item, engColMap.get(normalizeName("Ativo pela \xFAltima vez"))),
        weekStart: colText(item, engColMap.get(normalizeName("In\xEDcio da semana"))),
        refDate: colText(item, engColMap.get(normalizeName("Date"))),
        userStatus: colText(item, engColMap.get(normalizeName("Status do usu\xE1rio"))),
        createdAt: colText(item, engColMap.get(normalizeName("Criado em")))
      });
    });
  } else {
    const startColId = projColMap.get(normalizeName("In\xEDcio real da opera\xE7\xE3o")) || projColMap.get(normalizeName("Data de in\xEDcio")) || projColMap.get(normalizeName("In\xEDcio"));
    items.forEach((item) => {
      projRows.push({
        name: item.name || "",
        sgi: colText(item, projColMap.get(normalizeName("Nome SGI"))),
        sigla: colText(item, projColMap.get(normalizeName("Sigla do projeto"))),
        status: colText(item, projColMap.get(normalizeName("Status do projeto"))),
        managers: colText(item, projColMap.get(normalizeName("Gerente atual"))),
        axis: colText(item, projColMap.get(normalizeName("Eixo de projeto"))),
        client: colText(item, projColMap.get(normalizeName("Cliente"))),
        startDate: startColId ? colText(item, startColId) : void 0
      });
    });
  }
  return {
    engRows,
    projRows,
    cursor: page?.cursor ?? null,
    engName: engBoard.name,
    projName: projBoard.name,
    groups: engBoard.groups.map((g) => g.title)
  };
});
var applyImportedSnapshot = createServerFn({ method: "POST" }).validator(
  importIdsSchema.extend({
    engName: external_exports.string().max(500),
    projName: external_exports.string().max(500),
    groups: external_exports.array(external_exports.string().max(500)).max(2e3),
    engRows: external_exports.array(engagementRowSchema).max(6e4),
    projRows: external_exports.array(projectRowSchema).max(3e4)
  })
).handler(async ({ data }) => {
  const session = await resolveSession(data.clientClaim);
  requireManage(session);
  await assertTokenOwner(session, data.token);
  const engBoardId = data.engagementBoardId.trim();
  const projBoardId = data.projectsBoardId.trim();
  const parsedEngagement = data.engRows;
  const parsedProjects = data.projRows;
  let noIdentification = 0;
  let noGroup = 0;
  const incoming = [];
  parsedEngagement.forEach((r) => {
    if (!r.name.trim() && !r.email.trim()) {
      noIdentification++;
      return;
    }
    const group = (r.group ?? "").trim();
    if (!group) {
      noGroup++;
      return;
    }
    const ref = parseDateFlexible(r.refDate);
    const week = parseDateFlexible(r.weekStart);
    const created = parseDateFlexible(r.createdAt);
    incoming.push({
      name: r.name.trim(),
      email: r.email.trim(),
      team: r.team.trim(),
      department: r.department.trim(),
      lastAccess: r.lastAccess.trim() || null,
      refDate: ref ? toISODate(ref) : null,
      weekStart: week ? toISODate(week) : r.weekStart.trim() || null,
      userStatus: r.userStatus.trim(),
      group,
      checkedDays: r.checkedDays ?? [],
      ...created ? { createdAt: toISODate(created) } : {}
    });
  });
  const { saved: savedProjects, reasons: projReasons } = buildSavedProjects(parsedProjects);
  const discards = [];
  if (noIdentification > 0) discards.push({ reason: "Sem nome e sem e-mail", count: noIdentification });
  if (noGroup > 0) discards.push({ reason: "Item sem grupo", count: noGroup });
  const { report } = await mirrorBoardWeeksIntoBase(
    session,
    incoming,
    data.groups,
    (weeks, rowsSaved) => ({
      engagementFile: `API: ${data.engName} (ID ${engBoardId})`,
      projectsFile: `API: ${data.projName} (ID ${projBoardId})`,
      rowsRead: parsedEngagement.length,
      rowsSaved,
      rowsDiscarded: discards,
      projectsRead: parsedProjects.length,
      projectsSaved: savedProjects.length,
      projectsActive: savedProjects.filter((p) => isActiveProjectStatus(p.status)).length,
      projectsDiscarded: countReasons(projReasons),
      peopleExcludedByStatus: countDistinctPeople(parsedEngagement.filter((r) => !isActivatedStatus(r.userStatus))),
      weeks
    })
  );
  await db.collection(projectsDocCollection).doc(PROJECTS_DOC_ID2).set({ projects: savedProjects, rulesVersion: PROJECTS_STORE_VERSION, importedAt: (/* @__PURE__ */ new Date()).toISOString() });
  return { success: true, report };
});

// src/generated/server/weekActions.ts
var weekActions_exports = {};
__export(weekActions_exports, {
  deleteWeek: () => deleteWeek,
  getPendingPeriodWeeks: () => getPendingPeriodWeeks,
  reopenWeek: () => reopenWeek,
  setWeekPeriods: () => setWeekPeriods
});
var claimSchema4 = external_exports.object({ id: external_exports.union([external_exports.string(), external_exports.number()]).optional(), email: external_exports.string().optional(), name: external_exports.string().optional(), isAdmin: external_exports.boolean().optional() }).optional();
var isoSchema2 = external_exports.string().regex(/^\d{4}-\d{2}-\d{2}$/);
var groupSchema2 = external_exports.string().trim().min(1).max(500);
async function readWeekDoc(group) {
  const doc = await dbReadWithRetry("semana", () => db.collection(baseWeekStatusCollection).doc(weekDocId(group)).get());
  return doc?.data ?? null;
}
var setWeekPeriods = createServerFn({ method: "POST" }).validator(external_exports.object({ items: external_exports.array(external_exports.object({ group: groupSchema2, start: isoSchema2, end: isoSchema2 })).min(1).max(100), clientClaim: claimSchema4 })).handler(async ({ data }) => {
  const session = await requireManager(data.clientClaim);
  const { rows } = await loadBaseRows();
  let current = rows;
  const results = [];
  const toWrite = [];
  for (const item of data.items) {
    const err = periodError(item.start, item.end);
    if (err) {
      results.push({ group: item.group, ok: false, message: err });
      continue;
    }
    const gk = normGroupKey(item.group);
    const doc = await readWeekDoc(item.group);
    if (!doc && !current.some((r) => normGroupKey(r.group) === gk)) {
      results.push({ group: item.group, ok: false, message: "Semana n\xE3o encontrada na Base." });
      continue;
    }
    if (doc?.status === "validada") {
      results.push({ group: item.group, ok: false, message: "Semana validada: reabra a semana para alterar o per\xEDodo." });
      continue;
    }
    const res = recomputeGroupChecks(current, item.group, { weekStart: item.start, weekEnd: item.end });
    current = res.rows;
    const checks = Object.values(res.byDay).reduce((a, b) => a + b, 0);
    toWrite.push({
      group: doc?.group ?? item.group,
      start: item.start,
      end: item.end,
      added: res.added,
      counters: { people: res.people, checks, outside: res.outside, noAccess: res.noAccess, byDay: { ...res.byDay } }
    });
    results.push({ group: item.group, ok: true, added: res.added, people: res.people });
  }
  if (toWrite.length > 0) {
    await saveBaseRows(current, session);
    const now = (/* @__PURE__ */ new Date()).toISOString();
    for (const w of toWrite) {
      const prev = await readWeekDoc(w.group);
      const doc = {
        ...prev ?? {},
        group: prev?.group ?? w.group,
        status: prev?.status ?? "pendente",
        updatedAt: now,
        updatedByEmail: session.email,
        updatedByName: session.name,
        weekStart: w.start,
        weekEnd: w.end,
        lastReprocessedAt: now,
        counters: w.counters
      };
      delete doc.periodPending;
      delete doc.rangeFromDate;
      await dbWriteWithRetry("semana_periodo", () => db.collection(baseWeekStatusCollection).doc(weekDocId(w.group)).set(doc));
      await logWeekAction(session, "definiu_periodo", w.group, `${w.start} a ${w.end} \xB7 ${w.added} checks acrescentados`);
    }
  }
  return { results };
});
var deleteWeek = createServerFn({ method: "POST" }).validator(external_exports.object({ group: groupSchema2, confirmName: external_exports.string().max(500), clientClaim: claimSchema4 })).handler(async ({ data }) => {
  const session = await requireManager(data.clientClaim);
  if (data.confirmName !== data.group) throw new Error("O nome digitado n\xE3o confere com o nome da semana.");
  const doc = await readWeekDoc(data.group);
  if (doc?.status === "validada") throw new Error("Semana validada: reabra a semana antes de apagar.");
  const { rows } = await loadBaseRows();
  const gk = normGroupKey(data.group);
  const kept = rows.filter((r) => normGroupKey(r.group) !== gk);
  const removed = rows.length - kept.length;
  if (removed === 0 && !doc) throw new Error("Semana n\xE3o encontrada na Base.");
  await saveBaseRows(kept, session);
  await dbWriteWithRetry("semana_apagar", () => db.collection(baseWeekStatusCollection).doc(weekDocId(data.group)).delete());
  const queues = await dbReadWithRetry("fila_apagar", () => db.collection(mirrorQueueCollection).limit(1e3).get());
  for (const q of queues) {
    if (normText(q.data.group) === normText(data.group)) await dbWriteWithRetry("fila_apagar", () => db.collection(mirrorQueueCollection).doc(q.id).delete());
  }
  await logWeekAction(session, "apagou_semana", data.group, `${removed} linhas apagadas da Base`);
  return { removed };
});
var reopenWeek = createServerFn({ method: "POST" }).validator(external_exports.object({ group: groupSchema2, clientClaim: claimSchema4 })).handler(async ({ data }) => {
  const session = await requireManager(data.clientClaim);
  const prev = await readWeekDoc(data.group);
  if (!prev || prev.status !== "validada") throw new Error("Esta semana n\xE3o est\xE1 validada.");
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const doc = {
    ...prev,
    status: "pendente",
    updatedAt: now,
    updatedByEmail: session.email,
    updatedByName: session.name,
    reopenedAt: now,
    reopenedByEmail: session.email,
    reopenedByName: session.name
  };
  await dbWriteWithRetry("semana_reabrir", () => db.collection(baseWeekStatusCollection).doc(weekDocId(data.group)).set(doc));
  await logWeekAction(session, "reabriu_semana", data.group);
  return doc;
});
var getPendingPeriodWeeks = createServerFn({ method: "POST" }).validator(external_exports.object({ clientClaim: claimSchema4 }).optional()).handler(async ({ data }) => {
  await requireManager(data?.clientClaim);
  const docs = await dbReadWithRetry("semanas_sem_periodo", () => db.collection(baseWeekStatusCollection).limit(1e3).get());
  const pending = docs.filter((d) => d.data.periodPending && !(d.data.weekStart && d.data.weekEnd)).map((d) => d.data.group);
  if (pending.length === 0) return { weeks: [] };
  const { rows } = await loadBaseRows();
  return { weeks: pending.map((g) => ({ group: g, people: rows.filter((r) => normGroupKey(r.group) === normGroupKey(g)).length })) };
});

// server/registry.ts
var MODULES = {
  "apus": apus_exports,
  "baseEditMirror": baseEditMirror_exports,
  "baseManagement": baseManagement_exports,
  "communication": communication_exports,
  "mirror": mirror_exports,
  "panelUpdate": panelUpdate_exports,
  "portais": portais_exports,
  "storage": storage_exports,
  "weekActions": weekActions_exports
};

// server/index.ts
var FNS = /* @__PURE__ */ new Map();
for (const [mod, exp] of Object.entries(MODULES)) {
  for (const [name, v] of Object.entries(exp)) {
    if (typeof v === "function" && v.__serverFn) FNS.set(`${mod}:${name}`, v);
  }
}
var PUBLIC = import_node_path.default.join(__dirname, "public");
var MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".png": "image/png", ".svg": "image/svg+xml", ".json": "application/json", ".woff2": "font/woff2" };
function b64url(buf) {
  return buf.toString("base64").replace(/=+$/, "").replace(/\+/g, "-").replace(/\//g, "_");
}
function verifySession(token) {
  const secret = process.env.CLIENT_SECRET;
  if (!secret || !token) return null;
  const parts = token.replace(/^Bearer\s+/i, "").split(".");
  if (parts.length !== 3) return null;
  const sig = b64url((0, import_node_crypto4.createHmac)("sha256", secret).update(`${parts[0]}.${parts[1]}`).digest());
  const a = Buffer.from(sig), b = Buffer.from(parts[2]);
  if (a.length !== b.length || !(0, import_node_crypto4.timingSafeEqual)(a, b)) return null;
  try {
    const p = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
    if (p.exp && p.exp * 1e3 < Date.now()) return null;
    const d = p.dat ?? p;
    if (!d.user_id) return null;
    lembrarCliente(d.client_id, d.account_id);
    return { userId: String(d.user_id), accountId: String(d.account_id ?? ""), isAdmin: d.is_admin === true, isGuest: d.is_guest === true || d.user_kind === "guest" };
  } catch {
    return null;
  }
}
function send(res, status, body) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(body));
}
async function readBody(req, max = 60 * 1024 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > max) throw new Error("Envio grande demais.");
    chunks.push(c);
  }
  return Buffer.concat(chunks).toString("utf8");
}
function zodMessage(e) {
  const issues = e?.issues;
  if (!Array.isArray(issues)) return null;
  return "Dados inv\xE1lidos: " + issues.slice(0, 3).map((i) => `${(i.path ?? []).join(".")}: ${i.message}`).join("; ");
}
var server = import_node_http.default.createServer(async (req, res) => {
  const url = new URL(req.url ?? "/", "http://x");
  const p = url.pathname;
  try {
    if (req.method === "POST" && p.startsWith("/_fn/")) {
      const id = decodeURIComponent(p.slice(5));
      const fn = FNS.get(id);
      if (!fn) return send(res, 404, { ok: false, error: `Fun\xE7\xE3o n\xE3o encontrada: ${id}` });
      const ctx = verifySession(String(req.headers.authorization ?? ""));
      if (!ctx) return send(res, 401, { ok: false, error: "Sess\xE3o do monday inv\xE1lida ou expirada. Recarregue a p\xE1gina." });
      const body = JSON.parse(await readBody(req) || "{}");
      const callId = String(req.headers["x-call-id"] ?? "");
      if (/^[a-f0-9]{16,64}$/.test(callId)) ctx.callId = callId;
      try {
        const result = await reqCtx.run(ctx, () => fn.run(body?.data ?? void 0));
        return send(res, 200, { ok: true, result: result ?? null });
      } catch (e) {
        const msg = zodMessage(e) ?? (e instanceof Error ? e.message : String(e));
        console.error(`[fn ${id}]`, msg);
        return send(res, 200, { ok: false, error: msg.slice(0, 1e3) });
      } finally {
        ctx.encerrada = true;
      }
    }
    if (req.method === "POST" && (p === "/_mut/pendentes" || p === "/_mut/resultado")) {
      const ctx = verifySession(String(req.headers.authorization ?? ""));
      if (!ctx) return send(res, 401, { ok: false, error: "Sess\xE3o do monday inv\xE1lida ou expirada. Recarregue a p\xE1gina." });
      const b = JSON.parse(await readBody(req, 20 * 1024 * 1024) || "{}");
      if (p === "/_mut/pendentes") {
        const callId = String(b?.callId ?? "");
        if (!/^[a-f0-9]{16,64}$/.test(callId)) return send(res, 400, { ok: false });
        return send(res, 200, { ok: true, result: await pendentes(callId, ctx.userId) });
      }
      await registrarResultado(String(b?.id ?? ""), ctx.userId, b?.resposta ?? null, b?.erro);
      return send(res, 200, { ok: true });
    }
    if (p.startsWith("/mndy-cronjob/") || p.startsWith("/cron/")) {
      const job = p.split("/").filter(Boolean)[1] ?? "";
      if (p.startsWith("/cron/") && (!process.env.CRON_KEY || req.headers["x-cron-key"] !== process.env.CRON_KEY)) return send(res, 401, { ok: false });
      const body = req.method === "POST" ? await readBody(req, 1e6).catch(() => "") : "";
      let weekStart;
      try {
        weekStart = JSON.parse(body || "{}").weekStart;
      } catch {
      }
      const out = await startJob(job, p.startsWith("/cron/") ? weekStart : void 0).catch((e) => ({ error: String(e?.message ?? e) }));
      console.log(`[cron ${job}]`, JSON.stringify(out));
      return send(res, 200, { ok: true, result: out });
    }
    if (req.method === "GET" && p === "/oauth/start") return await oauthStart(req, res);
    if (req.method === "GET" && p === "/oauth/callback") return await oauthCallback(req, res, url);
    if (req.method === "GET" && p === "/oauth/status") return await oauthStatus(res);
    if (p === "/health") return send(res, 200, { ok: true });
    const rel = p === "/" ? "index.html" : import_node_path.default.normalize(p).replace(/^([/\\])+/, "");
    const file = import_node_path.default.join(PUBLIC, rel);
    if (!file.startsWith(PUBLIC)) return send(res, 404, { ok: false });
    try {
      const data = await (0, import_promises.readFile)(file);
      res.writeHead(200, { "Content-Type": MIME[import_node_path.default.extname(file)] ?? "application/octet-stream", "Cache-Control": rel === "index.html" ? "no-store" : "public, max-age=31536000, immutable" });
      return res.end(data);
    } catch {
      const html = await (0, import_promises.readFile)(import_node_path.default.join(PUBLIC, "index.html"));
      res.writeHead(200, { "Content-Type": MIME[".html"], "Cache-Control": "no-store" });
      return res.end(html);
    }
  } catch (e) {
    console.error("[server]", e);
    if (!res.headersSent) send(res, 500, { ok: false, error: e instanceof Error ? e.message : "Erro no servidor." });
  }
});
server.requestTimeout = 0;
server.headersTimeout = 12e4;
server.listen(Number(process.env.PORT) || 8080, () => console.log(`servidor no ar (${FNS.size} fun\xE7\xF5es)`));

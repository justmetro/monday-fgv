"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server/index.ts
var import_node_http = __toESM(require("node:http"), 1);
var import_node_crypto4 = require("node:crypto");
var import_promises = require("node:fs/promises");
var import_node_path = __toESM(require("node:path"), 1);

// server/context.ts
var import_node_async_hooks = require("node:async_hooks");
var reqCtx = new import_node_async_hooks.AsyncLocalStorage();
var currentCtx = () => reqCtx.getStore() ?? null;
var tokenAtual = new import_node_async_hooks.AsyncLocalStorage();

// server/mongo.ts
var import_mongodb = require("mongodb");
var clientP = null;
function mongo() {
  if (!clientP) {
    const uri = process.env.MNDY_MONGODB_CONNECTION_STRING;
    if (!uri) throw new Error("Banco do app indispon\xEDvel (MNDY_MONGODB_CONNECTION_STRING ausente).");
    const client = new import_mongodb.MongoClient(uri, { maxPoolSize: 10, serverSelectionTimeoutMS: 15e3 });
    clientP = client.connect().then((c) => c.db()).catch((e) => {
      clientP = null;
      throw e;
    });
  }
  return clientP;
}

// server/jobs.ts
var JOBS = {
  // exemplo: 'semanal': (arg) => consolidarSemana(arg),
};
var running = null;
async function startJob(kind, arg) {
  const fn = JOBS[kind];
  if (!fn) throw new Error(`Job desconhecido: ${kind}`);
  const col3 = (await mongo()).collection("app_jobs");
  const cur = await col3.findOne({ _id: "current" });
  if (running || cur?.status === "rodando" && Date.now() - Date.parse(cur.startedAt) < 20 * 6e4) {
    if (cur) return cur;
  }
  const state = { _id: "current", kind, status: "rodando", startedAt: (/* @__PURE__ */ new Date()).toISOString(), ...arg ? { arg } : {} };
  await col3.replaceOne({ _id: "current" }, state, { upsert: true });
  running = (async () => {
    try {
      const result = await fn(arg);
      await col3.updateOne({ _id: "current" }, { $set: { status: "concluido", finishedAt: (/* @__PURE__ */ new Date()).toISOString(), result } });
    } catch (e) {
      const error = e instanceof Error ? e.message : String(e);
      await col3.updateOne({ _id: "current" }, { $set: { status: "erro", finishedAt: (/* @__PURE__ */ new Date()).toISOString(), error } }).catch(() => null);
      console.error(`[job ${kind}]`, error);
    } finally {
      running = null;
    }
  })();
  return state;
}

// server/relay.ts
var import_node_crypto = require("node:crypto");
var SEM_NAVEGADOR = /* @__PURE__ */ Symbol("sem-navegador");
var col = async () => (await mongo()).collection("app_mutacoes");
var LIMITE_MS = 12e4;
var espera = (ms) => new Promise((r) => setTimeout(r, ms));
var ultimaLimpeza = 0;
async function limpar() {
  if (Date.now() - ultimaLimpeza < 60 * 6e4) return;
  ultimaLimpeza = Date.now();
  await (await col()).deleteMany({ at: { $lt: Date.now() - 24 * 60 * 6e4 } }).catch(() => null);
}
async function viaNavegador(query, variables) {
  const ctx = currentCtx();
  if (!ctx?.callId || ctx.viaCron || ctx.encerrada) return SEM_NAVEGADOR;
  const c = await col();
  const _id = (0, import_node_crypto.randomBytes)(12).toString("hex");
  await c.insertOne({ _id, callId: ctx.callId, userId: ctx.userId, query, variables: variables ?? {}, status: "pendente", at: Date.now() });
  void limpar();
  const fim = Date.now() + LIMITE_MS;
  let passo = 150;
  while (Date.now() < fim) {
    await espera(passo);
    passo = Math.min(passo + 100, 500);
    const p = await c.findOne({ _id });
    if (p?.status === "ok") return p.resposta;
    if (p?.status === "erro") return { errors: [{ message: p.erro || "Falha ao gravar no monday pelo navegador." }] };
  }
  await c.updateOne({ _id, status: { $in: ["pendente", "enviada"] } }, { $set: { status: "expirada" } });
  throw new Error("A grava\xE7\xE3o n\xE3o foi confirmada pelo navegador a tempo. Mantenha a aba aberta e tente novamente.");
}
async function pendentes(callId, userId, esperarMs = 8e3) {
  const c = await col();
  const fim = Date.now() + esperarMs;
  for (; ; ) {
    const lista2 = [];
    for (; ; ) {
      const p = await c.findOneAndUpdate({ callId, userId, status: "pendente" }, { $set: { status: "enviada" } }, { sort: { at: 1 }, returnDocument: "after" });
      const doc = p && "value" in p ? p.value : p;
      if (!doc) break;
      lista2.push({ id: doc._id, query: doc.query, variables: doc.variables });
    }
    if (lista2.length || Date.now() >= fim) return lista2;
    await espera(200);
  }
}
async function registrarResultado(id, userId, resposta, erro) {
  await (await col()).updateOne(
    { _id: id, userId, status: "enviada" },
    { $set: erro ? { status: "erro", erro: String(erro).slice(0, 1e3) } : { status: "ok", resposta } }
  );
}

// server/oauth.ts
var import_node_crypto2 = require("node:crypto");
var col2 = async () => (await mongo()).collection("app_oauth");
var cache = null;
var TTL = 5 * 60 * 1e3;
async function tokenOAuth() {
  if (cache && Date.now() - cache.at < TTL) return cache.token;
  try {
    const d = await (await col2()).findOne({ _id: "token" });
    cache = { at: Date.now(), token: typeof d?.accessToken === "string" ? d.accessToken : null };
  } catch (e) {
    console.error("[oauth] leitura do token", e);
    cache = { at: Date.now(), token: null };
  }
  return cache.token;
}
var cacheUsuario = /* @__PURE__ */ new Map();
async function tokenDoUsuario(userId) {
  const c = cacheUsuario.get(userId);
  if (c && Date.now() - c.at < TTL) return c.token;
  const d = await (await col2()).findOne({ _id: `u:${userId}` }).catch(() => null);
  const token = typeof d?.accessToken === "string" ? d.accessToken : null;
  cacheUsuario.set(userId, { at: Date.now(), token, nome: String(d?.nome ?? "") });
  return token;
}
async function autorizacaoDoUsuario(userId) {
  const d = await (await col2()).findOne({ _id: `u:${userId}` });
  return { autorizado: typeof d?.accessToken === "string", nome: d?.nome ?? null, em: d?.em ?? null };
}
async function linkAutorizacao(userId) {
  const state = (0, import_node_crypto2.randomBytes)(24).toString("hex");
  await (await col2()).insertOne({ _id: `s:${state}`, userId, at: Date.now() });
  const base2 = (process.env.OAUTH_REDIRECT_URI ?? RETORNO_PADRAO).replace(/\/oauth\/callback$/, "");
  return `${base2}/oauth/start?s=${state}`;
}
var conhecido = "";
function lembrarCliente(clientId, accountId) {
  const c = String(clientId ?? ""), a = String(accountId ?? "");
  if (!c || conhecido === `${c}|${a}`) return;
  conhecido = `${c}|${a}`;
  col2().then((x) => x.updateOne({ _id: "cliente" }, { $set: { clientId: c, accountId: a } }, { upsert: true })).catch(() => {
    conhecido = "";
  });
}
function pagina(res2, status, texto) {
  if (status >= 400) {
    console.error("[oauth]", status, texto);
    col2().then((x) => x.updateOne({ _id: "erro" }, { $set: { status, texto, em: (/* @__PURE__ */ new Date()).toISOString() } }, { upsert: true })).catch(() => null);
  }
  res2.writeHead(status, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
  res2.end(`<!doctype html><meta charset="utf-8"><title>Autoriza\xE7\xE3o do app</title><body style="font-family:system-ui;padding:40px;max-width:560px">${texto}</body>`);
}
var RETORNO_PADRAO = "https://live1-service-29669755-a2a4a63b.us.monday.app/oauth/callback";
function retorno(_req) {
  return process.env.OAUTH_REDIRECT_URI || RETORNO_PADRAO;
}
async function oauthStart(req, res2, pedido) {
  const c = await (await col2()).findOne({ _id: "cliente" });
  if (!c?.clientId) return pagina(res2, 409, "<p>Abra o app uma vez dentro do monday e depois volte a este link.</p>");
  let state = pedido?.searchParams.get("s") ?? "";
  if (state) {
    const s = await (await col2()).findOne({ _id: `s:${state}` });
    if (!s || Date.now() - Number(s.at ?? 0) > 15 * 60 * 1e3) return pagina(res2, 400, "<p>Link de autoriza\xE7\xE3o expirado. Volte ao hub e clique em Autorizar de novo.</p>");
  } else {
    state = (0, import_node_crypto2.randomBytes)(24).toString("hex");
    await (await col2()).updateOne({ _id: "state" }, { $set: { state, at: Date.now() } }, { upsert: true });
  }
  const url = new URL("https://auth.monday.com/oauth2/authorize");
  url.searchParams.set("client_id", String(c.clientId));
  url.searchParams.set("redirect_uri", retorno(req));
  url.searchParams.set("state", state);
  res2.writeHead(302, { Location: url.toString(), "Cache-Control": "no-store" });
  res2.end();
}
async function oauthCallback(req, res2, url) {
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const x = await col2();
  const pessoal = state ? await x.findOne({ _id: `s:${state}` }) : null;
  const s = pessoal ? null : await x.findOne({ _id: "state" });
  if (!code || !state || !pessoal && s?.state !== state || Date.now() - Number((pessoal ?? s)?.at ?? 0) > 15 * 60 * 1e3) {
    return pagina(res2, 400, "<p>Link de autoriza\xE7\xE3o inv\xE1lido ou expirado. Volte ao hub e clique em Autorizar de novo.</p>");
  }
  await x.deleteOne({ _id: pessoal ? `s:${state}` : "state" });
  const c = await x.findOne({ _id: "cliente" });
  const r = await fetch("https://auth.monday.com/oauth2/token", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ client_id: c?.clientId, client_secret: process.env.CLIENT_SECRET, code, redirect_uri: retorno(req) })
  });
  const j = await r.json().catch(() => null);
  if (!j?.access_token) return pagina(res2, 400, `<p>O monday recusou a autoriza\xE7\xE3o: ${String(j?.error_description ?? j?.error ?? r.status).replace(/[<>]/g, "")}</p>`);
  const me = await fetch("https://api.monday.com/v2", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: j.access_token, "API-Version": "2026-10" },
    body: JSON.stringify({ query: "{ me { id name kind } }" })
  }).then((y) => y.json()).catch(() => null);
  const u = me?.data?.me;
  if (pessoal) {
    if (!u || String(u.id) !== String(pessoal.userId)) {
      return pagina(res2, 403, "<p>A conta que autorizou n\xE3o \xE9 a mesma que est\xE1 usando o hub no monday. Entre no monday com a sua conta e tente de novo.</p>");
    }
    await x.updateOne({ _id: `u:${u.id}` }, { $set: { accessToken: j.access_token, nome: u.name, em: (/* @__PURE__ */ new Date()).toISOString() } }, { upsert: true });
    cacheUsuario.delete(String(u.id));
    return pagina(res2, 200, `<p>Pronto, ${u.name.replace(/[<>]/g, "")}. O hub vai agir no seu nome. Pode fechar esta aba e voltar ao monday.</p>`);
  }
  if (u?.kind !== "admin") {
    console.error("[oauth] me", JSON.stringify(me).slice(0, 500));
    return pagina(res2, 403, "<p>S\xF3 um admin da conta FGV DGPE pode autorizar o app.</p>");
  }
  await x.updateOne({ _id: "token" }, { $set: { accessToken: j.access_token, userId: String(u.id), nome: u.name, em: (/* @__PURE__ */ new Date()).toISOString() } }, { upsert: true });
  cache = null;
  return pagina(res2, 200, `<p>App autorizado por ${u.name.replace(/[<>]/g, "")}. Pode fechar esta aba e recarregar o app no monday.</p>`);
}
async function oauthStatus(res2) {
  const d = await (await col2()).findOne({ _id: "token" });
  const e = await (await col2()).findOne({ _id: "erro" });
  res2.writeHead(200, { "Content-Type": "application/json", "Cache-Control": "no-store" });
  res2.end(JSON.stringify({ autorizado: !!d?.accessToken, por: d?.nome ?? null, em: d?.em ?? null, ultimoErro: e ? { status: e.status, texto: e.texto, em: e.em } : null }));
}

// src/generated/server/gravacao.ts
var gravacao_exports = {};
__export(gravacao_exports, {
  gravarNoQuadro: () => gravarNoQuadro
});

// server/serverFn.ts
function createServerFn(_opts) {
  let validator = null;
  const b = {
    validator(v) {
      validator = v;
      return b;
    },
    inputValidator(v) {
      validator = v;
      return b;
    },
    middleware(_m) {
      return b;
    },
    handler(h) {
      const run = async (raw) => {
        let data = raw;
        if (validator) data = typeof validator === "function" ? validator(raw) : validator.parse(raw);
        return h({ data });
      };
      const fn = ((opts) => run(opts?.data));
      fn.__serverFn = true;
      fn.run = run;
      return fn;
    }
  };
  return b;
}

// node_modules/zod/v3/external.js
var external_exports = {};
__export(external_exports, {
  BRAND: () => BRAND,
  DIRTY: () => DIRTY,
  EMPTY_PATH: () => EMPTY_PATH,
  INVALID: () => INVALID,
  NEVER: () => NEVER,
  OK: () => OK,
  ParseStatus: () => ParseStatus,
  Schema: () => ZodType,
  ZodAny: () => ZodAny,
  ZodArray: () => ZodArray,
  ZodBigInt: () => ZodBigInt,
  ZodBoolean: () => ZodBoolean,
  ZodBranded: () => ZodBranded,
  ZodCatch: () => ZodCatch,
  ZodDate: () => ZodDate,
  ZodDefault: () => ZodDefault,
  ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
  ZodEffects: () => ZodEffects,
  ZodEnum: () => ZodEnum,
  ZodError: () => ZodError,
  ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
  ZodFunction: () => ZodFunction,
  ZodIntersection: () => ZodIntersection,
  ZodIssueCode: () => ZodIssueCode,
  ZodLazy: () => ZodLazy,
  ZodLiteral: () => ZodLiteral,
  ZodMap: () => ZodMap,
  ZodNaN: () => ZodNaN,
  ZodNativeEnum: () => ZodNativeEnum,
  ZodNever: () => ZodNever,
  ZodNull: () => ZodNull,
  ZodNullable: () => ZodNullable,
  ZodNumber: () => ZodNumber,
  ZodObject: () => ZodObject,
  ZodOptional: () => ZodOptional,
  ZodParsedType: () => ZodParsedType,
  ZodPipeline: () => ZodPipeline,
  ZodPromise: () => ZodPromise,
  ZodReadonly: () => ZodReadonly,
  ZodRecord: () => ZodRecord,
  ZodSchema: () => ZodType,
  ZodSet: () => ZodSet,
  ZodString: () => ZodString,
  ZodSymbol: () => ZodSymbol,
  ZodTransformer: () => ZodEffects,
  ZodTuple: () => ZodTuple,
  ZodType: () => ZodType,
  ZodUndefined: () => ZodUndefined,
  ZodUnion: () => ZodUnion,
  ZodUnknown: () => ZodUnknown,
  ZodVoid: () => ZodVoid,
  addIssueToContext: () => addIssueToContext,
  any: () => anyType,
  array: () => arrayType,
  bigint: () => bigIntType,
  boolean: () => booleanType,
  coerce: () => coerce,
  custom: () => custom,
  date: () => dateType,
  datetimeRegex: () => datetimeRegex,
  defaultErrorMap: () => en_default,
  discriminatedUnion: () => discriminatedUnionType,
  effect: () => effectsType,
  enum: () => enumType,
  function: () => functionType,
  getErrorMap: () => getErrorMap,
  getParsedType: () => getParsedType,
  instanceof: () => instanceOfType,
  intersection: () => intersectionType,
  isAborted: () => isAborted,
  isAsync: () => isAsync,
  isDirty: () => isDirty,
  isValid: () => isValid,
  late: () => late,
  lazy: () => lazyType,
  literal: () => literalType,
  makeIssue: () => makeIssue,
  map: () => mapType,
  nan: () => nanType,
  nativeEnum: () => nativeEnumType,
  never: () => neverType,
  null: () => nullType,
  nullable: () => nullableType,
  number: () => numberType,
  object: () => objectType,
  objectUtil: () => objectUtil,
  oboolean: () => oboolean,
  onumber: () => onumber,
  optional: () => optionalType,
  ostring: () => ostring,
  pipeline: () => pipelineType,
  preprocess: () => preprocessType,
  promise: () => promiseType,
  quotelessJson: () => quotelessJson,
  record: () => recordType,
  set: () => setType,
  setErrorMap: () => setErrorMap,
  strictObject: () => strictObjectType,
  string: () => stringType,
  symbol: () => symbolType,
  transformer: () => effectsType,
  tuple: () => tupleType,
  undefined: () => undefinedType,
  union: () => unionType,
  unknown: () => unknownType,
  util: () => util,
  void: () => voidType
});

// node_modules/zod/v3/helpers/util.js
var util;
(function(util2) {
  util2.assertEqual = (_) => {
  };
  function assertIs(_arg) {
  }
  util2.assertIs = assertIs;
  function assertNever(_x) {
    throw new Error();
  }
  util2.assertNever = assertNever;
  util2.arrayToEnum = (items) => {
    const obj = {};
    for (const item of items) {
      obj[item] = item;
    }
    return obj;
  };
  util2.getValidEnumValues = (obj) => {
    const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
    const filtered = {};
    for (const k of validKeys) {
      filtered[k] = obj[k];
    }
    return util2.objectValues(filtered);
  };
  util2.objectValues = (obj) => {
    return util2.objectKeys(obj).map(function(e) {
      return obj[e];
    });
  };
  util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
    const keys = [];
    for (const key in object) {
      if (Object.prototype.hasOwnProperty.call(object, key)) {
        keys.push(key);
      }
    }
    return keys;
  };
  util2.find = (arr, checker) => {
    for (const item of arr) {
      if (checker(item))
        return item;
    }
    return void 0;
  };
  util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
  function joinValues(array, separator = " | ") {
    return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
  }
  util2.joinValues = joinValues;
  util2.jsonStringifyReplacer = (_, value) => {
    if (typeof value === "bigint") {
      return value.toString();
    }
    return value;
  };
})(util || (util = {}));
var objectUtil;
(function(objectUtil2) {
  objectUtil2.mergeShapes = (first, second) => {
    return {
      ...first,
      ...second
      // second overwrites first
    };
  };
})(objectUtil || (objectUtil = {}));
var ZodParsedType = util.arrayToEnum([
  "string",
  "nan",
  "number",
  "integer",
  "float",
  "boolean",
  "date",
  "bigint",
  "symbol",
  "function",
  "undefined",
  "null",
  "array",
  "object",
  "unknown",
  "promise",
  "void",
  "never",
  "map",
  "set"
]);
var getParsedType = (data) => {
  const t2 = typeof data;
  switch (t2) {
    case "undefined":
      return ZodParsedType.undefined;
    case "string":
      return ZodParsedType.string;
    case "number":
      return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
    case "boolean":
      return ZodParsedType.boolean;
    case "function":
      return ZodParsedType.function;
    case "bigint":
      return ZodParsedType.bigint;
    case "symbol":
      return ZodParsedType.symbol;
    case "object":
      if (Array.isArray(data)) {
        return ZodParsedType.array;
      }
      if (data === null) {
        return ZodParsedType.null;
      }
      if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
        return ZodParsedType.promise;
      }
      if (typeof Map !== "undefined" && data instanceof Map) {
        return ZodParsedType.map;
      }
      if (typeof Set !== "undefined" && data instanceof Set) {
        return ZodParsedType.set;
      }
      if (typeof Date !== "undefined" && data instanceof Date) {
        return ZodParsedType.date;
      }
      return ZodParsedType.object;
    default:
      return ZodParsedType.unknown;
  }
};

// node_modules/zod/v3/ZodError.js
var ZodIssueCode = util.arrayToEnum([
  "invalid_type",
  "invalid_literal",
  "custom",
  "invalid_union",
  "invalid_union_discriminator",
  "invalid_enum_value",
  "unrecognized_keys",
  "invalid_arguments",
  "invalid_return_type",
  "invalid_date",
  "invalid_string",
  "too_small",
  "too_big",
  "invalid_intersection_types",
  "not_multiple_of",
  "not_finite"
]);
var quotelessJson = (obj) => {
  const json = JSON.stringify(obj, null, 2);
  return json.replace(/"([^"]+)":/g, "$1:");
};
var ZodError = class _ZodError extends Error {
  get errors() {
    return this.issues;
  }
  constructor(issues) {
    super();
    this.issues = [];
    this.addIssue = (sub) => {
      this.issues = [...this.issues, sub];
    };
    this.addIssues = (subs = []) => {
      this.issues = [...this.issues, ...subs];
    };
    const actualProto = new.target.prototype;
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(this, actualProto);
    } else {
      this.__proto__ = actualProto;
    }
    this.name = "ZodError";
    this.issues = issues;
  }
  format(_mapper) {
    const mapper = _mapper || function(issue) {
      return issue.message;
    };
    const fieldErrors = { _errors: [] };
    const processError = (error) => {
      for (const issue of error.issues) {
        if (issue.code === "invalid_union") {
          issue.unionErrors.map(processError);
        } else if (issue.code === "invalid_return_type") {
          processError(issue.returnTypeError);
        } else if (issue.code === "invalid_arguments") {
          processError(issue.argumentsError);
        } else if (issue.path.length === 0) {
          fieldErrors._errors.push(mapper(issue));
        } else {
          let curr = fieldErrors;
          let i = 0;
          while (i < issue.path.length) {
            const el = issue.path[i];
            const terminal = i === issue.path.length - 1;
            if (!terminal) {
              curr[el] = curr[el] || { _errors: [] };
            } else {
              curr[el] = curr[el] || { _errors: [] };
              curr[el]._errors.push(mapper(issue));
            }
            curr = curr[el];
            i++;
          }
        }
      }
    };
    processError(this);
    return fieldErrors;
  }
  static assert(value) {
    if (!(value instanceof _ZodError)) {
      throw new Error(`Not a ZodError: ${value}`);
    }
  }
  toString() {
    return this.message;
  }
  get message() {
    return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
  }
  get isEmpty() {
    return this.issues.length === 0;
  }
  flatten(mapper = (issue) => issue.message) {
    const fieldErrors = {};
    const formErrors = [];
    for (const sub of this.issues) {
      if (sub.path.length > 0) {
        const firstEl = sub.path[0];
        fieldErrors[firstEl] = fieldErrors[firstEl] || [];
        fieldErrors[firstEl].push(mapper(sub));
      } else {
        formErrors.push(mapper(sub));
      }
    }
    return { formErrors, fieldErrors };
  }
  get formErrors() {
    return this.flatten();
  }
};
ZodError.create = (issues) => {
  const error = new ZodError(issues);
  return error;
};

// node_modules/zod/v3/locales/en.js
var errorMap = (issue, _ctx) => {
  let message;
  switch (issue.code) {
    case ZodIssueCode.invalid_type:
      if (issue.received === ZodParsedType.undefined) {
        message = "Required";
      } else {
        message = `Expected ${issue.expected}, received ${issue.received}`;
      }
      break;
    case ZodIssueCode.invalid_literal:
      message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
      break;
    case ZodIssueCode.unrecognized_keys:
      message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
      break;
    case ZodIssueCode.invalid_union:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_union_discriminator:
      message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
      break;
    case ZodIssueCode.invalid_enum_value:
      message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
      break;
    case ZodIssueCode.invalid_arguments:
      message = `Invalid function arguments`;
      break;
    case ZodIssueCode.invalid_return_type:
      message = `Invalid function return type`;
      break;
    case ZodIssueCode.invalid_date:
      message = `Invalid date`;
      break;
    case ZodIssueCode.invalid_string:
      if (typeof issue.validation === "object") {
        if ("includes" in issue.validation) {
          message = `Invalid input: must include "${issue.validation.includes}"`;
          if (typeof issue.validation.position === "number") {
            message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
          }
        } else if ("startsWith" in issue.validation) {
          message = `Invalid input: must start with "${issue.validation.startsWith}"`;
        } else if ("endsWith" in issue.validation) {
          message = `Invalid input: must end with "${issue.validation.endsWith}"`;
        } else {
          util.assertNever(issue.validation);
        }
      } else if (issue.validation !== "regex") {
        message = `Invalid ${issue.validation}`;
      } else {
        message = "Invalid";
      }
      break;
    case ZodIssueCode.too_small:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "bigint")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.too_big:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "bigint")
        message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.custom:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_intersection_types:
      message = `Intersection results could not be merged`;
      break;
    case ZodIssueCode.not_multiple_of:
      message = `Number must be a multiple of ${issue.multipleOf}`;
      break;
    case ZodIssueCode.not_finite:
      message = "Number must be finite";
      break;
    default:
      message = _ctx.defaultError;
      util.assertNever(issue);
  }
  return { message };
};
var en_default = errorMap;

// node_modules/zod/v3/errors.js
var overrideErrorMap = en_default;
function setErrorMap(map) {
  overrideErrorMap = map;
}
function getErrorMap() {
  return overrideErrorMap;
}

// node_modules/zod/v3/helpers/parseUtil.js
var makeIssue = (params) => {
  const { data, path: path2, errorMaps, issueData } = params;
  const fullPath = [...path2, ...issueData.path || []];
  const fullIssue = {
    ...issueData,
    path: fullPath
  };
  if (issueData.message !== void 0) {
    return {
      ...issueData,
      path: fullPath,
      message: issueData.message
    };
  }
  let errorMessage2 = "";
  const maps = errorMaps.filter((m) => !!m).slice().reverse();
  for (const map of maps) {
    errorMessage2 = map(fullIssue, { data, defaultError: errorMessage2 }).message;
  }
  return {
    ...issueData,
    path: fullPath,
    message: errorMessage2
  };
};
var EMPTY_PATH = [];
function addIssueToContext(ctx, issueData) {
  const overrideMap = getErrorMap();
  const issue = makeIssue({
    issueData,
    data: ctx.data,
    path: ctx.path,
    errorMaps: [
      ctx.common.contextualErrorMap,
      // contextual error map is first priority
      ctx.schemaErrorMap,
      // then schema-bound map if available
      overrideMap,
      // then global override map
      overrideMap === en_default ? void 0 : en_default
      // then global default map
    ].filter((x) => !!x)
  });
  ctx.common.issues.push(issue);
}
var ParseStatus = class _ParseStatus {
  constructor() {
    this.value = "valid";
  }
  dirty() {
    if (this.value === "valid")
      this.value = "dirty";
  }
  abort() {
    if (this.value !== "aborted")
      this.value = "aborted";
  }
  static mergeArray(status, results) {
    const arrayValue = [];
    for (const s of results) {
      if (s.status === "aborted")
        return INVALID;
      if (s.status === "dirty")
        status.dirty();
      arrayValue.push(s.value);
    }
    return { status: status.value, value: arrayValue };
  }
  static async mergeObjectAsync(status, pairs) {
    const syncPairs = [];
    for (const pair of pairs) {
      const key = await pair.key;
      const value = await pair.value;
      syncPairs.push({
        key,
        value
      });
    }
    return _ParseStatus.mergeObjectSync(status, syncPairs);
  }
  static mergeObjectSync(status, pairs) {
    const finalObject = {};
    for (const pair of pairs) {
      const { key, value } = pair;
      if (key.status === "aborted")
        return INVALID;
      if (value.status === "aborted")
        return INVALID;
      if (key.status === "dirty")
        status.dirty();
      if (value.status === "dirty")
        status.dirty();
      if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
        finalObject[key.value] = value.value;
      }
    }
    return { status: status.value, value: finalObject };
  }
};
var INVALID = Object.freeze({
  status: "aborted"
});
var DIRTY = (value) => ({ status: "dirty", value });
var OK = (value) => ({ status: "valid", value });
var isAborted = (x) => x.status === "aborted";
var isDirty = (x) => x.status === "dirty";
var isValid = (x) => x.status === "valid";
var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

// node_modules/zod/v3/helpers/errorUtil.js
var errorUtil;
(function(errorUtil2) {
  errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
  errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
})(errorUtil || (errorUtil = {}));

// node_modules/zod/v3/types.js
var ParseInputLazyPath = class {
  constructor(parent, value, path2, key) {
    this._cachedPath = [];
    this.parent = parent;
    this.data = value;
    this._path = path2;
    this._key = key;
  }
  get path() {
    if (!this._cachedPath.length) {
      if (Array.isArray(this._key)) {
        this._cachedPath.push(...this._path, ...this._key);
      } else {
        this._cachedPath.push(...this._path, this._key);
      }
    }
    return this._cachedPath;
  }
};
var handleResult = (ctx, result) => {
  if (isValid(result)) {
    return { success: true, data: result.value };
  } else {
    if (!ctx.common.issues.length) {
      throw new Error("Validation failed but no issues detected.");
    }
    return {
      success: false,
      get error() {
        if (this._error)
          return this._error;
        const error = new ZodError(ctx.common.issues);
        this._error = error;
        return this._error;
      }
    };
  }
};
function processCreateParams(params) {
  if (!params)
    return {};
  const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
  if (errorMap2 && (invalid_type_error || required_error)) {
    throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
  }
  if (errorMap2)
    return { errorMap: errorMap2, description };
  const customMap = (iss, ctx) => {
    const { message } = params;
    if (iss.code === "invalid_enum_value") {
      return { message: message ?? ctx.defaultError };
    }
    if (typeof ctx.data === "undefined") {
      return { message: message ?? required_error ?? ctx.defaultError };
    }
    if (iss.code !== "invalid_type")
      return { message: ctx.defaultError };
    return { message: message ?? invalid_type_error ?? ctx.defaultError };
  };
  return { errorMap: customMap, description };
}
var ZodType = class {
  get description() {
    return this._def.description;
  }
  _getType(input) {
    return getParsedType(input.data);
  }
  _getOrReturnCtx(input, ctx) {
    return ctx || {
      common: input.parent.common,
      data: input.data,
      parsedType: getParsedType(input.data),
      schemaErrorMap: this._def.errorMap,
      path: input.path,
      parent: input.parent
    };
  }
  _processInputParams(input) {
    return {
      status: new ParseStatus(),
      ctx: {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      }
    };
  }
  _parseSync(input) {
    const result = this._parse(input);
    if (isAsync(result)) {
      throw new Error("Synchronous parse encountered promise.");
    }
    return result;
  }
  _parseAsync(input) {
    const result = this._parse(input);
    return Promise.resolve(result);
  }
  parse(data, params) {
    const result = this.safeParse(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  safeParse(data, params) {
    const ctx = {
      common: {
        issues: [],
        async: params?.async ?? false,
        contextualErrorMap: params?.errorMap
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const result = this._parseSync({ data, path: ctx.path, parent: ctx });
    return handleResult(ctx, result);
  }
  "~validate"(data) {
    const ctx = {
      common: {
        issues: [],
        async: !!this["~standard"].async
      },
      path: [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    if (!this["~standard"].async) {
      try {
        const result = this._parseSync({ data, path: [], parent: ctx });
        return isValid(result) ? {
          value: result.value
        } : {
          issues: ctx.common.issues
        };
      } catch (err) {
        if (err?.message?.toLowerCase()?.includes("encountered")) {
          this["~standard"].async = true;
        }
        ctx.common = {
          issues: [],
          async: true
        };
      }
    }
    return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
      value: result.value
    } : {
      issues: ctx.common.issues
    });
  }
  async parseAsync(data, params) {
    const result = await this.safeParseAsync(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  async safeParseAsync(data, params) {
    const ctx = {
      common: {
        issues: [],
        contextualErrorMap: params?.errorMap,
        async: true
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
    const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
    return handleResult(ctx, result);
  }
  refine(check, message) {
    const getIssueProperties = (val) => {
      if (typeof message === "string" || typeof message === "undefined") {
        return { message };
      } else if (typeof message === "function") {
        return message(val);
      } else {
        return message;
      }
    };
    return this._refinement((val, ctx) => {
      const result = check(val);
      const setError = () => ctx.addIssue({
        code: ZodIssueCode.custom,
        ...getIssueProperties(val)
      });
      if (typeof Promise !== "undefined" && result instanceof Promise) {
        return result.then((data) => {
          if (!data) {
            setError();
            return false;
          } else {
            return true;
          }
        });
      }
      if (!result) {
        setError();
        return false;
      } else {
        return true;
      }
    });
  }
  refinement(check, refinementData) {
    return this._refinement((val, ctx) => {
      if (!check(val)) {
        ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
        return false;
      } else {
        return true;
      }
    });
  }
  _refinement(refinement) {
    return new ZodEffects({
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "refinement", refinement }
    });
  }
  superRefine(refinement) {
    return this._refinement(refinement);
  }
  constructor(def) {
    this.spa = this.safeParseAsync;
    this._def = def;
    this.parse = this.parse.bind(this);
    this.safeParse = this.safeParse.bind(this);
    this.parseAsync = this.parseAsync.bind(this);
    this.safeParseAsync = this.safeParseAsync.bind(this);
    this.spa = this.spa.bind(this);
    this.refine = this.refine.bind(this);
    this.refinement = this.refinement.bind(this);
    this.superRefine = this.superRefine.bind(this);
    this.optional = this.optional.bind(this);
    this.nullable = this.nullable.bind(this);
    this.nullish = this.nullish.bind(this);
    this.array = this.array.bind(this);
    this.promise = this.promise.bind(this);
    this.or = this.or.bind(this);
    this.and = this.and.bind(this);
    this.transform = this.transform.bind(this);
    this.brand = this.brand.bind(this);
    this.default = this.default.bind(this);
    this.catch = this.catch.bind(this);
    this.describe = this.describe.bind(this);
    this.pipe = this.pipe.bind(this);
    this.readonly = this.readonly.bind(this);
    this.isNullable = this.isNullable.bind(this);
    this.isOptional = this.isOptional.bind(this);
    this["~standard"] = {
      version: 1,
      vendor: "zod",
      validate: (data) => this["~validate"](data)
    };
  }
  optional() {
    return ZodOptional.create(this, this._def);
  }
  nullable() {
    return ZodNullable.create(this, this._def);
  }
  nullish() {
    return this.nullable().optional();
  }
  array() {
    return ZodArray.create(this);
  }
  promise() {
    return ZodPromise.create(this, this._def);
  }
  or(option) {
    return ZodUnion.create([this, option], this._def);
  }
  and(incoming) {
    return ZodIntersection.create(this, incoming, this._def);
  }
  transform(transform) {
    return new ZodEffects({
      ...processCreateParams(this._def),
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "transform", transform }
    });
  }
  default(def) {
    const defaultValueFunc = typeof def === "function" ? def : () => def;
    return new ZodDefault({
      ...processCreateParams(this._def),
      innerType: this,
      defaultValue: defaultValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodDefault
    });
  }
  brand() {
    return new ZodBranded({
      typeName: ZodFirstPartyTypeKind.ZodBranded,
      type: this,
      ...processCreateParams(this._def)
    });
  }
  catch(def) {
    const catchValueFunc = typeof def === "function" ? def : () => def;
    return new ZodCatch({
      ...processCreateParams(this._def),
      innerType: this,
      catchValue: catchValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodCatch
    });
  }
  describe(description) {
    const This = this.constructor;
    return new This({
      ...this._def,
      description
    });
  }
  pipe(target) {
    return ZodPipeline.create(this, target);
  }
  readonly() {
    return ZodReadonly.create(this);
  }
  isOptional() {
    return this.safeParse(void 0).success;
  }
  isNullable() {
    return this.safeParse(null).success;
  }
};
var cuidRegex = /^c[^\s-]{8,}$/i;
var cuid2Regex = /^[0-9a-z]+$/;
var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
var nanoidRegex = /^[a-z0-9_-]{21}$/i;
var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
var emojiRegex;
var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
var dateRegex = new RegExp(`^${dateRegexSource}$`);
function timeRegexSource(args) {
  let secondsRegexSource = `[0-5]\\d`;
  if (args.precision) {
    secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
  } else if (args.precision == null) {
    secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
  }
  const secondsQuantifier = args.precision ? "+" : "?";
  return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
}
function timeRegex(args) {
  return new RegExp(`^${timeRegexSource(args)}$`);
}
function datetimeRegex(args) {
  let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
  const opts = [];
  opts.push(args.local ? `Z?` : `Z`);
  if (args.offset)
    opts.push(`([+-]\\d{2}:?\\d{2})`);
  regex = `${regex}(${opts.join("|")})`;
  return new RegExp(`^${regex}$`);
}
function isValidIP(ip, version) {
  if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
    return true;
  }
  return false;
}
function isValidJWT(jwt, alg) {
  if (!jwtRegex.test(jwt))
    return false;
  try {
    const [header] = jwt.split(".");
    if (!header)
      return false;
    const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
    const decoded = JSON.parse(atob(base64));
    if (typeof decoded !== "object" || decoded === null)
      return false;
    if ("typ" in decoded && decoded?.typ !== "JWT")
      return false;
    if (!decoded.alg)
      return false;
    if (alg && decoded.alg !== alg)
      return false;
    return true;
  } catch {
    return false;
  }
}
function isValidCidr(ip, version) {
  if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
    return true;
  }
  return false;
}
var ZodString = class _ZodString extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = String(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.string) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.string,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.length < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.length > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "length") {
        const tooBig = input.data.length > check.value;
        const tooSmall = input.data.length < check.value;
        if (tooBig || tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          if (tooBig) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          } else if (tooSmall) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          }
          status.dirty();
        }
      } else if (check.kind === "email") {
        if (!emailRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "email",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "emoji") {
        if (!emojiRegex) {
          emojiRegex = new RegExp(_emojiRegex, "u");
        }
        if (!emojiRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "emoji",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "uuid") {
        if (!uuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "uuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "nanoid") {
        if (!nanoidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "nanoid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid") {
        if (!cuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid2") {
        if (!cuid2Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid2",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ulid") {
        if (!ulidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ulid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "url") {
        try {
          new URL(input.data);
        } catch {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "regex") {
        check.regex.lastIndex = 0;
        const testResult = check.regex.test(input.data);
        if (!testResult) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "regex",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "trim") {
        input.data = input.data.trim();
      } else if (check.kind === "includes") {
        if (!input.data.includes(check.value, check.position)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { includes: check.value, position: check.position },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "toLowerCase") {
        input.data = input.data.toLowerCase();
      } else if (check.kind === "toUpperCase") {
        input.data = input.data.toUpperCase();
      } else if (check.kind === "startsWith") {
        if (!input.data.startsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { startsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "endsWith") {
        if (!input.data.endsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { endsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "datetime") {
        const regex = datetimeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "datetime",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "date") {
        const regex = dateRegex;
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "date",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "time") {
        const regex = timeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "time",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "duration") {
        if (!durationRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "duration",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ip") {
        if (!isValidIP(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ip",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "jwt") {
        if (!isValidJWT(input.data, check.alg)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "jwt",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cidr") {
        if (!isValidCidr(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cidr",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64") {
        if (!base64Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64url") {
        if (!base64urlRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _regex(regex, validation, message) {
    return this.refinement((data) => regex.test(data), {
      validation,
      code: ZodIssueCode.invalid_string,
      ...errorUtil.errToObj(message)
    });
  }
  _addCheck(check) {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  email(message) {
    return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
  }
  url(message) {
    return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
  }
  emoji(message) {
    return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
  }
  uuid(message) {
    return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
  }
  nanoid(message) {
    return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
  }
  cuid(message) {
    return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
  }
  cuid2(message) {
    return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
  }
  ulid(message) {
    return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
  }
  base64(message) {
    return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
  }
  base64url(message) {
    return this._addCheck({
      kind: "base64url",
      ...errorUtil.errToObj(message)
    });
  }
  jwt(options) {
    return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
  }
  ip(options) {
    return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
  }
  cidr(options) {
    return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
  }
  datetime(options) {
    if (typeof options === "string") {
      return this._addCheck({
        kind: "datetime",
        precision: null,
        offset: false,
        local: false,
        message: options
      });
    }
    return this._addCheck({
      kind: "datetime",
      precision: typeof options?.precision === "undefined" ? null : options?.precision,
      offset: options?.offset ?? false,
      local: options?.local ?? false,
      ...errorUtil.errToObj(options?.message)
    });
  }
  date(message) {
    return this._addCheck({ kind: "date", message });
  }
  time(options) {
    if (typeof options === "string") {
      return this._addCheck({
        kind: "time",
        precision: null,
        message: options
      });
    }
    return this._addCheck({
      kind: "time",
      precision: typeof options?.precision === "undefined" ? null : options?.precision,
      ...errorUtil.errToObj(options?.message)
    });
  }
  duration(message) {
    return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
  }
  regex(regex, message) {
    return this._addCheck({
      kind: "regex",
      regex,
      ...errorUtil.errToObj(message)
    });
  }
  includes(value, options) {
    return this._addCheck({
      kind: "includes",
      value,
      position: options?.position,
      ...errorUtil.errToObj(options?.message)
    });
  }
  startsWith(value, message) {
    return this._addCheck({
      kind: "startsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  endsWith(value, message) {
    return this._addCheck({
      kind: "endsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  min(minLength, message) {
    return this._addCheck({
      kind: "min",
      value: minLength,
      ...errorUtil.errToObj(message)
    });
  }
  max(maxLength, message) {
    return this._addCheck({
      kind: "max",
      value: maxLength,
      ...errorUtil.errToObj(message)
    });
  }
  length(len, message) {
    return this._addCheck({
      kind: "length",
      value: len,
      ...errorUtil.errToObj(message)
    });
  }
  /**
   * Equivalent to `.min(1)`
   */
  nonempty(message) {
    return this.min(1, errorUtil.errToObj(message));
  }
  trim() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "trim" }]
    });
  }
  toLowerCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toLowerCase" }]
    });
  }
  toUpperCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toUpperCase" }]
    });
  }
  get isDatetime() {
    return !!this._def.checks.find((ch) => ch.kind === "datetime");
  }
  get isDate() {
    return !!this._def.checks.find((ch) => ch.kind === "date");
  }
  get isTime() {
    return !!this._def.checks.find((ch) => ch.kind === "time");
  }
  get isDuration() {
    return !!this._def.checks.find((ch) => ch.kind === "duration");
  }
  get isEmail() {
    return !!this._def.checks.find((ch) => ch.kind === "email");
  }
  get isURL() {
    return !!this._def.checks.find((ch) => ch.kind === "url");
  }
  get isEmoji() {
    return !!this._def.checks.find((ch) => ch.kind === "emoji");
  }
  get isUUID() {
    return !!this._def.checks.find((ch) => ch.kind === "uuid");
  }
  get isNANOID() {
    return !!this._def.checks.find((ch) => ch.kind === "nanoid");
  }
  get isCUID() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid");
  }
  get isCUID2() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid2");
  }
  get isULID() {
    return !!this._def.checks.find((ch) => ch.kind === "ulid");
  }
  get isIP() {
    return !!this._def.checks.find((ch) => ch.kind === "ip");
  }
  get isCIDR() {
    return !!this._def.checks.find((ch) => ch.kind === "cidr");
  }
  get isBase64() {
    return !!this._def.checks.find((ch) => ch.kind === "base64");
  }
  get isBase64url() {
    return !!this._def.checks.find((ch) => ch.kind === "base64url");
  }
  get minLength() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxLength() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodString.create = (params) => {
  return new ZodString({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodString,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
function floatSafeRemainder(val, step) {
  const valDecCount = (val.toString().split(".")[1] || "").length;
  const stepDecCount = (step.toString().split(".")[1] || "").length;
  const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
  const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
  const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
  return valInt % stepInt / 10 ** decCount;
}
var ZodNumber = class _ZodNumber extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
    this.step = this.multipleOf;
  }
  _parse(input) {
    if (this._def.coerce) {
      input.data = Number(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.number) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.number,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "int") {
        if (!util.isInteger(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: "integer",
            received: "float",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (floatSafeRemainder(input.data, check.value) !== 0) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "finite") {
        if (!Number.isFinite(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_finite,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodNumber({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodNumber({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  int(message) {
    return this._addCheck({
      kind: "int",
      message: errorUtil.toString(message)
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  finite(message) {
    return this._addCheck({
      kind: "finite",
      message: errorUtil.toString(message)
    });
  }
  safe(message) {
    return this._addCheck({
      kind: "min",
      inclusive: true,
      value: Number.MIN_SAFE_INTEGER,
      message: errorUtil.toString(message)
    })._addCheck({
      kind: "max",
      inclusive: true,
      value: Number.MAX_SAFE_INTEGER,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
  get isInt() {
    return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
  }
  get isFinite() {
    let max = null;
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
        return true;
      } else if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      } else if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return Number.isFinite(min) && Number.isFinite(max);
  }
};
ZodNumber.create = (params) => {
  return new ZodNumber({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodNumber,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodBigInt = class _ZodBigInt extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
  }
  _parse(input) {
    if (this._def.coerce) {
      try {
        input.data = BigInt(input.data);
      } catch {
        return this._getInvalidInput(input);
      }
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.bigint) {
      return this._getInvalidInput(input);
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            type: "bigint",
            minimum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            type: "bigint",
            maximum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (input.data % check.value !== BigInt(0)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _getInvalidInput(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.bigint,
      received: ctx.parsedType
    });
    return INVALID;
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodBigInt({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodBigInt({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodBigInt.create = (params) => {
  return new ZodBigInt({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodBigInt,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
var ZodBoolean = class extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = Boolean(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.boolean) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.boolean,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodBoolean.create = (params) => {
  return new ZodBoolean({
    typeName: ZodFirstPartyTypeKind.ZodBoolean,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodDate = class _ZodDate extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = new Date(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.date) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.date,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    if (Number.isNaN(input.data.getTime())) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_date
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.getTime() < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            message: check.message,
            inclusive: true,
            exact: false,
            minimum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.getTime() > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            message: check.message,
            inclusive: true,
            exact: false,
            maximum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return {
      status: status.value,
      value: new Date(input.data.getTime())
    };
  }
  _addCheck(check) {
    return new _ZodDate({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  min(minDate, message) {
    return this._addCheck({
      kind: "min",
      value: minDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  max(maxDate, message) {
    return this._addCheck({
      kind: "max",
      value: maxDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  get minDate() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min != null ? new Date(min) : null;
  }
  get maxDate() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max != null ? new Date(max) : null;
  }
};
ZodDate.create = (params) => {
  return new ZodDate({
    checks: [],
    coerce: params?.coerce || false,
    typeName: ZodFirstPartyTypeKind.ZodDate,
    ...processCreateParams(params)
  });
};
var ZodSymbol = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.symbol) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.symbol,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodSymbol.create = (params) => {
  return new ZodSymbol({
    typeName: ZodFirstPartyTypeKind.ZodSymbol,
    ...processCreateParams(params)
  });
};
var ZodUndefined = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.undefined,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodUndefined.create = (params) => {
  return new ZodUndefined({
    typeName: ZodFirstPartyTypeKind.ZodUndefined,
    ...processCreateParams(params)
  });
};
var ZodNull = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.null) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.null,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodNull.create = (params) => {
  return new ZodNull({
    typeName: ZodFirstPartyTypeKind.ZodNull,
    ...processCreateParams(params)
  });
};
var ZodAny = class extends ZodType {
  constructor() {
    super(...arguments);
    this._any = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodAny.create = (params) => {
  return new ZodAny({
    typeName: ZodFirstPartyTypeKind.ZodAny,
    ...processCreateParams(params)
  });
};
var ZodUnknown = class extends ZodType {
  constructor() {
    super(...arguments);
    this._unknown = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodUnknown.create = (params) => {
  return new ZodUnknown({
    typeName: ZodFirstPartyTypeKind.ZodUnknown,
    ...processCreateParams(params)
  });
};
var ZodNever = class extends ZodType {
  _parse(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.never,
      received: ctx.parsedType
    });
    return INVALID;
  }
};
ZodNever.create = (params) => {
  return new ZodNever({
    typeName: ZodFirstPartyTypeKind.ZodNever,
    ...processCreateParams(params)
  });
};
var ZodVoid = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.void,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodVoid.create = (params) => {
  return new ZodVoid({
    typeName: ZodFirstPartyTypeKind.ZodVoid,
    ...processCreateParams(params)
  });
};
var ZodArray = class _ZodArray extends ZodType {
  _parse(input) {
    const { ctx, status } = this._processInputParams(input);
    const def = this._def;
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (def.exactLength !== null) {
      const tooBig = ctx.data.length > def.exactLength.value;
      const tooSmall = ctx.data.length < def.exactLength.value;
      if (tooBig || tooSmall) {
        addIssueToContext(ctx, {
          code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
          minimum: tooSmall ? def.exactLength.value : void 0,
          maximum: tooBig ? def.exactLength.value : void 0,
          type: "array",
          inclusive: true,
          exact: true,
          message: def.exactLength.message
        });
        status.dirty();
      }
    }
    if (def.minLength !== null) {
      if (ctx.data.length < def.minLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.minLength.message
        });
        status.dirty();
      }
    }
    if (def.maxLength !== null) {
      if (ctx.data.length > def.maxLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.maxLength.message
        });
        status.dirty();
      }
    }
    if (ctx.common.async) {
      return Promise.all([...ctx.data].map((item, i) => {
        return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      })).then((result2) => {
        return ParseStatus.mergeArray(status, result2);
      });
    }
    const result = [...ctx.data].map((item, i) => {
      return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
    });
    return ParseStatus.mergeArray(status, result);
  }
  get element() {
    return this._def.type;
  }
  min(minLength, message) {
    return new _ZodArray({
      ...this._def,
      minLength: { value: minLength, message: errorUtil.toString(message) }
    });
  }
  max(maxLength, message) {
    return new _ZodArray({
      ...this._def,
      maxLength: { value: maxLength, message: errorUtil.toString(message) }
    });
  }
  length(len, message) {
    return new _ZodArray({
      ...this._def,
      exactLength: { value: len, message: errorUtil.toString(message) }
    });
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodArray.create = (schema, params) => {
  return new ZodArray({
    type: schema,
    minLength: null,
    maxLength: null,
    exactLength: null,
    typeName: ZodFirstPartyTypeKind.ZodArray,
    ...processCreateParams(params)
  });
};
function deepPartialify(schema) {
  if (schema instanceof ZodObject) {
    const newShape = {};
    for (const key in schema.shape) {
      const fieldSchema = schema.shape[key];
      newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
    }
    return new ZodObject({
      ...schema._def,
      shape: () => newShape
    });
  } else if (schema instanceof ZodArray) {
    return new ZodArray({
      ...schema._def,
      type: deepPartialify(schema.element)
    });
  } else if (schema instanceof ZodOptional) {
    return ZodOptional.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodNullable) {
    return ZodNullable.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodTuple) {
    return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
  } else {
    return schema;
  }
}
var ZodObject = class _ZodObject extends ZodType {
  constructor() {
    super(...arguments);
    this._cached = null;
    this.nonstrict = this.passthrough;
    this.augment = this.extend;
  }
  _getCached() {
    if (this._cached !== null)
      return this._cached;
    const shape = this._def.shape();
    const keys = util.objectKeys(shape);
    this._cached = { shape, keys };
    return this._cached;
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.object) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const { status, ctx } = this._processInputParams(input);
    const { shape, keys: shapeKeys } = this._getCached();
    const extraKeys = [];
    if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
      for (const key in ctx.data) {
        if (!shapeKeys.includes(key)) {
          extraKeys.push(key);
        }
      }
    }
    const pairs = [];
    for (const key of shapeKeys) {
      const keyValidator = shape[key];
      const value = ctx.data[key];
      pairs.push({
        key: { status: "valid", value: key },
        value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (this._def.catchall instanceof ZodNever) {
      const unknownKeys = this._def.unknownKeys;
      if (unknownKeys === "passthrough") {
        for (const key of extraKeys) {
          pairs.push({
            key: { status: "valid", value: key },
            value: { status: "valid", value: ctx.data[key] }
          });
        }
      } else if (unknownKeys === "strict") {
        if (extraKeys.length > 0) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.unrecognized_keys,
            keys: extraKeys
          });
          status.dirty();
        }
      } else if (unknownKeys === "strip") {
      } else {
        throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
      }
    } else {
      const catchall = this._def.catchall;
      for (const key of extraKeys) {
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: catchall._parse(
            new ParseInputLazyPath(ctx, value, ctx.path, key)
            //, ctx.child(key), value, getParsedType(value)
          ),
          alwaysSet: key in ctx.data
        });
      }
    }
    if (ctx.common.async) {
      return Promise.resolve().then(async () => {
        const syncPairs = [];
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          syncPairs.push({
            key,
            value,
            alwaysSet: pair.alwaysSet
          });
        }
        return syncPairs;
      }).then((syncPairs) => {
        return ParseStatus.mergeObjectSync(status, syncPairs);
      });
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get shape() {
    return this._def.shape();
  }
  strict(message) {
    errorUtil.errToObj;
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strict",
      ...message !== void 0 ? {
        errorMap: (issue, ctx) => {
          const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
          if (issue.code === "unrecognized_keys")
            return {
              message: errorUtil.errToObj(message).message ?? defaultError
            };
          return {
            message: defaultError
          };
        }
      } : {}
    });
  }
  strip() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strip"
    });
  }
  passthrough() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "passthrough"
    });
  }
  // const AugmentFactory =
  //   <Def extends ZodObjectDef>(def: Def) =>
  //   <Augmentation extends ZodRawShape>(
  //     augmentation: Augmentation
  //   ): ZodObject<
  //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
  //     Def["unknownKeys"],
  //     Def["catchall"]
  //   > => {
  //     return new ZodObject({
  //       ...def,
  //       shape: () => ({
  //         ...def.shape(),
  //         ...augmentation,
  //       }),
  //     }) as any;
  //   };
  extend(augmentation) {
    return new _ZodObject({
      ...this._def,
      shape: () => ({
        ...this._def.shape(),
        ...augmentation
      })
    });
  }
  /**
   * Prior to zod@1.0.12 there was a bug in the
   * inferred type of merged objects. Please
   * upgrade if you are experiencing issues.
   */
  merge(merging) {
    const merged = new _ZodObject({
      unknownKeys: merging._def.unknownKeys,
      catchall: merging._def.catchall,
      shape: () => ({
        ...this._def.shape(),
        ...merging._def.shape()
      }),
      typeName: ZodFirstPartyTypeKind.ZodObject
    });
    return merged;
  }
  // merge<
  //   Incoming extends AnyZodObject,
  //   Augmentation extends Incoming["shape"],
  //   NewOutput extends {
  //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
  //       ? Augmentation[k]["_output"]
  //       : k extends keyof Output
  //       ? Output[k]
  //       : never;
  //   },
  //   NewInput extends {
  //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
  //       ? Augmentation[k]["_input"]
  //       : k extends keyof Input
  //       ? Input[k]
  //       : never;
  //   }
  // >(
  //   merging: Incoming
  // ): ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"],
  //   NewOutput,
  //   NewInput
  // > {
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  setKey(key, schema) {
    return this.augment({ [key]: schema });
  }
  // merge<Incoming extends AnyZodObject>(
  //   merging: Incoming
  // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
  // ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"]
  // > {
  //   // const mergedShape = objectUtil.mergeShapes(
  //   //   this._def.shape(),
  //   //   merging._def.shape()
  //   // );
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  catchall(index) {
    return new _ZodObject({
      ...this._def,
      catchall: index
    });
  }
  pick(mask) {
    const shape = {};
    for (const key of util.objectKeys(mask)) {
      if (mask[key] && this.shape[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  omit(mask) {
    const shape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (!mask[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  /**
   * @deprecated
   */
  deepPartial() {
    return deepPartialify(this);
  }
  partial(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      const fieldSchema = this.shape[key];
      if (mask && !mask[key]) {
        newShape[key] = fieldSchema;
      } else {
        newShape[key] = fieldSchema.optional();
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  required(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (mask && !mask[key]) {
        newShape[key] = this.shape[key];
      } else {
        const fieldSchema = this.shape[key];
        let newField = fieldSchema;
        while (newField instanceof ZodOptional) {
          newField = newField._def.innerType;
        }
        newShape[key] = newField;
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  keyof() {
    return createZodEnum(util.objectKeys(this.shape));
  }
};
ZodObject.create = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.strictCreate = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strict",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.lazycreate = (shape, params) => {
  return new ZodObject({
    shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
var ZodUnion = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const options = this._def.options;
    function handleResults(results) {
      for (const result of results) {
        if (result.result.status === "valid") {
          return result.result;
        }
      }
      for (const result of results) {
        if (result.result.status === "dirty") {
          ctx.common.issues.push(...result.ctx.common.issues);
          return result.result;
        }
      }
      const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return Promise.all(options.map(async (option) => {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        return {
          result: await option._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          }),
          ctx: childCtx
        };
      })).then(handleResults);
    } else {
      let dirty = void 0;
      const issues = [];
      for (const option of options) {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        const result = option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: childCtx
        });
        if (result.status === "valid") {
          return result;
        } else if (result.status === "dirty" && !dirty) {
          dirty = { result, ctx: childCtx };
        }
        if (childCtx.common.issues.length) {
          issues.push(childCtx.common.issues);
        }
      }
      if (dirty) {
        ctx.common.issues.push(...dirty.ctx.common.issues);
        return dirty.result;
      }
      const unionErrors = issues.map((issues2) => new ZodError(issues2));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
  }
  get options() {
    return this._def.options;
  }
};
ZodUnion.create = (types, params) => {
  return new ZodUnion({
    options: types,
    typeName: ZodFirstPartyTypeKind.ZodUnion,
    ...processCreateParams(params)
  });
};
var getDiscriminator = (type) => {
  if (type instanceof ZodLazy) {
    return getDiscriminator(type.schema);
  } else if (type instanceof ZodEffects) {
    return getDiscriminator(type.innerType());
  } else if (type instanceof ZodLiteral) {
    return [type.value];
  } else if (type instanceof ZodEnum) {
    return type.options;
  } else if (type instanceof ZodNativeEnum) {
    return util.objectValues(type.enum);
  } else if (type instanceof ZodDefault) {
    return getDiscriminator(type._def.innerType);
  } else if (type instanceof ZodUndefined) {
    return [void 0];
  } else if (type instanceof ZodNull) {
    return [null];
  } else if (type instanceof ZodOptional) {
    return [void 0, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodNullable) {
    return [null, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodBranded) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodReadonly) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodCatch) {
    return getDiscriminator(type._def.innerType);
  } else {
    return [];
  }
};
var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const discriminator = this.discriminator;
    const discriminatorValue = ctx.data[discriminator];
    const option = this.optionsMap.get(discriminatorValue);
    if (!option) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union_discriminator,
        options: Array.from(this.optionsMap.keys()),
        path: [discriminator]
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return option._parseAsync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    } else {
      return option._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    }
  }
  get discriminator() {
    return this._def.discriminator;
  }
  get options() {
    return this._def.options;
  }
  get optionsMap() {
    return this._def.optionsMap;
  }
  /**
   * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
   * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
   * have a different value for each object in the union.
   * @param discriminator the name of the discriminator property
   * @param types an array of object schemas
   * @param params
   */
  static create(discriminator, options, params) {
    const optionsMap = /* @__PURE__ */ new Map();
    for (const type of options) {
      const discriminatorValues = getDiscriminator(type.shape[discriminator]);
      if (!discriminatorValues.length) {
        throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
      }
      for (const value of discriminatorValues) {
        if (optionsMap.has(value)) {
          throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
        }
        optionsMap.set(value, type);
      }
    }
    return new _ZodDiscriminatedUnion({
      typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
      discriminator,
      options,
      optionsMap,
      ...processCreateParams(params)
    });
  }
};
function mergeValues(a, b) {
  const aType = getParsedType(a);
  const bType = getParsedType(b);
  if (a === b) {
    return { valid: true, data: a };
  } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
    const bKeys = util.objectKeys(b);
    const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
    const newObj = { ...a, ...b };
    for (const key of sharedKeys) {
      const sharedValue = mergeValues(a[key], b[key]);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newObj[key] = sharedValue.data;
    }
    return { valid: true, data: newObj };
  } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
    if (a.length !== b.length) {
      return { valid: false };
    }
    const newArray = [];
    for (let index = 0; index < a.length; index++) {
      const itemA = a[index];
      const itemB = b[index];
      const sharedValue = mergeValues(itemA, itemB);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newArray.push(sharedValue.data);
    }
    return { valid: true, data: newArray };
  } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
    return { valid: true, data: a };
  } else {
    return { valid: false };
  }
}
var ZodIntersection = class extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const handleParsed = (parsedLeft, parsedRight) => {
      if (isAborted(parsedLeft) || isAborted(parsedRight)) {
        return INVALID;
      }
      const merged = mergeValues(parsedLeft.value, parsedRight.value);
      if (!merged.valid) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_intersection_types
        });
        return INVALID;
      }
      if (isDirty(parsedLeft) || isDirty(parsedRight)) {
        status.dirty();
      }
      return { status: status.value, value: merged.data };
    };
    if (ctx.common.async) {
      return Promise.all([
        this._def.left._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }),
        this._def.right._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        })
      ]).then(([left, right]) => handleParsed(left, right));
    } else {
      return handleParsed(this._def.left._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }), this._def.right._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }));
    }
  }
};
ZodIntersection.create = (left, right, params) => {
  return new ZodIntersection({
    left,
    right,
    typeName: ZodFirstPartyTypeKind.ZodIntersection,
    ...processCreateParams(params)
  });
};
var ZodTuple = class _ZodTuple extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (ctx.data.length < this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_small,
        minimum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      return INVALID;
    }
    const rest = this._def.rest;
    if (!rest && ctx.data.length > this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_big,
        maximum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      status.dirty();
    }
    const items = [...ctx.data].map((item, itemIndex) => {
      const schema = this._def.items[itemIndex] || this._def.rest;
      if (!schema)
        return null;
      return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
    }).filter((x) => !!x);
    if (ctx.common.async) {
      return Promise.all(items).then((results) => {
        return ParseStatus.mergeArray(status, results);
      });
    } else {
      return ParseStatus.mergeArray(status, items);
    }
  }
  get items() {
    return this._def.items;
  }
  rest(rest) {
    return new _ZodTuple({
      ...this._def,
      rest
    });
  }
};
ZodTuple.create = (schemas, params) => {
  if (!Array.isArray(schemas)) {
    throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
  }
  return new ZodTuple({
    items: schemas,
    typeName: ZodFirstPartyTypeKind.ZodTuple,
    rest: null,
    ...processCreateParams(params)
  });
};
var ZodRecord = class _ZodRecord extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const pairs = [];
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    for (const key in ctx.data) {
      pairs.push({
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
        value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (ctx.common.async) {
      return ParseStatus.mergeObjectAsync(status, pairs);
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get element() {
    return this._def.valueType;
  }
  static create(first, second, third) {
    if (second instanceof ZodType) {
      return new _ZodRecord({
        keyType: first,
        valueType: second,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(third)
      });
    }
    return new _ZodRecord({
      keyType: ZodString.create(),
      valueType: first,
      typeName: ZodFirstPartyTypeKind.ZodRecord,
      ...processCreateParams(second)
    });
  }
};
var ZodMap = class extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.map) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.map,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    const pairs = [...ctx.data.entries()].map(([key, value], index) => {
      return {
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
        value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
      };
    });
    if (ctx.common.async) {
      const finalMap = /* @__PURE__ */ new Map();
      return Promise.resolve().then(async () => {
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status.value, value: finalMap };
      });
    } else {
      const finalMap = /* @__PURE__ */ new Map();
      for (const pair of pairs) {
        const key = pair.key;
        const value = pair.value;
        if (key.status === "aborted" || value.status === "aborted") {
          return INVALID;
        }
        if (key.status === "dirty" || value.status === "dirty") {
          status.dirty();
        }
        finalMap.set(key.value, value.value);
      }
      return { status: status.value, value: finalMap };
    }
  }
};
ZodMap.create = (keyType, valueType, params) => {
  return new ZodMap({
    valueType,
    keyType,
    typeName: ZodFirstPartyTypeKind.ZodMap,
    ...processCreateParams(params)
  });
};
var ZodSet = class _ZodSet extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.set) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.set,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const def = this._def;
    if (def.minSize !== null) {
      if (ctx.data.size < def.minSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.minSize.message
        });
        status.dirty();
      }
    }
    if (def.maxSize !== null) {
      if (ctx.data.size > def.maxSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.maxSize.message
        });
        status.dirty();
      }
    }
    const valueType = this._def.valueType;
    function finalizeSet(elements2) {
      const parsedSet = /* @__PURE__ */ new Set();
      for (const element of elements2) {
        if (element.status === "aborted")
          return INVALID;
        if (element.status === "dirty")
          status.dirty();
        parsedSet.add(element.value);
      }
      return { status: status.value, value: parsedSet };
    }
    const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
    if (ctx.common.async) {
      return Promise.all(elements).then((elements2) => finalizeSet(elements2));
    } else {
      return finalizeSet(elements);
    }
  }
  min(minSize, message) {
    return new _ZodSet({
      ...this._def,
      minSize: { value: minSize, message: errorUtil.toString(message) }
    });
  }
  max(maxSize, message) {
    return new _ZodSet({
      ...this._def,
      maxSize: { value: maxSize, message: errorUtil.toString(message) }
    });
  }
  size(size, message) {
    return this.min(size, message).max(size, message);
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodSet.create = (valueType, params) => {
  return new ZodSet({
    valueType,
    minSize: null,
    maxSize: null,
    typeName: ZodFirstPartyTypeKind.ZodSet,
    ...processCreateParams(params)
  });
};
var ZodFunction = class _ZodFunction extends ZodType {
  constructor() {
    super(...arguments);
    this.validate = this.implement;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.function) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.function,
        received: ctx.parsedType
      });
      return INVALID;
    }
    function makeArgsIssue(args, error) {
      return makeIssue({
        data: args,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_arguments,
          argumentsError: error
        }
      });
    }
    function makeReturnsIssue(returns, error) {
      return makeIssue({
        data: returns,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_return_type,
          returnTypeError: error
        }
      });
    }
    const params = { errorMap: ctx.common.contextualErrorMap };
    const fn = ctx.data;
    if (this._def.returns instanceof ZodPromise) {
      const me = this;
      return OK(async function(...args) {
        const error = new ZodError([]);
        const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
          error.addIssue(makeArgsIssue(args, e));
          throw error;
        });
        const result = await Reflect.apply(fn, this, parsedArgs);
        const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
          error.addIssue(makeReturnsIssue(result, e));
          throw error;
        });
        return parsedReturns;
      });
    } else {
      const me = this;
      return OK(function(...args) {
        const parsedArgs = me._def.args.safeParse(args, params);
        if (!parsedArgs.success) {
          throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
        }
        const result = Reflect.apply(fn, this, parsedArgs.data);
        const parsedReturns = me._def.returns.safeParse(result, params);
        if (!parsedReturns.success) {
          throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
        }
        return parsedReturns.data;
      });
    }
  }
  parameters() {
    return this._def.args;
  }
  returnType() {
    return this._def.returns;
  }
  args(...items) {
    return new _ZodFunction({
      ...this._def,
      args: ZodTuple.create(items).rest(ZodUnknown.create())
    });
  }
  returns(returnType) {
    return new _ZodFunction({
      ...this._def,
      returns: returnType
    });
  }
  implement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  strictImplement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  static create(args, returns, params) {
    return new _ZodFunction({
      args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
      returns: returns || ZodUnknown.create(),
      typeName: ZodFirstPartyTypeKind.ZodFunction,
      ...processCreateParams(params)
    });
  }
};
var ZodLazy = class extends ZodType {
  get schema() {
    return this._def.getter();
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const lazySchema = this._def.getter();
    return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
  }
};
ZodLazy.create = (getter, params) => {
  return new ZodLazy({
    getter,
    typeName: ZodFirstPartyTypeKind.ZodLazy,
    ...processCreateParams(params)
  });
};
var ZodLiteral = class extends ZodType {
  _parse(input) {
    if (input.data !== this._def.value) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_literal,
        expected: this._def.value
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
  get value() {
    return this._def.value;
  }
};
ZodLiteral.create = (value, params) => {
  return new ZodLiteral({
    value,
    typeName: ZodFirstPartyTypeKind.ZodLiteral,
    ...processCreateParams(params)
  });
};
function createZodEnum(values, params) {
  return new ZodEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodEnum,
    ...processCreateParams(params)
  });
}
var ZodEnum = class _ZodEnum extends ZodType {
  _parse(input) {
    if (typeof input.data !== "string") {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(this._def.values);
    }
    if (!this._cache.has(input.data)) {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get options() {
    return this._def.values;
  }
  get enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Values() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  extract(values, newDef = this._def) {
    return _ZodEnum.create(values, {
      ...this._def,
      ...newDef
    });
  }
  exclude(values, newDef = this._def) {
    return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
      ...this._def,
      ...newDef
    });
  }
};
ZodEnum.create = createZodEnum;
var ZodNativeEnum = class extends ZodType {
  _parse(input) {
    const nativeEnumValues = util.getValidEnumValues(this._def.values);
    const ctx = this._getOrReturnCtx(input);
    if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(util.getValidEnumValues(this._def.values));
    }
    if (!this._cache.has(input.data)) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get enum() {
    return this._def.values;
  }
};
ZodNativeEnum.create = (values, params) => {
  return new ZodNativeEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
    ...processCreateParams(params)
  });
};
var ZodPromise = class extends ZodType {
  unwrap() {
    return this._def.type;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.promise,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
    return OK(promisified.then((data) => {
      return this._def.type.parseAsync(data, {
        path: ctx.path,
        errorMap: ctx.common.contextualErrorMap
      });
    }));
  }
};
ZodPromise.create = (schema, params) => {
  return new ZodPromise({
    type: schema,
    typeName: ZodFirstPartyTypeKind.ZodPromise,
    ...processCreateParams(params)
  });
};
var ZodEffects = class extends ZodType {
  innerType() {
    return this._def.schema;
  }
  sourceType() {
    return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const effect = this._def.effect || null;
    const checkCtx = {
      addIssue: (arg) => {
        addIssueToContext(ctx, arg);
        if (arg.fatal) {
          status.abort();
        } else {
          status.dirty();
        }
      },
      get path() {
        return ctx.path;
      }
    };
    checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
    if (effect.type === "preprocess") {
      const processed = effect.transform(ctx.data, checkCtx);
      if (ctx.common.async) {
        return Promise.resolve(processed).then(async (processed2) => {
          if (status.value === "aborted")
            return INVALID;
          const result = await this._def.schema._parseAsync({
            data: processed2,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        });
      } else {
        if (status.value === "aborted")
          return INVALID;
        const result = this._def.schema._parseSync({
          data: processed,
          path: ctx.path,
          parent: ctx
        });
        if (result.status === "aborted")
          return INVALID;
        if (result.status === "dirty")
          return DIRTY(result.value);
        if (status.value === "dirty")
          return DIRTY(result.value);
        return result;
      }
    }
    if (effect.type === "refinement") {
      const executeRefinement = (acc) => {
        const result = effect.refinement(acc, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(result);
        }
        if (result instanceof Promise) {
          throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
        }
        return acc;
      };
      if (ctx.common.async === false) {
        const inner = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inner.status === "aborted")
          return INVALID;
        if (inner.status === "dirty")
          status.dirty();
        executeRefinement(inner.value);
        return { status: status.value, value: inner.value };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          return executeRefinement(inner.value).then(() => {
            return { status: status.value, value: inner.value };
          });
        });
      }
    }
    if (effect.type === "transform") {
      if (ctx.common.async === false) {
        const base2 = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (!isValid(base2))
          return INVALID;
        const result = effect.transform(base2.value, checkCtx);
        if (result instanceof Promise) {
          throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
        }
        return { status: status.value, value: result };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base2) => {
          if (!isValid(base2))
            return INVALID;
          return Promise.resolve(effect.transform(base2.value, checkCtx)).then((result) => ({
            status: status.value,
            value: result
          }));
        });
      }
    }
    util.assertNever(effect);
  }
};
ZodEffects.create = (schema, effect, params) => {
  return new ZodEffects({
    schema,
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    effect,
    ...processCreateParams(params)
  });
};
ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
  return new ZodEffects({
    schema,
    effect: { type: "preprocess", transform: preprocess },
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    ...processCreateParams(params)
  });
};
var ZodOptional = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.undefined) {
      return OK(void 0);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodOptional.create = (type, params) => {
  return new ZodOptional({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodOptional,
    ...processCreateParams(params)
  });
};
var ZodNullable = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.null) {
      return OK(null);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodNullable.create = (type, params) => {
  return new ZodNullable({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodNullable,
    ...processCreateParams(params)
  });
};
var ZodDefault = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    let data = ctx.data;
    if (ctx.parsedType === ZodParsedType.undefined) {
      data = this._def.defaultValue();
    }
    return this._def.innerType._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  removeDefault() {
    return this._def.innerType;
  }
};
ZodDefault.create = (type, params) => {
  return new ZodDefault({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodDefault,
    defaultValue: typeof params.default === "function" ? params.default : () => params.default,
    ...processCreateParams(params)
  });
};
var ZodCatch = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const newCtx = {
      ...ctx,
      common: {
        ...ctx.common,
        issues: []
      }
    };
    const result = this._def.innerType._parse({
      data: newCtx.data,
      path: newCtx.path,
      parent: {
        ...newCtx
      }
    });
    if (isAsync(result)) {
      return result.then((result2) => {
        return {
          status: "valid",
          value: result2.status === "valid" ? result2.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      });
    } else {
      return {
        status: "valid",
        value: result.status === "valid" ? result.value : this._def.catchValue({
          get error() {
            return new ZodError(newCtx.common.issues);
          },
          input: newCtx.data
        })
      };
    }
  }
  removeCatch() {
    return this._def.innerType;
  }
};
ZodCatch.create = (type, params) => {
  return new ZodCatch({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodCatch,
    catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
    ...processCreateParams(params)
  });
};
var ZodNaN = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.nan) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.nan,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
};
ZodNaN.create = (params) => {
  return new ZodNaN({
    typeName: ZodFirstPartyTypeKind.ZodNaN,
    ...processCreateParams(params)
  });
};
var BRAND = /* @__PURE__ */ Symbol("zod_brand");
var ZodBranded = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const data = ctx.data;
    return this._def.type._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  unwrap() {
    return this._def.type;
  }
};
var ZodPipeline = class _ZodPipeline extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.common.async) {
      const handleAsync = async () => {
        const inResult = await this._def.in._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return DIRTY(inResult.value);
        } else {
          return this._def.out._parseAsync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      };
      return handleAsync();
    } else {
      const inResult = this._def.in._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
      if (inResult.status === "aborted")
        return INVALID;
      if (inResult.status === "dirty") {
        status.dirty();
        return {
          status: "dirty",
          value: inResult.value
        };
      } else {
        return this._def.out._parseSync({
          data: inResult.value,
          path: ctx.path,
          parent: ctx
        });
      }
    }
  }
  static create(a, b) {
    return new _ZodPipeline({
      in: a,
      out: b,
      typeName: ZodFirstPartyTypeKind.ZodPipeline
    });
  }
};
var ZodReadonly = class extends ZodType {
  _parse(input) {
    const result = this._def.innerType._parse(input);
    const freeze = (data) => {
      if (isValid(data)) {
        data.value = Object.freeze(data.value);
      }
      return data;
    };
    return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodReadonly.create = (type, params) => {
  return new ZodReadonly({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodReadonly,
    ...processCreateParams(params)
  });
};
function cleanParams(params, data) {
  const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
  const p2 = typeof p === "string" ? { message: p } : p;
  return p2;
}
function custom(check, _params = {}, fatal) {
  if (check)
    return ZodAny.create().superRefine((data, ctx) => {
      const r = check(data);
      if (r instanceof Promise) {
        return r.then((r2) => {
          if (!r2) {
            const params = cleanParams(_params, data);
            const _fatal = params.fatal ?? fatal ?? true;
            ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
          }
        });
      }
      if (!r) {
        const params = cleanParams(_params, data);
        const _fatal = params.fatal ?? fatal ?? true;
        ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
      }
      return;
    });
  return ZodAny.create();
}
var late = {
  object: ZodObject.lazycreate
};
var ZodFirstPartyTypeKind;
(function(ZodFirstPartyTypeKind2) {
  ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
  ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
  ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
  ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
  ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
  ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
  ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
  ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
  ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
  ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
  ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
  ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
  ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
  ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
  ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
  ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
  ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
  ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
  ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
  ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
  ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
  ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
  ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
  ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
  ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
  ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
  ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
  ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
  ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
  ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
  ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
  ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
  ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
  ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
  ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
  ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
})(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
var instanceOfType = (cls, params = {
  message: `Input not instance of ${cls.name}`
}) => custom((data) => data instanceof cls, params);
var stringType = ZodString.create;
var numberType = ZodNumber.create;
var nanType = ZodNaN.create;
var bigIntType = ZodBigInt.create;
var booleanType = ZodBoolean.create;
var dateType = ZodDate.create;
var symbolType = ZodSymbol.create;
var undefinedType = ZodUndefined.create;
var nullType = ZodNull.create;
var anyType = ZodAny.create;
var unknownType = ZodUnknown.create;
var neverType = ZodNever.create;
var voidType = ZodVoid.create;
var arrayType = ZodArray.create;
var objectType = ZodObject.create;
var strictObjectType = ZodObject.strictCreate;
var unionType = ZodUnion.create;
var discriminatedUnionType = ZodDiscriminatedUnion.create;
var intersectionType = ZodIntersection.create;
var tupleType = ZodTuple.create;
var recordType = ZodRecord.create;
var mapType = ZodMap.create;
var setType = ZodSet.create;
var functionType = ZodFunction.create;
var lazyType = ZodLazy.create;
var literalType = ZodLiteral.create;
var enumType = ZodEnum.create;
var nativeEnumType = ZodNativeEnum.create;
var promiseType = ZodPromise.create;
var effectsType = ZodEffects.create;
var optionalType = ZodOptional.create;
var nullableType = ZodNullable.create;
var preprocessType = ZodEffects.createWithPreprocess;
var pipelineType = ZodPipeline.create;
var ostring = () => stringType().optional();
var onumber = () => numberType().optional();
var oboolean = () => booleanType().optional();
var coerce = {
  string: ((arg) => ZodString.create({ ...arg, coerce: true })),
  number: ((arg) => ZodNumber.create({ ...arg, coerce: true })),
  boolean: ((arg) => ZodBoolean.create({
    ...arg,
    coerce: true
  })),
  bigint: ((arg) => ZodBigInt.create({ ...arg, coerce: true })),
  date: ((arg) => ZodDate.create({ ...arg, coerce: true }))
};
var NEVER = INVALID;

// src/generated/server/hub.ts
var hub_exports = {};
__export(hub_exports, {
  Entrada: () => Entrada,
  SEM_AUTORIZACAO: () => SEM_AUTORIZACAO,
  agora: () => agora,
  anexarDocumento: () => anexarDocumento,
  atualizarExecucao: () => atualizarExecucao,
  colRuns: () => colRuns,
  criarExecucao: () => criarExecucao,
  ctxOuErro: () => ctxOuErro,
  estadoEtapas: () => estadoEtapas,
  gerarEtapa: () => gerarEtapa,
  gravarTap: () => gravarTap,
  infoBaseIndicadores: () => infoBaseIndicadores,
  iniciarGeracao: () => iniciarGeracao,
  listarExecucoes: () => listarExecucoes,
  listarModelos: () => listarModelos,
  marcarGravada: () => marcarGravada,
  nomeUsuario: () => nomeUsuario,
  obterExecucao: () => obterExecucao,
  pedirAutorizacao: () => pedirAutorizacao,
  rodando: () => rodando,
  salvarDocumentos: () => salvarDocumentos,
  salvarEdicao: () => salvarEdicao,
  setEtapa: () => setEtapa,
  statusIA: () => statusIA,
  tokenIA: () => tokenIA
});
var import_node_crypto3 = require("node:crypto");

// server/monday.ts
var API = "https://api.monday.com/v2";
function serviceToken() {
  return (process.env.MONDAY_API_TOKEN ?? "").trim();
}
var ehMutacao = (query) => /^\s*mutation\b/.test(query);
async function respostaMonday(query, variables = {}, opts = {}) {
  const ctx = currentCtx();
  const pessoal = opts.tokenFixo ?? tokenAtual.getStore() ?? (ctx?.userId ? await tokenDoUsuario(ctx.userId) : null);
  if (!pessoal && ehMutacao(query)) {
    const r = await viaNavegador(query, variables);
    if (r !== SEM_NAVEGADOR) return { status: 200, json: r };
  }
  const token = pessoal ?? await tokenOAuth() ?? serviceToken();
  if (!token) throw new Error("App sem autoriza\xE7\xE3o OAuth e sem token de servi\xE7o configurado.");
  const res2 = await fetch(API, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: token, "API-Version": opts.versao ?? "2026-10" },
    body: JSON.stringify({ query, variables }),
    signal: opts.signal
  });
  return { status: res2.status, json: await res2.json().catch(() => null) };
}
async function gql(query, variables = {}, tokenFixo) {
  let wait = 1500;
  for (let attempt = 1; ; attempt++) {
    const { status, json } = await respostaMonday(query, variables, { tokenFixo });
    const err = json?.errors?.[0];
    const msg = err?.message || json?.error_message || (status >= 400 ? `HTTP ${status}` : "");
    const retryable = status === 429 || status >= 500 || /complexity|rate|limit|timeout|temporar/i.test(`${msg} ${err?.extensions?.code ?? ""}`);
    if (!msg && json?.data) return json.data;
    if (retryable && attempt < 6) {
      const s = err?.extensions?.retry_in_seconds;
      await new Promise((r) => setTimeout(r, s ? s * 1e3 + 500 : wait));
      wait = Math.min(wait * 2, 3e4);
      continue;
    }
    throw new Error(`API do monday: ${msg || "resposta vazia"}`.slice(0, 400));
  }
}

// src/generated/server/iaCore.ts
var URL_IA = "https://api.monday.com/platform-ai-gateway/openai/v1/chat/completions";
var URL_GEMINI = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions";
var URL_OPENROUTER = "https://openrouter.ai/api/v1/chat/completions";
var ehGemini = (modelo) => /^gemini/.test(modelo);
var ehOpenRouter = (modelo) => modelo === "openrouter/free" || /:free$/.test(modelo);
var RESERVAS_OPENROUTER = ["nvidia/nemotron-3-ultra-550b-a55b:free", "nvidia/nemotron-3.5-super-vl:free"];
function provedor(modelo) {
  if (ehGemini(modelo)) return { url: URL_GEMINI, chave: process.env.GEMINI_API_KEY, fonte: "Gemini", variavel: "GEMINI_API_KEY" };
  if (ehOpenRouter(modelo)) return { url: URL_OPENROUTER, chave: process.env.OPENROUTER_API_KEY, fonte: "OpenRouter", variavel: "OPENROUTER_API_KEY" };
  return null;
}
var MODELOS = [
  { id: "monday-standard", nome: "Padr\xE3o da monday" },
  { id: "gpt-5", nome: "GPT-5" },
  { id: "gpt-5-mini", nome: "GPT-5 mini (mais barato)" },
  { id: "gemini-3.5-flash", nome: "Gemini 3.5 Flash (Google)" },
  { id: "gemini-3.8-flash", nome: "Gemini 3.8 Flash (Google)" },
  { id: "openrouter/free", nome: "OpenRouter gratuito (autom\xE1tico)" },
  { id: "nvidia/nemotron-3-ultra-550b-a55b:free", nome: "Nemotron 3 Ultra (OpenRouter gratuito)" },
  { id: "nvidia/nemotron-3.5-super-vl:free", nome: "Nemotron 3.5 Super (OpenRouter gratuito)" },
  { id: "nvidia/nemotron-3.5-lightning:free", nome: "Nemotron 3.5 Lightning (OpenRouter gratuito)" },
  { id: "baidu/ernie-5.5-flash-preview:free", nome: "ERNIE 5.5 Flash (OpenRouter gratuito)" },
  { id: "particle-ai/particle-1:free", nome: "Particle 1 (OpenRouter gratuito)" },
  { id: "google/gemma-4-31b-it:free", nome: "Gemma 4 31B (OpenRouter gratuito)" }
];
function extrairJson(texto) {
  let t2 = texto.trim();
  const cerca = t2.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (cerca) t2 = cerca[1].trim();
  const ini = t2.indexOf("{");
  const fim = t2.lastIndexOf("}");
  if (ini >= 0 && fim > ini) t2 = t2.slice(ini, fim + 1);
  return JSON.parse(t2);
}
async function chamarIA(prompt, token, modelo = "monday-standard") {
  const inicio = Date.now();
  const gemini = ehGemini(modelo);
  const openrouter = ehOpenRouter(modelo);
  const ext = provedor(modelo);
  const chave = ext ? (ext.chave ?? "").trim() : token;
  if (ext && !chave) throw new Error(`A chave do ${ext.fonte} n\xE3o est\xE1 configurada no servidor (${ext.variavel}).`);
  const url = ext ? ext.url : URL_IA;
  const fonte = ext ? ext.fonte : "IA da monday";
  const corpo = {
    model: modelo,
    messages: [
      { role: "system", content: prompt.system },
      { role: "user", content: prompt.user }
    ],
    // No Gemini o limite inclui o raciocínio interno, por isso a folga.
    max_tokens: gemini || openrouter ? Math.min(prompt.maxTokens + 16e3, 65536) : prompt.maxTokens
  };
  if (modelo === "openrouter/free") corpo.models = ["openrouter/free", ...RESERVAS_OPENROUTER];
  else if (openrouter) corpo.models = [modelo, "openrouter/free"];
  if (!/^gpt/.test(modelo)) corpo.temperature = 0.2;
  let ultimoErro = "";
  for (let tentativa = 1; tentativa <= (gemini ? 5 : 3); tentativa++) {
    let res2;
    try {
      res2 = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${chave}`,
          ...openrouter ? { "X-Title": "Hub de Planejamento FGV DGPE" } : {}
        },
        body: JSON.stringify(corpo),
        signal: AbortSignal.timeout(15 * 6e4)
      });
    } catch (e) {
      ultimoErro = `sem resposta (${e.message})`;
      await new Promise((r) => setTimeout(r, 5e3 * tentativa));
      continue;
    }
    let j = await res2.json().catch(() => null);
    if (Array.isArray(j)) j = j[0];
    if (!res2.ok) {
      ultimoErro = `${res2.status}: ${String(j?.error?.message ?? j?.message ?? "").slice(0, 300)}`;
      if (openrouter && res2.status === 429 && (tentativa >= 2 || /per-day|per day/i.test(ultimoErro))) {
        throw new Error("O limite gratuito do OpenRouter foi atingido (20 pedidos por minuto e 50 por dia). Espere um pouco ou troque o modelo de IA.");
      }
      if (res2.status === 429 || res2.status >= 500) {
        await new Promise((r) => setTimeout(r, (gemini ? 2e4 : 8e3) * tentativa));
        continue;
      }
      throw new Error(`${fonte} recusou o pedido (${ultimoErro}).`);
    }
    const texto = j?.choices?.[0]?.message?.content ?? "";
    const motivo = j?.choices?.[0]?.finish_reason;
    try {
      const data = extrairJson(texto);
      return {
        data,
        modelo: String(j?.model ?? modelo),
        custo: typeof j?.usage?.cost === "number" ? j.usage.cost : null,
        tokensEntrada: Number(j?.usage?.prompt_tokens ?? 0),
        tokensSaida: Number(j?.usage?.completion_tokens ?? 0),
        ms: Date.now() - inicio
      };
    } catch {
      ultimoErro = motivo === "length" ? "a resposta passou do limite de tamanho" : "a resposta n\xE3o veio em JSON v\xE1lido";
      if (motivo === "length") corpo.max_tokens = Math.min(Number(corpo.max_tokens) * 2, 64e3);
    }
  }
  throw new Error(`A IA n\xE3o concluiu: ${ultimoErro}. Tente de novo.`);
}

// src/generated/server/conhecimento.ts
var EIXOS = `EIXOS DE PROJETO (use exatamente um destes nomes):
- Alfabetiza\xE7\xE3o: melhoria da aprendizagem nos anos iniciais do EF. Faz: forma\xE7\xE3o de educadores, gest\xE3o e acompanhamento para a aprendizagem, materiais did\xE1ticos e pedag\xF3gicos, plataformas educacionais, avalia\xE7\xF5es, assessoria t\xE9cnica na pol\xEDtica. Projetos: Trilhos da Alfabetiza\xE7\xE3o, Compromisso Nacional Crian\xE7a Alfabetizada (CNCA), Qualifica\xE7\xE3o Direta em Primeira Inf\xE2ncia.
- Educa\xE7\xE3o de Jovens e Adultos: oportunidades educacionais para jovens, adultos e idosos. Faz: materiais did\xE1ticos, avalia\xE7\xF5es, forma\xE7\xE3o de alfabetizadores, busca ativa, plataforma de acompanhamento, assessoria t\xE9cnica. Projetos: Alfabetiza\xE7\xE3o de Jovens e Adultos, EJA associada \xE0 EPT, Brasil Alfabetizado.
- Educa\xE7\xE3o Profissional e Tecnol\xF3gica: fortalecer pol\xEDticas de EPT. Faz: apoio \xE0 pol\xEDtica estadual de EPT, metodologias de oferta de cursos, normativos, monitoramento, matrizes curriculares, forma\xE7\xE3o de profissionais de EPT. Projetos: P\xF3s-gradua\xE7\xE3o Gest\xE3o em EPT, Pol\xEDtica de Educa\xE7\xE3o Profissional, LINC, Portf\xF3lio do Sistema S.
- Forma\xE7\xE3o Continuada: desenvolvimento de educadores e profissionais para implementar pol\xEDticas educacionais. Faz: desenho e normatiza\xE7\xE3o da pol\xEDtica de forma\xE7\xE3o, diagn\xF3stico das redes, monitoramento, AVA, conte\xFAdo de forma\xE7\xE3o presencial ou online, materiais de apoio, impress\xE3o e distribui\xE7\xE3o. Projetos: forma\xE7\xF5es para EF e EM, implementa\xE7\xE3o do documento curricular, forma\xE7\xE3o de gestores escolares.
- Gest\xE3o Estrat\xE9gica: qualificar planejamento, coordena\xE7\xE3o, controle e acompanhamento de programas e projetos para desempenho organizacional e efici\xEAncia de pol\xEDticas p\xFAblicas. Faz: planejamento estrat\xE9gico e or\xE7ament\xE1rio, ferramentas e sistemas de gest\xE3o, avalia\xE7\xE3o, desenho e normatiza\xE7\xE3o da estrutura organizacional, regime de colabora\xE7\xE3o, mapeamento de processos e escrit\xF3rio de projetos. Projetos: Planejamento Estrat\xE9gico, Apoio ao Regime de Colabora\xE7\xE3o, Economicidade e otimiza\xE7\xE3o de recursos, Gest\xE3o estrat\xE9gica de regionais, Escrit\xF3rio de Projetos e Processos, PAR, Educa\xE7\xE3o Empreendedora.
- Gest\xE3o P\xFAblica: fortalecimento da gest\xE3o de entidades do setor p\xFAblico com assessoria t\xE9cnica especializada. Faz: capacita\xE7\xE3o de gestores e t\xE9cnicos, capta\xE7\xE3o de recursos, documentos e relat\xF3rios t\xE9cnicos, estudos de viabilidade, eventos t\xE9cnicos com parceiros. Projetos: Rio Grande 2030, metodologia ESG, Governo Aberto, \xCDndice de Inova\xE7\xE3o, Plano de Transi\xE7\xE3o Ecol\xF3gica, SIGED/BID.
- Gest\xE3o para a Aprendizagem: melhorar resultados educacionais e fluxo escolar com projetos integrados. Faz: avalia\xE7\xF5es de aprendizagem, materiais did\xE1ticos, acompanhamento pedag\xF3gico, forma\xE7\xE3o articulada \xE0s avalia\xE7\xF5es, engajamento e mobiliza\xE7\xE3o. Projetos: Sistema Estruturado de Ensino, Gest\xE3o para a Aprendizagem.
- Pesquisas e Estudos: investigar e propor solu\xE7\xF5es para desafios das pol\xEDticas educacionais (pesquisas e publica\xE7\xF5es).`;
var TIPOLOGIAS = `MANUAL DE TIPOLOGIAS DE ENTREGA (c\xF3digo, modalidade, descri\xE7\xE3o curta):
1. Forma\xE7\xE3o (percurso formativo reconhec\xEDvel: objetivos, carga hor\xE1ria, metodologia e, se aplic\xE1vel, avalia\xE7\xE3o e certifica\xE7\xE3o; eventos s\xF3 de articula\xE7\xE3o n\xE3o contam)
 1A Forma\xE7\xE3o Presencial: cursos, oficinas, workshops, semin\xE1rios formativos, imers\xF5es, encontros presenciais; log\xEDstica de local, alimenta\xE7\xE3o e deslocamento.
 1B Forma\xE7\xE3o Virtual S\xEDncrona: aulas ao vivo, webin\xE1rios, mentoria e tutoria online, encontros s\xEDncronos, bancas por videoconfer\xEAncia.
 1C Forma\xE7\xE3o Virtual Ass\xEDncrona: cursos autoinstrucionais em AVA, trilhas com m\xF3dulos, atividades avaliativas em plataforma, f\xF3runs com tutoria.
 1D Forma\xE7\xE3o H\xEDbrida: combina presencial, s\xEDncrono e ass\xEDncrono num percurso \xFAnico.
 1E Programas Especiais: p\xF3s-gradua\xE7\xE3o lato sensu, certifica\xE7\xE3o profissional, resid\xEAncia t\xE9cnica, comunidades de pr\xE1tica.
 1F Capacita\xE7\xE3o T\xE9cnica Embutida: treinamento curto para a equipe do contratante operar o que foi entregue (ferramentas, processos, rotinas de monitoramento).
2. Material Pedag\xF3gico (orienta como ensinar ou formar; destinat\xE1rio \xE9 o educador)
 2A Digital: guias metodol\xF3gicos, matrizes curriculares e de compet\xEAncias, sequ\xEAncias did\xE1ticas, planos de curso e de aula.
 2B F\xEDsico: os mesmos materiais impressos em tiragem, com diagrama\xE7\xE3o, impress\xE3o e distribui\xE7\xE3o.
3. Material Did\xE1tico (carrega o conte\xFAdo a ser aprendido)
 3A Digital: cadernos de conte\xFAdo e de atividades, textos de refer\xEAncia, bancos de quest\xF5es.
 3B F\xEDsico: os mesmos impressos em tiragem.
4. Recursos Educacionais Digitais
 4A Conte\xFAdos audiovisuais (videoaulas, podcasts, anima\xE7\xF5es). 4B Objetos e recursos interativos (OEDs, simula\xE7\xF5es, quizzes). 4C Ambientes virtuais de aprendizagem configurados com conte\xFAdo.
5. Avalia\xE7\xE3o
 5A Avalia\xE7\xE3o de aprendizagem (diagn\xF3sticas, formativas, somativas, rubricas, bancos de itens, relat\xF3rios de desempenho). 5B Avalia\xE7\xE3o institucional e de programas (\xEDndices de maturidade, avalia\xE7\xE3o de programas). 5C Avalia\xE7\xE3o causal e de impacto. 5D Avalia\xE7\xE3o de desempenho operacional (m\xE9tricas de uso e ado\xE7\xE3o).
6. Diagn\xF3stico e Estudos
 6A Diagn\xF3stico operacional e situacional (diagn\xF3stico de rede ou organizacional, mapeamento de processos e fluxos, invent\xE1rios, escutas e entrevistas, mapeamento de atores). 6B Estudos t\xE9cnicos e modelagens (estudos de viabilidade, bases unificadas, modelagem financeira, cen\xE1rios). 6C Pesquisas acad\xEAmicas e publica\xE7\xF5es.
7. Assessoramento Estrat\xE9gico
 7A Planejamento, estrat\xE9gia e estrutura\xE7\xE3o organizacional (planejamento estrat\xE9gico, planos de a\xE7\xE3o, modelos de governan\xE7a e estrutura, redesenho de processos, manuais operacionais, matrizes de indicadores). 7B Ferramentas, dashboards e pain\xE9is de gest\xE3o (pain\xE9is de indicadores, planilhas de controle, templates). 7C Normativo e regulat\xF3rio (minutas de leis, decretos, portarias, regimentos e normativos internos, notas t\xE9cnicas jur\xEDdicas).
8. Solu\xE7\xE3o Tecnol\xF3gica
 8A Plataformas e sistemas (desenvolvimento ou integra\xE7\xE3o de software). 8B Modelos algor\xEDtmicos e de IA.`;
var TIPOS_RISCO = `CATEGORIAS DE RISCO (Categoria -> Tema):
- Risco Operacional (Gest\xE3o): dificuldades na opera\xE7\xE3o das atividades: mobiliza\xE7\xE3o de participantes, log\xEDstica de eventos presenciais, articula\xE7\xE3o com muitos munic\xEDpios ou escolas, infraestrutura, sobreposi\xE7\xE3o de agendas.
- Risco T\xE9cnico (Gest\xE3o): complexidade metodol\xF3gica, ader\xEAncia a diretrizes, qualidade dos materiais, adequa\xE7\xE3o ao contexto, integra\xE7\xE3o entre frentes.
- Risco de Gerenciamento (Gest\xE3o): falhas de governan\xE7a, comunica\xE7\xE3o insuficiente com o cliente, pap\xE9is indefinidos, aus\xEAncia de inst\xE2ncias decis\xF3rias, atrasos de valida\xE7\xE3o.
- Risco de Conformidade Legal/Normativo (Jur\xEDdico): ader\xEAncia a normas da administra\xE7\xE3o p\xFAblica e da pol\xEDtica ou programa vinculado; questionamento de \xF3rg\xE3os de controle; ajustes contratuais.
- Risco Tribut\xE1rio (Jur\xEDdico): mudan\xE7as ou interpreta\xE7\xF5es tribut\xE1rias que afetem notas, reten\xE7\xF5es, enquadramento fiscal.
- Risco Pol\xEDtico (Jur\xEDdico): mudan\xE7as de governo, de lideran\xE7a das secretarias ou de prioridades.
- Risco Institucional/Reputacional (Imagem): percep\xE7\xE3o p\xFAblica ou institucional sobre qualidade, efetividade ou conformidade.
- Risco Financeiro (Financeiro): atrasos de pagamento, contingenciamento, restri\xE7\xF5es fiscais, descompasso entre cronograma f\xEDsico e financeiro.
Probabilidade depende do controle da equipe sobre a causa (menos controle, mais probabilidade). Impacto reflete o pior efeito plaus\xEDvel (prazo, custo, desgaste, contrato).
Estrat\xE9gias: Prevenir, Mitigar, Transferir, Escalar, Aceitar.
Reda\xE7\xE3o: "Se [causa], ent\xE3o pode ocorrer [risco], gerando [efeito]". Sem riscos gen\xE9ricos: cada causa cita um elemento concreto do projeto.`;
var PARTES_INTERESSADAS = `MATRIZ DE PARTES INTERESSADAS (metodologia FGV DGPE):
Identifica grupos ou institui\xE7\xF5es com poder de impactar o projeto (decidir, validar, aprovar, mobilizar, executar, avaliar ou influenciar). No planejamento o mapeamento \xE9 institucional: \xF3rg\xE3os, secretarias, \xE1reas, conselhos, financiadores, redes, p\xFAblicos e fornecedores cr\xEDticos. N\xE3o liste pessoas f\xEDsicas. N\xE3o infle a matriz com quem n\xE3o interfere de fato (cargo n\xE3o \xE9 influ\xEAncia). Normalmente de 5 a 12 partes.
Etapas: identificar; papel; interesse; poder/influ\xEAncia; estrat\xE9gia pelo cruzamento; expectativas; riscos da rela\xE7\xE3o (atrasos em decis\xF5es ou valida\xE7\xF5es, baixa ades\xE3o, mobiliza\xE7\xE3o, mudan\xE7a de direcionamento, retrabalho, comunica\xE7\xE3o, percep\xE7\xE3o de resultados).
Estrat\xE9gia (f\xF3rmula da monday): Poder Alto + Interesse Alto = Gerenciar de perto; Poder Alto + Interesse M\xE9dio ou Baixo = Engajar institucionalmente; Poder M\xE9dio ou Baixo + Interesse Alto = Consultar frequentemente; demais = Manter informado.`;
var OKR = `PAINEL DE INDICADORES (OKRs) da FGV DGPE:
- Objetivo (O): qualitativo e aspiracional, a principal mudan\xE7a que o projeto quer gerar. Racional: "O projeto ser\xE1 bem-sucedido se...". Ideal: at\xE9 3 por projeto, conforme o tamanho do escopo.
- Resultado-chave (KR): quantitativo, SMART, sem subjetividade; mede "o que mudou". Racional: "Ao final, [resultado] comprovado por [crit\xE9rio], at\xE9 [prazo]". Ideal: at\xE9 5 por objetivo.
- KPI de processo: acompanha a execu\xE7\xE3o operacional (prazo, cobertura, ader\xEAncia ao padr\xE3o); mede "executamos como planejado?". Ideal: at\xE9 3 por KR.
- Relacione KRs e KPIs aos produtos do cronograma. Confronte com o TR e o contrato (indicadores de medi\xE7\xE3o de resultado exigidos pelo cliente entram obrigatoriamente).`;
var EAP = `EAP E CRONOGRAMA DA FGV DGPE (grupo Cronograma do quadro [PLAN]):
- N\xEDvel 1 = Produto (j\xE1 existe no grupo Produtos; n\xE3o repetir).
- N\xEDvel 2 = Entreg\xE1vel: o que precisa existir para o produto estar conclu\xEDdo. 2 a 4 por produto.
- N\xEDvel 3 = Marco: resultado intermedi\xE1rio e verific\xE1vel que leva o entreg\xE1vel \xE0 conclus\xE3o; traz quantitativos e condicionantes do contrato quando existirem (ex.: "Recebimento provis\xF3rio (5 dias) e definitivo (10 dias)"). 2 a 4 por entreg\xE1vel. Inclua como marco o fluxo de aceite e faturamento de cada produto fatur\xE1vel.
- N\xEDvel 4 = Atividade do cronograma de execu\xE7\xE3o: o que fazer para atingir o marco. 2 a 4 por marco. A reda\xE7\xE3o \xE9 important\xEDssima: SEMPRE come\xE7a com verbo no infinitivo (Elaborar, Realizar, Validar, Consolidar, Enviar, Mapear...), \xE9 espec\xEDfica e verific\xE1vel, sem ger\xFAndio e sem substantivo no in\xEDcio.
- Padr\xF5es usuais (adapte, n\xE3o copie se n\xE3o couber): eventos e forma\xE7\xF5es = Prepara\xE7\xE3o Pedag\xF3gica e Log\xEDstica, Execu\xE7\xE3o, Avalia\xE7\xE3o, Relat\xF3rio e Aceite; documentos, estudos e diagn\xF3sticos = Levantamento/Mapeamento, Elabora\xE7\xE3o/Produ\xE7\xE3o, Valida\xE7\xE3o e Entrega; plano de trabalho ou in\xEDcio = Mobiliza\xE7\xE3o e Governan\xE7a, Planejamento Operacional, Plano de Trabalho.
- Prazos em dias corridos contados a partir do in\xEDcio da execu\xE7\xE3o (dia 1). Respeite as fases e marcos do TR e as datas de entrega dos produtos; nenhuma atividade passa do fim da vig\xEAncia.`;
var REGRAS_GERAIS = `REGRAS INVIOL\xC1VEIS
- Fonte dos dados: todo dado do projeto (nomes, n\xFAmeros, datas, valores, p\xFAblicos, locais) vem S\xD3 dos documentos do projeto enviados. A metodologia serve para m\xE9todo, vocabul\xE1rio e taxonomias. Nunca invente.
- Hierarquia documental: TR assinado > Contrato/Termo de Colabora\xE7\xE3o > Proposta > Minuta de escopo > ETP e demais anexos. Exce\xE7\xE3o: se o contrato ou a proposta disser expressamente que a proposta prevalece, siga e cite o item e o trecho.
- Diverg\xEAncias: use o documento de maior hierarquia e registre a diverg\xEAncia nas pend\xEAncias, com a fonte de cada vers\xE3o.
- Lacunas: quando a informa\xE7\xE3o n\xE3o existir, escreva "N\xE3o identificado nos documentos" e registre nas pend\xEAncias.
- Rastreabilidade: indique a fonte (documento + item, cl\xE1usula, p\xE1gina ou anexo) quando pedido. Copie o n\xFAmero do item como aparece; sem certeza, cite a se\xE7\xE3o pelo t\xEDtulo.
- Linguagem: portugu\xEAs, institucional, direta, simples, sem jarg\xE3o jur\xEDdico, sem cita\xE7\xF5es longas. Qualquer pessoa da DGPE deve entender o projeto lendo s\xF3 o seu texto. N\xE3o use travess\xE3o como conector de frases.
- Sem nomes de pessoas f\xEDsicas: use cargo ou inst\xE2ncia (ex.: "Superintendente", "Gestor do contrato"). Signat\xE1rios da proposta (diretoria da FGV DGPE) n\xE3o s\xE3o equipe gestora.
- Prazos: transcreva como est\xE3o ("10 dias", sem acrescentar "\xFAteis" ou "corridos").
- Valores: n\xFAmero com ponto decimal, sem "R$" e sem separador de milhar (ex.: 551526.22).`;
var RESP_SUPERINTENDENCIA = [
  "Orientar as decis\xF5es estrat\xE9gicas e custos do projeto, garantindo alinhamento ao escopo e \xE0s diretrizes institucionais.",
  "Validar ajustes relevantes de planejamento, escopo, metodologia, or\xE7ament\xE1rio ou composi\xE7\xE3o da equipe.",
  "Acompanhar a qualidade t\xE9cnica das entregas e apoiar a interlocu\xE7\xE3o com o cliente em temas estrat\xE9gicos.",
  "Assegurar que os ritos de planejamento, gest\xE3o e monitoramento sejam cumpridos."
];
var RESP_CDPE = [
  "Garantir o alinhamento estrat\xE9gico das frentes de trabalho pedag\xF3gicas e t\xE9cnicas do projeto, assegurando ader\xEAncia \xE0s diretrizes institucionais, ao escopo contratado e \xE0s orienta\xE7\xF5es metodol\xF3gicas da FGV DGPE.",
  "Elaborar e monitorar o planejamento financeiro do projeto, assegurando a execu\xE7\xE3o or\xE7ament\xE1ria.",
  "Acompanhar e validar os produtos do projeto, assegurando a qualidade t\xE9cnica e pedag\xF3gica e a organiza\xE7\xE3o da documenta\xE7\xE3o das entregas.",
  "Articular os atores pedag\xF3gicos, assegurando alinhamento t\xE9cnico e metodol\xF3gico \xE0s diretrizes do projeto e coer\xEAncia das a\xE7\xF5es."
];
var RESP_SAE = [
  "Orientar as decis\xF5es estrat\xE9gicas e custos do projeto, garantindo a aplica\xE7\xE3o da metodologia de Gest\xE3o para Aprendizagem da FGV DGPE.",
  "Disponibilizar recursos padronizados para a implementa\xE7\xE3o da metodologia.",
  "Disponibilizar especialistas, formadores e demais profissionais para garantir a implementa\xE7\xE3o adequada da metodologia de Gest\xE3o para Aprendizagem da FGV DGPE.",
  "Realizar integra\xE7\xE3o entre os projetos de Gest\xE3o para Aprendizagem para compartilhamento de boas pr\xE1ticas.",
  "Atuar como mediador do processo de aloca\xE7\xE3o de equipe e novas negocia\xE7\xF5es de modo a garantir a aplica\xE7\xE3o da metodologia de Gest\xE3o para Aprendizagem da FGV DGPE.",
  "Assegurar que os ritos de Gest\xE3o para Aprendizagem sejam cumpridos.",
  "Estruturar os processos basilares dos eixos da Gest\xE3o para Aprendizagem (Fluxo, Assessoria Educacional, RPP, entre outros).",
  "Monitorar os indicadores de Gest\xE3o para Aprendizagem e atuar na corre\xE7\xE3o de rota, se necess\xE1rio.",
  "Formar em servi\xE7o a equipe de projetos de Gest\xE3o para Aprendizagem."
];
var RESP_EQUIPE_PADRAO = [
  "Garantir o alinhamento estrat\xE9gico das partes envolvidas no projeto, conduzindo a execu\xE7\xE3o conforme o escopo contratado e as orienta\xE7\xF5es institucionais.",
  "Planejar, organizar e acompanhar as atividades do projeto, assegurando a integra\xE7\xE3o entre aspectos pedag\xF3gicos, operacionais e log\xEDsticos.",
  "Distribuir e coordenar as tarefas entre os membros da equipe, garantindo clareza de responsabilidades e cumprimento dos prazos.",
  "Realizar a interlocu\xE7\xE3o com o cliente, registrando demandas, encaminhamentos e ajustes necess\xE1rios ao andamento do projeto.",
  "Monitorar cronograma, escopo, custos e riscos, sinalizando desvios e propondo solu\xE7\xF5es quando necess\xE1rio.",
  "Validar internamente entregas parciais e finais, garantindo qualidade t\xE9cnica antes de encaminhar para valida\xE7\xE3o institucional ou envio ao cliente.",
  "Produzir e atualizar relat\xF3rios, documentos e registros, mantendo a organiza\xE7\xE3o e a rastreabilidade das informa\xE7\xF5es do projeto.",
  "Acompanhar o desempenho das a\xE7\xF5es previstas, analisando resultados, indicadores e evid\xEAncias de execu\xE7\xE3o.",
  "Articular especialistas, formadores e demais envolvidos, assegurando alinhamento t\xE9cnico e coer\xEAncia das a\xE7\xF5es.",
  "Promover a comunica\xE7\xE3o cont\xEDnua dentro da equipe, garantindo que todos estejam informados sobre prioridades, pend\xEAncias e decis\xF5es.",
  "Apoiar discuss\xF5es e ajustes operacionais com o cliente, sempre alinhados \xE0 coordena\xE7\xE3o interna da FGV DGPE."
];
var RESP_EQUIPE_CNCA = [
  "Assegurar o alinhamento do projeto com a equipe executora e com o cliente/parceiro, conduzindo a comunica\xE7\xE3o institucional, o engajamento das partes envolvidas e a tradu\xE7\xE3o das diretrizes estrat\xE9gicas em a\xE7\xF5es operacionais.",
  "Planejar, organizar e acompanhar as atividades do projeto, assegurando a integra\xE7\xE3o entre aspectos pedag\xF3gicos, operacionais e log\xEDsticos.",
  "Distribuir e coordenar as tarefas entre os membros da equipe, garantindo clareza de responsabilidades e cumprimento dos prazos.",
  "Realizar a interlocu\xE7\xE3o com o cliente, registrando demandas, encaminhamentos e ajustes necess\xE1rios ao andamento do projeto.",
  "Monitorar o cronograma, o escopo e os riscos do projeto em articula\xE7\xE3o com a CDPE, sinalizando desvios, impactos e necessidades de replanejamento.",
  "Validar internamente entregas parciais e finais, garantindo qualidade t\xE9cnica antes de encaminhar para valida\xE7\xE3o institucional ou envio ao cliente.",
  "Acompanhar o desempenho das a\xE7\xF5es previstas, analisando resultados, indicadores e evid\xEAncias de execu\xE7\xE3o.",
  "Promover a comunica\xE7\xE3o cont\xEDnua dentro da equipe, garantindo que todos estejam informados sobre prioridades, pend\xEAncias e decis\xF5es.",
  "Apoiar discuss\xF5es e ajustes operacionais com o cliente, sempre alinhados \xE0 coordena\xE7\xE3o interna da FGV DGPE."
];
function responsabilidades(modelo) {
  return {
    superintendencia: RESP_SUPERINTENDENCIA,
    cdpe: modelo === "cnca" ? RESP_CDPE : null,
    sae: modelo === "ga" ? RESP_SAE : null,
    equipe: modelo === "cnca" ? RESP_EQUIPE_CNCA : RESP_EQUIPE_PADRAO
  };
}

// src/generated/lib/rotulos.ts
var ROTULOS = {
  eixo: ["Gest\xE3o Estrat\xE9gica", "Alfabetiza\xE7\xE3o", "Gest\xE3o para a aprendizagem", "Gest\xE3o p\xFAblica", "Educa\xE7\xE3o profissional e tecnol\xF3gica", "Educa\xE7\xE3o de jovens e adultos", "Forma\xE7\xE3o continuada", "Pesquisas e estudos"],
  tipoEntrega: ["Forma\xE7\xE3o Presencial", "Forma\xE7\xE3o Virtual S\xEDncrona", "Forma\xE7\xE3o Virtual Ass\xEDncrona", "Forma\xE7\xE3o H\xEDbrida", "Material Pedag\xF3gico F\xEDsico", "Material Pedag\xF3gico Digital", "Recursos Educacionais Digitais", "Avalia\xE7\xE3o Presencial", "Avalia\xE7\xE3o Digital", "Avalia\xE7\xE3o Anal\xEDtica", "Diagn\xF3stico e Estudos", "Assessoramento Estrat\xE9gico Anal\xEDtico", "Assessoramento Estrat\xE9gico Institucional", "Solu\xE7\xE3o Tecnol\xF3gica"],
  frentes: ["Gest\xE3o do Projeto", "Produto", "Pedag\xF3gica", "Dados", "Log\xEDstica", "Mobiliza\xE7\xE3o", "Comunica\xE7\xE3o", "Qualidade", "Apoio \xE0 Gest\xE3o", "Gest\xE3o de Time", "Rotinas do Projeto"],
  categoria: ["Risco Operacional", "Risco T\xE9cnico", "Risco de Gerenciamento", "Risco de Conformidade Legal/Normativo", "Risco Tribut\xE1rio", "Risco Pol\xEDtico", "Risco Institucional/Reputacional", "Risco Financeiro"],
  probabilidade: ["Muito baixo", "Baixo", "M\xE9dio", "Alto", "Muito Alto"],
  impacto: ["Muito Baixo", "Baixo", "M\xE9dio", "Alto", "Muito Alto"],
  estrategia: ["Prevenir", "Mitigar", "Transferir", "Escalar", "Aceitar"],
  papel: ["Decisor", "Influenciador", "Executor", "T\xE9cnico", "Administrativo", "Valida\xE7\xE3o"],
  nivel: ["Alto", "M\xE9dio", "Baixo"],
  unidade: ["%", "Unidade", "Pessoa", "Projeto", "Dia", "Hora", "Professor", "Estudante", "NPS"],
  temporalidade: ["Mensal", "Bimestral", "Trimestral", "Semestral", "Anual"],
  coleta: ["Relat\xF3rio", "Formul\xE1rio", "Registro em ata", "An\xE1lise documental", "Grupo focal"],
  polaridade: ["Quanto mais, melhor", "Quanto menos, melhor"],
  natureza: ["Privado", "Municipal", "Estadual", "Federal", "Multissetorial"],
  modalidade: ["Presencial", "Remoto", "H\xEDbrido"],
  // Rótulos do quadro 09.1 Projetos | Calculadora de Riscos (v3)
  calc: {
    c1_fat: ["Pr\xF3-bono", "At\xE9 R$ 7.999.999,99 ao ano", "Entre R$ 8.000.000,00 e R$ 39.999.999,99 ao ano", "A partir de R$ 40.000.000,00 ao ano"],
    c2_tipofat: ["Parcela", "Produto fatur\xE1vel", "N\xE3o fatur\xE1vel"],
    c3_vig: ["At\xE9 12 meses", "Entre 13 e 24 meses", "A partir de 25 meses"],
    c4_cli: ["P\xFAblico | Municipal", "P\xFAblico | Estadual / Federal", "Privado", "Multissetorial"],
    c5_mod: ["Presencial", "Remoto", "H\xEDbrido"],
    c6_prod: ["At\xE9 2 produtos por m\xEAs", "Entre 3 a 6 produtos por m\xEAs", "Igual ou acima de 7 produtos por m\xEAs"],
    c7_tipo: ["Forma\xE7\xE3o", "Material Pedag\xF3gico", "Material Did\xE1tico", "Recursos Educacionais Digitais", "Avalia\xE7\xE3o", "Diagn\xF3stico e Estudos", "Assessoramento Estrat\xE9gico", "Solu\xE7\xE3o Tecnol\xF3gica"],
    c8_equipe: ["At\xE9 10 membros na equipe", "Entre 11 e 30 membros na equipe", "Entre 31 e 99 membros na equipe", "A partir de 100 membros na equipe"]
  }
};
var ROTULO_ETAPA = {
  analise: "An\xE1lise",
  tap: "TAP",
  produtos: "Produtos",
  eap: "EAP e Cronograma",
  riscos: "Riscos espec\xEDficos",
  complemento: "Riscos da calculadora",
  indicadores: "Indicadores",
  partes: "Partes Interessadas",
  calculadora: "Calculadora de Riscos"
};

// src/generated/server/prompts.ts
var lista = (xs) => xs.map((x) => `"${x}"`).join(", ");
function blocoDocumentos(docs) {
  return docs.map((d) => `===== DOCUMENTO: ${d.nome} (tipo: ${d.tipo}) =====
${d.texto.trim()}
===== FIM DE ${d.nome} =====`).join("\n\n");
}
var PAPEL = `Voc\xEA \xE9 analista da Coordena\xE7\xE3o de Planejamento de Projetos da FGV DGPE. A partir dos documentos de pactua\xE7\xE3o de UM projeto, voc\xEA produz o pr\xE9-preenchimento dos instrumentos de planejamento, no padr\xE3o da DGPE, para gravar no quadro [PLAN] do projeto na monday. Quem revisa \xE9 o Ponto Focal de Planejamento. Siga exatamente os campos, os valores permitidos e os formatos pedidos.`;
var SAIDA = `Responda SOMENTE com um objeto JSON v\xE1lido, sem texto antes ou depois e sem blocos de c\xF3digo. Use exatamente as chaves pedidas. Textos em portugu\xEAs.`;
function base(extra) {
  return [PAPEL, REGRAS_GERAIS, extra, SAIDA].join("\n\n");
}
function cabecalho(p) {
  return `PROJETO NO 02.01: ${p.nomeItem} (c\xF3digo ${p.codigo || "n\xE3o informado"}).${p.eixo02 ? ` Eixo cadastrado: ${p.eixo02}.` : ""}${p.valor02 ? ` Valor cadastrado: ${p.valor02}.` : ""}${p.inicioExecucao ? ` In\xEDcio de execu\xE7\xE3o considerado: ${p.inicioExecucao}.` : ""}${p.diasVigencia ? ` Vig\xEAncia considerada: ${p.diasVigencia} dias.` : ""}`;
}
function promptAnalise(p, docs) {
  const formato = `FORMATO DA RESPOSTA:
{
 "ficha": {
  "codigo_nome": string, "cliente": string, "uf_abrangencia": string, "instrumento": string,
  "data_assinatura": string (dd/mm/aaaa ou "N\xE3o identificado nos documentos"),
  "vigencia": string (ex.: "180 dias a contar da assinatura"), "vigencia_dias": number|null (dias corridos),
  "prazo_execucao": string, "valor_global": number|null, "modalidade": um de [${lista(ROTULOS.modalidade)}],
  "eixo": um de [${lista(ROTULOS.eixo)}] (compare o objeto com o que cada eixo faz; n\xE3o invente; n\xE3o deixe vazio),
  "eixo_justificativa": string (uma frase),
  "tipologias": [string] (c\xF3digo e nome do Manual, ex.: "7C Normativo e Regulat\xF3rio"),
  "documentos": [{"nome": string, "data": string}]
 },
 "tap": {
  "nome_projeto": string (exatamente o nome do projeto no 02.01),
  "data_inicio_contrato": string (data dd/mm/aaaa ou a regra, ex.: "A contar da assinatura do contrato (n\xE3o assinado at\xE9 a an\xE1lise)"),
  "vigencia_contratual": string (ex.: "180 dias (6 meses), prorrog\xE1vel nos termos do art. 111 da Lei 14.133/2021"),
  "valor_total": number|null,
  "natureza_cliente": um de [${lista(ROTULOS.natureza)}],
  "modalidade": um de [${lista(ROTULOS.modalidade)}],
  "experiencia_institucional": string (experi\xEAncia anterior da FGV DGPE com este cliente ou objeto citada nos documentos; se n\xE3o houver, "N\xE3o identificado nos documentos"),
  "justificativa": string (1 ou 2 par\xE1grafos corridos: quem contratou e com que finalidade p\xFAblica; problema ou contexto evidenciado; s\xEDntese do escopo. Sem t\xF3picos),
  "resultado_principal": string (come\xE7a com "O resultado principal esperado \xE9"),
  "como_chega": string (par\xE1grafo curto: arranjo de a\xE7\xF5es, produtos e governan\xE7a),
  "resultados_quantitativos": [string] (um por quantidade evidenciada, n\xFAmeros exatamente como nos documentos),
  "total_produtos": number,
  "tipos_entrega": [string] (r\xF3tulos entre [${lista(ROTULOS.tipoEntrega)}]),
  "processo_entrega": [string] (linhas: quem recebe, recebimento provis\xF3rio e definitivo com prazos, OS e NE, garantia, condi\xE7\xF5es de pagamento, documentos para faturamento; cada linha termina com a fonte entre par\xEAnteses),
  "perfis_equipe": string (perfis de especialista ou coordenador indicados na proposta, sem nomes; ou "N\xE3o identificado nos documentos"),
  "fora_escopo": [string] (cada item come\xE7a com "N\xE3o contempla" e termina com a fonte entre par\xEAnteses; s\xF3 limites expl\xEDcitos ou claramente impl\xEDcitos),
  "necessidades": [string] (requisitos e condicionantes cr\xEDticos priorizados: qualidade, crit\xE9rios de aceite, normas, premissas, depend\xEAncias do cliente, indicadores de medi\xE7\xE3o de resultado),
  "modelo_tap": "cnca" se for projeto do Compromisso Nacional Crian\xE7a Alfabetizada; "ga" se o eixo for Gest\xE3o para a Aprendizagem; sen\xE3o "padrao"
 },
 "calculadora": {
  "c1_fat": um de [${lista(ROTULOS.calc.c1_fat)}] (faturamento m\xE9dio por ano: valor global dividido pela vig\xEAncia em anos; 0 = Pr\xF3-bono),
  "c2_tipofat": um de [${lista(ROTULOS.calc.c2_tipofat)}],
  "c3_vig": um de [${lista(ROTULOS.calc.c3_vig)}],
  "c4_cli": um de [${lista(ROTULOS.calc.c4_cli)}],
  "c5_mod": um de [${lista(ROTULOS.calc.c5_mod)}],
  "c6_prod": um de [${lista(ROTULOS.calc.c6_prod)}] (pico de produtos entregues no mesmo m\xEAs),
  "c7_tipo": [um ou mais de ${lista(ROTULOS.calc.c7_tipo)}],
  "c8_equipe": um de [${lista(ROTULOS.calc.c8_equipe)}] (nunca null: se os documentos n\xE3o trouxerem o tamanho da equipe, estime pelos perfis, horas, produtos e valor, e comece a justificativa com "Estimado:"),
  "c8_gr85": boolean (outros v\xEDnculos como RPA ou tempor\xE1rios superam os efetivos),
  "justificativas": {"c1_fat": string, "c2_tipofat": string, "c3_vig": string, "c4_cli": string, "c5_mod": string, "c6_prod": string, "c7_tipo": string, "c8_equipe": string} (uma linha com a fonte)
 },
 "pendencias": [{"instrumento": string, "pendencia": string, "fontes": string, "pergunta": string}] (tudo que ficou "N\xE3o identificado", toda diverg\xEAncia entre documentos e toda inconsist\xEAncia)
}`;
  return {
    system: base([EIXOS, TIPOLOGIAS, formato].join("\n\n")),
    user: `${cabecalho(p)}

Leia todos os documentos antes de responder. Se faltar o TR ou o contrato, registre nas pend\xEAncias e siga com o que houver.

${blocoDocumentos(docs)}`,
    maxTokens: 16e3
  };
}
function promptProdutos(p, docs) {
  const formato = `CRONOGRAMA DE PRODUTOS (grupo "Produtos" do quadro [PLAN]):
Uma linha por produto fatur\xE1vel ou entrega contratual. Produtos com parcelas ou entregas repetidas viram uma linha por parcela, com sufixo "(1/4)" ou "\u2013 Encontro 1/4". Se o TR ou o contrato numerar os produtos, use essa numera\xE7\xE3o (P01, P02...). Se n\xE3o numerar, ordene cronologicamente pela entrega prevista. Inclua produtos sem valor pr\xF3prio (plano de trabalho, relat\xF3rio final) quando o TR ou a proposta os descreverem como etapa ou entrega. Todas as linhas sempre completas, nunca "mesmas condi\xE7\xF5es do Pxx".

FORMATO DA RESPOSTA:
{
 "produtos": [{
  "codigo": string (ex.: "P01"),
  "nome": string (nome como aparece no TR/contrato, sem o c\xF3digo),
  "descricao": string (1 a 3 frases espec\xEDficas e verific\xE1veis: o que \xE9, para quem, quantitativos, evid\xEAncia de entrega exigida; sem valor pr\xF3prio termina com "Sem valor pr\xF3prio na composi\xE7\xE3o de pre\xE7o."),
  "objetivo": string (uma frase iniciada por verbo no infinitivo com a finalidade do produto),
  "mes_inicio": number (m\xEAs contratual de in\xEDcio, 1 = primeiro m\xEAs), "mes_fim": number (m\xEAs contratual da entrega),
  "dia_inicio": number|null, "dia_fim": number|null (quando o TR trouxer prazos em dias a partir do in\xEDcio, use-os; sen\xE3o null),
  "valor": number (0 se n\xE3o tiver valor pr\xF3prio),
  "fase": "Fase 1" | "Fase 2" | "Fase 3" | "Fase 4" (fase ou etapa do TR \xE0 qual o produto pertence; se o TR n\xE3o tiver fases, agrupe em ordem cronol\xF3gica em at\xE9 4),
  "tipologia": string (c\xF3digo e modalidade do Manual, ex.: "6A Diagn\xF3stico Operacional e Situacional"),
  "tipo_entrega": um de [${lista(ROTULOS.tipoEntrega)}],
  "fonte": string (documento e item)
 }],
 "checagem": {
  "soma_valores": number, "valor_global": number|null, "diferenca": number|null, "diferenca_pct": number|null,
  "fora_da_vigencia": [string], "max_produtos_mes": number, "media_produtos_mes": number,
  "observacoes": [string] (inconsist\xEAncias; vazio se n\xE3o houver)
 }
}`;
  return {
    system: base([TIPOLOGIAS, formato].join("\n\n")),
    user: `${cabecalho(p)}

${blocoDocumentos(docs)}`,
    maxTokens: 16e3
  };
}
var fmtProdutos = (ps) => ps.map((x) => `${x.ordem}. ${x.codigo} - ${x.nome} | prazo: ${x.dia_inicio != null && x.dia_fim != null ? `dia ${x.dia_inicio} a ${x.dia_fim}` : `M${x.mes_inicio ?? "?"} a M${x.mes_fim ?? "?"}`} | ${x.descricao}`).join("\n");
function promptEap(p, docs, lote, todos) {
  const formato = `FORMATO DA RESPOSTA:
{
 "produtos": [{
  "codigo": string (igual ao da lista),
  "entregaveis": [{
   "nome": string (N\xEDvel 2, substantivo curto, ex.: "Diagn\xF3stico institucional"),
   "dia_inicio": number, "dia_fim": number,
   "marcos": [{
    "nome": string (N\xEDvel 3, resultado verific\xE1vel no partic\xEDpio, ex.: "Diagn\xF3stico validado pela SUFOTUR (at\xE9 o dia 45)"),
    "dia_inicio": number, "dia_fim": number,
    "atividades": [{"nome": string (N\xEDvel 4, come\xE7a com verbo no infinitivo), "dia_inicio": number, "dia_fim": number, "frente": um de [${lista(ROTULOS.frentes)}]}]
   }]
  }]
 }]
}
Os dias contam a partir do in\xEDcio da execu\xE7\xE3o (dia 1). Dia de fim nunca menor que o de in\xEDcio. Atividades dentro do intervalo do marco, marcos dentro do intervalo do entreg\xE1vel e entreg\xE1veis dentro do prazo do produto (com folga para o fluxo de aceite quando o documento previr).`;
  return {
    system: base([EAP, formato].join("\n\n")),
    user: `${cabecalho(p)}

TODOS OS PRODUTOS DO PROJETO (para contexto de depend\xEAncias):
${fmtProdutos(todos)}

GERE A EAP S\xD3 PARA ESTES PRODUTOS:
${fmtProdutos(lote)}

${blocoDocumentos(docs)}`,
    maxTokens: 2e4
  };
}
function promptRiscos(p, docs, produtos) {
  const formato = `MATRIZ DE RISCOS ESPEC\xCDFICOS (grupo "Riscos" do quadro [PLAN]):
Gere de 10 a 20 riscos ESPEC\xCDFICOS deste projeto, que s\xF3 fazem sentido com estes documentos. Os riscos gen\xE9ricos do Card\xE1pio de Riscos s\xE3o gerados \xE0 parte pela Calculadora de Riscos; n\xE3o os repita. Cada causa cita um elemento concreto dos documentos: prazo, cl\xE1usula, volume, local, depend\xEAncia do cliente, ator, cadeia de produtos ou condi\xE7\xE3o de pagamento. Cubra s\xF3 as categorias que os documentos sustentarem.
Tema segue a categoria: Operacional, T\xE9cnico e de Gerenciamento = "Gest\xE3o"; Conformidade Legal/Normativo, Tribut\xE1rio e Pol\xEDtico = "Jur\xEDdico"; Institucional/Reputacional = "Imagem"; Financeiro = "Financeiro".

FORMATO DA RESPOSTA:
{
 "riscos": [{
  "id": string ("RISCO 01", "RISCO 02"...),
  "titulo": string (at\xE9 12 palavras, nomeia o risco),
  "categoria": um de [${lista(ROTULOS.categoria)}],
  "tema": "Gest\xE3o" | "Jur\xEDdico" | "Imagem" | "Financeiro",
  "impactado": ["Cliente"] | ["FGV DGPE"] | ["Cliente", "FGV DGPE"],
  "causa": string (o gerador, contextualizado),
  "efeito": string (impactos em cadeia, sem dramatizar; cite produtos e depend\xEAncias, ex.: P01 -> P02),
  "probabilidade": um de [${lista(ROTULOS.probabilidade)}],
  "impacto": um de [${lista(ROTULOS.impacto)}],
  "estrategia": um de [${lista(ROTULOS.estrategia)}],
  "resposta": string (2 a 4 a\xE7\xF5es objetivas e verific\xE1veis, com momento ou gatilho; n\xE3o prometa recursos fora do contrato; evite "monitorar" sem a\xE7\xE3o concreta),
  "cargo_responsavel": string (cargo ou inst\xE2ncia, nunca nome),
  "frente": um de [${lista(ROTULOS.frentes)}] (\xE1rea de execu\xE7\xE3o que responde pelo risco),
  "dia_inicio": number, "dia_fim": number (per\xEDodo em que o risco pode ocorrer, em dias desde o in\xEDcio da execu\xE7\xE3o),
  "produtos": [string] (c\xF3digos ligados)
 }]
}`;
  return {
    system: base([TIPOS_RISCO, formato].join("\n\n")),
    user: `${cabecalho(p)}

PRODUTOS:
${fmtProdutos(produtos)}

${blocoDocumentos(docs)}`,
    maxTokens: 16e3
  };
}
function promptPartes(p, docs, riscos) {
  const formato = `FORMATO DA RESPOSTA:
{
 "partes": [{
  "nome": string ("SIGLA \u2013 Nome da institui\xE7\xE3o ou \xE1rea", ex.: "CEE/RJ \u2013 Conselho Estadual de Educa\xE7\xE3o"),
  "cargo_cliente": string (cargo ou fun\xE7\xE3o de quem representa a parte, sem nomes),
  "area": string (posi\xE7\xE3o no arranjo: "\xD3rg\xE3o Contratante", "\xC1rea Requisitante", "Financiador", "\xD3rg\xE3o de controle", "P\xFAblico benefici\xE1rio direto", "Cadeia de fornecimento", "Contratada"...),
  "classe": "Contratante e decis\xE3o" | "Execu\xE7\xE3o e valida\xE7\xE3o t\xE9cnica" | "P\xFAblico benefici\xE1rio" | "Controle e conformidade" | "Parceiros e rede" | "Fornecedores cr\xEDticos" | "FGV DGPE",
  "papel": [um ou mais de ${lista(ROTULOS.papel)}],
  "interesse": um de [${lista(ROTULOS.nivel)}],
  "poder": um de [${lista(ROTULOS.nivel)}],
  "expectativas": string (par\xE1grafo corrido que come\xE7a pelo papel da parte no projeto e segue com o que ela espera; sem n\xFAmeros, valores ou datas),
  "riscos_associados": string (IDs da lista de riscos ligados a essa parte, ex.: "RISCO 03; RISCO 05", seguidos de uma frase sobre como a atua\xE7\xE3o ou omiss\xE3o dela pode afetar o projeto)
 }]
}
Antes de fechar, releia o TR e a proposta procurando toda institui\xE7\xE3o citada; cada uma entra ou \xE9 descartada por falta de influ\xEAncia real.`;
  return {
    system: base([PARTES_INTERESSADAS, formato].join("\n\n")),
    user: `${cabecalho(p)}

RISCOS J\xC1 MAPEADOS:
${riscos.map((r) => `${r.id} - ${r.titulo}`).join("\n") || "(nenhum)"}

${blocoDocumentos(docs)}`,
    maxTokens: 1e4
  };
}
function promptIndicadores(p, docs, produtos, referencias = "") {
  const formato = `FORMATO DA RESPOSTA:
{
 "objetivos": [{
  "objetivo": string (qualitativo; come\xE7a com "O projeto ser\xE1 bem-sucedido se"),
  "krs": [{
   "nome": string (nome curto do indicador, ex.: "Percentual de processos redesenhados validados"),
   "descricao": string ("Ao final, [resultado] comprovado por [crit\xE9rio], at\xE9 [prazo]"),
   "formula": string (forma de c\xE1lculo),
   "meta": number, "unidade": um de [${lista(ROTULOS.unidade)}], "polaridade": um de [${lista(ROTULOS.polaridade)}],
   "temporalidade": um de [${lista(ROTULOS.temporalidade)}], "coleta": um de [${lista(ROTULOS.coleta)}],
   "medicoes": [number] (dias, desde o in\xEDcio da execu\xE7\xE3o, em que cada medi\xE7\xE3o acontece; coerente com a temporalidade e a vig\xEAncia),
   "produtos": [string] (c\xF3digos),
   "referencia": string (indicador parecido da base de projetos anteriores que inspirou este, no formato "Projeto: nome do indicador"; vazio se n\xE3o houver),
   "kpis": [{"nome": string, "descricao": string, "formula": string, "meta": number, "unidade": um de [${lista(ROTULOS.unidade)}], "polaridade": um de [${lista(ROTULOS.polaridade)}], "temporalidade": um de [${lista(ROTULOS.temporalidade)}], "coleta": um de [${lista(ROTULOS.coleta)}], "medicoes": [number], "produtos": [string]}]
  }]
 }]
}
At\xE9 3 objetivos, at\xE9 5 KRs por objetivo e at\xE9 3 KPIs por KR, proporcional ao escopo. Indicadores de medi\xE7\xE3o de resultado exigidos pelo TR ou contrato entram obrigatoriamente.
BASE DE PROJETOS ANTERIORES: a mensagem traz indicadores j\xE1 usados em outros planejamentos da FGV DGPE, primeiro os do mesmo eixo. Use-os como refer\xEAncia de reda\xE7\xE3o, forma de c\xE1lculo, unidade, temporalidade, coleta e ordem de grandeza de metas. Adapte ao escopo deste projeto: nunca copie nomes de clientes, p\xFAblicos, quantidades ou datas de outros projetos.`;
  return {
    system: base([OKR, formato].join("\n\n")),
    user: `${cabecalho(p)}

PRODUTOS:
${fmtProdutos(produtos)}

${referencias ? `INDICADORES DE PROJETOS ANTERIORES (refer\xEAncia):
${referencias}

` : ""}${blocoDocumentos(docs)}`,
    maxTokens: 12e3
  };
}
function promptComplemento(p, produtos, riscos, resumoProjeto) {
  const formato = `Para cada risco abaixo (vindos do Card\xE1pio de Riscos pela Calculadora), complete os campos para ESTE projeto. N\xE3o mude causa nem efeito. Use o resumo do projeto e os produtos para situar o per\xEDodo em que o risco pode ocorrer e a \xE1rea respons\xE1vel.

FORMATO DA RESPOSTA:
{
 "riscos": [{
  "id": string (o id recebido),
  "dia_inicio": number, "dia_fim": number (per\xEDodo do risco em dias desde o in\xEDcio da execu\xE7\xE3o),
  "frente": um de [${lista(ROTULOS.frentes)}],
  "estrategia": um de [${lista(ROTULOS.estrategia)}],
  "resposta": string (2 a 4 a\xE7\xF5es objetivas e verific\xE1veis para este projeto, com momento ou gatilho; se j\xE1 houver resposta adequada, adapte ao projeto em vez de repetir)
 }]
}`;
  return {
    system: base([TIPOS_RISCO, formato].join("\n\n")),
    user: `${cabecalho(p)}

RESUMO DO PROJETO:
${resumoProjeto}

PRODUTOS:
${fmtProdutos(produtos)}

RISCOS:
${riscos.map((r) => JSON.stringify(r)).join("\n")}`,
    maxTokens: 14e3
  };
}

// src/generated/server/tap.ts
var MCP = "https://mcp.monday.com/mcp";
var seq = 0;
async function mcp(tool, args, token) {
  const r = await fetch(MCP, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", Accept: "application/json, text/event-stream" },
    body: JSON.stringify({ jsonrpc: "2.0", id: ++seq, method: "tools/call", params: { name: tool, arguments: args } }),
    signal: AbortSignal.timeout(11e4)
  });
  const bruto = await r.text();
  let j = null;
  try {
    j = JSON.parse(bruto);
  } catch {
    const linha = bruto.split("\n").find((l) => l.startsWith("data:"));
    if (linha) j = JSON.parse(linha.slice(5));
  }
  if (!r.ok || j?.error) throw new Error(`MCP da monday (${tool}): ${j?.error?.message ?? r.status}`);
  const txt2 = j?.result?.content?.[0]?.text ?? "";
  if (j?.result?.isError) throw new Error(`MCP da monday (${tool}): ${String(txt2).slice(0, 300)}`);
  try {
    return JSON.parse(txt2);
  } catch {
    return txt2;
  }
}
function textoDoBloco(b) {
  try {
    const c = JSON.parse(b.content ?? "{}");
    return (c.deltaFormat ?? []).map((o) => typeof o.insert === "string" ? o.insert : o.insert?.text ?? "").join("");
  } catch {
    return "";
  }
}
function emOrdem(blocos) {
  const filhos = /* @__PURE__ */ new Map();
  for (const b of blocos) {
    const p = b.parent_block_id ?? "";
    if (!filhos.has(p)) filhos.set(p, []);
    filhos.get(p).push(b);
  }
  for (const xs of filhos.values()) xs.sort((a, b) => (a.position ?? 0) - (b.position ?? 0));
  const out = [];
  const visitar = (b) => {
    out.push(b);
    if (b.type === "table") {
      try {
        const cells = JSON.parse(b.content ?? "{}").cells ?? [];
        for (const linha of cells) for (const cel of linha) {
          const celula = blocos.find((x) => x.id === cel.blockId);
          if (celula) visitar(celula);
        }
      } catch {
      }
    } else {
      for (const f of filhos.get(b.id) ?? []) visitar(f);
    }
  };
  for (const b of filhos.get("") ?? []) visitar(b);
  return out;
}
var brl = (v) => v == null ? "N\xE3o identificado nos documentos" : v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
var linhaFinal = { insert: { text: "\n" } };
var rotulado = (rotulo, valor) => [{ insert: { text: rotulo }, attributes: { bold: true } }, { insert: { text: valor } }, linhaFinal];
var simples = (valor) => [{ insert: { text: valor } }, linhaFinal];
var numerada = (xs) => xs.map((x, i) => `${i + 1}. ${x}`).join("\n");
async function escreverTap(boardId, tap, autor, token, avisar) {
  const d = await gql("query ($b: [ID!]) { boards(ids: $b) { views { id name type } } }", { b: [boardId] });
  const vista = d.boards?.[0]?.views?.find((v) => /\btap\b/i.test(v.name));
  if (!vista) throw new Error('O quadro n\xE3o tem a aba "0. TAP".');
  const lido = await mcp("read_docs", { board_id: boardId, view_id: vista.id, include_blocks: true, blocks_limit: 400 }, token);
  const doc = lido?.data?.[0];
  if (!doc?.id) throw new Error("N\xE3o consegui abrir o doc do TAP pelo MCP da monday.");
  const blocos = emOrdem(doc.blocks ?? []);
  const textos = blocos.map((b) => ({ b, t: textoDoBloco(b).trim() }));
  const ops = [];
  const apagar = [];
  const naoAchei = [];
  const tipoConteudo = (b) => /list/i.test(b.type) ? "list_item" : "text";
  const atualizar = (b, delta) => ops.push({ operation_type: "update_block", block_id: b.id, content: { block_content_type: tipoConteudo(b), delta_format: delta } });
  const acharComeco = (prefixo, desde = 0) => textos.findIndex((x, i) => i >= desde && x.t.toLowerCase().startsWith(prefixo.toLowerCase()));
  const porPrefixo = (prefixo, delta) => {
    const i = acharComeco(prefixo);
    if (i < 0) {
      naoAchei.push(prefixo);
      return;
    }
    atualizar(textos[i].b, delta(textos[i].t));
  };
  const proximoMarcador = (marcador, desde) => textos.findIndex((x, i) => i > desde && x.t.startsWith(marcador));
  porPrefixo("Nome do projeto", () => rotulado("Nome do projeto: ", tap.nome_projeto));
  porPrefixo("TAP elaborado por", () => rotulado("TAP elaborado por: ", `${autor} (pr\xE9-preenchido pelo Hub de Planejamento, revisar)`));
  porPrefixo("Data de in\xEDcio do contrato", () => rotulado("Data de in\xEDcio do contrato: ", tap.data_inicio_contrato));
  porPrefixo("Vig\xEAncia contratual", () => rotulado("Vig\xEAncia contratual: ", tap.vigencia_contratual));
  porPrefixo("Valor total do projeto", () => rotulado("Valor total do projeto: ", brl(tap.valor_total)));
  porPrefixo("Natureza do cliente", () => rotulado("Natureza do cliente: ", tap.natureza_cliente));
  porPrefixo("Modalidade do atendimento", () => rotulado("Modalidade do atendimento: ", tap.modalidade));
  porPrefixo("Experi\xEAncia Institucional", () => rotulado("Experi\xEAncia Institucional: ", tap.experiencia_institucional));
  porPrefixo("[Inserir justificativa]", () => simples(tap.justificativa));
  const resultados = [tap.resultado_principal, tap.como_chega, ...tap.resultados_quantitativos.length ? ["Resultados quantitativos esperados:", ...tap.resultados_quantitativos.map((x) => `\u2022 ${x}`)] : []].filter(Boolean).join("\n");
  porPrefixo("[Inserir resultados]", () => simples(resultados));
  porPrefixo("3.1. TOTAL DE PRODUTOS", () => rotulado("3.1. TOTAL DE PRODUTOS PREVISTOS: ", `${tap.total_produtos} produtos previstos`));
  const iTipos = acharComeco("3.2. Tipos de entrega");
  if (iTipos >= 0) {
    atualizar(textos[iTipos].b, rotulado("3.2. Tipos de entrega: ", tap.tipos_entrega.join("; ") || "N\xE3o identificado nos documentos"));
    const pai = textos[iTipos].b.parent_block_id;
    for (let k = iTipos + 1; k < textos.length && textos[k].b.parent_block_id === pai; k++) apagar.push(textos[k].b.id);
  } else naoAchei.push("3.2. Tipos de entrega");
  porPrefixo("[Inserir processo de entrega", () => simples(tap.processo_entrega.join("\n") || "N\xE3o identificado nos documentos"));
  porPrefixo("[Inserir respons\xE1veis]", () => simples(`A definir pela Coordena\xE7\xE3o de Planejamento.
Especialista(s): a definir
Gerente(s): a definir${tap.perfis_equipe && !/não identificado/i.test(tap.perfis_equipe) ? `
Perfis indicados na proposta: ${tap.perfis_equipe}` : ""}`));
  const resp = responsabilidades(tap.modelo_tap);
  const secoes = [
    { cabecalho: "6.1. Responsabilidades Superintend\xEAncia de Projetos", itens: resp.superintendencia },
    { cabecalho: "6.1.1. Responsabilidades Coordena\xE7\xE3o de Desenvolvimento", itens: resp.cdpe },
    { cabecalho: "6.1.1. Responsabilidades Superintend\xEAncia de A\xE7\xF5es Estruturadas", itens: resp.sae },
    { cabecalho: "6.2. Equipe Gestora", itens: resp.equipe }
  ];
  for (const s of secoes) {
    const ic = acharComeco(s.cabecalho);
    if (ic < 0) {
      naoAchei.push(s.cabecalho);
      continue;
    }
    const ip = proximoMarcador("[Inserir responsabilidade", ic);
    if (s.itens) {
      if (ip >= 0) atualizar(textos[ip].b, simples(numerada(s.itens)));
    } else {
      apagar.push(textos[ic].b.id);
      if (ip >= 0) apagar.push(textos[ip].b.id);
    }
  }
  porPrefixo("[Inserir n\xE3o escopo]", () => simples(numerada(tap.fora_escopo) || "N\xE3o identificado nos documentos"));
  const necess = textos.filter((x) => x.t.startsWith("[Inserir necessidades]"));
  const itens = tap.necessidades.length ? tap.necessidades : ["N\xE3o identificado nos documentos"];
  necess.forEach((x, k) => {
    if (k < itens.length) atualizar(x.b, simples(itens[k]));
    else apagar.push(x.b.id);
  });
  const extras = [];
  const ultimo = necess[necess.length - 1]?.b;
  if (ultimo && itens.length > necess.length) {
    for (const t2 of itens.slice(necess.length).reverse()) {
      extras.push({
        operation_type: "create_block",
        after_block_id: ultimo.id,
        ...ultimo.parent_block_id ? { parent_block_id: ultimo.parent_block_id } : {},
        block: { block_type: "list_item", list_block_type: "NUMBERED_LIST", delta_format: simples(t2) }
      });
    }
  }
  if (!necess.length) naoAchei.push("[Inserir necessidades]");
  if (!ops.length) throw new Error("O doc do TAP n\xE3o est\xE1 no formato do modelo (nenhum campo para preencher). Ele j\xE1 pode ter sido preenchido.");
  ops.push(...extras);
  if (apagar.length) ops.push({ operation_type: "delete_blocks", block_ids: apagar.slice(0, 100) });
  for (let i = 0; i < ops.length; i += 20) {
    await avisar(`Gravando o TAP (${Math.min(i + 20, ops.length)} de ${ops.length} altera\xE7\xF5es)\u2026`);
    await mcp("update_doc", { doc_id: String(doc.id), operations: ops.slice(i, i + 20) }, token);
  }
  return `TAP preenchido (${ops.length} altera\xE7\xF5es)${naoAchei.length ? `. Campos n\xE3o encontrados no modelo: ${naoAchei.join(", ")}` : ""}.`;
}

// src/generated/server/hub.ts
var ETAPAS = ["analise", "produtos", "eap", "riscos", "partes", "indicadores", "complemento", "tap", "calculadora"];
var colRuns = async () => (await mongo()).collection("hub_runs");
var colDocs = async () => (await mongo()).collection("hub_docs");
var agora = () => (/* @__PURE__ */ new Date()).toISOString();
function ctxOuErro() {
  const c = currentCtx();
  if (!c) throw new Error("Sess\xE3o inv\xE1lida.");
  return c;
}
var SEM_AUTORIZACAO = "Voc\xEA ainda n\xE3o autorizou o hub a agir no seu nome. Clique em Autorizar no topo do hub.";
async function tokenIA() {
  const c = ctxOuErro();
  const t2 = await tokenDoUsuario(c.userId);
  if (!t2) throw new Error(SEM_AUTORIZACAO);
  return t2;
}
async function nomeUsuario(id) {
  try {
    const d = await gql("query ($ids: [ID!]) { users(ids: $ids) { name } }", { ids: [id] });
    return d.users?.[0]?.name ?? "";
  } catch {
    return "";
  }
}
var semDocsTexto = (r) => r;
var listarModelos = createServerFn().handler(async () => MODELOS);
var criarExecucao = createServerFn().validator(external_exports.object({ itemId: external_exports.string(), nomeItem: external_exports.string(), codigo: external_exports.string(), eixo02: external_exports.string().optional(), valor02: external_exports.number().nullable().optional(), cliente02: external_exports.string().optional(), boardId: external_exports.string().optional(), boardUrl: external_exports.string().optional() })).handler(async ({ data }) => {
  const c = ctxOuErro();
  const r = {
    _id: (0, import_node_crypto3.randomUUID)(),
    itemId: data.itemId,
    nomeItem: data.nomeItem,
    codigo: data.codigo,
    boardId: data.boardId,
    boardUrl: data.boardUrl,
    criadoPor: c.userId,
    criadoPorNome: await nomeUsuario(c.userId),
    criadoEm: agora(),
    atualizadoEm: agora(),
    modelo: "monday-standard",
    contexto: { nomeItem: data.nomeItem, codigo: data.codigo, eixo02: data.eixo02, valor02: data.valor02 ?? null, cliente02: data.cliente02 },
    docs: [],
    etapas: {}
  };
  await (await colRuns()).insertOne(r);
  return semDocsTexto(r);
});
var listarExecucoes = createServerFn().validator(external_exports.object({ itemId: external_exports.string() })).handler(async ({ data }) => {
  const rs = await (await colRuns()).find({ itemId: data.itemId }, { projection: { "etapas.analise.resultado": 0, "etapas.produtos.resultado": 0, "etapas.eap.resultado": 0, "etapas.riscos.resultado": 0, "etapas.partes.resultado": 0, "etapas.indicadores.resultado": 0, "etapas.complemento.resultado": 0 } }).sort({ criadoEm: -1 }).limit(20).toArray();
  return rs;
});
var obterExecucao = createServerFn().validator(external_exports.object({ runId: external_exports.string() })).handler(async ({ data }) => {
  const r = await (await colRuns()).findOne({ _id: data.runId });
  if (!r) throw new Error("Execu\xE7\xE3o n\xE3o encontrada.");
  return r;
});
var atualizarExecucao = createServerFn().validator(external_exports.object({
  runId: external_exports.string(),
  boardId: external_exports.string().optional(),
  boardUrl: external_exports.string().optional(),
  hubItemId: external_exports.string().optional(),
  modelo: external_exports.string().optional(),
  inicioExecucao: external_exports.string().nullable().optional(),
  diasVigencia: external_exports.number().nullable().optional()
})).handler(async ({ data }) => {
  const set = { atualizadoEm: agora() };
  if (data.boardId !== void 0) set.boardId = data.boardId;
  if (data.boardUrl !== void 0) set.boardUrl = data.boardUrl;
  if (data.hubItemId !== void 0) set.hubItemId = data.hubItemId;
  if (data.modelo !== void 0) {
    if (!MODELOS.some((m) => m.id === data.modelo)) throw new Error("Modelo de IA desconhecido.");
    set.modelo = data.modelo;
  }
  if (data.inicioExecucao !== void 0) set["contexto.inicioExecucao"] = data.inicioExecucao;
  if (data.diasVigencia !== void 0) set["contexto.diasVigencia"] = data.diasVigencia;
  await (await colRuns()).updateOne({ _id: data.runId }, { $set: set });
  return await (await colRuns()).findOne({ _id: data.runId });
});
var salvarDocumentos = createServerFn().validator(external_exports.object({ runId: external_exports.string(), docs: external_exports.array(external_exports.object({ nome: external_exports.string(), tipo: external_exports.string(), texto: external_exports.string() })).min(1) })).handler(async ({ data }) => {
  const docs = data.docs.map((d) => ({ ...d, texto: d.texto.replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n") }));
  const total = docs.reduce((s, d) => s + d.texto.length, 0);
  if (total > 15e5) throw new Error("Os documentos somam texto demais para a IA (mais de 1,5 milh\xE3o de caracteres). Envie s\xF3 os documentos de pactua\xE7\xE3o principais.");
  await (await colDocs()).updateOne({ _id: data.runId }, { $set: { docs } }, { upsert: true });
  await (await colRuns()).updateOne({ _id: data.runId }, { $set: { docs: docs.map((d) => ({ nome: d.nome, tipo: d.tipo, chars: d.texto.length })), atualizadoEm: agora() } });
  return { ok: true, chars: total };
});
var salvarEdicao = createServerFn().validator(external_exports.object({ runId: external_exports.string(), etapa: external_exports.enum(ETAPAS), resultado: external_exports.unknown() })).handler(async ({ data }) => {
  await (await colRuns()).updateOne({ _id: data.runId }, { $set: { [`etapas.${data.etapa}.resultado`]: data.resultado, atualizadoEm: agora() } });
  return { ok: true };
});
var marcarGravada = createServerFn().validator(external_exports.object({ runId: external_exports.string(), etapa: external_exports.enum(ETAPAS), resumo: external_exports.string() })).handler(async ({ data }) => {
  const c = ctxOuErro();
  await (await colRuns()).updateOne({ _id: data.runId }, { $set: {
    [`etapas.${data.etapa}.status`]: "gravada",
    [`etapas.${data.etapa}.gravadaEm`]: agora(),
    [`etapas.${data.etapa}.gravadaPor`]: c.userId,
    [`etapas.${data.etapa}.resumoGravacao`]: data.resumo,
    atualizadoEm: agora()
  } });
  return { ok: true };
});
var rodando = /* @__PURE__ */ new Map();
async function setEtapa(runId, etapa, patch) {
  const set = { atualizadoEm: agora() };
  for (const [k, v] of Object.entries(patch)) set[`etapas.${etapa}.${k}`] = v;
  await (await colRuns()).updateOne({ _id: runId }, { $set: set });
}
async function rodarIA(prompt, modelo) {
  return chamarIA(prompt, await tokenIA(), modelo);
}
async function emParalelo(xs, n, fn) {
  const out = new Array(xs.length);
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, xs.length) }, async () => {
    while (i < xs.length) {
      const k = i++;
      out[k] = await fn(xs[k], k);
    }
  }));
  return out;
}
var Entrada = external_exports.object({
  produtos: external_exports.array(external_exports.object({ codigo: external_exports.string(), nome: external_exports.string(), descricao: external_exports.string(), dia_inicio: external_exports.number().nullable().optional(), dia_fim: external_exports.number().nullable().optional(), mes_inicio: external_exports.number().optional(), mes_fim: external_exports.number().optional(), valor: external_exports.number().optional(), ordem: external_exports.number() })).optional(),
  riscos: external_exports.array(external_exports.object({ id: external_exports.string(), titulo: external_exports.string() })).optional(),
  riscosQuadro: external_exports.array(external_exports.object({ id: external_exports.string(), nome: external_exports.string(), causa: external_exports.string(), efeito: external_exports.string(), categoria: external_exports.string(), estrategia: external_exports.string(), resposta: external_exports.string() })).optional(),
  resumo: external_exports.string().optional(),
  codigos: external_exports.array(external_exports.string()).optional()
}).optional();
async function executarEtapa(run, etapa, entrada) {
  const docs = (await (await colDocs()).findOne({ _id: run._id }))?.docs ?? [];
  if (!docs.length && etapa !== "complemento") throw new Error("Envie os documentos antes de gerar.");
  const p = run.contexto;
  const m = run.modelo || "monday-standard";
  const salvos = run.etapas?.produtos?.resultado?.produtos ?? [];
  const produtos = entrada?.produtos?.length ? entrada.produtos : salvos.map((x, i) => ({
    codigo: x.codigo,
    nome: x.nome,
    descricao: x.descricao,
    dia_inicio: x.dia_inicio,
    dia_fim: x.dia_fim,
    mes_inicio: x.mes_inicio,
    mes_fim: x.mes_fim,
    valor: x.valor,
    ordem: i + 1
  }));
  let custo = 0, tokens = 0, modelo = m;
  const somar = (r) => {
    custo += r.custo ?? 0;
    tokens += r.tokensEntrada + r.tokensSaida;
    modelo = r.modelo;
  };
  let resultado;
  if (etapa === "analise") {
    const r = await rodarIA(promptAnalise(p, docs), m);
    somar(r);
    resultado = r.data;
  } else if (etapa === "produtos") {
    const r = await rodarIA(promptProdutos(p, docs), m);
    somar(r);
    resultado = r.data;
  } else if (etapa === "eap") {
    if (!produtos.length) throw new Error("Grave ou aprove os produtos antes de gerar a EAP.");
    const alvo = entrada?.codigos?.length ? produtos.filter((x) => entrada.codigos.includes(x.codigo)) : produtos;
    const lotes = [];
    for (let i = 0; i < alvo.length; i += 3) lotes.push(alvo.slice(i, i + 3));
    let feitos = 0;
    const partes = await emParalelo(lotes, 2, async (lote) => {
      const r = await rodarIA(promptEap(p, docs, lote, produtos), m);
      somar(r);
      feitos += lote.length;
      await setEtapa(run._id, etapa, { progresso: `${feitos} de ${alvo.length} produtos` });
      return r.data?.produtos ?? [];
    });
    resultado = { produtos: partes.flat() };
  } else if (etapa === "riscos") {
    const r = await rodarIA(promptRiscos(p, docs, produtos), m);
    somar(r);
    resultado = r.data;
  } else if (etapa === "partes") {
    const r = await rodarIA(promptPartes(p, docs, entrada?.riscos ?? []), m);
    somar(r);
    resultado = r.data;
  } else if (etapa === "indicadores") {
    await setEtapa(run._id, etapa, { progresso: "Lendo indicadores de planejamentos anteriores\u2026" });
    const base2 = await baseIndicadores().catch((e) => {
      console.error("[base indicadores]", e);
      return null;
    });
    const refs = base2 ? referenciasIndicadores(base2.itens, p.eixo02 ?? "") : { texto: "", usados: 0 };
    await setEtapa(run._id, etapa, { progresso: `Gerando OKRs com ${refs.usados} indicadores de refer\xEAncia\u2026` });
    const r = await rodarIA(promptIndicadores(p, docs, produtos, refs.texto), m);
    somar(r);
    resultado = { ...r.data, base: base2 ? { indicadores: base2.itens.length, projetos: base2.projetos, usados: refs.usados, em: base2.em } : null };
  } else if (etapa === "complemento") {
    const rq = entrada?.riscosQuadro ?? [];
    if (!rq.length) throw new Error("Nenhum risco da calculadora para completar.");
    const lotes = [];
    for (let i = 0; i < rq.length; i += 20) lotes.push(rq.slice(i, i + 20));
    let feitos = 0;
    const partes = await emParalelo(lotes, 2, async (lote) => {
      const r = await rodarIA(promptComplemento(p, produtos, lote, entrada?.resumo ?? ""), m);
      somar(r);
      feitos += lote.length;
      await setEtapa(run._id, etapa, { progresso: `${feitos} de ${rq.length} riscos` });
      return r.data?.riscos ?? [];
    });
    resultado = { riscos: partes.flat() };
  } else {
    throw new Error(`Etapa sem IA: ${etapa}`);
  }
  await setEtapa(run._id, etapa, { status: "pronta", fim: agora(), resultado, custo: Math.round(custo * 1e4) / 1e4, tokens, modelo, progresso: "" });
}
var gerarEtapa = createServerFn().validator(external_exports.object({ runId: external_exports.string(), etapa: external_exports.enum(["analise", "produtos", "eap", "riscos", "partes", "indicadores", "complemento"]), entrada: Entrada })).handler(async ({ data }) => {
  const run = await (await colRuns()).findOne({ _id: data.runId });
  if (!run) throw new Error("Execu\xE7\xE3o n\xE3o encontrada.");
  await tokenIA();
  return iniciarGeracao(run, data.etapa, data.entrada);
});
async function iniciarGeracao(run, etapa, entrada) {
  const chave = `${run._id}:${etapa}`;
  if (rodando.has(chave)) return { iniciada: false, motivo: "J\xE1 est\xE1 gerando." };
  await setEtapa(run._id, etapa, { status: "gerando", inicio: agora(), erro: "", progresso: "Lendo os documentos\u2026", resultado: null });
  const job = executarEtapa(run, etapa, entrada).catch(async (e) => {
    console.error(`[etapa ${etapa}]`, e);
    await setEtapa(run._id, etapa, { status: "erro", fim: agora(), erro: e instanceof Error ? e.message : String(e), progresso: "" });
  }).finally(() => rodando.delete(chave));
  rodando.set(chave, job);
  return { iniciada: true };
}
var estadoEtapas = createServerFn().validator(external_exports.object({ runId: external_exports.string() })).handler(async ({ data }) => {
  const run = await (await colRuns()).findOne({ _id: data.runId });
  if (!run) throw new Error("Execu\xE7\xE3o n\xE3o encontrada.");
  for (const e of ETAPAS) {
    const st = run.etapas[e];
    if (st?.status === "gerando" && !rodando.has(`${run._id}:${e}`) && Date.now() - Date.parse(st.inicio ?? agora()) > 9e4) {
      await setEtapa(run._id, e, { status: "erro", erro: "A gera\xE7\xE3o foi interrompida (o servidor reiniciou). Gere de novo.", progresso: "" });
      st.status = "erro";
      st.erro = "A gera\xE7\xE3o foi interrompida (o servidor reiniciou). Gere de novo.";
    }
    if (st?.gravando && !rodando.has(`${run._id}:grav:${e}`) && Date.now() - Date.parse(st.batidaGravacao ?? agora()) > 18e4) {
      const msg = "A grava\xE7\xE3o foi interrompida (o servidor reiniciou). Clique em gravar de novo.";
      await setEtapa(run._id, e, { gravando: false, erroGravacao: msg, progressoGravacao: "" });
      st.gravando = false;
      st.erroGravacao = msg;
    }
  }
  return run;
});
var COLS_IND = ["18370004806__color_mm07qht8", "long_text_mm1gn28m", "18370004806__text_mm0qr7n2", "18370004806__numeric_mm07cbq5", "18370004806__dropdown_mm078vv2", "18370004806__dropdown_mm077dhe", "18370004806__dropdown_mm0791cx", "color_mm1hzeyh"];
async function baseIndicadores() {
  const col3 = (await mongo()).collection("hub_base_indicadores");
  const atual = await col3.findOne({ _id: "base" });
  if (atual && Date.now() - Date.parse(atual.em) < 12 * 36e5) return atual;
  const eixoPorQuadro = /* @__PURE__ */ new Map();
  let cursor = null;
  do {
    const d = cursor ? await gql('query ($c: String!) { next_items_page(limit: 500, cursor: $c) { cursor items { column_values(ids: ["link_mm383m1p", "dropdown_mm38v0xw"]) { id text value } } } }', { c: cursor }) : await gql('query { boards(ids: [18412010674]) { items_page(limit: 500) { cursor items { column_values(ids: ["link_mm383m1p", "dropdown_mm38v0xw"]) { id text value } } } } }');
    const pg = cursor ? d.next_items_page : d.boards[0].items_page;
    for (const it of pg.items) {
      const link = it.column_values.find((c) => c.id === "link_mm383m1p");
      const eixo = it.column_values.find((c) => c.id === "dropdown_mm38v0xw")?.text ?? "";
      let url = "";
      try {
        url = JSON.parse(link?.value || "null")?.url ?? "";
      } catch {
        url = "";
      }
      const id = url.match(/\/boards\/(\d+)/)?.[1];
      if (id) eixoPorQuadro.set(id, eixo);
    }
    cursor = pg.cursor;
  } while (cursor);
  const quadros = [...eixoPorQuadro.keys()];
  const itens = [];
  let projetos = 0;
  for (let i = 0; i < quadros.length; i += 8) {
    const d = await gql(`query ($b: [ID!], $c: [String!]) { boards(ids: $b) { id name groups { id } items_page(limit: 200, query_params: { rules: [{ column_id: "group", compare_value: ["group_mm0gtzbd"], operator: any_of }] }) { items { name column_values(ids: $c) { id text } } } } }`, { b: quadros.slice(i, i + 8), c: COLS_IND }).catch(() => null);
    for (const b of d?.boards ?? []) {
      if (!b.groups?.some((g) => g.id === "group_mm0gtzbd")) continue;
      const validos = (b.items_page?.items ?? []).filter((it) => !/^INDICADOR (KR|KPI) \d+$/i.test(it.name.trim()));
      if (!validos.length) continue;
      projetos++;
      for (const it of validos) {
        const v = (id) => it.column_values.find((c) => c.id === id)?.text ?? "";
        const desc = v("long_text_mm1gn28m"), formula = v("18370004806__text_mm0qr7n2");
        if (!desc && !formula) continue;
        itens.push({ projeto: String(b.name).replace(/^\[PLAN\]\s*/, "").slice(0, 80), eixo: eixoPorQuadro.get(String(b.id)) ?? "", tipo: v("18370004806__color_mm07qht8"), nome: it.name, descricao: desc, formula, meta: v("18370004806__numeric_mm07cbq5"), unidade: v("18370004806__dropdown_mm078vv2"), temporalidade: v("18370004806__dropdown_mm077dhe"), coleta: v("18370004806__dropdown_mm0791cx"), polaridade: v("color_mm1hzeyh") });
      }
    }
  }
  const doc = { _id: "base", itens, projetos, em: agora() };
  await col3.replaceOne({ _id: "base" }, doc, { upsert: true });
  return doc;
}
function referenciasIndicadores(itens, eixo) {
  const e = eixo.trim().toLowerCase();
  const mesmo = itens.filter((x) => e && x.eixo.toLowerCase() === e);
  const outros = itens.filter((x) => !(e && x.eixo.toLowerCase() === e));
  const sel = [...mesmo.slice(0, 30), ...outros.filter((_, i) => i % Math.max(1, Math.floor(outros.length / 20)) === 0).slice(0, 20)];
  const texto = sel.map((x) => `[${x.eixo || "sem eixo"} | ${x.projeto}] ${x.tipo || "Indicador"} | ${x.nome} | ${x.descricao.replace(/\s+/g, " ").slice(0, 220)} | c\xE1lculo: ${x.formula.slice(0, 160)} | meta ${x.meta} ${x.unidade} | ${x.temporalidade} | ${x.coleta} | ${x.polaridade}`).join("\n");
  return { texto, usados: sel.length };
}
var infoBaseIndicadores = createServerFn().handler(async () => {
  const b = await baseIndicadores();
  const porEixo = {};
  for (const x of b.itens) porEixo[x.eixo || "sem eixo"] = (porEixo[x.eixo || "sem eixo"] ?? 0) + 1;
  return { indicadores: b.itens.length, projetos: b.projetos, em: b.em, porEixo };
});
var gravarTap = createServerFn().validator(external_exports.object({ runId: external_exports.string(), boardId: external_exports.string(), tap: external_exports.unknown() })).handler(async ({ data }) => {
  const c = ctxOuErro();
  const chave = `${data.runId}:tap`;
  if (rodando.has(chave)) return { iniciada: false };
  const token = await tokenIA();
  const autor = await nomeUsuario(c.userId) || "Hub de Planejamento";
  await setEtapa(data.runId, "tap", { status: "gerando", inicio: agora(), erro: "", progresso: "Lendo o doc do TAP\u2026" });
  const job = escreverTap(data.boardId, data.tap, autor, token, (msg) => setEtapa(data.runId, "tap", { progresso: msg })).then(async (resumo) => {
    await setEtapa(data.runId, "tap", { status: "gravada", fim: agora(), gravadaEm: agora(), gravadaPor: c.userId, resumoGravacao: resumo, progresso: "" });
  }).catch(async (e) => {
    console.error("[tap]", e);
    await setEtapa(data.runId, "tap", { status: "erro", fim: agora(), erro: e instanceof Error ? e.message : String(e), progresso: "" });
  }).finally(() => rodando.delete(chave));
  rodando.set(chave, job);
  return { iniciada: true };
});
var anexarDocumento = createServerFn().validator(external_exports.object({ itemId: external_exports.string(), columnId: external_exports.string(), nome: external_exports.string(), base64: external_exports.string(), mime: external_exports.string().optional() })).handler(async ({ data }) => {
  const token = await tokenIA();
  const bytes = Buffer.from(data.base64, "base64");
  if (bytes.length > 45 * 1024 * 1024) throw new Error(`${data.nome}: arquivo grande demais para anexar (limite 45 MB).`);
  const form = new FormData();
  form.append("query", "mutation ($file: File!, $item: ID!, $col: String!) { add_file_to_column(item_id: $item, column_id: $col, file: $file) { id } }");
  form.append("variables", JSON.stringify({ item: data.itemId, col: data.columnId }));
  form.append("map", JSON.stringify({ arquivo: "variables.file" }));
  form.append("arquivo", new Blob([bytes], { type: data.mime || "application/octet-stream" }), data.nome);
  const r = await fetch("https://api.monday.com/v2/file", { method: "POST", headers: { Authorization: token, "API-Version": "2026-10" }, body: form });
  const j = await r.json().catch(() => null);
  if (!r.ok || j?.errors?.length || j?.error_message) throw new Error(`Falha ao anexar ${data.nome}: ${j?.errors?.[0]?.message ?? j?.error_message ?? r.status}`);
  return { ok: true, assetId: j?.data?.add_file_to_column?.id ?? null };
});
var statusIA = createServerFn().handler(async () => {
  const c = ctxOuErro();
  return autorizacaoDoUsuario(c.userId);
});
var pedirAutorizacao = createServerFn().handler(async () => {
  const c = ctxOuErro();
  return { url: await linkAutorizacao(c.userId) };
});

// src/generated/lib/monday.js
var executor = null;
function definirExecutor(fn) {
  executor = fn;
}
async function execGql(query, variables) {
  if (!executor) throw new Error("Cliente da API do monday n\xE3o configurado.");
  let res2;
  try {
    res2 = await executor(query, variables);
  } catch (e) {
    const errs = e?.data?.errors || e?.errors || (e?.data?.error_message ? [{ message: e.data.error_message }] : null);
    throw Object.assign(new Error(errs ? errs.map((x) => x.message).join("; ") : String(e?.message || e)), { cause: { errors: errs || [] } });
  }
  if (res2?.errors?.length) throw Object.assign(new Error(res2.errors.map((x) => x.message).join("; ")), { cause: { errors: res2.errors } });
  if (res2?.error_message) throw Object.assign(new Error(res2.error_message), { cause: { errors: [{ message: res2.error_message }] } });
  return res2?.data;
}
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
var CV_FIELDS = `id text value
  ... on BoardRelationValue { linked_item_ids }
  ... on DropdownValue { values { id label } }
  ... on CheckboxValue { checked }
  ... on MirrorValue { display_value }`;
function rateLimitDelay(err) {
  const errs = err?.cause?.errors || [];
  const ext = errs[0]?.extensions || {};
  const blob = `${err?.message || ""} ${errs.map((e) => e.message).join(" ")} ${JSON.stringify(ext)}`;
  if (!/complexity|rate.?limit|too many|429|concurrency|budget|minute limit/i.test(blob)) return null;
  const secs = ext.retry_in_seconds ?? blob.match(/(\d+)\s*(seconds|segundos)/i)?.[1];
  return Math.min(60, Math.max(2, Number(secs) || 10)) * 1e3 + 500;
}
function isRateLimit(err) {
  return rateLimitDelay(err) !== null;
}
async function gql2(query, variables = {}, attempts = 5) {
  for (let i = 0; ; i++) {
    try {
      return await execGql(query, variables);
    } catch (err) {
      const wait = rateLimitDelay(err);
      if (wait === null || i >= attempts - 1) throw err;
      await sleep(wait);
    }
  }
}
function errorMessage(err) {
  const errs = err?.cause?.errors;
  if (Array.isArray(errs) && errs.length) return errs.map((e) => e.message).join("; ");
  return String(err?.message || err).replace(/^Monday API request failed[^:]*:\s*/, "");
}
function normalize(item) {
  const cols = {};
  (item.column_values || []).forEach((cv) => {
    cols[cv.id] = cv;
  });
  return { id: String(item.id), name: item.name || "", cols };
}
async function fetchAllItems(boardId, columnIds, queryParams = null) {
  const first = queryParams ? await gql2(
    `query ($b: [ID!], $c: [String!], $qp: ItemsQuery) { boards(ids: $b) { items_page(limit: 500, query_params: $qp) { cursor items { id name column_values(ids: $c) { ${CV_FIELDS} } } } } }`,
    { b: [String(boardId)], c: columnIds, qp: queryParams }
  ) : await gql2(
    `query ($b: [ID!], $c: [String!]) { boards(ids: $b) { items_page(limit: 500) { cursor items { id name column_values(ids: $c) { ${CV_FIELDS} } } } } }`,
    { b: [String(boardId)], c: columnIds }
  );
  const page = first?.boards?.[0]?.items_page;
  if (!page) throw new Error(`N\xE3o foi poss\xEDvel ler o board ${boardId} (sem acesso ou board inexistente).`);
  const items = page.items.map(normalize);
  let cursor = page.cursor;
  while (cursor) {
    await sleep(250);
    const next = await gql2(
      `query ($cur: String!, $c: [String!]) { next_items_page(limit: 500, cursor: $cur) { cursor items { id name column_values(ids: $c) { ${CV_FIELDS} } } } }`,
      { cur: cursor, c: columnIds }
    );
    items.push(...(next?.next_items_page?.items || []).map(normalize));
    cursor = next?.next_items_page?.cursor || null;
  }
  return items;
}
async function fetchItemsByIds(ids, columnIds) {
  const out = [];
  for (let i = 0; i < ids.length; i += 100) {
    const chunk = ids.slice(i, i + 100);
    const res2 = await gql2(
      `query ($ids: [ID!], $c: [String!]) { items(ids: $ids) { id name column_values(ids: $c) { ${CV_FIELDS} } } }`,
      { ids: chunk.map(String), c: columnIds }
    );
    out.push(...(res2?.items || []).map(normalize));
    if (i + 100 < ids.length) await sleep(250);
  }
  return out;
}
var txt = (cv) => String(cv?.text ?? cv?.display_value ?? "");
var isChecked = (cv) => cv?.checked === true || txt(cv).trim() === "v";
var dropdownLabels = (cv) => {
  if (Array.isArray(cv?.values)) return cv.values.map((v) => v.label).filter((l) => l != null && l !== "");
  const t2 = txt(cv).trim();
  return t2 ? [t2] : [];
};
var linkedIds = (cv) => {
  if (Array.isArray(cv?.linked_item_ids)) return cv.linked_item_ids.map(String);
  try {
    const v = JSON.parse(cv?.value || "null");
    return (v?.linkedPulseIds || []).map((x) => String(x.linkedPulseId));
  } catch {
    return [];
  }
};
function todayISO() {
  const d = /* @__PURE__ */ new Date();
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

// src/generated/lib/quadros.ts
var B_HUB = 18441661190;
var CP = {
  grupos: { cronograma: "group_mkx65fxg", produtos: "group_title", indicador: "group_mm0gtzbd", medicao: "group_mm0g8q60", riscos: "group_mkx6zkd3", partes: "group_mm0q9sxj" },
  status: "status",
  cronograma: "timerange_mkx683na",
  frentes: "color_mkyfzcfy",
  eap: "18423546593__dropdown_mm5q2max",
  produtoRel: "board_relation_mkx6fhk",
  // Produtos
  codigo: "text_mkx6zb99",
  descricao: "18423546593__text_mm5q27ah",
  meses: "18423546593__text_mm6470ww",
  valor: "numeric_mkx6wcm",
  tipoEntrega: "dropdown_mm7gtmhy",
  etapaProduto: "color_mkx6cxq6",
  contratual: "timerange_mkx6bqv7",
  objetivo: "18423546593__text_mm6cezpg",
  statusProduto: "color_mkx62m2a",
  categoriaInsumo: "dropdown_mm58yxh5",
  // Riscos
  tema: "dropdown_mkx6jx0w",
  categoria: "dropdown_mkx6g0d8",
  impactado: "dropdown_mkx6cbyv",
  causa: "long_text_mkx6r3mk",
  efeito: "long_text_mkx610qv",
  prob: "color_mkx6b6pv",
  imp: "color_mkx66rff",
  estrategia: "color_mkx62a0c",
  resposta: "long_text_mkx6sp8g",
  cargoResp: "text_mkx6p5fz",
  periodo: "timerange_mkyfxmm1",
  eixoRisco: "dropdown_mkx6jrha",
  riscosAssoc: "text_mm7g99h8",
  // Partes interessadas
  cargoCliente: "18370004806__text_mm0qdk7c",
  area: "18370004806__text_mm0qq9jf",
  papel: "18370004806__dropdown_mm0qbmm5",
  interesse: "18370004806__color_mm0qw69m",
  poder: "18370004806__color_mm0qvbfv",
  expectativas: "18370004806__long_text_mm0qenb1",
  // Indicadores
  tipoInd: "18370004806__color_mm07qht8",
  descInd: "long_text_mm1gn28m",
  formula: "18370004806__text_mm0qr7n2",
  meta: "18370004806__numeric_mm07cbq5",
  unidade: "18370004806__dropdown_mm078vv2",
  temporalidade: "18370004806__dropdown_mm077dhe",
  coleta: "18370004806__dropdown_mm0791cx",
  polaridade: "color_mm1hzeyh",
  qtdMed: "18370004806__numeric_mm07hr82",
  prazoMed: "18370004806__date_mm0ghv21",
  indVinculado: "18370004806__board_relation_mm0q1pre",
  krVinculado: "board_relation_mm46hwwg",
  statusMed: "color_mm1gg0hb"
};
async function itensDosGrupos(boardId, grupos, colunas) {
  const out = [];
  let cursor = null;
  const cols = JSON.stringify(colunas);
  do {
    const d = cursor ? await gql2(`query ($c: String!) { next_items_page(limit: 200, cursor: $c) { cursor items { id name group { id } column_values(ids: ${cols}) { id text value } } } }`, { c: cursor }) : await gql2(`query ($b: [ID!], $g: CompareValue!) { boards(ids: $b) { items_page(limit: 200, query_params: { rules: [{ column_id: "group", compare_value: $g, operator: any_of }] }) { cursor items { id name group { id } column_values(ids: ${cols}) { id text value } } } } }`, { b: [boardId], g: grupos });
    const page = cursor ? d.next_items_page : d.boards[0].items_page;
    for (const it of page.items) out.push({ id: String(it.id), name: it.name, group: it.group.id, cols: Object.fromEntries(it.column_values.map((c) => [c.id, c])) });
    cursor = page.cursor;
  } while (cursor);
  return out;
}
var NO_SERVIDOR = typeof window === "undefined";
var LOTE = NO_SERVIDOR ? 20 : 8;
var PAUSA = NO_SERVIDOR ? 150 : 400;
async function criarItens(boardId, grupo, itens, onProgresso, criarRotulos = false) {
  const ids = [];
  for (let i = 0; i < itens.length; i += LOTE) {
    const lote = itens.slice(i, i + LOTE);
    const defs = [], corpo = [];
    const vars = { b: String(boardId), g: grupo };
    lote.forEach((it, k) => {
      defs.push(`$n${k}: String!, $v${k}: JSON!`);
      corpo.push(`c${k}: create_item(board_id: $b, group_id: $g, item_name: $n${k}, column_values: $v${k}, create_labels_if_missing: ${criarRotulos}) { id }`);
      vars[`n${k}`] = it.nome.slice(0, 255);
      vars[`v${k}`] = JSON.stringify(it.valores);
    });
    const d = await gql2(`mutation ($b: ID!, $g: String!, ${defs.join(", ")}) { ${corpo.join(" ")} }`, vars);
    lote.forEach((_, k) => ids.push(String(d[`c${k}`].id)));
    onProgresso?.(ids.length);
    await sleep(PAUSA);
  }
  return ids;
}
async function alterarItens(boardId, mudancas, onProgresso, criarRotulos = false) {
  const lotes = [];
  for (let i = 0; i < mudancas.length; i += LOTE) lotes.push(mudancas.slice(i, i + LOTE));
  let feitos = 0;
  const um = async (lote) => {
    const defs = [], corpo = [];
    const vars = { b: String(boardId) };
    lote.forEach((m, k) => {
      defs.push(`$i${k}: ID!, $v${k}: JSON!`);
      corpo.push(`c${k}: change_multiple_column_values(board_id: $b, item_id: $i${k}, column_values: $v${k}, create_labels_if_missing: ${criarRotulos}) { id }`);
      vars[`i${k}`] = m.id;
      vars[`v${k}`] = JSON.stringify(m.valores);
    });
    await gql2(`mutation ($b: ID!, ${defs.join(", ")}) { ${corpo.join(" ")} }`, vars);
    feitos += lote.length;
    onProgresso?.(feitos);
    await sleep(PAUSA);
  };
  const paralelos = NO_SERVIDOR ? 3 : 1;
  let prox = 0;
  await Promise.all(Array.from({ length: Math.min(paralelos, lotes.length) }, async () => {
    while (prox < lotes.length) await um(lotes[prox++]);
  }));
}
async function arquivarItens(ids) {
  for (let i = 0; i < ids.length; i += 10) {
    const corpo = ids.slice(i, i + 10).map((id, k) => `a${k}: archive_item(item_id: ${Number(id)}) { id }`);
    await gql2(`mutation { ${corpo.join(" ")} }`);
    await sleep(300);
  }
}
function somarDias(iso, dias) {
  const d = /* @__PURE__ */ new Date(`${iso}T12:00:00`);
  d.setDate(d.getDate() + dias);
  return d.toISOString().slice(0, 10);
}
var diaParaData = (inicio, dia) => somarDias(inicio, Math.max(0, Math.round(dia) - 1));
var faixa = (inicio, a, b) => {
  const de = diaParaData(inicio, Math.min(a, b));
  const ate = diaParaData(inicio, Math.max(a, b));
  return { from: de, to: ate };
};
var hojeISO = () => new Date(Date.now() - 3 * 36e5).toISOString().slice(0, 10);
async function registrarNoHub(params) {
  const valores = {
    item_0201: params.itemId,
    run_id: params.runId,
    ultima: { date: hojeISO() },
    etapas: { text: params.etapas },
    executor: { personsAndTeams: [{ id: Number(params.userId), kind: "person" }] }
  };
  if (params.quadroUrl) valores.quadro_plan = { url: params.quadroUrl, text: "Quadro [PLAN]" };
  if (params.hubItemId) {
    await gql2("mutation ($b: ID!, $i: ID!, $v: JSON!) { change_multiple_column_values(board_id: $b, item_id: $i, column_values: $v) { id } }", { b: String(B_HUB), i: params.hubItemId, v: JSON.stringify(valores) });
    return params.hubItemId;
  }
  const d = await gql2('mutation ($b: ID!, $n: String!, $v: JSON!) { create_item(board_id: $b, group_id: "topics", item_name: $n, column_values: $v) { id } }', { b: String(B_HUB), n: params.nome, v: JSON.stringify(valores) });
  return String(d.create_item.id);
}

// src/generated/lib/gravar.ts
function diasDoProduto(p) {
  const ini = p.dia_inicio ?? (Math.max(1, p.mes_inicio || 1) - 1) * 30 + 1;
  const fim = p.dia_fim ?? Math.max(1, p.mes_fim || p.mes_inicio || 1) * 30;
  return { ini, fim: Math.max(ini, fim) };
}
var MODELO = {
  [CP.grupos.produtos]: /^PRODUTO \d+$/i,
  [CP.grupos.cronograma]: /^(Criar item|\d+(\.\d+)*\.?\s*(COMPONENTE|PACOTE DE ENTREGAS)|hghghg)$/i,
  [CP.grupos.riscos]: /^RISCO \d+$/i,
  [CP.grupos.indicador]: /^INDICADOR (KR|KPI) \d+$/i,
  [CP.grupos.partes]: /^GRUPO \/ INSTITUI[ÇC][ÃA]O \d+$/i
};
async function limparModelo(boardId, grupo) {
  const rx = MODELO[grupo];
  if (!rx) return 0;
  const its = await itensDosGrupos(boardId, [grupo], ["name"]);
  const ids = its.filter((it) => rx.test(it.name.trim())).map((it) => it.id);
  if (ids.length) await arquivarItens(ids);
  return ids.length;
}
async function ajustarAbaCronograma(boardId) {
  const d = await gql2(`query ($b: [ID!]) { boards(ids: $b) { columns(ids: ["${CP.eap}"]) { settings_str } views { id name } } }`, { b: [boardId] });
  const b = d?.boards?.[0];
  const labels = JSON.parse(b?.columns?.[0]?.settings_str || "{}").labels ?? [];
  const ids = labels.filter((l) => /n[ií]vel\s*[34]/i.test(l.name ?? l.label ?? "")).map((l) => l.id);
  if (ids.length < 2) {
    const itens = await itensDosGrupos(boardId, [CP.grupos.cronograma], [CP.eap]).catch(() => []);
    for (const it of itens) {
      const c = it.cols[CP.eap];
      if (!/n[ií]vel\s*[34]/i.test(c?.text ?? "")) continue;
      for (const id of JSON.parse(c?.value || "{}").ids ?? []) if (!ids.includes(id)) ids.push(id);
    }
  }
  const vista = (b?.views ?? []).find((v) => /cronograma/i.test(v.name) && !/gantt/i.test(v.name));
  if (!vista || !ids.length) return false;
  await gql2(`mutation ($b: ID!, $v: ID!, $f: ItemsQueryGroup) { update_view(board_id: $b, view_id: $v, type: TABLE, filter: $f) { id } }`, {
    b: boardId,
    v: String(vista.id),
    f: { operator: "and", groups: [
      { operator: "and", rules: [{ column_id: "group", compare_value: [CP.grupos.cronograma], operator: "any_of" }] },
      { operator: "and", rules: [{ column_id: CP.eap, compare_value: ids, operator: "any_of" }] }
    ] }
  });
  return true;
}
var cortar = (s, n = 1900) => s.length > n ? `${s.slice(0, n - 1)}\u2026` : s;
async function gravarProdutos(boardId, produtos, inicio, progresso) {
  progresso("Arquivando os produtos de exemplo do modelo\u2026");
  await limparModelo(boardId, CP.grupos.produtos);
  progresso("Conferindo produtos j\xE1 existentes\u2026");
  const existentes = await itensDosGrupos(boardId, [CP.grupos.produtos], [CP.codigo]);
  const porCodigo = /* @__PURE__ */ new Map();
  for (const it of existentes) {
    const cod = (txt(it.cols[CP.codigo]).trim() || it.name.match(/^\s*(P\d+)/i)?.[1] || "").toUpperCase();
    if (cod) porCodigo.set(cod, it.id);
  }
  const valores = (p) => {
    const v = {
      [CP.codigo]: p.codigo,
      [CP.descricao]: cortar(p.descricao),
      [CP.meses]: `M${p.mes_inicio} - M${p.mes_fim}`,
      [CP.valor]: String(p.valor ?? 0),
      [CP.objetivo]: cortar(p.objetivo || ""),
      [CP.categoriaInsumo]: { labels: ["PRODUTO"] }
    };
    if (p.tipo_entrega) v[CP.tipoEntrega] = { labels: [p.tipo_entrega] };
    if (/^Fase [1-4]$/.test(p.fase)) {
      v[CP.etapaProduto] = { label: p.fase };
      v.color_mkyf9bv4 = { label: p.fase };
    }
    if (inicio) {
      const d = diasDoProduto(p);
      v[CP.contratual] = faixa(inicio, d.ini, d.fim);
    }
    return v;
  };
  const novos = produtos.filter((p) => !porCodigo.has(p.codigo.toUpperCase()));
  const velhos = produtos.filter((p) => porCodigo.has(p.codigo.toUpperCase()));
  if (velhos.length) {
    progresso(`Atualizando ${velhos.length} produtos que j\xE1 existiam\u2026`);
    await alterarItens(boardId, velhos.map((p) => ({ id: porCodigo.get(p.codigo.toUpperCase()), valores: valores(p) })));
  }
  if (novos.length) {
    const ids = await criarItens(boardId, CP.grupos.produtos, novos.map((p) => ({ nome: `${p.codigo} - ${p.nome}`, valores: valores(p) })), (n) => progresso(`Criando produtos ${n}/${novos.length}\u2026`));
    novos.forEach((p, i) => porCodigo.set(p.codigo.toUpperCase(), ids[i]));
  }
  return { mapa: Object.fromEntries(porCodigo), criados: novos.length, atualizados: velhos.length };
}
async function mapaProdutos(boardId) {
  const existentes = await itensDosGrupos(boardId, [CP.grupos.produtos], [CP.codigo]);
  const m = {};
  for (const it of existentes) {
    const cod = (txt(it.cols[CP.codigo]).trim() || it.name.match(/^\s*(P\d+)/i)?.[1] || "").toUpperCase();
    if (cod) m[cod] = it.id;
  }
  return m;
}
async function gravarEap(boardId, eap, ordem, mapa, inicio, progresso) {
  const linhas = [];
  const semProduto = [];
  for (const p of eap) {
    const k = ordem.indexOf(p.codigo) + 1 || ordem.length + 1;
    const pid = mapa[p.codigo.toUpperCase()];
    if (!pid) semProduto.push(p.codigo);
    const rel = pid ? { [CP.produtoRel]: { item_ids: [Number(pid)] } } : {};
    p.entregaveis.forEach((e, ie) => {
      const n2 = `${k}.${ie + 1}.`;
      linhas.push({ nome: `${n2} ENTREG\xC1VEL | ${e.nome}`, valores: { ...rel, [CP.eap]: { labels: ["N\xEDvel 2"] }, [CP.cronograma]: faixa(inicio, e.dia_inicio, e.dia_fim), [CP.status]: { label: "N\xE3o Iniciado" } } });
      e.marcos.forEach((m, im) => {
        const n3 = `${n2}${im + 1}.`;
        linhas.push({ nome: `${n3} MARCO | ${m.nome}`, valores: { ...rel, [CP.eap]: { labels: ["N\xEDvel 3"] }, [CP.cronograma]: faixa(inicio, m.dia_inicio, m.dia_fim), [CP.status]: { label: "N\xE3o Iniciado" } } });
        m.atividades.forEach((a, ia) => {
          const v = { ...rel, [CP.eap]: { labels: ["N\xEDvel 4"] }, [CP.cronograma]: faixa(inicio, a.dia_inicio, a.dia_fim), [CP.status]: { label: "N\xE3o Iniciado" } };
          if (a.frente) v[CP.frentes] = { label: a.frente };
          linhas.push({ nome: `${n3}${ia + 1}. ${a.nome}`, valores: v });
        });
      });
    });
  }
  progresso("Arquivando os itens de exemplo do modelo\u2026");
  await limparModelo(boardId, CP.grupos.cronograma);
  await criarItens(boardId, CP.grupos.cronograma, linhas, (n) => progresso(`Criando itens do cronograma ${n}/${linhas.length}\u2026`), true);
  progresso("Ajustando a aba 8. CRONOGRAMA para mostrar marcos e atividades\u2026");
  const aba = await ajustarAbaCronograma(boardId).catch(() => false);
  return { itens: linhas.length, semProduto, aba };
}
function valoresRisco(r, inicio) {
  const v = {
    [CP.tema]: { labels: [r.tema] },
    [CP.categoria]: { labels: [r.categoria] },
    [CP.impactado]: { labels: r.impactado },
    [CP.causa]: { text: r.causa },
    [CP.efeito]: { text: r.efeito },
    [CP.prob]: { label: r.probabilidade },
    [CP.imp]: { label: r.impacto },
    [CP.estrategia]: { label: r.estrategia },
    [CP.resposta]: { text: r.resposta },
    [CP.cargoResp]: r.cargo_responsavel,
    [CP.status]: { label: "N\xE3o Iniciado" }
  };
  if (r.frente) v[CP.frentes] = { label: r.frente };
  if (inicio && r.dia_inicio && r.dia_fim) v[CP.periodo] = faixa(inicio, r.dia_inicio, r.dia_fim);
  if (r.produtos?.length) v[CP.riscosAssoc] = `Produtos: ${r.produtos.join(", ")}`;
  return v;
}
async function gravarRiscosIA(boardId, riscos, inicio, progresso) {
  const sel = riscos.filter((r) => r.incluir !== false);
  await limparModelo(boardId, CP.grupos.riscos);
  await criarItens(boardId, CP.grupos.riscos, sel.map((r) => ({ nome: `${r.id} | ${r.titulo}`, valores: valoresRisco(r, inicio) })), (n) => progresso(`Criando riscos ${n}/${sel.length}\u2026`));
  return sel.length;
}
async function gravarPartes(boardId, partes, progresso) {
  const sel = partes.filter((p) => p.incluir !== false);
  await limparModelo(boardId, CP.grupos.partes);
  await criarItens(boardId, CP.grupos.partes, sel.map((p) => ({
    nome: p.nome,
    valores: {
      [CP.cargoCliente]: p.cargo_cliente,
      [CP.area]: `${p.area}${p.classe ? ` (${p.classe})` : ""}`,
      [CP.papel]: { labels: p.papel },
      [CP.interesse]: { label: p.interesse },
      [CP.poder]: { label: p.poder },
      [CP.expectativas]: { text: p.expectativas },
      [CP.riscosAssoc]: cortar(p.riscos_associados, 1e3),
      [CP.status]: { label: "N\xE3o Iniciado" }
    }
  })), (n) => progresso(`Criando partes interessadas ${n}/${sel.length}\u2026`));
  return sel.length;
}
function valoresIndicador(i, tipo, objetivo) {
  return {
    [CP.tipoInd]: { label: tipo },
    [CP.descInd]: { text: i.descricao },
    [CP.formula]: cortar(i.formula, 1e3),
    [CP.meta]: String(i.meta ?? ""),
    [CP.unidade]: { labels: [i.unidade] },
    [CP.temporalidade]: { labels: [i.temporalidade] },
    [CP.coleta]: { labels: [i.coleta] },
    [CP.polaridade]: { label: i.polaridade },
    [CP.qtdMed]: String(i.medicoes?.length ?? 0),
    [CP.objetivo]: cortar(objetivo, 1e3),
    [CP.statusMed]: { label: "Em Planejamento" }
  };
}
async function gravarIndicadores(boardId, objetivos, inicio, progresso) {
  let nInd = 0, nMed = 0;
  const medicoes = [];
  const addMed = (ind, id) => {
    (ind.medicoes ?? []).forEach((dia, k) => {
      const v = { [CP.meta]: String(ind.meta ?? ""), [CP.formula]: cortar(ind.formula, 1e3), [CP.indVinculado]: { item_ids: [Number(id)] }, [CP.statusMed]: { label: "N\xE3o Iniciado" } };
      if (inicio) v[CP.prazoMed] = { date: diaParaData(inicio, dia) };
      medicoes.push({ nome: `Medi\xE7\xE3o ${k + 1} - ${ind.nome}`, valores: v });
    });
  };
  await limparModelo(boardId, CP.grupos.indicador);
  for (const o of objetivos) {
    const krIds = await criarItens(boardId, CP.grupos.indicador, o.krs.map((kr) => ({ nome: kr.nome, valores: valoresIndicador(kr, "KR - Resultado Chave", o.objetivo) })));
    nInd += krIds.length;
    progresso(`Criando indicadores (${nInd})\u2026`);
    for (let k = 0; k < o.krs.length; k++) {
      const kr = o.krs[k];
      addMed(kr, krIds[k]);
      if (kr.kpis?.length) {
        const kpiIds = await criarItens(boardId, CP.grupos.indicador, kr.kpis.map((kpi) => ({ nome: kpi.nome, valores: { ...valoresIndicador(kpi, "KPI - Resultado de Processo", o.objetivo), [CP.krVinculado]: { item_ids: [Number(krIds[k])] } } })));
        nInd += kpiIds.length;
        kr.kpis.forEach((kpi, j) => addMed(kpi, kpiIds[j]));
        progresso(`Criando indicadores (${nInd})\u2026`);
      }
    }
  }
  if (medicoes.length) {
    await criarItens(boardId, CP.grupos.medicao, medicoes, (n) => progresso(`Criando medi\xE7\xF5es ${n}/${medicoes.length}\u2026`));
    nMed = medicoes.length;
  }
  return { indicadores: nInd, medicoes: nMed };
}

// src/generated/lib/engineData.js
var B_PROJ = 18439788380;
var B_MET = 18439788479;
var B_BASE = 18439788427;
var B_RISCOS = 18439788527;
var QUESTIONS = [
  { col: "c1_fat", n: 1 },
  { col: "c2_tipofat", n: 2 },
  { col: "c3_vig", n: 3 },
  { col: "c4_cli", n: 4 },
  { col: "c5_mod", n: 5 },
  { col: "c6_prod", n: 6 },
  { col: "c7_tipo", n: 7 },
  { col: "c8_equipe", n: 8 }
];
var PROJECT_COLS = [...QUESTIONS.map((q) => q.col), "c8_gr85", "calc"];
var t = (cv) => txt(cv).trim();
async function loadContext(onPhase) {
  onPhase("Identificando usu\xE1rio\u2026");
  const me = await gql2("query { me { id name } }");
  onPhase("Lendo metodologia (09.3)\u2026");
  const metItems = await fetchAllItems(B_MET, ["chave", "valor", "codigo_gr", "eixo", "rotulo", "ativo", "versao"]);
  const cfg = new Map(metItems.filter((it) => t(it.cols.chave)).map((it) => [t(it.cols.chave), t(it.cols.valor)]));
  const VERSAO = cfg.get("VERSAO_VIGENTE") || "2026-v2";
  const STATUS_OK = (cfg.get("BASE_STATUS_INCLUIDOS") || "Pendente;Em revis\xE3o;Confirmado").split(";").map((s) => s.trim()).filter(Boolean);
  const valid = (it) => isChecked(it.cols.ativo) && t(it.cols.versao) === VERSAO;
  const answerMap = /* @__PURE__ */ new Map();
  let GR_TRANS = null;
  let GR_85 = null;
  metItems.filter(valid).forEach((it) => {
    const code = t(it.cols.codigo_gr);
    if (!code) return;
    const eixo = t(it.cols.eixo).slice(0, 2);
    const rotulo = t(it.cols.rotulo).toLowerCase();
    const key = `${eixo}|${rotulo}`;
    if (rotulo && !answerMap.has(key)) answerMap.set(key, code);
    if (code === "Transversal") GR_TRANS = code;
    if (!GR_85 && code.startsWith("GR8.5")) GR_85 = code;
  });
  await sleep(250);
  onPhase("Lendo base de riscos (09.2)\u2026");
  const baseItems = await fetchAllItems(B_BASE, [
    "id_risco",
    "causa",
    "efeito",
    "categoria",
    "prob_ref",
    "imp_ref",
    "status_met",
    "parecer",
    "dup_status",
    "ativo",
    "versao",
    "codigo_gr"
  ]);
  const base2 = /* @__PURE__ */ new Map();
  const rxg = /* @__PURE__ */ new Map();
  baseItems.forEach((it) => {
    const statusMet = t(it.cols.status_met);
    if (!valid(it) || !STATUS_OK.includes(statusMet)) return;
    const code = t(it.cols.codigo_gr);
    if (code) {
      if (!rxg.has(code)) rxg.set(code, []);
      rxg.get(code).push(it.id);
    }
    base2.set(it.id, {
      id: it.id,
      name: it.name,
      idRisco: t(it.cols.id_risco),
      causa: txt(it.cols.causa),
      efeito: txt(it.cols.efeito),
      categoria: t(it.cols.categoria),
      prob: t(it.cols.prob_ref),
      imp: t(it.cols.imp_ref),
      statusMet,
      parecer: t(it.cols.parecer),
      dup: t(it.cols.dup_status)
    });
  });
  await sleep(250);
  onPhase("Lendo riscos j\xE1 gerados (09.4)\u2026");
  const riskItems = await fetchAllItems(B_RISCOS, ["chave"]);
  const keys = /* @__PURE__ */ new Set();
  const counts = /* @__PURE__ */ new Map();
  const ctx = { userName: me?.me?.name || "usu\xE1rio", VERSAO, STATUS_OK, answerMap, GR_TRANS, GR_85, rxg, base: base2, keys, counts };
  riskItems.forEach((it) => addKey(ctx, t(it.cols.chave)));
  return ctx;
}
function addKey(ctx, key) {
  if (!key || ctx.keys.has(key)) return;
  ctx.keys.add(key);
  const pid = key.split("|")[0];
  ctx.counts.set(pid, (ctx.counts.get(pid) || 0) + 1);
}
async function readProjects(ids) {
  const items = await fetchItemsByIds(ids, PROJECT_COLS);
  const byId = new Map(items.map((it) => [it.id, it]));
  return ids.map((id) => byId.get(String(id))).filter(Boolean);
}

// src/generated/lib/engineReconcile.js
var AUTO_DISCARD_PREFIX = "Descartado automaticamente pela calculadora";
var RISK_COLS = ["chave", "id_risco", "aplic", "justif", "sinal", "grs_origem"];
function toRisk(it) {
  return {
    itemId: it.id,
    key: txt(it.cols.chave).trim(),
    idRisco: txt(it.cols.id_risco).trim(),
    aplic: txt(it.cols.aplic).trim(),
    justif: txt(it.cols.justif),
    sinal: txt(it.cols.sinal),
    origins: dropdownLabels(it.cols.grs_origem)
  };
}
async function fetchProjectRisks(projectId) {
  const prefix = `${projectId}|`;
  let items;
  try {
    items = await fetchAllItems(B_RISCOS, RISK_COLS, {
      rules: [{ column_id: "chave", compare_value: [prefix], operator: "contains_text" }]
    });
  } catch (err) {
    if (isRateLimit(err)) throw err;
    console.error("Filtro por chave n\xE3o aceito; lendo o 09.4 completo:", err);
    items = await fetchAllItems(B_RISCOS, RISK_COLS);
  }
  return items.map(toRisk).filter((r) => r.key.startsWith(prefix));
}
var sameSet = (a, b) => a.length === b.length && a.every((x) => b.includes(x));
function planReconcile(existing, selectedOrigins, hoje) {
  const updates = [];
  const counts = { descartados: 0, sinalizados: 0, reativados: 0 };
  const finalAplic = /* @__PURE__ */ new Map();
  const reviewLine = `Em ${hoje} este risco deixou de corresponder \xE0s respostas do projeto. Revisar se ainda se aplica.`;
  existing.forEach((r) => {
    const values = {};
    let aplic = r.aplic;
    const origins = selectedOrigins.get(r.key);
    if (!origins) {
      if (r.aplic === "Identificado") {
        values.aplic = { label: "N\xE3o aplic\xE1vel" };
        values.justif = { text: `${AUTO_DISCARD_PREFIX} em ${hoje}: a resposta que originava este risco foi removida do cadastro.` };
        aplic = "N\xE3o aplic\xE1vel";
        counts.descartados += 1;
      } else if (r.aplic === "Aplic\xE1vel" || r.aplic === "Em avalia\xE7\xE3o") {
        const lines = r.sinal.split("\n").map((l) => l.trim());
        if (!lines.includes(reviewLine)) {
          values.sinal = { text: r.sinal.trim() ? `${r.sinal.replace(/\s+$/, "")}
${reviewLine}` : reviewLine };
          counts.sinalizados += 1;
        }
      }
    } else {
      if (r.aplic === "N\xE3o aplic\xE1vel" && r.justif.trim().startsWith(AUTO_DISCARD_PREFIX)) {
        values.aplic = { label: "Identificado" };
        values.justif = { text: "" };
        aplic = "Identificado";
        counts.reativados += 1;
      }
      if (!sameSet(r.origins, origins)) values.grs_origem = { labels: origins };
    }
    finalAplic.set(r.itemId, aplic);
    if (Object.keys(values).length) updates.push({ itemId: r.itemId, key: r.key, values });
  });
  const ativos = [...finalAplic.values()].filter((a) => a !== "N\xE3o aplic\xE1vel").length;
  return { updates, counts, ativos };
}
async function updateMany(batch) {
  const defs = [];
  const body = [];
  const vars = {};
  batch.forEach((u, i) => {
    defs.push(`$i${i}: ID!, $v${i}: JSON!`);
    body.push(`u${i}: change_multiple_column_values(board_id: ${B_RISCOS}, item_id: $i${i}, column_values: $v${i}, create_labels_if_missing: false) { id }`);
    vars[`i${i}`] = String(u.itemId);
    vars[`v${i}`] = JSON.stringify(u.values);
  });
  await gql2(`mutation (${defs.join(", ")}) { ${body.join(" ")} }`, vars);
}
async function applyUpdates(updates, onFraction) {
  for (let i = 0; i < updates.length; i += 10) {
    const batch = updates.slice(i, i + 10);
    try {
      await updateMany(batch);
    } catch (err) {
      if (isRateLimit(err)) throw err;
      console.error("Lote de atualiza\xE7\xE3o falhou, repetindo item a item:", err);
      for (const u of batch) {
        try {
          await updateMany([u]);
        } catch (e) {
          throw new Error(`Falha ao atualizar o risco ${u.key}: ${errorMessage(e)}`);
        }
        await sleep(200);
      }
    }
    onFraction?.(Math.min(1, (i + 10) / updates.length));
    await sleep(350);
  }
}

// src/generated/lib/engineRun.js
var UPDATE_MUTATION = `mutation ($b: ID!, $i: ID!, $v: JSON!) {
  change_multiple_column_values(board_id: $b, item_id: $i, column_values: $v) { id } }`;
async function updateProject(itemId, values) {
  await gql2(UPDATE_MUTATION, { b: String(B_PROJ), i: String(itemId), v: JSON.stringify(values) });
}
function selectRisks(ctx, project) {
  const warnings = [];
  const groups = [];
  QUESTIONS.forEach(({ col: col3, n }) => {
    const labels = dropdownLabels(project.cols[col3]);
    if (!labels.length) {
      warnings.push(`Pergunta ${n} sem resposta.`);
      return;
    }
    if (labels.length > 1) warnings.push(`Pergunta ${n} com mais de uma resposta: os grupos de todas as respostas foram somados.`);
    labels.forEach((label) => {
      const gr = ctx.answerMap.get(`${n}.|${label.trim().toLowerCase()}`);
      if (gr) groups.push(gr);
      else warnings.push(`Resposta '${label.trim()}' (pergunta ${n}) n\xE3o tem grupo na base: n\xE3o gerou riscos.`);
    });
  });
  if (isChecked(project.cols.c8_gr85) && ctx.GR_85) groups.push(ctx.GR_85);
  if (ctx.GR_TRANS) groups.push(ctx.GR_TRANS);
  const uniqueGroups = [...new Set(groups)];
  const selec = /* @__PURE__ */ new Map();
  uniqueGroups.forEach((g) => {
    (ctx.rxg.get(g) || []).forEach((riskId) => {
      if (!ctx.base.has(riskId)) return;
      const origins = selec.get(riskId);
      if (!origins) selec.set(riskId, [g]);
      else if (!origins.includes(g)) origins.push(g);
    });
  });
  const nTot = selec.size;
  let nTr = 0;
  selec.forEach((o) => {
    if (o.length === 1 && o[0] === ctx.GR_TRANS) nTr += 1;
  });
  return { warnings, groups: uniqueGroups, selec, nTot, nTr, nEsp: nTot - nTr };
}
function buildRiskPayload(ctx, projectId, risk, origins) {
  const key = `${projectId}|${risk.idRisco || risk.id}`;
  const sinais = [];
  if (risk.parecer && risk.parecer !== "OK") sinais.push(`Parecer da revis\xE3o: ${risk.parecer}.`);
  if (risk.dup.startsWith("Repetido")) sinais.push("Texto repetido na planilha com atributos divergentes.");
  if (risk.statusMet === "Em revis\xE3o") sinais.push("Risco em revis\xE3o metodol\xF3gica na base.");
  const cv = {
    rel_proj: { item_ids: [Number(projectId)] },
    rel_base: { item_ids: [Number(risk.id)] },
    id_risco: risk.idRisco,
    chave: key,
    grs_origem: { labels: origins },
    causa: { text: risk.causa },
    efeito: { text: risk.efeito },
    aplic: { label: "Identificado" },
    status_trat: { label: "N\xE3o iniciado" },
    ref_pi: `P: ${risk.prob || "-"} / I: ${risk.imp || "-"} (base ${ctx.VERSAO})`,
    versao: ctx.VERSAO
  };
  if (risk.categoria) cv.categoria = { labels: [risk.categoria] };
  if (risk.prob) cv.prob = { label: risk.prob };
  if (risk.imp) cv.imp = { label: risk.imp };
  if (sinais.length) cv.sinal = { text: sinais.join(" ") };
  return { key, idRisco: risk.idRisco, name: (risk.name || risk.idRisco || "Risco").slice(0, 255), cv };
}
async function createMany(batch) {
  const defs = [];
  const body = [];
  const vars = {};
  batch.forEach((b, i) => {
    defs.push(`$n${i}: String!, $v${i}: JSON!`);
    body.push(`m${i}: create_item(board_id: ${B_RISCOS}, group_id: "topics", item_name: $n${i}, column_values: $v${i}, create_labels_if_missing: false) { id }`);
    vars[`n${i}`] = b.name;
    vars[`v${i}`] = JSON.stringify(b.cv);
  });
  await gql2(`mutation (${defs.join(", ")}) { ${body.join(" ")} }`, vars);
}
async function existingKeys(keys) {
  const res2 = await gql2(
    `query ($b: ID!, $cols: [ItemsPageByColumnValuesQuery!]) { items_page_by_column_values(limit: 50, board_id: $b, columns: $cols) { items { column_values(ids: ["chave"]) { text } } } }`,
    { b: String(B_RISCOS), cols: [{ column_id: "chave", column_values: keys }] }
  );
  return new Set((res2?.items_page_by_column_values?.items || []).map((it) => txt(it.column_values?.[0]).trim()));
}
async function createBatch(ctx, batch) {
  try {
    await createMany(batch);
    batch.forEach((b) => addKey(ctx, b.key));
    return;
  } catch (err) {
    if (isRateLimit(err)) throw err;
    console.error("Lote falhou, conferindo itens criados:", err);
  }
  const found = await existingKeys(batch.map((b) => b.key));
  for (const b of batch) {
    if (found.has(b.key)) {
      addKey(ctx, b.key);
      continue;
    }
    try {
      await createMany([b]);
      addKey(ctx, b.key);
    } catch (err) {
      throw new Error(`Falha ao criar o risco ${b.idRisco || b.name}: ${errorMessage(err)}`);
    }
    await sleep(200);
  }
}
async function processProject(ctx, project, onFraction) {
  const sel = selectRisks(ctx, project);
  const hoje = todayISO();
  const existing = await fetchProjectRisks(project.id);
  existing.forEach((r) => addKey(ctx, r.key));
  const existingKeys2 = new Set(existing.map((r) => r.key));
  onFraction?.(0.1);
  const toCreate = [];
  const selectedOrigins = /* @__PURE__ */ new Map();
  sel.selec.forEach((origins, riskId) => {
    const payload = buildRiskPayload(ctx, project.id, ctx.base.get(riskId), origins);
    selectedOrigins.set(payload.key, origins);
    if (!existingKeys2.has(payload.key) && !ctx.keys.has(payload.key)) toCreate.push(payload);
  });
  toCreate.sort((a, b) => String(a.idRisco).localeCompare(String(b.idRisco), "pt-BR", { numeric: true }));
  for (let i = 0; i < toCreate.length; i += 10) {
    await createBatch(ctx, toCreate.slice(i, i + 10));
    onFraction?.(0.1 + Math.min(1, (i + 10) / toCreate.length) * 0.5);
    await sleep(350);
  }
  const plan = planReconcile(existing, selectedOrigins, hoje);
  await applyUpdates(plan.updates, (f) => onFraction?.(0.6 + f * 0.3));
  const alteracoes = { novos: toCreate.length, ...plan.counts };
  const total = plan.ativos + toCreate.length;
  const lines = [
    `${hoje} | base ${ctx.VERSAO} | ${sel.groups.length} grupos | ${total} riscos no projeto (${toCreate.length} novos nesta execu\xE7\xE3o)`,
    `Executado por: ${ctx.userName} pelo app Rodar Calculadora`,
    `RESULTADO: ${sel.nTot} riscos = ${sel.nEsp} espec\xEDficos + ${sel.nTr} transversais.`,
    `ALTERA\xC7\xD5ES: ${alteracoes.novos} novos, ${alteracoes.descartados} descartados automaticamente, ${alteracoes.sinalizados} sinalizados para revis\xE3o (j\xE1 avaliados), ${alteracoes.reativados} reativados.`,
    `GRUPOS: ${sel.groups.join(", ")}`,
    "AVISOS:",
    ...sel.warnings.map((w) => `  - ${w}`)
  ];
  const log = lines.join("\n");
  const status = sel.warnings.length ? "Executada c/ avisos" : "Executada";
  await updateProject(project.id, {
    grs_ident: sel.groups.join(", "),
    n_riscos: String(total),
    versao: ctx.VERSAO,
    data_calc: { date: hoje },
    log_calc: { text: log },
    calc: { label: status }
  });
  onFraction?.(1);
  return {
    id: project.id,
    name: project.name,
    status,
    groups: sel.groups,
    novos: toCreate.length,
    alteracoes,
    total,
    nTot: sel.nTot,
    nEsp: sel.nEsp,
    nTr: sel.nTr,
    warnings: sel.warnings,
    log,
    date: hoje
  };
}

// src/generated/lib/sendData.js
var SYSTEM_BOARDS = new Set([B_PROJ, B_MET, B_BASE, B_RISCOS].map(String));
var RISK_COLS2 = ["rel_proj", "rel_base", "id_risco", "causa", "efeito", "categoria", "prob", "imp", "estrategia", "resposta", "responsavel", "aplic", "justif"];
var TARGETS = [
  { key: "causa", title: "Causa", type: "long_text" },
  { key: "efeito", title: "Efeito", type: "long_text" },
  { key: "categoria", title: "Categoria", type: "dropdown" },
  { key: "tema", title: "Tema", type: "dropdown" },
  { key: "impactado", title: "Impactado", type: "dropdown" },
  { key: "prob", title: "Probabilidade", type: "status" },
  { key: "imp", title: "Impacto", type: "status" },
  { key: "estrategia", title: "Estrat\xE9gia", type: "status" },
  { key: "resposta", title: "Descri\xE7\xE3o da Resposta ao Risco", type: "long_text" },
  { key: "responsavel", title: "Respons\xE1vel pelo Monitoramento", type: "people" }
];
var OPTIONAL_TARGETS = [
  { key: "aplic", title: "Aplicabilidade", type: "status" },
  { key: "justif", title: "Justificativa", type: "long_text" }
];
var norm = (s) => String(s ?? "").trim().toLowerCase();
var listLabels = (cv) => {
  if (Array.isArray(cv?.values) && cv.values.length) return cv.values.map((v) => String(v.label ?? "").trim()).filter(Boolean);
  return txt(cv).split(", ").map((s) => s.trim()).filter(Boolean);
};
function labelsFromSettings(col3) {
  let s = col3.settings_str ?? col3.settings;
  if (typeof s === "string") {
    try {
      s = JSON.parse(s);
    } catch {
      s = null;
    }
  }
  const raw = s?.labels;
  const list = Array.isArray(raw) ? raw : raw && typeof raw === "object" ? Object.values(raw) : [];
  return list.map((l) => typeof l === "string" ? l : l?.name ?? l?.label ?? "").map((l) => String(l).trim()).filter(Boolean);
}
async function readDestBoard(boardId) {
  const q = (field) => `query ($b: [ID!]) { boards(ids: $b) { id name groups { id title } views { id name } columns { id title type ${field} } } }`;
  let res2;
  try {
    res2 = await gql2(q("settings_str"), { b: [String(boardId)] });
  } catch (err) {
    if (isRateLimit(err) || !/settings_str/i.test(String(err?.message))) throw err;
    res2 = await gql2(q("settings"), { b: [String(boardId)] });
  }
  const b = res2?.boards?.[0];
  if (!b) return null;
  return { ...b, columns: (b.columns || []).map((c) => ({ ...c, labels: labelsFromSettings(c) })) };
}
function findRiscosView(views) {
  const clean = (n) => norm(n).replace(/^\d+\s*[.\-–:)]*\s*/, "").trim();
  return (views || []).find((v) => clean(v.name) === "riscos") ?? null;
}
function mapColumns(columns) {
  const map = {};
  const missing = [];
  const find = (t2) => columns.find((c) => norm(c.title) === norm(t2.title) && c.type === t2.type);
  TARGETS.forEach((t2) => {
    const col3 = find(t2);
    if (col3) map[t2.key] = { id: col3.id, title: col3.title, labels: col3.labels };
    else missing.push(t2.title);
  });
  OPTIONAL_TARGETS.forEach((t2) => {
    const col3 = find(t2);
    if (col3) map[t2.key] = { id: col3.id, title: col3.title, labels: col3.labels, optional: true };
  });
  return { map, missing };
}
async function readDestExisting(boardId, groupId) {
  const ids = /* @__PURE__ */ new Set();
  const names = /* @__PURE__ */ new Set();
  const add = (items) => (items || []).forEach((it) => {
    const m = String(it.name || "").match(/^\s*(R\d*-\d+)/);
    if (m) ids.add(m[1].toUpperCase());
    names.add(norm(it.name));
  });
  const first = await gql2(
    "query ($b: [ID!], $g: [String]) { boards(ids: $b) { groups(ids: $g) { items_page(limit: 500) { cursor items { id name } } } } }",
    { b: [String(boardId)], g: [groupId] }
  );
  const page = first?.boards?.[0]?.groups?.[0]?.items_page;
  add(page?.items);
  let cursor = page?.cursor || null;
  while (cursor) {
    await sleep(250);
    const next = await gql2("query ($c: String!) { next_items_page(limit: 500, cursor: $c) { cursor items { id name } } }", { c: cursor });
    add(next?.next_items_page?.items);
    cursor = next?.next_items_page?.cursor || null;
  }
  return { ids, names };
}
async function readProjectRisks(projectId) {
  const pid = String(projectId);
  let items;
  try {
    items = await fetchAllItems(B_RISCOS, RISK_COLS2, {
      rules: [{ column_id: "rel_proj", compare_value: [Number(pid)], operator: "any_of" }]
    });
  } catch (err) {
    if (isRateLimit(err)) throw err;
    console.error("Filtro por projeto n\xE3o aceito; lendo o 09.4 completo:", err);
    items = await fetchAllItems(B_RISCOS, RISK_COLS2);
  }
  return items.filter((it) => linkedIds(it.cols.rel_proj).includes(pid));
}
async function readBaseThemes(riskIds) {
  const out = /* @__PURE__ */ new Map();
  if (!riskIds.length) return out;
  const items = await fetchItemsByIds(riskIds, ["tema", "impactado"]);
  items.forEach((it) => out.set(it.id, { tema: listLabels(it.cols.tema), impactado: listLabels(it.cols.impactado) }));
  return out;
}

// src/generated/lib/sendRun.js
var TEMA_MAP = {
  "riscos jur\xEDdicos": "Jur\xEDdico",
  "riscos de gest\xE3o": "Gest\xE3o",
  "riscos de imagem": "Imagem",
  "riscos financeiros": "Financeiro"
};
var BATCH = 5;
var findLabel = (labels, x) => labels.find((l) => norm(l) === norm(x)) ?? null;
var riskCode = (r) => {
  const id = txt(r.cols.id_risco).trim();
  return id || String(r.name).match(/^\s*(R\d*-\d+)/)?.[1] || "";
};
function buildValues(r, base2, map, warnings) {
  const cv = {};
  const code = riskCode(r) || r.name;
  const text = (key, value) => {
    if (map[key] && value.trim()) cv[map[key].id] = { text: value };
  };
  const labels = (key, values, alias) => {
    const col3 = map[key];
    if (!col3 || !values.length) return;
    const found = [];
    values.forEach((x) => {
      let hit = findLabel(col3.labels, x);
      if (!hit && alias) hit = alias(x, col3.labels);
      const v = hit || String(x).trim();
      if (v && !found.includes(v)) found.push(v);
    });
    if (found.length) cv[col3.id] = { labels: found };
  };
  const status = (key, value) => {
    const col3 = map[key];
    const x = value.trim();
    if (!col3 || !x) return;
    const hit = findLabel(col3.labels, x);
    if (hit) cv[col3.id] = { label: hit };
    else warnings.push(`${code}: '${x}' n\xE3o existe em ${col3.title} no destino`);
  };
  text("causa", txt(r.cols.causa));
  text("efeito", txt(r.cols.efeito));
  text("resposta", txt(r.cols.resposta));
  labels("categoria", listLabels(r.cols.categoria));
  labels("tema", (base2?.tema || []).map((t2) => TEMA_MAP[norm(t2)] ?? t2));
  labels("impactado", base2?.impactado || [], (x, ls) => norm(x) === "parceiro" ? findLabel(ls, "Cliente") : null);
  status("prob", txt(r.cols.prob));
  status("imp", txt(r.cols.imp));
  status("estrategia", txt(r.cols.estrategia));
  const aplic = txt(r.cols.aplic).trim();
  if (map.aplic && aplic) {
    const hit = findLabel(map.aplic.labels, aplic);
    if (hit) cv[map.aplic.id] = { label: hit };
  }
  text("justif", txt(r.cols.justif));
  if (map.responsavel) {
    let people = [];
    try {
      people = JSON.parse(r.cols.responsavel?.value || "null")?.personsAndTeams || [];
    } catch {
      people = [];
    }
    if (people.length) cv[map.responsavel.id] = { personsAndTeams: people.map((p) => ({ id: Number(p.id), kind: p.kind || "person" })) };
  }
  return cv;
}
async function createMany2(boardId, groupId, batch) {
  const defs = [];
  const body = [];
  const vars = { b: String(boardId), g: String(groupId) };
  batch.forEach((it, i) => {
    defs.push(`$n${i}: String!, $v${i}: JSON!`);
    body.push(`c${i}: create_item(board_id: $b, group_id: $g, item_name: $n${i}, column_values: $v${i}, create_labels_if_missing: true) { id }`);
    vars[`n${i}`] = it.name;
    vars[`v${i}`] = JSON.stringify(it.cv);
  });
  await gql2(`mutation ($b: ID!, $g: String!, ${defs.join(", ")}) { ${body.join(" ")} }`, vars);
}
function monHost(slug, fallbackUrl) {
  if (slug) return `https://${slug}.monday.com`;
  try {
    const u = new URL(fallbackUrl);
    if (u.host.endsWith("monday.com")) return `${u.protocol}//${u.host}`;
  } catch {
  }
  return "https://monday.com";
}
function destLink(host, boardId, views) {
  const view = findRiscosView(views);
  return view ? `${host}/boards/${boardId}/views/${view.id}` : `${host}/boards/${boardId}`;
}
async function sendProject(project, { slug } = {}, onPhase) {
  const bid = project.boardId;
  if (!bid) throw new Error("Preencha o 'Link do Planejamento' com o endere\xE7o do quadro [PLAN] do projeto.");
  if (SYSTEM_BOARDS.has(String(bid)) || String(bid) === String(B_PROJ)) {
    throw new Error(`O 'Link do Planejamento' aponta para um quadro da calculadora (${bid}), n\xE3o para o quadro [PLAN] do projeto.`);
  }
  onPhase?.("Lendo o quadro de planejamento\u2026", 0.05);
  const dest = await readDestBoard(bid);
  if (!dest) throw new Error(`Quadro de planejamento ${bid} n\xE3o encontrado ou sem acesso.`);
  const group = (dest.groups || []).find((g) => norm(g.title) === "riscos");
  if (!group) throw new Error(`O quadro '${dest.name}' n\xE3o tem um grupo chamado 'Riscos'.`);
  const warnings = [];
  const { map, missing } = mapColumns(dest.columns || []);
  if (missing.length) warnings.push(`Colunas n\xE3o encontradas no destino (n\xE3o copiadas): ${missing.join(", ")}`);
  onPhase?.("Lendo os riscos do projeto (09.4)\u2026", 0.15);
  const risks = await readProjectRisks(project.id);
  const result = {
    destName: dest.name,
    boardId: String(bid),
    destUrl: destLink(monHost(slug, project.url), bid, dest.views),
    total: risks.length,
    copied: 0,
    skipped: 0,
    warnings
  };
  if (!risks.length) {
    warnings.push("Nenhum risco encontrado no 09.4 para este projeto.");
    return result;
  }
  risks.sort((a, b) => riskCode(a).localeCompare(riskCode(b), "pt-BR", { numeric: true }));
  onPhase?.("Lendo tema e impactado na Base (09.2)\u2026", 0.25);
  const baseIds = [...new Set(risks.map((r) => linkedIds(r.cols.rel_base)[0]).filter(Boolean))];
  const base2 = await readBaseThemes(baseIds);
  onPhase?.("Conferindo riscos j\xE1 existentes no destino\u2026", 0.35);
  const existing = await readDestExisting(bid, group.id);
  const isDup = (it) => it.code && existing.ids.has(it.code.toUpperCase()) || existing.names.has(norm(it.name));
  const markDone = (it) => {
    if (it.code) existing.ids.add(it.code.toUpperCase());
    existing.names.add(norm(it.name));
  };
  const toCreate = [];
  risks.forEach((r) => {
    const it = { code: riskCode(r), name: String(r.name || riskCode(r)).slice(0, 255) };
    if (isDup(it)) {
      result.skipped += 1;
      return;
    }
    it.cv = buildValues(r, base2.get(linkedIds(r.cols.rel_base)[0]), map, warnings);
    markDone(it);
    toCreate.push(it);
  });
  for (let i = 0; i < toCreate.length; i += BATCH) {
    const batch = toCreate.slice(i, i + BATCH);
    onPhase?.(`Copiando riscos ${Math.min(i + BATCH, toCreate.length)}/${toCreate.length}\u2026`, 0.4 + 0.55 * (i / toCreate.length));
    try {
      await createMany2(bid, group.id, batch);
      result.copied += batch.length;
    } catch (err) {
      if (isRateLimit(err)) throw err;
      console.error("Lote de c\xF3pia falhou, conferindo o destino e repetindo item a item:", err);
      const now = await readDestExisting(bid, group.id);
      for (const it of batch) {
        if (it.code && now.ids.has(it.code.toUpperCase()) || now.names.has(norm(it.name))) {
          result.copied += 1;
          continue;
        }
        try {
          await createMany2(bid, group.id, [it]);
          result.copied += 1;
        } catch (e) {
          throw new Error(`Falha ao copiar o risco ${it.code || it.name}: ${errorMessage(e)} (${result.copied} j\xE1 copiados)`);
        }
        await sleep(300);
      }
    }
    await sleep(600);
  }
  return result;
}

// src/generated/lib/calc.ts
var LINK = "link_mm7nck8b";
async function prepararProjetoCalc(nome, planUrl, boardId, c, userId) {
  const itens = await fetchAllItems(B_PROJ, [LINK]);
  const achado = itens.find((it) => {
    let url = "";
    try {
      url = JSON.parse(it.cols[LINK]?.value || "null")?.url ?? "";
    } catch {
      url = "";
    }
    return url.includes(`/boards/${boardId}`) || it.name.trim().toLowerCase() === nome.trim().toLowerCase();
  });
  const valores = {
    c1_fat: { labels: [c.c1_fat] },
    c2_tipofat: { labels: [c.c2_tipofat] },
    c3_vig: { labels: [c.c3_vig] },
    c4_cli: { labels: [c.c4_cli] },
    c5_mod: { labels: [c.c5_mod] },
    c6_prod: { labels: [c.c6_prod] },
    c7_tipo: { labels: c.c7_tipo },
    c8_gr85: c.c8_gr85 ? { checked: "true" } : null,
    [LINK]: { url: planUrl, text: "Quadro [PLAN]" },
    situacao: { label: "Cadastro conclu\xEDdo" },
    data_cad: { date: hojeISO() },
    responsavel: { personsAndTeams: [{ id: Number(userId), kind: "person" }] }
  };
  if (c.c8_equipe) valores.c8_equipe = { labels: [c.c8_equipe] };
  if (achado) {
    await gql2("mutation ($b: ID!, $i: ID!, $v: JSON!) { change_multiple_column_values(board_id: $b, item_id: $i, column_values: $v) { id } }", { b: String(B_PROJ), i: achado.id, v: JSON.stringify(valores) });
    return String(achado.id);
  }
  const d = await gql2("mutation ($b: ID!, $n: String!, $v: JSON!) { create_item(board_id: $b, item_name: $n, column_values: $v) { id } }", { b: String(B_PROJ), n: nome, v: JSON.stringify(valores) });
  return String(d.create_item.id);
}
async function rodarCalculadora(projetoCalcId, progresso) {
  const ctx = await loadContext((m) => progresso(m));
  const [proj] = await readProjects([projetoCalcId]);
  if (!proj) throw new Error("Projeto n\xE3o encontrado no 09.1.");
  progresso("Gerando riscos pela metodologia\u2026");
  return processProject(ctx, proj, (f) => progresso(`Gerando riscos\u2026 ${Math.round(f * 100)}%`));
}
async function enviarAoPlanejamento(projetoCalcId, nome, planUrl, boardId, progresso) {
  return sendProject({ id: projetoCalcId, name: nome, url: planUrl, boardId }, {}, (m) => progresso(m));
}
async function riscosDoQuadro(boardId) {
  const its = await itensDosGrupos(boardId, [CP.grupos.riscos], [CP.causa, CP.efeito, CP.categoria, CP.estrategia, CP.resposta, CP.periodo, CP.frentes]);
  return its.map((it) => ({
    id: it.id,
    nome: it.name,
    causa: txt(it.cols[CP.causa]),
    efeito: txt(it.cols[CP.efeito]),
    categoria: txt(it.cols[CP.categoria]),
    estrategia: txt(it.cols[CP.estrategia]),
    resposta: txt(it.cols[CP.resposta]),
    periodo: txt(it.cols[CP.periodo]),
    frente: txt(it.cols[CP.frentes]),
    daIA: /^RISCO \d+/i.test(it.name)
  }));
}
async function aplicarComplemento(boardId, itens, inicio, progresso) {
  const sel = itens.filter((x) => x.aplicar !== false);
  await alterarItens(boardId, sel.map((x) => {
    const v = { [CP.estrategia]: { label: x.estrategia }, [CP.resposta]: { text: x.resposta } };
    if (x.frente) v[CP.frentes] = { label: x.frente };
    if (inicio && x.dia_inicio && x.dia_fim) v[CP.periodo] = faixa(inicio, x.dia_inicio, x.dia_fim);
    return { id: x.id, valores: v };
  }), (n) => progresso(`Completando riscos ${n}/${sel.length}\u2026`));
  return sel.length;
}

// src/generated/server/gravacao.ts
var ACOES = ["produtos", "eap", "riscos", "partes", "indicadores", "complemento", "calculadora"];
var res = (run, e) => run.etapas[e]?.resultado;
function produtosResumo(run) {
  return (res(run, "produtos")?.produtos ?? []).map((x, i) => ({
    codigo: x.codigo,
    nome: x.nome,
    descricao: x.descricao,
    dia_inicio: x.dia_inicio,
    dia_fim: x.dia_fim,
    mes_inicio: x.mes_inicio,
    mes_fim: x.mes_fim,
    valor: x.valor,
    ordem: i + 1
  }));
}
async function executar(run, acao, userId, prog) {
  const boardId = run.boardId;
  if (!boardId) throw new Error("Vincule o quadro [PLAN] antes de gravar.");
  const inicio = run.contexto.inicioExecucao ?? null;
  switch (acao) {
    case "produtos": {
      const r = res(run, "produtos");
      if (!r?.produtos?.length) throw new Error("N\xE3o h\xE1 produtos para gravar.");
      const out = await gravarProdutos(boardId, r.produtos, inicio, prog);
      return `${out.criados} produtos criados e ${out.atualizados} atualizados no grupo Produtos`;
    }
    case "eap": {
      const r = res(run, "eap");
      if (!r?.produtos?.length) throw new Error("N\xE3o h\xE1 EAP para gravar.");
      if (!inicio) throw new Error("Defina a data de in\xEDcio da execu\xE7\xE3o na aba Quadro.");
      prog("Lendo os produtos do quadro\u2026");
      const mapa = await mapaProdutos(boardId);
      const out = await gravarEap(boardId, r.produtos, produtosResumo(run).map((p) => p.codigo), mapa, inicio, prog);
      return `${out.itens} itens criados no grupo Cronograma (N\xEDveis 2, 3 e 4)${out.semProduto.length ? `; sem produto no quadro: ${out.semProduto.join(", ")}` : ""}`;
    }
    case "riscos": {
      const r = res(run, "riscos");
      if (!r?.riscos?.length) throw new Error("N\xE3o h\xE1 riscos para gravar.");
      const n = await gravarRiscosIA(boardId, r.riscos, inicio, prog);
      return `${n} riscos espec\xEDficos criados no grupo Riscos`;
    }
    case "partes": {
      const r = res(run, "partes");
      if (!r?.partes?.length) throw new Error("N\xE3o h\xE1 partes interessadas para gravar.");
      const n = await gravarPartes(boardId, r.partes, prog);
      return `${n} partes interessadas (institucionais) criadas`;
    }
    case "indicadores": {
      const r = res(run, "indicadores");
      if (!r?.objetivos?.length) throw new Error("N\xE3o h\xE1 indicadores para gravar.");
      const out = await gravarIndicadores(boardId, r.objetivos, inicio, prog);
      return `${out.indicadores} indicadores (KRs e KPIs) e ${out.medicoes} medi\xE7\xF5es criados`;
    }
    case "complemento": {
      const r = res(run, "complemento");
      if (!r?.riscos?.length) throw new Error("N\xE3o h\xE1 complemento para aplicar.");
      const n = await aplicarComplemento(boardId, r.riscos, inicio, prog);
      return `${n} riscos da calculadora completados (per\xEDodo, frente, estrat\xE9gia e resposta)`;
    }
    case "calculadora": {
      const analise = res(run, "analise");
      if (!analise?.calculadora) throw new Error("Gere a an\xE1lise dos documentos antes (ela define as 8 caracter\xEDsticas).");
      if (!run.boardUrl) throw new Error("Vincule o quadro [PLAN] antes.");
      const c = { ...analise.calculadora, c8_equipe: analise.calculadora.c8_equipe || "At\xE9 10 membros na equipe" };
      prog("Arquivando os riscos de exemplo do modelo\u2026");
      await limparModelo(boardId, CP.grupos.riscos);
      prog("Cadastrando o projeto no 09.1 com as 8 caracter\xEDsticas\u2026");
      const id = await prepararProjetoCalc(run.nomeItem, run.boardUrl, boardId, c, userId);
      const rc = await rodarCalculadora(id, prog);
      prog("Enviando os riscos ao quadro [PLAN]\u2026");
      const env = await enviarAoPlanejamento(id, run.nomeItem, run.boardUrl, boardId, prog);
      const resumo = `Calculadora: ${rc.nTot} riscos (${rc.nEsp} dos grupos de risco e ${rc.nTr} transversais); ${env.copied} enviados ao grupo Riscos, ${env.skipped} j\xE1 estavam l\xE1${env.warnings?.length ? `. Avisos: ${env.warnings.slice(0, 3).join("; ")}` : ""}`;
      const alvo = (await riscosDoQuadro(boardId)).filter((x) => !x.daIA);
      if (alvo.length) {
        const t2 = analise.tap ?? {};
        await iniciarGeracao(run, "complemento", {
          produtos: produtosResumo(run),
          resumo: [t2.justificativa, t2.resultado_principal, t2.como_chega].filter(Boolean).join("\n") || run.nomeItem,
          riscosQuadro: alvo.map((x) => ({ id: x.id, nome: x.nome, causa: x.causa, efeito: x.efeito, categoria: x.categoria, estrategia: x.estrategia, resposta: x.resposta }))
        });
      }
      return resumo;
    }
  }
}
async function registrar(runId, userId) {
  try {
    const atual = await (await colRuns()).findOne({ _id: runId });
    if (!atual) return;
    const linhas = Object.keys(ROTULO_ETAPA).filter((k) => atual.etapas[k]?.status === "gravada").map((k) => `${ROTULO_ETAPA[k]}: ${atual.etapas[k]?.resumoGravacao ?? ""} (${(atual.etapas[k]?.gravadaEm ?? "").slice(0, 10).split("-").reverse().join("/")})`);
    const id = await registrarNoHub({ hubItemId: atual.hubItemId, nome: atual.nomeItem, itemId: atual.itemId, runId, quadroUrl: atual.boardUrl, userId, etapas: linhas.join("\n") });
    if (id !== atual.hubItemId) await (await colRuns()).updateOne({ _id: runId }, { $set: { hubItemId: id } });
  } catch (e) {
    console.error("[registro 09.0]", e);
  }
}
var gravarNoQuadro = createServerFn().validator(external_exports.object({ runId: external_exports.string(), acao: external_exports.enum(ACOES) })).handler(async ({ data }) => {
  const c = ctxOuErro();
  const token = await tokenIA();
  const run = await (await colRuns()).findOne({ _id: data.runId });
  if (!run) throw new Error("Execu\xE7\xE3o n\xE3o encontrada.");
  const chave = `${run._id}:grav:${data.acao}`;
  if (rodando.has(chave)) return { iniciada: false, motivo: "J\xE1 est\xE1 gravando." };
  const e = data.acao;
  await setEtapa(run._id, e, { gravando: true, erroGravacao: "", progressoGravacao: "Come\xE7ando a grava\xE7\xE3o\u2026", batidaGravacao: agora() });
  let ultimo = 0;
  const prog = (m) => {
    if (Date.now() - ultimo < 2e3) return;
    ultimo = Date.now();
    setEtapa(run._id, e, { progressoGravacao: m, batidaGravacao: agora() }).catch(() => null);
  };
  const job = tokenAtual.run(token, async () => {
    try {
      const resumo = await executar(run, data.acao, c.userId, prog);
      await setEtapa(run._id, e, {
        gravando: false,
        progressoGravacao: "",
        erroGravacao: "",
        status: "gravada",
        gravadaEm: agora(),
        gravadaPor: c.userId,
        resumoGravacao: resumo
      });
      await registrar(run._id, c.userId);
    } catch (err) {
      console.error(`[gravar ${data.acao}]`, err);
      await setEtapa(run._id, e, { gravando: false, progressoGravacao: "", erroGravacao: err instanceof Error ? err.message : String(err) });
    }
  }).finally(() => rodando.delete(chave));
  rodando.set(chave, job);
  return { iniciada: true };
});

// server/registry.ts
var MODULES = {
  "gravacao": gravacao_exports,
  "hub": hub_exports
};

// server/index.ts
definirExecutor(async (query, variables) => {
  const { status, json } = await respostaMonday(query, variables ?? {});
  if (!json) return { errors: [{ message: `HTTP ${status}` }] };
  if (status === 429 && !json.errors) return { ...json, errors: [{ message: "rate limit (429)" }] };
  return json;
});
var FNS = /* @__PURE__ */ new Map();
for (const [mod, exp] of Object.entries(MODULES)) {
  for (const [name, v] of Object.entries(exp)) {
    if (typeof v === "function" && v.__serverFn) FNS.set(`${mod}:${name}`, v);
  }
}
var PUBLIC = import_node_path.default.join(__dirname, "public");
var MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".mjs": "text/javascript", ".css": "text/css", ".png": "image/png", ".svg": "image/svg+xml", ".json": "application/json", ".woff2": "font/woff2" };
function b64url(buf) {
  return buf.toString("base64").replace(/=+$/, "").replace(/\+/g, "-").replace(/\//g, "_");
}
function verifySession(token) {
  const secret = process.env.CLIENT_SECRET;
  if (!secret || !token) return null;
  const parts = token.replace(/^Bearer\s+/i, "").split(".");
  if (parts.length !== 3) return null;
  const sig = b64url((0, import_node_crypto4.createHmac)("sha256", secret).update(`${parts[0]}.${parts[1]}`).digest());
  const a = Buffer.from(sig), b = Buffer.from(parts[2]);
  if (a.length !== b.length || !(0, import_node_crypto4.timingSafeEqual)(a, b)) return null;
  try {
    const p = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
    if (p.exp && p.exp * 1e3 < Date.now()) return null;
    const d = p.dat ?? p;
    if (!d.user_id) return null;
    lembrarCliente(d.client_id, d.account_id);
    return { userId: String(d.user_id), accountId: String(d.account_id ?? ""), isAdmin: d.is_admin === true, isGuest: d.is_guest === true || d.user_kind === "guest" };
  } catch {
    return null;
  }
}
function send(res2, status, body) {
  res2.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res2.end(JSON.stringify(body));
}
async function readBody(req, max = 60 * 1024 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > max) throw new Error("Envio grande demais.");
    chunks.push(c);
  }
  return Buffer.concat(chunks).toString("utf8");
}
function zodMessage(e) {
  const issues = e?.issues;
  if (!Array.isArray(issues)) return null;
  return "Dados inv\xE1lidos: " + issues.slice(0, 3).map((i) => `${(i.path ?? []).join(".")}: ${i.message}`).join("; ");
}
var server = import_node_http.default.createServer(async (req, res2) => {
  const url = new URL(req.url ?? "/", "http://x");
  const p = url.pathname;
  try {
    if (req.method === "POST" && p.startsWith("/_fn/")) {
      const id = decodeURIComponent(p.slice(5));
      const fn = FNS.get(id);
      if (!fn) return send(res2, 404, { ok: false, error: `Fun\xE7\xE3o n\xE3o encontrada: ${id}` });
      const ctx = verifySession(String(req.headers.authorization ?? ""));
      if (!ctx) return send(res2, 401, { ok: false, error: "Sess\xE3o do monday inv\xE1lida ou expirada. Recarregue a p\xE1gina." });
      const body = JSON.parse(await readBody(req) || "{}");
      const callId = String(req.headers["x-call-id"] ?? "");
      if (/^[a-f0-9]{16,64}$/.test(callId)) ctx.callId = callId;
      try {
        const result = await reqCtx.run(ctx, () => fn.run(body?.data ?? void 0));
        return send(res2, 200, { ok: true, result: result ?? null });
      } catch (e) {
        const msg = zodMessage(e) ?? (e instanceof Error ? e.message : String(e));
        console.error(`[fn ${id}]`, msg);
        return send(res2, 200, { ok: false, error: msg.slice(0, 1e3) });
      } finally {
        ctx.encerrada = true;
      }
    }
    if (req.method === "POST" && (p === "/_mut/pendentes" || p === "/_mut/resultado")) {
      const ctx = verifySession(String(req.headers.authorization ?? ""));
      if (!ctx) return send(res2, 401, { ok: false, error: "Sess\xE3o do monday inv\xE1lida ou expirada. Recarregue a p\xE1gina." });
      const b = JSON.parse(await readBody(req, 20 * 1024 * 1024) || "{}");
      if (p === "/_mut/pendentes") {
        const callId = String(b?.callId ?? "");
        if (!/^[a-f0-9]{16,64}$/.test(callId)) return send(res2, 400, { ok: false });
        return send(res2, 200, { ok: true, result: await pendentes(callId, ctx.userId) });
      }
      await registrarResultado(String(b?.id ?? ""), ctx.userId, b?.resposta ?? null, b?.erro);
      return send(res2, 200, { ok: true });
    }
    if (p.startsWith("/mndy-cronjob/") || p.startsWith("/cron/")) {
      const job = p.split("/").filter(Boolean)[1] ?? "";
      if (p.startsWith("/cron/") && (!process.env.CRON_KEY || req.headers["x-cron-key"] !== process.env.CRON_KEY)) return send(res2, 401, { ok: false });
      const body = req.method === "POST" ? await readBody(req, 1e6).catch(() => "") : "";
      let weekStart;
      try {
        weekStart = JSON.parse(body || "{}").weekStart;
      } catch {
      }
      const out = await startJob(job, p.startsWith("/cron/") ? weekStart : void 0).catch((e) => ({ error: String(e?.message ?? e) }));
      console.log(`[cron ${job}]`, JSON.stringify(out));
      return send(res2, 200, { ok: true, result: out });
    }
    if (req.method === "GET" && p === "/oauth/start") return await oauthStart(req, res2, url);
    if (req.method === "GET" && p === "/oauth/callback") return await oauthCallback(req, res2, url);
    if (req.method === "GET" && p === "/oauth/status") return await oauthStatus(res2);
    if (p === "/health") return send(res2, 200, { ok: true });
    const rel = p === "/" ? "index.html" : import_node_path.default.normalize(p).replace(/^([/\\])+/, "");
    const file = import_node_path.default.join(PUBLIC, rel);
    if (!file.startsWith(PUBLIC)) return send(res2, 404, { ok: false });
    try {
      const data = await (0, import_promises.readFile)(file);
      res2.writeHead(200, { "Content-Type": MIME[import_node_path.default.extname(file)] ?? "application/octet-stream", "Cache-Control": rel === "index.html" ? "no-store" : "public, max-age=31536000, immutable" });
      return res2.end(data);
    } catch {
      const html = await (0, import_promises.readFile)(import_node_path.default.join(PUBLIC, "index.html"));
      res2.writeHead(200, { "Content-Type": MIME[".html"], "Cache-Control": "no-store" });
      return res2.end(html);
    }
  } catch (e) {
    console.error("[server]", e);
    if (!res2.headersSent) send(res2, 500, { ok: false, error: e instanceof Error ? e.message : "Erro no servidor." });
  }
});
server.requestTimeout = 0;
server.headersTimeout = 12e4;
server.listen(Number(process.env.PORT) || 8080, () => console.log(`servidor no ar (${FNS.size} fun\xE7\xF5es)`));

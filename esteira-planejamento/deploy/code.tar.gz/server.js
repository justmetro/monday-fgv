"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server/index.ts
var import_node_http = __toESM(require("node:http"), 1);
var import_node_crypto4 = require("node:crypto");
var import_promises = require("node:fs/promises");
var import_node_path = __toESM(require("node:path"), 1);

// server/context.ts
var import_node_async_hooks = require("node:async_hooks");
var reqCtx = new import_node_async_hooks.AsyncLocalStorage();
var currentCtx = () => reqCtx.getStore() ?? null;

// server/mongo.ts
var import_mongodb = require("mongodb");
var clientP = null;
function mongo() {
  if (!clientP) {
    const uri = process.env.MNDY_MONGODB_CONNECTION_STRING;
    if (!uri) throw new Error("Banco do app indispon\xEDvel (MNDY_MONGODB_CONNECTION_STRING ausente).");
    const client = new import_mongodb.MongoClient(uri, { maxPoolSize: 10, serverSelectionTimeoutMS: 15e3 });
    clientP = client.connect().then((c) => c.db()).catch((e) => {
      clientP = null;
      throw e;
    });
  }
  return clientP;
}

// server/jobs.ts
var JOBS = {};
var running = null;
async function startJob(kind, arg) {
  const fn = JOBS[kind];
  if (!fn) throw new Error(`Job desconhecido: ${kind}`);
  const col3 = (await mongo()).collection("app_jobs");
  const cur = await col3.findOne({ _id: "current" });
  if (running || cur?.status === "rodando" && Date.now() - Date.parse(cur.startedAt) < 20 * 6e4) {
    if (cur) return cur;
  }
  const state = { _id: "current", kind, status: "rodando", startedAt: (/* @__PURE__ */ new Date()).toISOString(), ...arg ? { arg } : {} };
  await col3.replaceOne({ _id: "current" }, state, { upsert: true });
  running = (async () => {
    try {
      const result = await fn(arg);
      await col3.updateOne({ _id: "current" }, { $set: { status: "concluido", finishedAt: (/* @__PURE__ */ new Date()).toISOString(), result } });
    } catch (e) {
      const error = e instanceof Error ? e.message : String(e);
      await col3.updateOne({ _id: "current" }, { $set: { status: "erro", finishedAt: (/* @__PURE__ */ new Date()).toISOString(), error } }).catch(() => null);
      console.error(`[job ${kind}]`, error);
    } finally {
      running = null;
    }
  })();
  return state;
}

// server/relay.ts
var import_node_crypto = require("node:crypto");
var SEM_NAVEGADOR = /* @__PURE__ */ Symbol("sem-navegador");
var col = async () => (await mongo()).collection("app_mutacoes");
var LIMITE_MS = 12e4;
var espera = (ms) => new Promise((r) => setTimeout(r, ms));
var ultimaLimpeza = 0;
async function limpar() {
  if (Date.now() - ultimaLimpeza < 60 * 6e4) return;
  ultimaLimpeza = Date.now();
  await (await col()).deleteMany({ at: { $lt: Date.now() - 24 * 60 * 6e4 } }).catch(() => null);
}
async function viaNavegador(query, variables) {
  const ctx = currentCtx();
  if (!ctx?.callId || ctx.viaCron || ctx.encerrada) return SEM_NAVEGADOR;
  const c = await col();
  const _id = (0, import_node_crypto.randomBytes)(12).toString("hex");
  await c.insertOne({ _id, callId: ctx.callId, userId: ctx.userId, query, variables: variables ?? {}, status: "pendente", at: Date.now() });
  void limpar();
  const fim = Date.now() + LIMITE_MS;
  let passo = 150;
  while (Date.now() < fim) {
    await espera(passo);
    passo = Math.min(passo + 100, 500);
    const p = await c.findOne({ _id });
    if (p?.status === "ok") return p.resposta;
    if (p?.status === "erro") return { errors: [{ message: p.erro || "Falha ao gravar no monday pelo navegador." }] };
  }
  await c.updateOne({ _id, status: { $in: ["pendente", "enviada"] } }, { $set: { status: "expirada" } });
  throw new Error("A grava\xE7\xE3o n\xE3o foi confirmada pelo navegador a tempo. Mantenha a aba aberta e tente novamente.");
}
async function pendentes(callId, userId, esperarMs = 8e3) {
  const c = await col();
  const fim = Date.now() + esperarMs;
  for (; ; ) {
    const lista = [];
    for (; ; ) {
      const p = await c.findOneAndUpdate({ callId, userId, status: "pendente" }, { $set: { status: "enviada" } }, { sort: { at: 1 }, returnDocument: "after" });
      const doc = p && "value" in p ? p.value : p;
      if (!doc) break;
      lista.push({ id: doc._id, query: doc.query, variables: doc.variables });
    }
    if (lista.length || Date.now() >= fim) return lista;
    await espera(200);
  }
}
async function registrarResultado(id2, userId, resposta, erro) {
  await (await col()).updateOne(
    { _id: id2, userId, status: "enviada" },
    { $set: erro ? { status: "erro", erro: String(erro).slice(0, 1e3) } : { status: "ok", resposta } }
  );
}

// server/oauth.ts
var import_node_crypto2 = require("node:crypto");
var col2 = async () => (await mongo()).collection("app_oauth");
var cache = null;
var TTL = 5 * 60 * 1e3;
async function tokenOAuth() {
  if (cache && Date.now() - cache.at < TTL) return cache.token;
  try {
    const d = await (await col2()).findOne({ _id: "token" });
    cache = { at: Date.now(), token: typeof d?.accessToken === "string" ? d.accessToken : null };
  } catch (e) {
    console.error("[oauth] leitura do token", e);
    cache = { at: Date.now(), token: null };
  }
  return cache.token;
}
var conhecido = "";
function lembrarCliente(clientId, accountId) {
  const c = String(clientId ?? ""), a = String(accountId ?? "");
  if (!c || conhecido === `${c}|${a}`) return;
  conhecido = `${c}|${a}`;
  col2().then((x) => x.updateOne({ _id: "cliente" }, { $set: { clientId: c, accountId: a } }, { upsert: true })).catch(() => {
    conhecido = "";
  });
}
function pagina(res, status, texto) {
  if (status >= 400) {
    console.error("[oauth]", status, texto);
    col2().then((x) => x.updateOne({ _id: "erro" }, { $set: { status, texto, em: (/* @__PURE__ */ new Date()).toISOString() } }, { upsert: true })).catch(() => null);
  }
  res.writeHead(status, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
  res.end(`<!doctype html><meta charset="utf-8"><title>Autoriza\xE7\xE3o do app</title><body style="font-family:system-ui;padding:40px;max-width:560px">${texto}</body>`);
}
function retorno(req) {
  if (process.env.OAUTH_REDIRECT_URI) return process.env.OAUTH_REDIRECT_URI;
  let host = String(req.headers["x-forwarded-host"] ?? req.headers.host ?? "").split(",")[0].trim();
  const m = host.match(/^([a-z0-9]+)---(service-\d+-[a-z0-9]+)-[a-z0-9]+-[a-z]+\.a\.run\.app$/);
  if (m) host = `${m[1]}-${m[2]}.us.monday.app`;
  return `https://${host}/oauth/callback`;
}
async function oauthStart(req, res) {
  const c = await (await col2()).findOne({ _id: "cliente" });
  if (!c?.clientId) return pagina(res, 409, "<p>Abra o app uma vez dentro do monday e depois volte a este link.</p>");
  const state = (0, import_node_crypto2.randomBytes)(24).toString("hex");
  await (await col2()).updateOne({ _id: "state" }, { $set: { state, at: Date.now() } }, { upsert: true });
  const url = new URL("https://auth.monday.com/oauth2/authorize");
  url.searchParams.set("client_id", String(c.clientId));
  url.searchParams.set("redirect_uri", retorno(req));
  url.searchParams.set("state", state);
  res.writeHead(302, { Location: url.toString(), "Cache-Control": "no-store" });
  res.end();
}
async function oauthCallback(req, res, url) {
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const x = await col2();
  const s = await x.findOne({ _id: "state" });
  if (!code || !state || s?.state !== state || Date.now() - Number(s?.at ?? 0) > 15 * 60 * 1e3) {
    return pagina(res, 400, "<p>Link de autoriza\xE7\xE3o inv\xE1lido ou expirado. Abra /oauth/start de novo.</p>");
  }
  await x.deleteOne({ _id: "state" });
  const c = await x.findOne({ _id: "cliente" });
  const r = await fetch("https://auth.monday.com/oauth2/token", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ client_id: c?.clientId, client_secret: process.env.CLIENT_SECRET, code, redirect_uri: retorno(req) })
  });
  const j = await r.json().catch(() => null);
  if (!j?.access_token) return pagina(res, 400, `<p>O monday recusou a autoriza\xE7\xE3o: ${String(j?.error_description ?? j?.error ?? r.status).replace(/[<>]/g, "")}</p>`);
  const me = await fetch("https://api.monday.com/v2", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: j.access_token, "API-Version": "2026-10" },
    body: JSON.stringify({ query: "{ me { id name kind } }" })
  }).then((y) => y.json()).catch(() => null);
  const u = me?.data?.me;
  if (u?.kind !== "admin") {
    console.error("[oauth] me", JSON.stringify(me).slice(0, 500));
    return pagina(res, 403, "<p>S\xF3 um admin da conta FGV DGPE pode autorizar o app.</p>");
  }
  await x.updateOne({ _id: "token" }, { $set: { accessToken: j.access_token, userId: String(u.id), nome: u.name, em: (/* @__PURE__ */ new Date()).toISOString() } }, { upsert: true });
  cache = null;
  return pagina(res, 200, `<p>App autorizado por ${u.name.replace(/[<>]/g, "")}. Pode fechar esta aba e recarregar o app no monday.</p>`);
}
async function oauthStatus(res) {
  const d = await (await col2()).findOne({ _id: "token" });
  const e = await (await col2()).findOne({ _id: "erro" });
  res.writeHead(200, { "Content-Type": "application/json", "Cache-Control": "no-store" });
  res.end(JSON.stringify({ autorizado: !!d?.accessToken, por: d?.nome ?? null, em: d?.em ?? null, ultimoErro: e ? { status: e.status, texto: e.texto, em: e.em } : null }));
}

// src/generated/server/acoes.ts
var acoes_exports = {};
__export(acoes_exports, {
  autoresAcoes: () => autoresAcoes,
  desfazerAcao: () => desfazerAcao,
  listarAcoes: () => listarAcoes,
  registrarRelatorio: () => registrarRelatorio
});

// server/serverFn.ts
function createServerFn(_opts) {
  let validator = null;
  const b = {
    validator(v) {
      validator = v;
      return b;
    },
    inputValidator(v) {
      validator = v;
      return b;
    },
    middleware(_m) {
      return b;
    },
    handler(h) {
      const run = async (raw) => {
        let data = raw;
        if (validator) data = typeof validator === "function" ? validator(raw) : validator.parse(raw);
        return h({ data });
      };
      const fn = ((opts) => run(opts?.data));
      fn.__serverFn = true;
      fn.run = run;
      return fn;
    }
  };
  return b;
}

// node_modules/zod/v3/external.js
var external_exports = {};
__export(external_exports, {
  BRAND: () => BRAND,
  DIRTY: () => DIRTY,
  EMPTY_PATH: () => EMPTY_PATH,
  INVALID: () => INVALID,
  NEVER: () => NEVER,
  OK: () => OK,
  ParseStatus: () => ParseStatus,
  Schema: () => ZodType,
  ZodAny: () => ZodAny,
  ZodArray: () => ZodArray,
  ZodBigInt: () => ZodBigInt,
  ZodBoolean: () => ZodBoolean,
  ZodBranded: () => ZodBranded,
  ZodCatch: () => ZodCatch,
  ZodDate: () => ZodDate,
  ZodDefault: () => ZodDefault,
  ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
  ZodEffects: () => ZodEffects,
  ZodEnum: () => ZodEnum,
  ZodError: () => ZodError,
  ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
  ZodFunction: () => ZodFunction,
  ZodIntersection: () => ZodIntersection,
  ZodIssueCode: () => ZodIssueCode,
  ZodLazy: () => ZodLazy,
  ZodLiteral: () => ZodLiteral,
  ZodMap: () => ZodMap,
  ZodNaN: () => ZodNaN,
  ZodNativeEnum: () => ZodNativeEnum,
  ZodNever: () => ZodNever,
  ZodNull: () => ZodNull,
  ZodNullable: () => ZodNullable,
  ZodNumber: () => ZodNumber,
  ZodObject: () => ZodObject,
  ZodOptional: () => ZodOptional,
  ZodParsedType: () => ZodParsedType,
  ZodPipeline: () => ZodPipeline,
  ZodPromise: () => ZodPromise,
  ZodReadonly: () => ZodReadonly,
  ZodRecord: () => ZodRecord,
  ZodSchema: () => ZodType,
  ZodSet: () => ZodSet,
  ZodString: () => ZodString,
  ZodSymbol: () => ZodSymbol,
  ZodTransformer: () => ZodEffects,
  ZodTuple: () => ZodTuple,
  ZodType: () => ZodType,
  ZodUndefined: () => ZodUndefined,
  ZodUnion: () => ZodUnion,
  ZodUnknown: () => ZodUnknown,
  ZodVoid: () => ZodVoid,
  addIssueToContext: () => addIssueToContext,
  any: () => anyType,
  array: () => arrayType,
  bigint: () => bigIntType,
  boolean: () => booleanType,
  coerce: () => coerce,
  custom: () => custom,
  date: () => dateType,
  datetimeRegex: () => datetimeRegex,
  defaultErrorMap: () => en_default,
  discriminatedUnion: () => discriminatedUnionType,
  effect: () => effectsType,
  enum: () => enumType,
  function: () => functionType,
  getErrorMap: () => getErrorMap,
  getParsedType: () => getParsedType,
  instanceof: () => instanceOfType,
  intersection: () => intersectionType,
  isAborted: () => isAborted,
  isAsync: () => isAsync,
  isDirty: () => isDirty,
  isValid: () => isValid,
  late: () => late,
  lazy: () => lazyType,
  literal: () => literalType,
  makeIssue: () => makeIssue,
  map: () => mapType,
  nan: () => nanType,
  nativeEnum: () => nativeEnumType,
  never: () => neverType,
  null: () => nullType,
  nullable: () => nullableType,
  number: () => numberType,
  object: () => objectType,
  objectUtil: () => objectUtil,
  oboolean: () => oboolean,
  onumber: () => onumber,
  optional: () => optionalType,
  ostring: () => ostring,
  pipeline: () => pipelineType,
  preprocess: () => preprocessType,
  promise: () => promiseType,
  quotelessJson: () => quotelessJson,
  record: () => recordType,
  set: () => setType,
  setErrorMap: () => setErrorMap,
  strictObject: () => strictObjectType,
  string: () => stringType,
  symbol: () => symbolType,
  transformer: () => effectsType,
  tuple: () => tupleType,
  undefined: () => undefinedType,
  union: () => unionType,
  unknown: () => unknownType,
  util: () => util,
  void: () => voidType
});

// node_modules/zod/v3/helpers/util.js
var util;
(function(util2) {
  util2.assertEqual = (_) => {
  };
  function assertIs(_arg) {
  }
  util2.assertIs = assertIs;
  function assertNever(_x) {
    throw new Error();
  }
  util2.assertNever = assertNever;
  util2.arrayToEnum = (items) => {
    const obj = {};
    for (const item of items) {
      obj[item] = item;
    }
    return obj;
  };
  util2.getValidEnumValues = (obj) => {
    const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
    const filtered = {};
    for (const k of validKeys) {
      filtered[k] = obj[k];
    }
    return util2.objectValues(filtered);
  };
  util2.objectValues = (obj) => {
    return util2.objectKeys(obj).map(function(e) {
      return obj[e];
    });
  };
  util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
    const keys = [];
    for (const key in object) {
      if (Object.prototype.hasOwnProperty.call(object, key)) {
        keys.push(key);
      }
    }
    return keys;
  };
  util2.find = (arr, checker) => {
    for (const item of arr) {
      if (checker(item))
        return item;
    }
    return void 0;
  };
  util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
  function joinValues(array, separator = " | ") {
    return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
  }
  util2.joinValues = joinValues;
  util2.jsonStringifyReplacer = (_, value) => {
    if (typeof value === "bigint") {
      return value.toString();
    }
    return value;
  };
})(util || (util = {}));
var objectUtil;
(function(objectUtil2) {
  objectUtil2.mergeShapes = (first, second) => {
    return {
      ...first,
      ...second
      // second overwrites first
    };
  };
})(objectUtil || (objectUtil = {}));
var ZodParsedType = util.arrayToEnum([
  "string",
  "nan",
  "number",
  "integer",
  "float",
  "boolean",
  "date",
  "bigint",
  "symbol",
  "function",
  "undefined",
  "null",
  "array",
  "object",
  "unknown",
  "promise",
  "void",
  "never",
  "map",
  "set"
]);
var getParsedType = (data) => {
  const t = typeof data;
  switch (t) {
    case "undefined":
      return ZodParsedType.undefined;
    case "string":
      return ZodParsedType.string;
    case "number":
      return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
    case "boolean":
      return ZodParsedType.boolean;
    case "function":
      return ZodParsedType.function;
    case "bigint":
      return ZodParsedType.bigint;
    case "symbol":
      return ZodParsedType.symbol;
    case "object":
      if (Array.isArray(data)) {
        return ZodParsedType.array;
      }
      if (data === null) {
        return ZodParsedType.null;
      }
      if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
        return ZodParsedType.promise;
      }
      if (typeof Map !== "undefined" && data instanceof Map) {
        return ZodParsedType.map;
      }
      if (typeof Set !== "undefined" && data instanceof Set) {
        return ZodParsedType.set;
      }
      if (typeof Date !== "undefined" && data instanceof Date) {
        return ZodParsedType.date;
      }
      return ZodParsedType.object;
    default:
      return ZodParsedType.unknown;
  }
};

// node_modules/zod/v3/ZodError.js
var ZodIssueCode = util.arrayToEnum([
  "invalid_type",
  "invalid_literal",
  "custom",
  "invalid_union",
  "invalid_union_discriminator",
  "invalid_enum_value",
  "unrecognized_keys",
  "invalid_arguments",
  "invalid_return_type",
  "invalid_date",
  "invalid_string",
  "too_small",
  "too_big",
  "invalid_intersection_types",
  "not_multiple_of",
  "not_finite"
]);
var quotelessJson = (obj) => {
  const json2 = JSON.stringify(obj, null, 2);
  return json2.replace(/"([^"]+)":/g, "$1:");
};
var ZodError = class _ZodError extends Error {
  get errors() {
    return this.issues;
  }
  constructor(issues) {
    super();
    this.issues = [];
    this.addIssue = (sub) => {
      this.issues = [...this.issues, sub];
    };
    this.addIssues = (subs = []) => {
      this.issues = [...this.issues, ...subs];
    };
    const actualProto = new.target.prototype;
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(this, actualProto);
    } else {
      this.__proto__ = actualProto;
    }
    this.name = "ZodError";
    this.issues = issues;
  }
  format(_mapper) {
    const mapper = _mapper || function(issue) {
      return issue.message;
    };
    const fieldErrors = { _errors: [] };
    const processError = (error) => {
      for (const issue of error.issues) {
        if (issue.code === "invalid_union") {
          issue.unionErrors.map(processError);
        } else if (issue.code === "invalid_return_type") {
          processError(issue.returnTypeError);
        } else if (issue.code === "invalid_arguments") {
          processError(issue.argumentsError);
        } else if (issue.path.length === 0) {
          fieldErrors._errors.push(mapper(issue));
        } else {
          let curr = fieldErrors;
          let i = 0;
          while (i < issue.path.length) {
            const el = issue.path[i];
            const terminal = i === issue.path.length - 1;
            if (!terminal) {
              curr[el] = curr[el] || { _errors: [] };
            } else {
              curr[el] = curr[el] || { _errors: [] };
              curr[el]._errors.push(mapper(issue));
            }
            curr = curr[el];
            i++;
          }
        }
      }
    };
    processError(this);
    return fieldErrors;
  }
  static assert(value) {
    if (!(value instanceof _ZodError)) {
      throw new Error(`Not a ZodError: ${value}`);
    }
  }
  toString() {
    return this.message;
  }
  get message() {
    return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
  }
  get isEmpty() {
    return this.issues.length === 0;
  }
  flatten(mapper = (issue) => issue.message) {
    const fieldErrors = {};
    const formErrors = [];
    for (const sub of this.issues) {
      if (sub.path.length > 0) {
        const firstEl = sub.path[0];
        fieldErrors[firstEl] = fieldErrors[firstEl] || [];
        fieldErrors[firstEl].push(mapper(sub));
      } else {
        formErrors.push(mapper(sub));
      }
    }
    return { formErrors, fieldErrors };
  }
  get formErrors() {
    return this.flatten();
  }
};
ZodError.create = (issues) => {
  const error = new ZodError(issues);
  return error;
};

// node_modules/zod/v3/locales/en.js
var errorMap = (issue, _ctx) => {
  let message;
  switch (issue.code) {
    case ZodIssueCode.invalid_type:
      if (issue.received === ZodParsedType.undefined) {
        message = "Required";
      } else {
        message = `Expected ${issue.expected}, received ${issue.received}`;
      }
      break;
    case ZodIssueCode.invalid_literal:
      message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
      break;
    case ZodIssueCode.unrecognized_keys:
      message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
      break;
    case ZodIssueCode.invalid_union:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_union_discriminator:
      message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
      break;
    case ZodIssueCode.invalid_enum_value:
      message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
      break;
    case ZodIssueCode.invalid_arguments:
      message = `Invalid function arguments`;
      break;
    case ZodIssueCode.invalid_return_type:
      message = `Invalid function return type`;
      break;
    case ZodIssueCode.invalid_date:
      message = `Invalid date`;
      break;
    case ZodIssueCode.invalid_string:
      if (typeof issue.validation === "object") {
        if ("includes" in issue.validation) {
          message = `Invalid input: must include "${issue.validation.includes}"`;
          if (typeof issue.validation.position === "number") {
            message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
          }
        } else if ("startsWith" in issue.validation) {
          message = `Invalid input: must start with "${issue.validation.startsWith}"`;
        } else if ("endsWith" in issue.validation) {
          message = `Invalid input: must end with "${issue.validation.endsWith}"`;
        } else {
          util.assertNever(issue.validation);
        }
      } else if (issue.validation !== "regex") {
        message = `Invalid ${issue.validation}`;
      } else {
        message = "Invalid";
      }
      break;
    case ZodIssueCode.too_small:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "bigint")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.too_big:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "bigint")
        message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.custom:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_intersection_types:
      message = `Intersection results could not be merged`;
      break;
    case ZodIssueCode.not_multiple_of:
      message = `Number must be a multiple of ${issue.multipleOf}`;
      break;
    case ZodIssueCode.not_finite:
      message = "Number must be finite";
      break;
    default:
      message = _ctx.defaultError;
      util.assertNever(issue);
  }
  return { message };
};
var en_default = errorMap;

// node_modules/zod/v3/errors.js
var overrideErrorMap = en_default;
function setErrorMap(map) {
  overrideErrorMap = map;
}
function getErrorMap() {
  return overrideErrorMap;
}

// node_modules/zod/v3/helpers/parseUtil.js
var makeIssue = (params) => {
  const { data, path: path2, errorMaps, issueData } = params;
  const fullPath = [...path2, ...issueData.path || []];
  const fullIssue = {
    ...issueData,
    path: fullPath
  };
  if (issueData.message !== void 0) {
    return {
      ...issueData,
      path: fullPath,
      message: issueData.message
    };
  }
  let errorMessage = "";
  const maps = errorMaps.filter((m) => !!m).slice().reverse();
  for (const map of maps) {
    errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
  }
  return {
    ...issueData,
    path: fullPath,
    message: errorMessage
  };
};
var EMPTY_PATH = [];
function addIssueToContext(ctx, issueData) {
  const overrideMap = getErrorMap();
  const issue = makeIssue({
    issueData,
    data: ctx.data,
    path: ctx.path,
    errorMaps: [
      ctx.common.contextualErrorMap,
      // contextual error map is first priority
      ctx.schemaErrorMap,
      // then schema-bound map if available
      overrideMap,
      // then global override map
      overrideMap === en_default ? void 0 : en_default
      // then global default map
    ].filter((x) => !!x)
  });
  ctx.common.issues.push(issue);
}
var ParseStatus = class _ParseStatus {
  constructor() {
    this.value = "valid";
  }
  dirty() {
    if (this.value === "valid")
      this.value = "dirty";
  }
  abort() {
    if (this.value !== "aborted")
      this.value = "aborted";
  }
  static mergeArray(status, results) {
    const arrayValue = [];
    for (const s of results) {
      if (s.status === "aborted")
        return INVALID;
      if (s.status === "dirty")
        status.dirty();
      arrayValue.push(s.value);
    }
    return { status: status.value, value: arrayValue };
  }
  static async mergeObjectAsync(status, pairs) {
    const syncPairs = [];
    for (const pair of pairs) {
      const key = await pair.key;
      const value = await pair.value;
      syncPairs.push({
        key,
        value
      });
    }
    return _ParseStatus.mergeObjectSync(status, syncPairs);
  }
  static mergeObjectSync(status, pairs) {
    const finalObject = {};
    for (const pair of pairs) {
      const { key, value } = pair;
      if (key.status === "aborted")
        return INVALID;
      if (value.status === "aborted")
        return INVALID;
      if (key.status === "dirty")
        status.dirty();
      if (value.status === "dirty")
        status.dirty();
      if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
        finalObject[key.value] = value.value;
      }
    }
    return { status: status.value, value: finalObject };
  }
};
var INVALID = Object.freeze({
  status: "aborted"
});
var DIRTY = (value) => ({ status: "dirty", value });
var OK = (value) => ({ status: "valid", value });
var isAborted = (x) => x.status === "aborted";
var isDirty = (x) => x.status === "dirty";
var isValid = (x) => x.status === "valid";
var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

// node_modules/zod/v3/helpers/errorUtil.js
var errorUtil;
(function(errorUtil2) {
  errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
  errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
})(errorUtil || (errorUtil = {}));

// node_modules/zod/v3/types.js
var ParseInputLazyPath = class {
  constructor(parent, value, path2, key) {
    this._cachedPath = [];
    this.parent = parent;
    this.data = value;
    this._path = path2;
    this._key = key;
  }
  get path() {
    if (!this._cachedPath.length) {
      if (Array.isArray(this._key)) {
        this._cachedPath.push(...this._path, ...this._key);
      } else {
        this._cachedPath.push(...this._path, this._key);
      }
    }
    return this._cachedPath;
  }
};
var handleResult = (ctx, result) => {
  if (isValid(result)) {
    return { success: true, data: result.value };
  } else {
    if (!ctx.common.issues.length) {
      throw new Error("Validation failed but no issues detected.");
    }
    return {
      success: false,
      get error() {
        if (this._error)
          return this._error;
        const error = new ZodError(ctx.common.issues);
        this._error = error;
        return this._error;
      }
    };
  }
};
function processCreateParams(params) {
  if (!params)
    return {};
  const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
  if (errorMap2 && (invalid_type_error || required_error)) {
    throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
  }
  if (errorMap2)
    return { errorMap: errorMap2, description };
  const customMap = (iss, ctx) => {
    const { message } = params;
    if (iss.code === "invalid_enum_value") {
      return { message: message ?? ctx.defaultError };
    }
    if (typeof ctx.data === "undefined") {
      return { message: message ?? required_error ?? ctx.defaultError };
    }
    if (iss.code !== "invalid_type")
      return { message: ctx.defaultError };
    return { message: message ?? invalid_type_error ?? ctx.defaultError };
  };
  return { errorMap: customMap, description };
}
var ZodType = class {
  get description() {
    return this._def.description;
  }
  _getType(input) {
    return getParsedType(input.data);
  }
  _getOrReturnCtx(input, ctx) {
    return ctx || {
      common: input.parent.common,
      data: input.data,
      parsedType: getParsedType(input.data),
      schemaErrorMap: this._def.errorMap,
      path: input.path,
      parent: input.parent
    };
  }
  _processInputParams(input) {
    return {
      status: new ParseStatus(),
      ctx: {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      }
    };
  }
  _parseSync(input) {
    const result = this._parse(input);
    if (isAsync(result)) {
      throw new Error("Synchronous parse encountered promise.");
    }
    return result;
  }
  _parseAsync(input) {
    const result = this._parse(input);
    return Promise.resolve(result);
  }
  parse(data, params) {
    const result = this.safeParse(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  safeParse(data, params) {
    const ctx = {
      common: {
        issues: [],
        async: params?.async ?? false,
        contextualErrorMap: params?.errorMap
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const result = this._parseSync({ data, path: ctx.path, parent: ctx });
    return handleResult(ctx, result);
  }
  "~validate"(data) {
    const ctx = {
      common: {
        issues: [],
        async: !!this["~standard"].async
      },
      path: [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    if (!this["~standard"].async) {
      try {
        const result = this._parseSync({ data, path: [], parent: ctx });
        return isValid(result) ? {
          value: result.value
        } : {
          issues: ctx.common.issues
        };
      } catch (err) {
        if (err?.message?.toLowerCase()?.includes("encountered")) {
          this["~standard"].async = true;
        }
        ctx.common = {
          issues: [],
          async: true
        };
      }
    }
    return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
      value: result.value
    } : {
      issues: ctx.common.issues
    });
  }
  async parseAsync(data, params) {
    const result = await this.safeParseAsync(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  async safeParseAsync(data, params) {
    const ctx = {
      common: {
        issues: [],
        contextualErrorMap: params?.errorMap,
        async: true
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
    const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
    return handleResult(ctx, result);
  }
  refine(check, message) {
    const getIssueProperties = (val) => {
      if (typeof message === "string" || typeof message === "undefined") {
        return { message };
      } else if (typeof message === "function") {
        return message(val);
      } else {
        return message;
      }
    };
    return this._refinement((val, ctx) => {
      const result = check(val);
      const setError = () => ctx.addIssue({
        code: ZodIssueCode.custom,
        ...getIssueProperties(val)
      });
      if (typeof Promise !== "undefined" && result instanceof Promise) {
        return result.then((data) => {
          if (!data) {
            setError();
            return false;
          } else {
            return true;
          }
        });
      }
      if (!result) {
        setError();
        return false;
      } else {
        return true;
      }
    });
  }
  refinement(check, refinementData) {
    return this._refinement((val, ctx) => {
      if (!check(val)) {
        ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
        return false;
      } else {
        return true;
      }
    });
  }
  _refinement(refinement) {
    return new ZodEffects({
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "refinement", refinement }
    });
  }
  superRefine(refinement) {
    return this._refinement(refinement);
  }
  constructor(def) {
    this.spa = this.safeParseAsync;
    this._def = def;
    this.parse = this.parse.bind(this);
    this.safeParse = this.safeParse.bind(this);
    this.parseAsync = this.parseAsync.bind(this);
    this.safeParseAsync = this.safeParseAsync.bind(this);
    this.spa = this.spa.bind(this);
    this.refine = this.refine.bind(this);
    this.refinement = this.refinement.bind(this);
    this.superRefine = this.superRefine.bind(this);
    this.optional = this.optional.bind(this);
    this.nullable = this.nullable.bind(this);
    this.nullish = this.nullish.bind(this);
    this.array = this.array.bind(this);
    this.promise = this.promise.bind(this);
    this.or = this.or.bind(this);
    this.and = this.and.bind(this);
    this.transform = this.transform.bind(this);
    this.brand = this.brand.bind(this);
    this.default = this.default.bind(this);
    this.catch = this.catch.bind(this);
    this.describe = this.describe.bind(this);
    this.pipe = this.pipe.bind(this);
    this.readonly = this.readonly.bind(this);
    this.isNullable = this.isNullable.bind(this);
    this.isOptional = this.isOptional.bind(this);
    this["~standard"] = {
      version: 1,
      vendor: "zod",
      validate: (data) => this["~validate"](data)
    };
  }
  optional() {
    return ZodOptional.create(this, this._def);
  }
  nullable() {
    return ZodNullable.create(this, this._def);
  }
  nullish() {
    return this.nullable().optional();
  }
  array() {
    return ZodArray.create(this);
  }
  promise() {
    return ZodPromise.create(this, this._def);
  }
  or(option) {
    return ZodUnion.create([this, option], this._def);
  }
  and(incoming) {
    return ZodIntersection.create(this, incoming, this._def);
  }
  transform(transform) {
    return new ZodEffects({
      ...processCreateParams(this._def),
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "transform", transform }
    });
  }
  default(def) {
    const defaultValueFunc = typeof def === "function" ? def : () => def;
    return new ZodDefault({
      ...processCreateParams(this._def),
      innerType: this,
      defaultValue: defaultValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodDefault
    });
  }
  brand() {
    return new ZodBranded({
      typeName: ZodFirstPartyTypeKind.ZodBranded,
      type: this,
      ...processCreateParams(this._def)
    });
  }
  catch(def) {
    const catchValueFunc = typeof def === "function" ? def : () => def;
    return new ZodCatch({
      ...processCreateParams(this._def),
      innerType: this,
      catchValue: catchValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodCatch
    });
  }
  describe(description) {
    const This = this.constructor;
    return new This({
      ...this._def,
      description
    });
  }
  pipe(target) {
    return ZodPipeline.create(this, target);
  }
  readonly() {
    return ZodReadonly.create(this);
  }
  isOptional() {
    return this.safeParse(void 0).success;
  }
  isNullable() {
    return this.safeParse(null).success;
  }
};
var cuidRegex = /^c[^\s-]{8,}$/i;
var cuid2Regex = /^[0-9a-z]+$/;
var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
var nanoidRegex = /^[a-z0-9_-]{21}$/i;
var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
var emojiRegex;
var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
var dateRegex = new RegExp(`^${dateRegexSource}$`);
function timeRegexSource(args) {
  let secondsRegexSource = `[0-5]\\d`;
  if (args.precision) {
    secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
  } else if (args.precision == null) {
    secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
  }
  const secondsQuantifier = args.precision ? "+" : "?";
  return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
}
function timeRegex(args) {
  return new RegExp(`^${timeRegexSource(args)}$`);
}
function datetimeRegex(args) {
  let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
  const opts = [];
  opts.push(args.local ? `Z?` : `Z`);
  if (args.offset)
    opts.push(`([+-]\\d{2}:?\\d{2})`);
  regex = `${regex}(${opts.join("|")})`;
  return new RegExp(`^${regex}$`);
}
function isValidIP(ip, version) {
  if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
    return true;
  }
  return false;
}
function isValidJWT(jwt, alg) {
  if (!jwtRegex.test(jwt))
    return false;
  try {
    const [header] = jwt.split(".");
    if (!header)
      return false;
    const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
    const decoded = JSON.parse(atob(base64));
    if (typeof decoded !== "object" || decoded === null)
      return false;
    if ("typ" in decoded && decoded?.typ !== "JWT")
      return false;
    if (!decoded.alg)
      return false;
    if (alg && decoded.alg !== alg)
      return false;
    return true;
  } catch {
    return false;
  }
}
function isValidCidr(ip, version) {
  if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
    return true;
  }
  return false;
}
var ZodString = class _ZodString extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = String(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.string) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.string,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.length < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.length > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "length") {
        const tooBig = input.data.length > check.value;
        const tooSmall = input.data.length < check.value;
        if (tooBig || tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          if (tooBig) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          } else if (tooSmall) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          }
          status.dirty();
        }
      } else if (check.kind === "email") {
        if (!emailRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "email",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "emoji") {
        if (!emojiRegex) {
          emojiRegex = new RegExp(_emojiRegex, "u");
        }
        if (!emojiRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "emoji",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "uuid") {
        if (!uuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "uuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "nanoid") {
        if (!nanoidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "nanoid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid") {
        if (!cuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid2") {
        if (!cuid2Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid2",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ulid") {
        if (!ulidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ulid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "url") {
        try {
          new URL(input.data);
        } catch {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "regex") {
        check.regex.lastIndex = 0;
        const testResult = check.regex.test(input.data);
        if (!testResult) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "regex",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "trim") {
        input.data = input.data.trim();
      } else if (check.kind === "includes") {
        if (!input.data.includes(check.value, check.position)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { includes: check.value, position: check.position },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "toLowerCase") {
        input.data = input.data.toLowerCase();
      } else if (check.kind === "toUpperCase") {
        input.data = input.data.toUpperCase();
      } else if (check.kind === "startsWith") {
        if (!input.data.startsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { startsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "endsWith") {
        if (!input.data.endsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { endsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "datetime") {
        const regex = datetimeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "datetime",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "date") {
        const regex = dateRegex;
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "date",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "time") {
        const regex = timeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "time",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "duration") {
        if (!durationRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "duration",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ip") {
        if (!isValidIP(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ip",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "jwt") {
        if (!isValidJWT(input.data, check.alg)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "jwt",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cidr") {
        if (!isValidCidr(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cidr",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64") {
        if (!base64Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64url") {
        if (!base64urlRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _regex(regex, validation, message) {
    return this.refinement((data) => regex.test(data), {
      validation,
      code: ZodIssueCode.invalid_string,
      ...errorUtil.errToObj(message)
    });
  }
  _addCheck(check) {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  email(message) {
    return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
  }
  url(message) {
    return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
  }
  emoji(message) {
    return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
  }
  uuid(message) {
    return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
  }
  nanoid(message) {
    return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
  }
  cuid(message) {
    return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
  }
  cuid2(message) {
    return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
  }
  ulid(message) {
    return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
  }
  base64(message) {
    return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
  }
  base64url(message) {
    return this._addCheck({
      kind: "base64url",
      ...errorUtil.errToObj(message)
    });
  }
  jwt(options) {
    return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
  }
  ip(options) {
    return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
  }
  cidr(options) {
    return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
  }
  datetime(options) {
    if (typeof options === "string") {
      return this._addCheck({
        kind: "datetime",
        precision: null,
        offset: false,
        local: false,
        message: options
      });
    }
    return this._addCheck({
      kind: "datetime",
      precision: typeof options?.precision === "undefined" ? null : options?.precision,
      offset: options?.offset ?? false,
      local: options?.local ?? false,
      ...errorUtil.errToObj(options?.message)
    });
  }
  date(message) {
    return this._addCheck({ kind: "date", message });
  }
  time(options) {
    if (typeof options === "string") {
      return this._addCheck({
        kind: "time",
        precision: null,
        message: options
      });
    }
    return this._addCheck({
      kind: "time",
      precision: typeof options?.precision === "undefined" ? null : options?.precision,
      ...errorUtil.errToObj(options?.message)
    });
  }
  duration(message) {
    return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
  }
  regex(regex, message) {
    return this._addCheck({
      kind: "regex",
      regex,
      ...errorUtil.errToObj(message)
    });
  }
  includes(value, options) {
    return this._addCheck({
      kind: "includes",
      value,
      position: options?.position,
      ...errorUtil.errToObj(options?.message)
    });
  }
  startsWith(value, message) {
    return this._addCheck({
      kind: "startsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  endsWith(value, message) {
    return this._addCheck({
      kind: "endsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  min(minLength, message) {
    return this._addCheck({
      kind: "min",
      value: minLength,
      ...errorUtil.errToObj(message)
    });
  }
  max(maxLength, message) {
    return this._addCheck({
      kind: "max",
      value: maxLength,
      ...errorUtil.errToObj(message)
    });
  }
  length(len, message) {
    return this._addCheck({
      kind: "length",
      value: len,
      ...errorUtil.errToObj(message)
    });
  }
  /**
   * Equivalent to `.min(1)`
   */
  nonempty(message) {
    return this.min(1, errorUtil.errToObj(message));
  }
  trim() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "trim" }]
    });
  }
  toLowerCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toLowerCase" }]
    });
  }
  toUpperCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toUpperCase" }]
    });
  }
  get isDatetime() {
    return !!this._def.checks.find((ch) => ch.kind === "datetime");
  }
  get isDate() {
    return !!this._def.checks.find((ch) => ch.kind === "date");
  }
  get isTime() {
    return !!this._def.checks.find((ch) => ch.kind === "time");
  }
  get isDuration() {
    return !!this._def.checks.find((ch) => ch.kind === "duration");
  }
  get isEmail() {
    return !!this._def.checks.find((ch) => ch.kind === "email");
  }
  get isURL() {
    return !!this._def.checks.find((ch) => ch.kind === "url");
  }
  get isEmoji() {
    return !!this._def.checks.find((ch) => ch.kind === "emoji");
  }
  get isUUID() {
    return !!this._def.checks.find((ch) => ch.kind === "uuid");
  }
  get isNANOID() {
    return !!this._def.checks.find((ch) => ch.kind === "nanoid");
  }
  get isCUID() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid");
  }
  get isCUID2() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid2");
  }
  get isULID() {
    return !!this._def.checks.find((ch) => ch.kind === "ulid");
  }
  get isIP() {
    return !!this._def.checks.find((ch) => ch.kind === "ip");
  }
  get isCIDR() {
    return !!this._def.checks.find((ch) => ch.kind === "cidr");
  }
  get isBase64() {
    return !!this._def.checks.find((ch) => ch.kind === "base64");
  }
  get isBase64url() {
    return !!this._def.checks.find((ch) => ch.kind === "base64url");
  }
  get minLength() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxLength() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodString.create = (params) => {
  return new ZodString({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodString,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
function floatSafeRemainder(val, step) {
  const valDecCount = (val.toString().split(".")[1] || "").length;
  const stepDecCount = (step.toString().split(".")[1] || "").length;
  const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
  const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
  const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
  return valInt % stepInt / 10 ** decCount;
}
var ZodNumber = class _ZodNumber extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
    this.step = this.multipleOf;
  }
  _parse(input) {
    if (this._def.coerce) {
      input.data = Number(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.number) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.number,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "int") {
        if (!util.isInteger(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: "integer",
            received: "float",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (floatSafeRemainder(input.data, check.value) !== 0) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "finite") {
        if (!Number.isFinite(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_finite,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodNumber({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodNumber({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  int(message) {
    return this._addCheck({
      kind: "int",
      message: errorUtil.toString(message)
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  finite(message) {
    return this._addCheck({
      kind: "finite",
      message: errorUtil.toString(message)
    });
  }
  safe(message) {
    return this._addCheck({
      kind: "min",
      inclusive: true,
      value: Number.MIN_SAFE_INTEGER,
      message: errorUtil.toString(message)
    })._addCheck({
      kind: "max",
      inclusive: true,
      value: Number.MAX_SAFE_INTEGER,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
  get isInt() {
    return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
  }
  get isFinite() {
    let max = null;
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
        return true;
      } else if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      } else if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return Number.isFinite(min) && Number.isFinite(max);
  }
};
ZodNumber.create = (params) => {
  return new ZodNumber({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodNumber,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodBigInt = class _ZodBigInt extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
  }
  _parse(input) {
    if (this._def.coerce) {
      try {
        input.data = BigInt(input.data);
      } catch {
        return this._getInvalidInput(input);
      }
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.bigint) {
      return this._getInvalidInput(input);
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            type: "bigint",
            minimum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            type: "bigint",
            maximum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (input.data % check.value !== BigInt(0)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _getInvalidInput(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.bigint,
      received: ctx.parsedType
    });
    return INVALID;
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodBigInt({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodBigInt({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodBigInt.create = (params) => {
  return new ZodBigInt({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodBigInt,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
var ZodBoolean = class extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = Boolean(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.boolean) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.boolean,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodBoolean.create = (params) => {
  return new ZodBoolean({
    typeName: ZodFirstPartyTypeKind.ZodBoolean,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodDate = class _ZodDate extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = new Date(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.date) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.date,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    if (Number.isNaN(input.data.getTime())) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_date
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.getTime() < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            message: check.message,
            inclusive: true,
            exact: false,
            minimum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.getTime() > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            message: check.message,
            inclusive: true,
            exact: false,
            maximum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return {
      status: status.value,
      value: new Date(input.data.getTime())
    };
  }
  _addCheck(check) {
    return new _ZodDate({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  min(minDate, message) {
    return this._addCheck({
      kind: "min",
      value: minDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  max(maxDate, message) {
    return this._addCheck({
      kind: "max",
      value: maxDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  get minDate() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min != null ? new Date(min) : null;
  }
  get maxDate() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max != null ? new Date(max) : null;
  }
};
ZodDate.create = (params) => {
  return new ZodDate({
    checks: [],
    coerce: params?.coerce || false,
    typeName: ZodFirstPartyTypeKind.ZodDate,
    ...processCreateParams(params)
  });
};
var ZodSymbol = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.symbol) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.symbol,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodSymbol.create = (params) => {
  return new ZodSymbol({
    typeName: ZodFirstPartyTypeKind.ZodSymbol,
    ...processCreateParams(params)
  });
};
var ZodUndefined = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.undefined,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodUndefined.create = (params) => {
  return new ZodUndefined({
    typeName: ZodFirstPartyTypeKind.ZodUndefined,
    ...processCreateParams(params)
  });
};
var ZodNull = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.null) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.null,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodNull.create = (params) => {
  return new ZodNull({
    typeName: ZodFirstPartyTypeKind.ZodNull,
    ...processCreateParams(params)
  });
};
var ZodAny = class extends ZodType {
  constructor() {
    super(...arguments);
    this._any = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodAny.create = (params) => {
  return new ZodAny({
    typeName: ZodFirstPartyTypeKind.ZodAny,
    ...processCreateParams(params)
  });
};
var ZodUnknown = class extends ZodType {
  constructor() {
    super(...arguments);
    this._unknown = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodUnknown.create = (params) => {
  return new ZodUnknown({
    typeName: ZodFirstPartyTypeKind.ZodUnknown,
    ...processCreateParams(params)
  });
};
var ZodNever = class extends ZodType {
  _parse(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.never,
      received: ctx.parsedType
    });
    return INVALID;
  }
};
ZodNever.create = (params) => {
  return new ZodNever({
    typeName: ZodFirstPartyTypeKind.ZodNever,
    ...processCreateParams(params)
  });
};
var ZodVoid = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.void,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodVoid.create = (params) => {
  return new ZodVoid({
    typeName: ZodFirstPartyTypeKind.ZodVoid,
    ...processCreateParams(params)
  });
};
var ZodArray = class _ZodArray extends ZodType {
  _parse(input) {
    const { ctx, status } = this._processInputParams(input);
    const def = this._def;
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (def.exactLength !== null) {
      const tooBig = ctx.data.length > def.exactLength.value;
      const tooSmall = ctx.data.length < def.exactLength.value;
      if (tooBig || tooSmall) {
        addIssueToContext(ctx, {
          code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
          minimum: tooSmall ? def.exactLength.value : void 0,
          maximum: tooBig ? def.exactLength.value : void 0,
          type: "array",
          inclusive: true,
          exact: true,
          message: def.exactLength.message
        });
        status.dirty();
      }
    }
    if (def.minLength !== null) {
      if (ctx.data.length < def.minLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.minLength.message
        });
        status.dirty();
      }
    }
    if (def.maxLength !== null) {
      if (ctx.data.length > def.maxLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.maxLength.message
        });
        status.dirty();
      }
    }
    if (ctx.common.async) {
      return Promise.all([...ctx.data].map((item, i) => {
        return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      })).then((result2) => {
        return ParseStatus.mergeArray(status, result2);
      });
    }
    const result = [...ctx.data].map((item, i) => {
      return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
    });
    return ParseStatus.mergeArray(status, result);
  }
  get element() {
    return this._def.type;
  }
  min(minLength, message) {
    return new _ZodArray({
      ...this._def,
      minLength: { value: minLength, message: errorUtil.toString(message) }
    });
  }
  max(maxLength, message) {
    return new _ZodArray({
      ...this._def,
      maxLength: { value: maxLength, message: errorUtil.toString(message) }
    });
  }
  length(len, message) {
    return new _ZodArray({
      ...this._def,
      exactLength: { value: len, message: errorUtil.toString(message) }
    });
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodArray.create = (schema, params) => {
  return new ZodArray({
    type: schema,
    minLength: null,
    maxLength: null,
    exactLength: null,
    typeName: ZodFirstPartyTypeKind.ZodArray,
    ...processCreateParams(params)
  });
};
function deepPartialify(schema) {
  if (schema instanceof ZodObject) {
    const newShape = {};
    for (const key in schema.shape) {
      const fieldSchema = schema.shape[key];
      newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
    }
    return new ZodObject({
      ...schema._def,
      shape: () => newShape
    });
  } else if (schema instanceof ZodArray) {
    return new ZodArray({
      ...schema._def,
      type: deepPartialify(schema.element)
    });
  } else if (schema instanceof ZodOptional) {
    return ZodOptional.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodNullable) {
    return ZodNullable.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodTuple) {
    return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
  } else {
    return schema;
  }
}
var ZodObject = class _ZodObject extends ZodType {
  constructor() {
    super(...arguments);
    this._cached = null;
    this.nonstrict = this.passthrough;
    this.augment = this.extend;
  }
  _getCached() {
    if (this._cached !== null)
      return this._cached;
    const shape = this._def.shape();
    const keys = util.objectKeys(shape);
    this._cached = { shape, keys };
    return this._cached;
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.object) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const { status, ctx } = this._processInputParams(input);
    const { shape, keys: shapeKeys } = this._getCached();
    const extraKeys = [];
    if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
      for (const key in ctx.data) {
        if (!shapeKeys.includes(key)) {
          extraKeys.push(key);
        }
      }
    }
    const pairs = [];
    for (const key of shapeKeys) {
      const keyValidator = shape[key];
      const value = ctx.data[key];
      pairs.push({
        key: { status: "valid", value: key },
        value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (this._def.catchall instanceof ZodNever) {
      const unknownKeys = this._def.unknownKeys;
      if (unknownKeys === "passthrough") {
        for (const key of extraKeys) {
          pairs.push({
            key: { status: "valid", value: key },
            value: { status: "valid", value: ctx.data[key] }
          });
        }
      } else if (unknownKeys === "strict") {
        if (extraKeys.length > 0) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.unrecognized_keys,
            keys: extraKeys
          });
          status.dirty();
        }
      } else if (unknownKeys === "strip") {
      } else {
        throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
      }
    } else {
      const catchall = this._def.catchall;
      for (const key of extraKeys) {
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: catchall._parse(
            new ParseInputLazyPath(ctx, value, ctx.path, key)
            //, ctx.child(key), value, getParsedType(value)
          ),
          alwaysSet: key in ctx.data
        });
      }
    }
    if (ctx.common.async) {
      return Promise.resolve().then(async () => {
        const syncPairs = [];
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          syncPairs.push({
            key,
            value,
            alwaysSet: pair.alwaysSet
          });
        }
        return syncPairs;
      }).then((syncPairs) => {
        return ParseStatus.mergeObjectSync(status, syncPairs);
      });
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get shape() {
    return this._def.shape();
  }
  strict(message) {
    errorUtil.errToObj;
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strict",
      ...message !== void 0 ? {
        errorMap: (issue, ctx) => {
          const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
          if (issue.code === "unrecognized_keys")
            return {
              message: errorUtil.errToObj(message).message ?? defaultError
            };
          return {
            message: defaultError
          };
        }
      } : {}
    });
  }
  strip() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strip"
    });
  }
  passthrough() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "passthrough"
    });
  }
  // const AugmentFactory =
  //   <Def extends ZodObjectDef>(def: Def) =>
  //   <Augmentation extends ZodRawShape>(
  //     augmentation: Augmentation
  //   ): ZodObject<
  //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
  //     Def["unknownKeys"],
  //     Def["catchall"]
  //   > => {
  //     return new ZodObject({
  //       ...def,
  //       shape: () => ({
  //         ...def.shape(),
  //         ...augmentation,
  //       }),
  //     }) as any;
  //   };
  extend(augmentation) {
    return new _ZodObject({
      ...this._def,
      shape: () => ({
        ...this._def.shape(),
        ...augmentation
      })
    });
  }
  /**
   * Prior to zod@1.0.12 there was a bug in the
   * inferred type of merged objects. Please
   * upgrade if you are experiencing issues.
   */
  merge(merging) {
    const merged = new _ZodObject({
      unknownKeys: merging._def.unknownKeys,
      catchall: merging._def.catchall,
      shape: () => ({
        ...this._def.shape(),
        ...merging._def.shape()
      }),
      typeName: ZodFirstPartyTypeKind.ZodObject
    });
    return merged;
  }
  // merge<
  //   Incoming extends AnyZodObject,
  //   Augmentation extends Incoming["shape"],
  //   NewOutput extends {
  //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
  //       ? Augmentation[k]["_output"]
  //       : k extends keyof Output
  //       ? Output[k]
  //       : never;
  //   },
  //   NewInput extends {
  //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
  //       ? Augmentation[k]["_input"]
  //       : k extends keyof Input
  //       ? Input[k]
  //       : never;
  //   }
  // >(
  //   merging: Incoming
  // ): ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"],
  //   NewOutput,
  //   NewInput
  // > {
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  setKey(key, schema) {
    return this.augment({ [key]: schema });
  }
  // merge<Incoming extends AnyZodObject>(
  //   merging: Incoming
  // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
  // ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"]
  // > {
  //   // const mergedShape = objectUtil.mergeShapes(
  //   //   this._def.shape(),
  //   //   merging._def.shape()
  //   // );
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  catchall(index) {
    return new _ZodObject({
      ...this._def,
      catchall: index
    });
  }
  pick(mask) {
    const shape = {};
    for (const key of util.objectKeys(mask)) {
      if (mask[key] && this.shape[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  omit(mask) {
    const shape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (!mask[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  /**
   * @deprecated
   */
  deepPartial() {
    return deepPartialify(this);
  }
  partial(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      const fieldSchema = this.shape[key];
      if (mask && !mask[key]) {
        newShape[key] = fieldSchema;
      } else {
        newShape[key] = fieldSchema.optional();
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  required(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (mask && !mask[key]) {
        newShape[key] = this.shape[key];
      } else {
        const fieldSchema = this.shape[key];
        let newField = fieldSchema;
        while (newField instanceof ZodOptional) {
          newField = newField._def.innerType;
        }
        newShape[key] = newField;
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  keyof() {
    return createZodEnum(util.objectKeys(this.shape));
  }
};
ZodObject.create = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.strictCreate = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strict",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.lazycreate = (shape, params) => {
  return new ZodObject({
    shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
var ZodUnion = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const options = this._def.options;
    function handleResults(results) {
      for (const result of results) {
        if (result.result.status === "valid") {
          return result.result;
        }
      }
      for (const result of results) {
        if (result.result.status === "dirty") {
          ctx.common.issues.push(...result.ctx.common.issues);
          return result.result;
        }
      }
      const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return Promise.all(options.map(async (option) => {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        return {
          result: await option._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          }),
          ctx: childCtx
        };
      })).then(handleResults);
    } else {
      let dirty = void 0;
      const issues = [];
      for (const option of options) {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        const result = option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: childCtx
        });
        if (result.status === "valid") {
          return result;
        } else if (result.status === "dirty" && !dirty) {
          dirty = { result, ctx: childCtx };
        }
        if (childCtx.common.issues.length) {
          issues.push(childCtx.common.issues);
        }
      }
      if (dirty) {
        ctx.common.issues.push(...dirty.ctx.common.issues);
        return dirty.result;
      }
      const unionErrors = issues.map((issues2) => new ZodError(issues2));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
  }
  get options() {
    return this._def.options;
  }
};
ZodUnion.create = (types, params) => {
  return new ZodUnion({
    options: types,
    typeName: ZodFirstPartyTypeKind.ZodUnion,
    ...processCreateParams(params)
  });
};
var getDiscriminator = (type) => {
  if (type instanceof ZodLazy) {
    return getDiscriminator(type.schema);
  } else if (type instanceof ZodEffects) {
    return getDiscriminator(type.innerType());
  } else if (type instanceof ZodLiteral) {
    return [type.value];
  } else if (type instanceof ZodEnum) {
    return type.options;
  } else if (type instanceof ZodNativeEnum) {
    return util.objectValues(type.enum);
  } else if (type instanceof ZodDefault) {
    return getDiscriminator(type._def.innerType);
  } else if (type instanceof ZodUndefined) {
    return [void 0];
  } else if (type instanceof ZodNull) {
    return [null];
  } else if (type instanceof ZodOptional) {
    return [void 0, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodNullable) {
    return [null, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodBranded) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodReadonly) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodCatch) {
    return getDiscriminator(type._def.innerType);
  } else {
    return [];
  }
};
var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const discriminator = this.discriminator;
    const discriminatorValue = ctx.data[discriminator];
    const option = this.optionsMap.get(discriminatorValue);
    if (!option) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union_discriminator,
        options: Array.from(this.optionsMap.keys()),
        path: [discriminator]
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return option._parseAsync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    } else {
      return option._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    }
  }
  get discriminator() {
    return this._def.discriminator;
  }
  get options() {
    return this._def.options;
  }
  get optionsMap() {
    return this._def.optionsMap;
  }
  /**
   * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
   * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
   * have a different value for each object in the union.
   * @param discriminator the name of the discriminator property
   * @param types an array of object schemas
   * @param params
   */
  static create(discriminator, options, params) {
    const optionsMap = /* @__PURE__ */ new Map();
    for (const type of options) {
      const discriminatorValues = getDiscriminator(type.shape[discriminator]);
      if (!discriminatorValues.length) {
        throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
      }
      for (const value of discriminatorValues) {
        if (optionsMap.has(value)) {
          throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
        }
        optionsMap.set(value, type);
      }
    }
    return new _ZodDiscriminatedUnion({
      typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
      discriminator,
      options,
      optionsMap,
      ...processCreateParams(params)
    });
  }
};
function mergeValues(a, b) {
  const aType = getParsedType(a);
  const bType = getParsedType(b);
  if (a === b) {
    return { valid: true, data: a };
  } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
    const bKeys = util.objectKeys(b);
    const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
    const newObj = { ...a, ...b };
    for (const key of sharedKeys) {
      const sharedValue = mergeValues(a[key], b[key]);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newObj[key] = sharedValue.data;
    }
    return { valid: true, data: newObj };
  } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
    if (a.length !== b.length) {
      return { valid: false };
    }
    const newArray = [];
    for (let index = 0; index < a.length; index++) {
      const itemA = a[index];
      const itemB = b[index];
      const sharedValue = mergeValues(itemA, itemB);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newArray.push(sharedValue.data);
    }
    return { valid: true, data: newArray };
  } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
    return { valid: true, data: a };
  } else {
    return { valid: false };
  }
}
var ZodIntersection = class extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const handleParsed = (parsedLeft, parsedRight) => {
      if (isAborted(parsedLeft) || isAborted(parsedRight)) {
        return INVALID;
      }
      const merged = mergeValues(parsedLeft.value, parsedRight.value);
      if (!merged.valid) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_intersection_types
        });
        return INVALID;
      }
      if (isDirty(parsedLeft) || isDirty(parsedRight)) {
        status.dirty();
      }
      return { status: status.value, value: merged.data };
    };
    if (ctx.common.async) {
      return Promise.all([
        this._def.left._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }),
        this._def.right._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        })
      ]).then(([left, right]) => handleParsed(left, right));
    } else {
      return handleParsed(this._def.left._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }), this._def.right._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }));
    }
  }
};
ZodIntersection.create = (left, right, params) => {
  return new ZodIntersection({
    left,
    right,
    typeName: ZodFirstPartyTypeKind.ZodIntersection,
    ...processCreateParams(params)
  });
};
var ZodTuple = class _ZodTuple extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (ctx.data.length < this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_small,
        minimum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      return INVALID;
    }
    const rest = this._def.rest;
    if (!rest && ctx.data.length > this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_big,
        maximum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      status.dirty();
    }
    const items = [...ctx.data].map((item, itemIndex) => {
      const schema = this._def.items[itemIndex] || this._def.rest;
      if (!schema)
        return null;
      return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
    }).filter((x) => !!x);
    if (ctx.common.async) {
      return Promise.all(items).then((results) => {
        return ParseStatus.mergeArray(status, results);
      });
    } else {
      return ParseStatus.mergeArray(status, items);
    }
  }
  get items() {
    return this._def.items;
  }
  rest(rest) {
    return new _ZodTuple({
      ...this._def,
      rest
    });
  }
};
ZodTuple.create = (schemas, params) => {
  if (!Array.isArray(schemas)) {
    throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
  }
  return new ZodTuple({
    items: schemas,
    typeName: ZodFirstPartyTypeKind.ZodTuple,
    rest: null,
    ...processCreateParams(params)
  });
};
var ZodRecord = class _ZodRecord extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const pairs = [];
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    for (const key in ctx.data) {
      pairs.push({
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
        value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (ctx.common.async) {
      return ParseStatus.mergeObjectAsync(status, pairs);
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get element() {
    return this._def.valueType;
  }
  static create(first, second, third) {
    if (second instanceof ZodType) {
      return new _ZodRecord({
        keyType: first,
        valueType: second,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(third)
      });
    }
    return new _ZodRecord({
      keyType: ZodString.create(),
      valueType: first,
      typeName: ZodFirstPartyTypeKind.ZodRecord,
      ...processCreateParams(second)
    });
  }
};
var ZodMap = class extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.map) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.map,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    const pairs = [...ctx.data.entries()].map(([key, value], index) => {
      return {
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
        value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
      };
    });
    if (ctx.common.async) {
      const finalMap = /* @__PURE__ */ new Map();
      return Promise.resolve().then(async () => {
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status.value, value: finalMap };
      });
    } else {
      const finalMap = /* @__PURE__ */ new Map();
      for (const pair of pairs) {
        const key = pair.key;
        const value = pair.value;
        if (key.status === "aborted" || value.status === "aborted") {
          return INVALID;
        }
        if (key.status === "dirty" || value.status === "dirty") {
          status.dirty();
        }
        finalMap.set(key.value, value.value);
      }
      return { status: status.value, value: finalMap };
    }
  }
};
ZodMap.create = (keyType, valueType, params) => {
  return new ZodMap({
    valueType,
    keyType,
    typeName: ZodFirstPartyTypeKind.ZodMap,
    ...processCreateParams(params)
  });
};
var ZodSet = class _ZodSet extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.set) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.set,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const def = this._def;
    if (def.minSize !== null) {
      if (ctx.data.size < def.minSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.minSize.message
        });
        status.dirty();
      }
    }
    if (def.maxSize !== null) {
      if (ctx.data.size > def.maxSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.maxSize.message
        });
        status.dirty();
      }
    }
    const valueType = this._def.valueType;
    function finalizeSet(elements2) {
      const parsedSet = /* @__PURE__ */ new Set();
      for (const element of elements2) {
        if (element.status === "aborted")
          return INVALID;
        if (element.status === "dirty")
          status.dirty();
        parsedSet.add(element.value);
      }
      return { status: status.value, value: parsedSet };
    }
    const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
    if (ctx.common.async) {
      return Promise.all(elements).then((elements2) => finalizeSet(elements2));
    } else {
      return finalizeSet(elements);
    }
  }
  min(minSize, message) {
    return new _ZodSet({
      ...this._def,
      minSize: { value: minSize, message: errorUtil.toString(message) }
    });
  }
  max(maxSize, message) {
    return new _ZodSet({
      ...this._def,
      maxSize: { value: maxSize, message: errorUtil.toString(message) }
    });
  }
  size(size, message) {
    return this.min(size, message).max(size, message);
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodSet.create = (valueType, params) => {
  return new ZodSet({
    valueType,
    minSize: null,
    maxSize: null,
    typeName: ZodFirstPartyTypeKind.ZodSet,
    ...processCreateParams(params)
  });
};
var ZodFunction = class _ZodFunction extends ZodType {
  constructor() {
    super(...arguments);
    this.validate = this.implement;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.function) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.function,
        received: ctx.parsedType
      });
      return INVALID;
    }
    function makeArgsIssue(args, error) {
      return makeIssue({
        data: args,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_arguments,
          argumentsError: error
        }
      });
    }
    function makeReturnsIssue(returns, error) {
      return makeIssue({
        data: returns,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_return_type,
          returnTypeError: error
        }
      });
    }
    const params = { errorMap: ctx.common.contextualErrorMap };
    const fn = ctx.data;
    if (this._def.returns instanceof ZodPromise) {
      const me = this;
      return OK(async function(...args) {
        const error = new ZodError([]);
        const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
          error.addIssue(makeArgsIssue(args, e));
          throw error;
        });
        const result = await Reflect.apply(fn, this, parsedArgs);
        const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
          error.addIssue(makeReturnsIssue(result, e));
          throw error;
        });
        return parsedReturns;
      });
    } else {
      const me = this;
      return OK(function(...args) {
        const parsedArgs = me._def.args.safeParse(args, params);
        if (!parsedArgs.success) {
          throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
        }
        const result = Reflect.apply(fn, this, parsedArgs.data);
        const parsedReturns = me._def.returns.safeParse(result, params);
        if (!parsedReturns.success) {
          throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
        }
        return parsedReturns.data;
      });
    }
  }
  parameters() {
    return this._def.args;
  }
  returnType() {
    return this._def.returns;
  }
  args(...items) {
    return new _ZodFunction({
      ...this._def,
      args: ZodTuple.create(items).rest(ZodUnknown.create())
    });
  }
  returns(returnType) {
    return new _ZodFunction({
      ...this._def,
      returns: returnType
    });
  }
  implement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  strictImplement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  static create(args, returns, params) {
    return new _ZodFunction({
      args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
      returns: returns || ZodUnknown.create(),
      typeName: ZodFirstPartyTypeKind.ZodFunction,
      ...processCreateParams(params)
    });
  }
};
var ZodLazy = class extends ZodType {
  get schema() {
    return this._def.getter();
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const lazySchema = this._def.getter();
    return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
  }
};
ZodLazy.create = (getter, params) => {
  return new ZodLazy({
    getter,
    typeName: ZodFirstPartyTypeKind.ZodLazy,
    ...processCreateParams(params)
  });
};
var ZodLiteral = class extends ZodType {
  _parse(input) {
    if (input.data !== this._def.value) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_literal,
        expected: this._def.value
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
  get value() {
    return this._def.value;
  }
};
ZodLiteral.create = (value, params) => {
  return new ZodLiteral({
    value,
    typeName: ZodFirstPartyTypeKind.ZodLiteral,
    ...processCreateParams(params)
  });
};
function createZodEnum(values, params) {
  return new ZodEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodEnum,
    ...processCreateParams(params)
  });
}
var ZodEnum = class _ZodEnum extends ZodType {
  _parse(input) {
    if (typeof input.data !== "string") {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(this._def.values);
    }
    if (!this._cache.has(input.data)) {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get options() {
    return this._def.values;
  }
  get enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Values() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  extract(values, newDef = this._def) {
    return _ZodEnum.create(values, {
      ...this._def,
      ...newDef
    });
  }
  exclude(values, newDef = this._def) {
    return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
      ...this._def,
      ...newDef
    });
  }
};
ZodEnum.create = createZodEnum;
var ZodNativeEnum = class extends ZodType {
  _parse(input) {
    const nativeEnumValues = util.getValidEnumValues(this._def.values);
    const ctx = this._getOrReturnCtx(input);
    if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(util.getValidEnumValues(this._def.values));
    }
    if (!this._cache.has(input.data)) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get enum() {
    return this._def.values;
  }
};
ZodNativeEnum.create = (values, params) => {
  return new ZodNativeEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
    ...processCreateParams(params)
  });
};
var ZodPromise = class extends ZodType {
  unwrap() {
    return this._def.type;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.promise,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
    return OK(promisified.then((data) => {
      return this._def.type.parseAsync(data, {
        path: ctx.path,
        errorMap: ctx.common.contextualErrorMap
      });
    }));
  }
};
ZodPromise.create = (schema, params) => {
  return new ZodPromise({
    type: schema,
    typeName: ZodFirstPartyTypeKind.ZodPromise,
    ...processCreateParams(params)
  });
};
var ZodEffects = class extends ZodType {
  innerType() {
    return this._def.schema;
  }
  sourceType() {
    return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const effect = this._def.effect || null;
    const checkCtx = {
      addIssue: (arg) => {
        addIssueToContext(ctx, arg);
        if (arg.fatal) {
          status.abort();
        } else {
          status.dirty();
        }
      },
      get path() {
        return ctx.path;
      }
    };
    checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
    if (effect.type === "preprocess") {
      const processed = effect.transform(ctx.data, checkCtx);
      if (ctx.common.async) {
        return Promise.resolve(processed).then(async (processed2) => {
          if (status.value === "aborted")
            return INVALID;
          const result = await this._def.schema._parseAsync({
            data: processed2,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        });
      } else {
        if (status.value === "aborted")
          return INVALID;
        const result = this._def.schema._parseSync({
          data: processed,
          path: ctx.path,
          parent: ctx
        });
        if (result.status === "aborted")
          return INVALID;
        if (result.status === "dirty")
          return DIRTY(result.value);
        if (status.value === "dirty")
          return DIRTY(result.value);
        return result;
      }
    }
    if (effect.type === "refinement") {
      const executeRefinement = (acc) => {
        const result = effect.refinement(acc, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(result);
        }
        if (result instanceof Promise) {
          throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
        }
        return acc;
      };
      if (ctx.common.async === false) {
        const inner = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inner.status === "aborted")
          return INVALID;
        if (inner.status === "dirty")
          status.dirty();
        executeRefinement(inner.value);
        return { status: status.value, value: inner.value };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          return executeRefinement(inner.value).then(() => {
            return { status: status.value, value: inner.value };
          });
        });
      }
    }
    if (effect.type === "transform") {
      if (ctx.common.async === false) {
        const base = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (!isValid(base))
          return INVALID;
        const result = effect.transform(base.value, checkCtx);
        if (result instanceof Promise) {
          throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
        }
        return { status: status.value, value: result };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
          if (!isValid(base))
            return INVALID;
          return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
            status: status.value,
            value: result
          }));
        });
      }
    }
    util.assertNever(effect);
  }
};
ZodEffects.create = (schema, effect, params) => {
  return new ZodEffects({
    schema,
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    effect,
    ...processCreateParams(params)
  });
};
ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
  return new ZodEffects({
    schema,
    effect: { type: "preprocess", transform: preprocess },
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    ...processCreateParams(params)
  });
};
var ZodOptional = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.undefined) {
      return OK(void 0);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodOptional.create = (type, params) => {
  return new ZodOptional({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodOptional,
    ...processCreateParams(params)
  });
};
var ZodNullable = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.null) {
      return OK(null);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodNullable.create = (type, params) => {
  return new ZodNullable({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodNullable,
    ...processCreateParams(params)
  });
};
var ZodDefault = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    let data = ctx.data;
    if (ctx.parsedType === ZodParsedType.undefined) {
      data = this._def.defaultValue();
    }
    return this._def.innerType._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  removeDefault() {
    return this._def.innerType;
  }
};
ZodDefault.create = (type, params) => {
  return new ZodDefault({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodDefault,
    defaultValue: typeof params.default === "function" ? params.default : () => params.default,
    ...processCreateParams(params)
  });
};
var ZodCatch = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const newCtx = {
      ...ctx,
      common: {
        ...ctx.common,
        issues: []
      }
    };
    const result = this._def.innerType._parse({
      data: newCtx.data,
      path: newCtx.path,
      parent: {
        ...newCtx
      }
    });
    if (isAsync(result)) {
      return result.then((result2) => {
        return {
          status: "valid",
          value: result2.status === "valid" ? result2.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      });
    } else {
      return {
        status: "valid",
        value: result.status === "valid" ? result.value : this._def.catchValue({
          get error() {
            return new ZodError(newCtx.common.issues);
          },
          input: newCtx.data
        })
      };
    }
  }
  removeCatch() {
    return this._def.innerType;
  }
};
ZodCatch.create = (type, params) => {
  return new ZodCatch({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodCatch,
    catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
    ...processCreateParams(params)
  });
};
var ZodNaN = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.nan) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.nan,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
};
ZodNaN.create = (params) => {
  return new ZodNaN({
    typeName: ZodFirstPartyTypeKind.ZodNaN,
    ...processCreateParams(params)
  });
};
var BRAND = /* @__PURE__ */ Symbol("zod_brand");
var ZodBranded = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const data = ctx.data;
    return this._def.type._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  unwrap() {
    return this._def.type;
  }
};
var ZodPipeline = class _ZodPipeline extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.common.async) {
      const handleAsync = async () => {
        const inResult = await this._def.in._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return DIRTY(inResult.value);
        } else {
          return this._def.out._parseAsync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      };
      return handleAsync();
    } else {
      const inResult = this._def.in._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
      if (inResult.status === "aborted")
        return INVALID;
      if (inResult.status === "dirty") {
        status.dirty();
        return {
          status: "dirty",
          value: inResult.value
        };
      } else {
        return this._def.out._parseSync({
          data: inResult.value,
          path: ctx.path,
          parent: ctx
        });
      }
    }
  }
  static create(a, b) {
    return new _ZodPipeline({
      in: a,
      out: b,
      typeName: ZodFirstPartyTypeKind.ZodPipeline
    });
  }
};
var ZodReadonly = class extends ZodType {
  _parse(input) {
    const result = this._def.innerType._parse(input);
    const freeze = (data) => {
      if (isValid(data)) {
        data.value = Object.freeze(data.value);
      }
      return data;
    };
    return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodReadonly.create = (type, params) => {
  return new ZodReadonly({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodReadonly,
    ...processCreateParams(params)
  });
};
function cleanParams(params, data) {
  const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
  const p2 = typeof p === "string" ? { message: p } : p;
  return p2;
}
function custom(check, _params = {}, fatal) {
  if (check)
    return ZodAny.create().superRefine((data, ctx) => {
      const r = check(data);
      if (r instanceof Promise) {
        return r.then((r2) => {
          if (!r2) {
            const params = cleanParams(_params, data);
            const _fatal = params.fatal ?? fatal ?? true;
            ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
          }
        });
      }
      if (!r) {
        const params = cleanParams(_params, data);
        const _fatal = params.fatal ?? fatal ?? true;
        ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
      }
      return;
    });
  return ZodAny.create();
}
var late = {
  object: ZodObject.lazycreate
};
var ZodFirstPartyTypeKind;
(function(ZodFirstPartyTypeKind2) {
  ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
  ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
  ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
  ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
  ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
  ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
  ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
  ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
  ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
  ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
  ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
  ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
  ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
  ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
  ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
  ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
  ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
  ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
  ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
  ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
  ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
  ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
  ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
  ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
  ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
  ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
  ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
  ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
  ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
  ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
  ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
  ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
  ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
  ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
  ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
  ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
})(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
var instanceOfType = (cls, params = {
  message: `Input not instance of ${cls.name}`
}) => custom((data) => data instanceof cls, params);
var stringType = ZodString.create;
var numberType = ZodNumber.create;
var nanType = ZodNaN.create;
var bigIntType = ZodBigInt.create;
var booleanType = ZodBoolean.create;
var dateType = ZodDate.create;
var symbolType = ZodSymbol.create;
var undefinedType = ZodUndefined.create;
var nullType = ZodNull.create;
var anyType = ZodAny.create;
var unknownType = ZodUnknown.create;
var neverType = ZodNever.create;
var voidType = ZodVoid.create;
var arrayType = ZodArray.create;
var objectType = ZodObject.create;
var strictObjectType = ZodObject.strictCreate;
var unionType = ZodUnion.create;
var discriminatedUnionType = ZodDiscriminatedUnion.create;
var intersectionType = ZodIntersection.create;
var tupleType = ZodTuple.create;
var recordType = ZodRecord.create;
var mapType = ZodMap.create;
var setType = ZodSet.create;
var functionType = ZodFunction.create;
var lazyType = ZodLazy.create;
var literalType = ZodLiteral.create;
var enumType = ZodEnum.create;
var nativeEnumType = ZodNativeEnum.create;
var promiseType = ZodPromise.create;
var effectsType = ZodEffects.create;
var optionalType = ZodOptional.create;
var nullableType = ZodNullable.create;
var preprocessType = ZodEffects.createWithPreprocess;
var pipelineType = ZodPipeline.create;
var ostring = () => stringType().optional();
var onumber = () => numberType().optional();
var oboolean = () => booleanType().optional();
var coerce = {
  string: ((arg) => ZodString.create({ ...arg, coerce: true })),
  number: ((arg) => ZodNumber.create({ ...arg, coerce: true })),
  boolean: ((arg) => ZodBoolean.create({
    ...arg,
    coerce: true
  })),
  bigint: ((arg) => ZodBigInt.create({ ...arg, coerce: true })),
  date: ((arg) => ZodDate.create({ ...arg, coerce: true }))
};
var NEVER = INVALID;

// server/vibeDb.ts
var import_node_crypto3 = require("node:crypto");
var OPS = { "==": "$eq", "!=": "$ne", ">": "$gt", ">=": "$gte", "<": "$lt", "<=": "$lte", in: "$in", "not-in": "$nin" };
function strip(d) {
  if (!d) return null;
  const { _id, ...rest } = d;
  return { id: String(_id), data: rest };
}
function clean(data) {
  const out = { ...data };
  delete out._id;
  for (const k of Object.keys(out)) if (out[k] === void 0) delete out[k];
  return out;
}
var enc = (o) => Buffer.from(JSON.stringify(o)).toString("base64url");
var dec = (s) => JSON.parse(Buffer.from(s, "base64url").toString("utf8"));
var DocRef = class {
  constructor(c, id2) {
    this.c = c;
    this.id = id2;
  }
  c;
  id;
  async col() {
    return (await mongo()).collection(this.c);
  }
  async get() {
    return strip(await (await this.col()).findOne({ _id: this.id }));
  }
  async set(data, opts) {
    const col3 = await this.col();
    if (opts?.merge) await col3.updateOne({ _id: this.id }, { $set: clean(data) }, { upsert: true });
    else await col3.replaceOne({ _id: this.id }, clean(data), { upsert: true });
    return await this.get() ?? { id: this.id, data };
  }
  async update(data) {
    const col3 = await this.col();
    const r = await col3.findOneAndUpdate({ _id: this.id }, { $set: clean(data) }, { returnDocument: "after" });
    if (!r) throw new Error("Registro n\xE3o encontrado.");
    return strip(r);
  }
  async delete() {
    await (await this.col()).deleteOne({ _id: this.id });
  }
};
var Query = class _Query {
  constructor(c, filter = {}, ord = [], lim = 0, after = null) {
    this.c = c;
    this.filter = filter;
    this.ord = ord;
    this.lim = lim;
    this.after = after;
  }
  c;
  filter;
  ord;
  lim;
  after;
  where(field, op, value) {
    const mop = OPS[op];
    if (!mop) throw new Error(`Operador n\xE3o suportado: ${op}`);
    const key = field === "id" ? "_id" : field;
    const prev = this.filter[key];
    const cond = { ...prev && typeof prev === "object" && !Array.isArray(prev) ? prev : {}, [mop]: value };
    return new _Query(this.c, { ...this.filter, [key]: cond }, this.ord, this.lim, this.after);
  }
  orderBy(field, dir = "asc") {
    return new _Query(this.c, this.filter, [...this.ord, [field === "id" ? "_id" : field, dir === "desc" ? -1 : 1]], this.lim, this.after);
  }
  limit(n) {
    return new _Query(this.c, this.filter, this.ord, n, this.after);
  }
  startAfter(cursor) {
    return new _Query(this.c, this.filter, this.ord, this.lim, cursor || null);
  }
  sortSpec() {
    return this.ord.some(([f]) => f === "_id") ? this.ord : [...this.ord, ["_id", 1]];
  }
  /** Filtro "depois do cursor" para a ordenação composta (campos + _id). */
  afterFilter() {
    if (!this.after) return this.filter;
    const { v, id: id2 } = dec(this.after);
    const spec = this.sortSpec();
    const vals = [...v, id2];
    const ors = spec.map((_, i) => {
      const o = {};
      for (let j = 0; j < i; j++) o[spec[j][0]] = vals[j];
      o[spec[i][0]] = { [spec[i][1] === 1 ? "$gt" : "$lt"]: vals[i] };
      return o;
    });
    return { $and: [this.filter, { $or: ors }] };
  }
  async getPage() {
    const lim = this.lim || 500;
    const col3 = (await mongo()).collection(this.c);
    const spec = this.sortSpec();
    const raw = await col3.find(this.afterFilter()).sort(Object.fromEntries(spec)).limit(lim).toArray();
    const docs = raw.map((d) => strip(d));
    let cursor = null;
    if (raw.length === lim) {
      const last = raw[raw.length - 1];
      cursor = enc({ v: spec.filter(([f]) => f !== "_id").map(([f]) => last[f] ?? null), id: String(last._id) });
    }
    return { docs, cursor };
  }
  async get() {
    const col3 = (await mongo()).collection(this.c);
    let cur = col3.find(this.afterFilter());
    if (this.ord.length) cur = cur.sort(Object.fromEntries(this.ord));
    if (this.lim) cur = cur.limit(this.lim);
    return (await cur.toArray()).map((d) => strip(d));
  }
  async count() {
    return (await mongo()).collection(this.c).countDocuments(this.filter);
  }
  aggregate() {
    const c = this.c, filter = this.filter;
    return {
      groupBy: (field) => ({
        count: async () => {
          const rows = await (await mongo()).collection(c).aggregate([{ $match: filter }, { $group: { _id: `$${field}`, count: { $sum: 1 } } }]).toArray();
          return rows.map((r) => ({ key: r._id, count: r.count }));
        }
      })
    };
  }
};
var CollRef = class extends Query {
  constructor(name) {
    super(name);
  }
  doc(id2) {
    return new DocRef(this.c, id2 ?? (0, import_node_crypto3.randomUUID)());
  }
  async add(data) {
    const id2 = (0, import_node_crypto3.randomUUID)();
    const doc = clean(data);
    await (await mongo()).collection(this.c).insertOne({ _id: id2, ...doc });
    return { id: id2, data: doc };
  }
};
var db = {
  collection(c) {
    return new CollRef(c.name);
  }
};

// src/shims/vibe-db.ts
function defineCollection(opts) {
  return { name: opts.name, indexes: opts.indexes ?? [] };
}

// src/generated/models.ts
var ACAO_TIPOS = [
  "ajuste",
  "voltar_calculado",
  "desativar",
  "reativar",
  "massa",
  "projetar",
  "trocar_projecao",
  "remover_projecao",
  "comentario",
  "historico_adicionar",
  "historico_editar",
  "historico_remover",
  "importacao",
  "descartar_pendente",
  "validar",
  "desfazer_status",
  "desfazer",
  "regra_capacidade",
  "relatorio"
];
var AJUSTE_LABEL = {
  temperatura: "Temperatura",
  complexidade: "Complexidade",
  capacidade: "Capacidade",
  eixos: "Eixos",
  desativado: "Desativa\xE7\xE3o"
};
var alocAjustes = defineCollection({ name: "aloc_ajustes" });
var alocAcoes = defineCollection({ name: "aloc_acoes", indexes: ["em"] });
var alocComentarios = defineCollection({ name: "aloc_comentarios" });
var alocProjecoes = defineCollection({ name: "aloc_projecoes" });
var alocHistorico = defineCollection({ name: "aloc_historico" });
var alocImportPendentes = defineCollection({ name: "aloc_import_pendentes" });
var alocRegraCapacidade = defineCollection({ name: "aloc_regra_capacidade" });
var ALOC_COLLECTIONS = [
  alocAjustes.name,
  alocComentarios.name,
  alocProjecoes.name,
  alocHistorico.name,
  alocImportPendentes.name,
  alocRegraCapacidade.name
];
var snapshotsSemanais = defineCollection({ name: "snapshots_semanais", indexes: ["semana"] });

// server/monday.ts
var API = "https://api.monday.com/v2";
function serviceToken() {
  return (process.env.MONDAY_API_TOKEN ?? "").trim();
}
var ehMutacao = (query) => /^\s*mutation\b/.test(query);
async function respostaMonday(query, variables = {}, opts = {}) {
  if (!opts.tokenFixo && ehMutacao(query)) {
    const r = await viaNavegador(query, variables);
    if (r !== SEM_NAVEGADOR) return { status: 200, json: r };
  }
  const token = opts.tokenFixo ?? await tokenOAuth() ?? serviceToken();
  if (!token) throw new Error("App sem autoriza\xE7\xE3o OAuth e sem token de servi\xE7o configurado.");
  const res = await fetch(API, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: token, "API-Version": opts.versao ?? "2026-10" },
    body: JSON.stringify({ query, variables }),
    signal: opts.signal
  });
  return { status: res.status, json: await res.json().catch(() => null) };
}
async function gql(query, variables = {}, tokenFixo) {
  let wait = 1500;
  for (let attempt = 1; ; attempt++) {
    const { status, json: json2 } = await respostaMonday(query, variables, { tokenFixo });
    const err = json2?.errors?.[0];
    const msg = err?.message || json2?.error_message || (status >= 400 ? `HTTP ${status}` : "");
    const retryable = status === 429 || status >= 500 || /complexity|rate|limit|timeout|temporar/i.test(`${msg} ${err?.extensions?.code ?? ""}`);
    if (!msg && json2?.data) return json2.data;
    if (retryable && attempt < 6) {
      const s = err?.extensions?.retry_in_seconds;
      await new Promise((r) => setTimeout(r, s ? s * 1e3 + 500 : wait));
      wait = Math.min(wait * 2, 3e4);
      continue;
    }
    throw new Error(`API do monday: ${msg || "resposta vazia"}`.slice(0, 400));
  }
}

// server/currentUser.ts
async function getCurrentUser() {
  const ctx = currentCtx();
  if (!ctx?.userId) return null;
  const r = await gql("query ($ids: [ID!]) { users(ids: $ids) { id name email } }", { ids: [ctx.userId] });
  return r.users?.[0] ?? null;
}

// src/generated/server/acoes.server.ts
async function autoria() {
  const user = await getCurrentUser();
  if (!user) throw new Error("N\xE3o foi poss\xEDvel identificar o seu usu\xE1rio para registrar a altera\xE7\xE3o.");
  return { autor: user.name || "Usu\xE1rio", autorId: String(user.id), em: (/* @__PURE__ */ new Date()).toISOString() };
}
var RETENCAO_MS = 90 * 24 * 60 * 60 * 1e3;
var corteRetencao = () => new Date(Date.now() - RETENCAO_MS).toISOString();
var json = (x) => x ? JSON.parse(JSON.stringify(x)) : null;
function estavel(v) {
  if (Array.isArray(v)) return `[${v.map(estavel).join(",")}]`;
  if (v && typeof v === "object") {
    return `{${Object.keys(v).sort().map((k) => `${JSON.stringify(k)}:${estavel(v[k])}`).join(",")}}`;
  }
  return JSON.stringify(v ?? null);
}
var Registro = class {
  constructor(a) {
    this.a = a;
  }
  a;
  mudancas = [];
  anotar(colecao, docId, alvo, antes, depois) {
    this.mudancas.push({ colecao, docId, alvo: alvo.slice(0, 300), antes: json(antes), depois: json(depois) });
  }
  async add(c, data, alvo) {
    const d = await db.collection(c).add(data);
    this.anotar(c.name, d.id, alvo, null, d.data);
    return d;
  }
  /** Create-or-replace; `antes` may be passed when already read (undefined = read it now). */
  async set(c, docId, data, alvo, antes) {
    const prev = antes !== void 0 ? antes : (await db.collection(c).doc(docId).get())?.data ?? null;
    const d = await db.collection(c).doc(docId).set(data);
    this.anotar(c.name, docId, alvo, prev, d.data);
    return d;
  }
  async update(c, docId, parcial, alvo, antes) {
    const prev = antes !== void 0 ? antes : (await db.collection(c).doc(docId).get())?.data ?? null;
    const d = await db.collection(c).doc(docId).update(parcial);
    this.anotar(c.name, docId, alvo, prev, d.data);
    return d;
  }
  async remove(c, docId, alvo, antes) {
    const prev = antes !== void 0 ? antes : (await db.collection(c).doc(docId).get())?.data ?? null;
    if (!prev) return;
    await db.collection(c).doc(docId).delete();
    this.anotar(c.name, docId, alvo, prev, null);
  }
  async salvar(tipo, descricao, extra = {}) {
    if (!this.mudancas.length) return null;
    try {
      const col3 = db.collection(alocAcoes);
      const d = await col3.add({
        lote: globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`,
        tipo,
        descricao: descricao.slice(0, 600),
        ...this.a,
        desfeita: false,
        desfeitaPor: "",
        desfeitaEm: "",
        itens: extra.itens ?? this.mudancas.length,
        mudancas: this.mudancas,
        ...extra.desfazDe ? { desfazDe: extra.desfazDe } : {}
      });
      await limparAntigos();
      return { id: d.id, tipo, descricao: d.data.descricao };
    } catch (e) {
      console.error("Falha ao gravar o registro de a\xE7\xF5es", e);
      return {
        id: "",
        tipo,
        descricao: descricao.slice(0, 600),
        falhaRegistro: "A altera\xE7\xE3o foi salva, mas n\xE3o entrou no Registro de a\xE7\xF5es \u2014 ela n\xE3o poder\xE1 ser desfeita pelo app."
      };
    }
  }
};
async function limparAntigos() {
  try {
    const col3 = db.collection(alocAcoes);
    const velhos = await col3.where("em", "<", corteRetencao()).limit(100).get();
    await Promise.all(velhos.map((v) => col3.doc(v.id).delete()));
  } catch (e) {
    console.error("Falha ao limpar registros antigos", e);
  }
}

// src/generated/server/acoes.ts
var norm = (v) => v.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
var COLECOES = /* @__PURE__ */ new Set([
  alocAjustes.name,
  alocComentarios.name,
  alocProjecoes.name,
  alocHistorico.name,
  alocImportPendentes.name,
  alocRegraCapacidade.name
]);
var AVISO_VALIDACAO = "O que foi gravado no 02.01 (Gerente, dropdown e Aloca\xE7\xE3o Gerente) n\xE3o \xE9 desfeito \u2014 ajuste no monday se necess\xE1rio.";
var listarAcoes = createServerFn({ method: "GET" }).validator(external_exports.object({
  autor: external_exports.string().max(200).optional(),
  tipo: external_exports.enum(ACAO_TIPOS).optional(),
  busca: external_exports.string().max(100).optional(),
  cursor: external_exports.string().max(4e3).optional()
})).handler(async ({ data }) => {
  const POR_PAGINA = 25;
  const MAX_PAGINAS = 40;
  const termo = norm(data.busca ?? "");
  const casa = (d) => {
    const x = d.data;
    if (data.autor && x.autor !== data.autor) return false;
    if (data.tipo && x.tipo !== data.tipo) return false;
    if (termo && ![x.descricao, x.autor, x.tipo, ...(x.mudancas ?? []).map((m) => m.alvo)].some((v) => norm(v ?? "").includes(termo))) return false;
    return true;
  };
  const docs = [];
  let cursor = data.cursor;
  let fim = false;
  for (let i = 0; i < MAX_PAGINAS && docs.length < POR_PAGINA; i++) {
    let q = db.collection(alocAcoes).where("em", ">=", corteRetencao()).orderBy("em", "desc").limit(POR_PAGINA - docs.length);
    if (cursor) q = q.startAfter(cursor);
    const page2 = await q.getPage();
    docs.push(...page2.docs.filter(casa));
    cursor = page2.cursor ?? void 0;
    if (!cursor) {
      fim = true;
      break;
    }
  }
  const page = { docs, cursor: fim ? null : cursor ?? null };
  return {
    itens: page.docs.map((d) => ({
      id: d.id,
      tipo: d.data.tipo,
      descricao: d.data.descricao,
      autor: d.data.autor,
      em: d.data.em,
      desfeita: !!d.data.desfeita,
      desfeitaPor: d.data.desfeitaPor ?? "",
      desfeitaEm: d.data.desfeitaEm ?? "",
      itens: d.data.itens ?? d.data.mudancas?.length ?? 0
    })),
    cursor: page.cursor ?? null
  };
});
var autoresAcoes = createServerFn({ method: "GET" }).validator(external_exports.object({}).optional()).handler(async () => {
  const rows = await db.collection(alocAcoes).aggregate().groupBy("autor").count();
  return rows.map((r) => typeof r.key === "string" ? r.key : "").filter(Boolean).sort((a, b) => a.localeCompare(b, "pt-BR"));
});
var desfazerAcao = createServerFn({ method: "POST" }).validator((d) => external_exports.object({ id: external_exports.string().min(1).max(64), forcar: external_exports.boolean().optional() }).parse(d)).handler(async ({ data }) => {
  const a = await autoria();
  const col3 = db.collection(alocAcoes);
  const doc = await col3.doc(data.id).get();
  if (!doc) throw new Error("Registro n\xE3o encontrado (registros com mais de 90 dias s\xE3o apagados).");
  if (doc.data.desfeita) throw new Error("Esta a\xE7\xE3o j\xE1 foi desfeita.");
  if (doc.data.tipo === "desfazer") throw new Error("Um registro de desfazer n\xE3o pode ser desfeito.");
  const ms = (doc.data.mudancas ?? []).filter((m) => COLECOES.has(m.colecao));
  const handle = (nome) => ({ name: nome, indexes: [] });
  const atuais = await Promise.all(ms.map((m) => db.collection(handle(m.colecao)).doc(m.docId).get()));
  const conflitos = [...new Set(ms.filter((m, i) => estavel(json(atuais[i]?.data ?? null)) !== estavel(m.depois)).map((m) => m.alvo))];
  if (conflitos.length && !data.forcar) return { status: "conflito", conflitos: conflitos.slice(0, 20), acao: null, aviso: null };
  const reg = new Registro(a);
  for (let i = ms.length - 1; i >= 0; i--) {
    const m = ms[i];
    if (!m) continue;
    const atual = atuais[i]?.data ?? null;
    if (m.antes === null) await reg.remove(handle(m.colecao), m.docId, m.alvo, atual);
    else await reg.set(handle(m.colecao), m.docId, m.antes, m.alvo, atual);
  }
  await col3.doc(doc.id).update({ desfeita: true, desfeitaPor: a.autor, desfeitaEm: a.em });
  const acao = await reg.salvar("desfazer", `Desfeito: ${doc.data.descricao}`, { itens: doc.data.itens, desfazDe: doc.id });
  return { status: "ok", conflitos: [], acao, aviso: doc.data.tipo === "validar" ? AVISO_VALIDACAO : null };
});
var registrarRelatorio = createServerFn({ method: "POST" }).validator((d) => external_exports.object({ descricao: external_exports.string().min(1).max(600), itens: external_exports.number().int().min(0).max(5e3) }).parse(d)).handler(async ({ data }) => {
  const a = await autoria();
  const col3 = db.collection(alocAcoes);
  const doc = await col3.add({
    lote: globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`,
    tipo: "relatorio",
    descricao: data.descricao,
    ...a,
    desfeita: false,
    desfeitaPor: "",
    desfeitaEm: "",
    itens: data.itens,
    mudancas: []
  });
  return { id: doc.id };
});

// src/generated/server/alocacao.ts
var alocacao_exports = {};
__export(alocacao_exports, {
  adicionarProjecao: () => adicionarProjecao,
  ajustesEmMassa: () => ajustesEmMassa,
  getAlocacao: () => getAlocacao,
  getRegraCapacidade: () => getRegraCapacidade,
  importarTemperaturas: () => importarTemperaturas,
  removerAjuste: () => removerAjuste,
  removerHistorico: () => removerHistorico,
  removerImportPendente: () => removerImportPendente,
  removerProjecao: () => removerProjecao,
  resetRegraCapacidade: () => resetRegraCapacidade,
  salvarAjuste: () => salvarAjuste,
  salvarComentario: () => salvarComentario,
  salvarHistorico: () => salvarHistorico,
  salvarRegraCapacidade: () => salvarRegraCapacidade,
  statusProjecoes: () => statusProjecoes
});

// server/columns.json
var columns_default = {
  "18422833691": {
    name: {
      id: "name",
      type: "name"
    },
    subelementos: {
      id: "subtasks_mm7faf00",
      type: "subtasks"
    },
    statusProjetoEspelho: {
      id: "lookup_mm5gt615",
      type: "mirror"
    },
    statusProjeto: {
      id: "color_mm6v67nv",
      type: "status",
      labels: {
        "Aguardando planejamento": 0,
        "Pagamento pendente": 1,
        Inicia\u00E7\u00E3o: 2,
        Finalizado: 3,
        "Em planejamento": 4,
        "N\xE3o Iniciado": 5,
        Pausado: 6,
        "Plan: Aguardando Aprova\xE7\xE3o SGI": 7,
        "Em execu\xE7\xE3o": 8,
        "Em encerramento": 9
      }
    },
    colaStatus: {
      id: "button_mm67p6wc",
      type: "button"
    },
    telefone: {
      id: "text_mm5ef4qw",
      type: "text"
    },
    local: {
      id: "location_mm5ehn2c",
      type: "location"
    },
    certificaoPmi: {
      id: "dropdown_mm5e50ej",
      type: "dropdown"
    },
    processoDeQualificao: {
      id: "dropdown_mm7gbrw4",
      type: "dropdown"
    },
    status: {
      id: "color_mm7gphww",
      type: "status",
      labels: {
        "Em Progresso": 0,
        Conclu\u00EDdo: 1,
        Cancelado: 2,
        "Aguardando Inscri\xE7\xE3o": 3,
        "Bolsa 2027": 4,
        "N/A": 5,
        "Aguardando GP": 11,
        "Em Processo de Sele\xE7\xE3o": 12,
        "Aguardando In\xEDcio": 17
      }
    },
    perfil: {
      id: "dropdown_mm5e7wsd",
      type: "dropdown"
    },
    projetosGerenciados: {
      id: "board_relation_mm5epxs",
      type: "board_relation"
    },
    alocaoNoProjeto: {
      id: "lookup_mm6vcpsw",
      type: "mirror"
    },
    fimAtuao: {
      id: "timerange_mm67nw07",
      type: "timeline"
    },
    vignciaContratual: {
      id: "lookup_mm6vga5d",
      type: "mirror"
    },
    atividadeAtual: {
      id: "color_mm5ehxrr",
      type: "status",
      labels: {
        SUPPRO: 0,
        SAE: 1,
        SUPGP: 2,
        GERENTE: 3,
        CORP: 4,
        "N\xE3o Iniciado": 5,
        EXEC: 6,
        TI: 7,
        NAVEM\u00C3E: 8,
        CONSULTOR: 9,
        ESPECIALISTA: 10,
        PESQUISADOR: 11,
        INATIVO: 12
      }
    },
    valorDoContrato: {
      id: "lookup_mm6vt27k",
      type: "mirror"
    },
    eixo: {
      id: "lookup_mm6vmj6d",
      type: "mirror"
    },
    sadaDoProjeto: {
      id: "date_mm6vsz95",
      type: "date"
    },
    perodoNoProjeto: {
      id: "formula_mm6vrvqh",
      type: "formula"
    },
    compexidadeDoProjeto: {
      id: "numeric_mm6vennr",
      type: "numbers"
    },
    avDesempenho: {
      id: "numeric_mm7g61q5",
      type: "numbers"
    },
    fimAtuao1: {
      id: "lookup_mm6vw2j9",
      type: "mirror"
    },
    totalProjetos: {
      id: "formula_mm6vy9nt",
      type: "formula"
    },
    email: {
      id: "email_mm5eqgfn",
      type: "email"
    }
  },
  "18412010674": {
    name: {
      id: "name",
      type: "name"
    },
    gerente: {
      id: "board_relation_mm5egrbf",
      type: "board_relation"
    },
    statusPlanejamento: {
      id: "color_mm3axm14",
      type: "status",
      labels: {
        "Em andamento": 0,
        "Instrumento Conclu\xEDdo": 1,
        "Sem planejamento [ANTIGOS]": 2,
        "Em revis\xE3o": 3,
        "Finalizado (Plan + SGI)": 4,
        "Novo Cadastro - 30 a 45 dias": 5,
        "Planejado aguardando assinatura": 6,
        "Novo Cadastro - 45 a 60 dias": 7,
        "Em replanejamento": 8,
        Pausado: 11,
        Despriorizado: 17
      }
    },
    statusSgi: {
      id: "color_mm34f2he",
      type: "status",
      labels: {
        "Validado no SGI": 1,
        "Sem planejamento [ANTIGOS]": 2,
        "Em registro no SGI": 3,
        "Em valida\xE7\xE3o no SGI": 4,
        "N\xE3o Iniciado": 5,
        "TAP Reprovado": 6,
        "Aguardando cadastro no SGI": 7,
        "Aguardando planejamento": 8,
        Pausado: 11,
        Despriorizado: 17
      }
    },
    subelementos: {
      id: "subtasks_mm33p1kt",
      type: "subtasks"
    },
    pontoFocal: {
      id: "person",
      type: "people"
    },
    vignciaContratual: {
      id: "timerange_mm6vw3pb",
      type: "timeline"
    },
    eixo: {
      id: "dropdown_mm38v0xw",
      type: "dropdown"
    },
    gerente1: {
      id: "dropdown_mm6v1tw6",
      type: "dropdown"
    },
    tipoDeContrato: {
      id: "dropdown_mm34venp",
      type: "dropdown"
    },
    statusProspeco: {
      id: "dropdown_mm33pfht",
      type: "dropdown"
    },
    tipoPlanejamento: {
      id: "dropdown_mm3a5hsg",
      type: "dropdown"
    },
    avano: {
      id: "lookup_mm337trg",
      type: "mirror"
    },
    prioridade: {
      id: "color_mm33f6am",
      type: "status",
      labels: {
        N\u00E3o: 0,
        Baixa: 7,
        Cr\u00EDtico: 10,
        M\u00E9dia: 109,
        Alta: 110
      }
    },
    quadroDoPlanejamento: {
      id: "link_mm383m1p",
      type: "link"
    },
    painelSgi: {
      id: "link_mm39c5rc",
      type: "link"
    },
    dataValidaoSgi: {
      id: "date_mm4ycb3r",
      type: "date"
    },
    incioPlanejamento: {
      id: "data",
      type: "date"
    },
    alocaoGerente: {
      id: "date_mm33vrwt",
      type: "date"
    },
    dataDeAssinatura: {
      id: "date_mm33km09",
      type: "date"
    },
    calcPrazoDeConcluso: {
      id: "formula_mm33v8cc",
      type: "formula"
    },
    prazoDeConcluso: {
      id: "formula_mm35rrft",
      type: "formula"
    },
    msRefernciaResultado: {
      id: "color_mm34v1y5",
      type: "status",
      labels: {
        "12.Dezembro": 0,
        "11.Novembro": 1,
        "10.Outubro": 2,
        "09.Setembro": 3,
        "08.Agosto": 4,
        "N/A": 5,
        "07.Julho": 6,
        "06.Junho": 7,
        "05.Maio": 8,
        "04.Abril": 9,
        "03.Mar\xE7o": 10,
        "02.Fevereiro": 11,
        "01.Janeiro": 12
      }
    },
    ltimoProdutoPrevisto: {
      id: "date_mm5g69fd",
      type: "date"
    },
    uf: {
      id: "dropdown_mm3815pa",
      type: "dropdown"
    },
    conclusoDoPlanejamento: {
      id: "date_mm3325j4",
      type: "date"
    },
    resultadoConclusoPlanejamento: {
      id: "formula_mm3352pb",
      type: "formula"
    },
    tempoDePlanejamento: {
      id: "formula_mm33q988",
      type: "formula"
    },
    prazoRegistroSgi: {
      id: "formula_mm33q9bm",
      type: "formula"
    },
    calcPrazoRegistroSgi: {
      id: "formula_mm3jrn1n",
      type: "formula"
    },
    conclusoRegistroSgi: {
      id: "date_mm3397yt",
      type: "date"
    },
    resultadoSgi: {
      id: "formula_mm33s95p",
      type: "formula"
    },
    tempoRegistroSgi: {
      id: "formula_mm33r9s2",
      type: "formula"
    },
    planilhaPlanejamento: {
      id: "link_mm34pjnd",
      type: "link"
    },
    valorDoContrato: {
      id: "numeric_mm33ha60",
      type: "numbers"
    },
    equipeOr: {
      id: "numeric_mm33x89s",
      type: "numbers"
    },
    equipePlan: {
      id: "numeric_mm33rmra",
      type: "numbers"
    },
    rSaldoEquipe: {
      id: "formula_mm33p5g8",
      type: "formula"
    },
    rSaldoInsumos: {
      id: "formula_mm6crw51",
      type: "formula"
    },
    oradoTotal: {
      id: "numeric_mm333732",
      type: "numbers"
    },
    oradoInsumos: {
      id: "numeric_mm6cceqx",
      type: "numbers"
    },
    planejadoInsumos: {
      id: "numeric_mm6c38bj",
      type: "numbers"
    },
    planejadoTotal: {
      id: "numeric_mm33jpn2",
      type: "numbers"
    },
    rSaldoTotal: {
      id: "formula_mm33av5w",
      type: "formula"
    },
    it11: {
      id: "formula_mm34jx1f",
      type: "formula"
    },
    it12: {
      id: "formula_mm34x4rw",
      type: "formula"
    },
    it13: {
      id: "formula_mm34evxz",
      type: "formula"
    },
    it14: {
      id: "formula_mm345wf4",
      type: "formula"
    },
    mondayDocV2: {
      id: "direct_doc_mm386xze",
      type: "direct_doc"
    },
    pendnciaSistema: {
      id: "text_mm3990vj",
      type: "text"
    },
    pendnciaDeValidao: {
      id: "text_mm39657m",
      type: "text"
    },
    pendnciaPlanejamento: {
      id: "text_mm39knp0",
      type: "text"
    },
    radarMonitoramento: {
      id: "color_mm3zcq9z",
      type: "status",
      labels: {
        "Alta Prob. de Repactua\xE7\xE3o": 0,
        "Crono Produtos Pactuado": 3,
        "Crono Produtos em Constru\xE7\xE3o": 5
      }
    },
    cdigoProjeto: {
      id: "text_mm4dd4n0",
      type: "text"
    },
    linkHistricoDeProjetos: {
      id: "board_relation_mm4dbzww",
      type: "board_relation"
    },
    statusHistricoDeProjetos: {
      id: "lookup_mm4dprb8",
      type: "mirror"
    },
    faixaDeComplexidadeEspelho: {
      id: "lookup_mm72vkd8",
      type: "mirror"
    },
    nvelDeComplexidadeEspelho: {
      id: "lookup_mm72pfhy",
      type: "mirror"
    },
    colocaoNvelDeMaturidadeDosProjetos: {
      id: "lookup_mm72889z",
      type: "mirror"
    },
    botoLinkPlanMonit: {
      id: "button_mm4drjem",
      type: "button"
    },
    linkToMapaDeGerentes: {
      id: "board_relation_mm5eyyvt",
      type: "board_relation"
    },
    linkToMapaDeGerentes1: {
      id: "board_relation_mm5e21db",
      type: "board_relation"
    },
    linkToMapaDeGerentes2: {
      id: "board_relation_mm5easxk",
      type: "board_relation"
    },
    criaoQuadroDePlanejamentoDoProjeto: {
      id: "button_mm6chr0v",
      type: "button"
    },
    abrangnciaDoProjetoCoverageCode: {
      id: "dropdown_mm6cxpgj",
      type: "dropdown"
    },
    pas: {
      id: "text_mm6crjwh",
      type: "text"
    },
    cliente: {
      id: "text_mm6cqc6v",
      type: "text"
    },
    prazoIncioExecuo: {
      id: "date_mm6c7z59",
      type: "date"
    },
    prazoTrminoExecuo: {
      id: "date_mm6cd45w",
      type: "date"
    },
    tempoMdioDeRecebimento: {
      id: "numeric_mm6c9e48",
      type: "numbers"
    },
    dataIncioExecuo: {
      id: "date_mm762pgv",
      type: "date"
    },
    dataFimExecuo: {
      id: "date_mm76xjkw",
      type: "date"
    },
    centroDeCusto: {
      id: "text_mm762gda",
      type: "text"
    },
    idProjeto: {
      id: "text_mm76y727",
      type: "text"
    },
    status: {
      id: "color_mm76p330",
      type: "status",
      labels: {
        "Em Progresso": 0,
        Conclu\u00EDdo: 1,
        Cancelado: 2,
        "Em Planejamento": 3,
        "Em Revis\xE3o": 4,
        "N\xE3o Iniciado": 5,
        Inicia\u00E7\u00E3o: 6,
        Execu\u00E7\u00E3o: 7,
        Encerramento: 8,
        Parado: 11,
        Despriorizado: 17
      }
    },
    nomeSgi: {
      id: "formula_mm76de1",
      type: "formula"
    },
    alocaoDeEquipe: {
      id: "color_mm766rs9",
      type: "status",
      labels: {
        "Equipe alocada": 3,
        "Sem equipe": 4,
        "N\xE3o preenchido": 5,
        Verificar: 17
      }
    },
    conclusoDoDimensionamento: {
      id: "date_mm7wr54s",
      type: "date"
    },
    prazoDimensionamento: {
      id: "formula_mm7wr92h",
      type: "formula"
    },
    diasDimensionamento: {
      id: "formula_mm7wx69z",
      type: "formula"
    },
    io211NoPrazo: {
      id: "formula_mm7w17zq",
      type: "formula"
    },
    io212Adequado: {
      id: "formula_mm7w4dy5",
      type: "formula"
    },
    dimensionamentoConcludo: {
      id: "color_mm7y8hwt",
      type: "status",
      labels: {
        Conclu\u00EDdo: 1,
        "N\xE3o conclu\xEDdo": 5
      }
    },
    SaldoEquipe: {
      id: "formula_mm3448h8",
      type: "formula"
    },
    SaldoInsumos: {
      id: "formula_mm6cqeep",
      type: "formula"
    },
    SaldoTotal: {
      id: "formula_mm34y3tj",
      type: "formula"
    }
  }
};

// server/boardSdk.ts
var MAPS = columns_default;
var FRAG = `id type text value
  ... on StatusValue { label }
  ... on DropdownValue { values { label } }
  ... on DateValue { date }
  ... on TimelineValue { from to }
  ... on MirrorValue { display_value }
  ... on FormulaValue { display_value }
  ... on BoardRelationValue { linked_item_ids linked_items { id name } }
  ... on PeopleValue { persons_and_teams { id kind } }
  ... on EmailValue { email }
  ... on LocationValue { city address }`;
var userNames = /* @__PURE__ */ new Map();
async function resolverNomes(ids) {
  const falta = [...new Set(ids)].filter((id2) => !userNames.has(id2));
  for (let i = 0; i < falta.length; i += 100) {
    const r = await gql("query ($ids: [ID!]) { users(ids: $ids) { id name } }", { ids: falta.slice(i, i + 100) });
    for (const u of r.users ?? []) userNames.set(String(u.id), u.name);
  }
}
function lerValor(def, cv) {
  if (!cv) return null;
  const parse = () => {
    try {
      return cv.value ? JSON.parse(cv.value) : null;
    } catch {
      return null;
    }
  };
  switch (def.type) {
    case "text":
    case "long_text":
    case "phone":
      return cv.text || null;
    case "numbers": {
      const n = cv.text === null || cv.text === "" ? NaN : Number(cv.text);
      return Number.isFinite(n) ? n : null;
    }
    case "status":
      return cv.label || cv.text || null;
    case "dropdown":
      return (cv.values ?? []).map((v) => v.label);
    case "date":
      return cv.date ? /* @__PURE__ */ new Date(`${cv.date.slice(0, 10)}T00:00:00Z`) : null;
    case "timeline":
      return cv.from || cv.to ? { from: (cv.from ?? "").slice(0, 10), to: (cv.to ?? "").slice(0, 10) } : null;
    case "mirror":
      return { displayValue: cv.display_value ?? cv.text ?? null };
    case "formula":
      return cv.display_value ?? cv.text ?? null;
    case "board_relation": {
      const linked = (cv.linked_items ?? []).map((l) => ({ id: String(l.id), name: l.name }));
      const ids = (cv.linked_item_ids ?? []).map(String);
      for (const id2 of ids) if (!linked.some((l) => l.id === id2)) linked.push({ id: id2, name: "" });
      return { linkedItems: linked, linkedItemIds: ids };
    }
    case "people":
      return (cv.persons_and_teams ?? []).map((p) => ({ id: String(p.id), kind: p.kind, name: userNames.get(String(p.id)) ?? "" }));
    case "link": {
      const v = parse();
      return v?.url ? { url: v.url, text: v.text ?? "" } : null;
    }
    case "email":
      return cv.email || cv.text ? { email: cv.email ?? cv.text, text: cv.text ?? "" } : null;
    case "location":
      return cv.city || cv.address || cv.text ? { city: cv.city ?? null, address: cv.address ?? cv.text ?? null } : null;
    case "checkbox":
      return !!parse()?.checked;
    default:
      return cv.text ?? null;
  }
}
var isoDia = (v) => {
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  return String(v).slice(0, 10);
};
function escreverValor(def, v) {
  if (v === null || v === void 0 || Array.isArray(v) && v.length === 0) {
    if (def.type === "text" || def.type === "numbers") return "";
    if (def.type === "long_text") return { text: "" };
    return {};
  }
  switch (def.type) {
    case "text":
      return String(v);
    case "long_text":
      return { text: String(v) };
    case "numbers":
      return String(v);
    case "status": {
      const label = String(v);
      if (def.labels && !(label in def.labels)) throw new Error(`R\xF3tulo inexistente na coluna: ${label}`);
      return { label };
    }
    case "dropdown":
      return { labels: v.map(String) };
    case "date":
      return { date: isoDia(v) };
    case "timeline": {
      const t = v;
      return { from: isoDia(t.from), to: isoDia(t.to) };
    }
    case "people":
      return { personsAndTeams: v.map((p) => ({ id: Number(p.id), kind: p.kind ?? "person" })) };
    case "board_relation": {
      const o = v;
      return { item_ids: (o.linkedItems?.map((l) => l.id) ?? o.itemIds ?? []).map(Number) };
    }
    case "link": {
      const o = v;
      return { url: o.url, text: o.text ?? o.url };
    }
    case "checkbox":
      return v ? { checked: "true" } : {};
    default:
      return String(v);
  }
}
function montarItem(map, raw, cols) {
  const it = { id: String(raw.id), name: raw.name, group: raw.group ? { id: raw.group.id, title: raw.group.title } : null, updatedAt: raw.updated_at ?? null, createdAt: raw.created_at ?? null };
  const byId = new Map((raw.column_values ?? []).map((c) => [c.id, c]));
  for (const k of cols) {
    const def = map[k];
    if (def && def.id !== "name") it[k] = lerValor(def, byId.get(def.id));
  }
  if (raw.updates) it.updates = raw.updates;
  return it;
}
async function prepararPessoas(raws) {
  const ids = [];
  for (const r of raws) for (const c of r.column_values ?? []) for (const p of c.persons_and_teams ?? []) if (p.kind === "person") ids.push(String(p.id));
  if (ids.length) await resolverNomes(ids);
}
var ItemsQuery = class {
  constructor(boardId, map) {
    this.boardId = boardId;
    this.map = map;
  }
  boardId;
  map;
  cols = [];
  rules = [];
  order = null;
  pag = {};
  upd = null;
  withColumns(c) {
    this.cols = [...c];
    return this;
  }
  withUpdates(u) {
    this.upd = u;
    return this;
  }
  orderBy(o) {
    const id2 = o.column === "name" ? "name" : this.map[o.column]?.id ?? o.column;
    this.order = [{ column_id: id2, direction: o.direction ?? "asc" }];
    return this;
  }
  where(w) {
    for (const [k, v] of Object.entries(w)) {
      if (k === "group") {
        this.rules.push({ column_id: "group", compare_value: (Array.isArray(v) ? v : [v]).map(String), operator: "any_of" });
        continue;
      }
      const def = this.map[k];
      if (!def) throw new Error(`Coluna desconhecida: ${k}`);
      if (def.type === "board_relation") {
        const ids = typeof v === "object" && v && "itemId" in v ? [v.itemId] : v.itemIds ?? [];
        this.rules.push({ column_id: def.id, compare_value: ids.map(Number), operator: "any_of" });
      } else if (def.type === "status") {
        const labels = (Array.isArray(v) ? v : [v]).map(String);
        const idx = labels.map((l) => def.labels?.[l]).filter((x) => x !== void 0);
        if (!idx.length) throw new Error(`R\xF3tulo inexistente: ${labels.join(", ")}`);
        this.rules.push({ column_id: def.id, compare_value: idx, operator: "any_of" });
      } else {
        this.rules.push({ column_id: def.id, compare_value: Array.isArray(v) ? v : [v], operator: "any_of" });
      }
    }
    return this;
  }
  withPagination(p) {
    this.pag = p;
    return this;
  }
  campos() {
    const ids = this.cols.map((k) => this.map[k]?.id).filter((x) => !!x && x !== "name");
    const upd = this.upd ? `updates(limit: ${this.upd.limit}${this.upd.page ? `, page: ${this.upd.page}` : ""}) { id body text_body created_at creator { id name } }` : "";
    return `id name updated_at created_at group { id title } column_values(ids: ${JSON.stringify(ids)}) { ${FRAG} } ${upd}`;
  }
  async execute() {
    const temFormula = this.cols.some((k) => this.map[k]?.type === "formula");
    const limit = Math.min(this.pag.limit ?? 100, temFormula ? 100 : 500);
    let page;
    if (this.pag.cursor) {
      const r = await gql(`query ($c: String!, $l: Int!) { next_items_page(cursor: $c, limit: $l) { cursor items { ${this.campos()} } } }`, { c: this.pag.cursor, l: limit });
      page = r.next_items_page;
    } else {
      const qp = {};
      if (this.rules.length) qp.rules = this.rules;
      if (this.order) qp.order_by = this.order;
      const r = await gql(`query ($b: [ID!], $l: Int!, $qp: ItemsQuery) { boards(ids: $b) { items_page(limit: $l, query_params: $qp) { cursor items { ${this.campos()} } } } }`, { b: [this.boardId], l: limit, qp: Object.keys(qp).length ? qp : null });
      page = r.boards?.[0]?.items_page ?? { cursor: null, items: [] };
    }
    await prepararPessoas(page.items);
    return { items: page.items.map((it) => montarItem(this.map, it, this.cols)), cursor: page.cursor ?? null };
  }
};
function payload(map, obj) {
  const cv = {};
  let name;
  for (const [k, v] of Object.entries(obj)) {
    if (v === void 0) continue;
    if (k === "name") {
      name = String(v);
      continue;
    }
    const def = map[k];
    if (!def) throw new Error(`Coluna desconhecida: ${k}`);
    cv[def.id] = escreverValor(def, v);
  }
  return { name, cv };
}
var ItemRef = class {
  constructor(boardId, map, id2) {
    this.boardId = boardId;
    this.map = map;
    this.id = id2;
  }
  boardId;
  map;
  id;
  cols = [];
  upd = null;
  withColumns(c) {
    this.cols = [...c];
    return this;
  }
  withUpdates(u) {
    this.upd = u;
    return this;
  }
  async execute() {
    const ids = this.cols.map((k) => this.map[k]?.id).filter((x) => !!x && x !== "name");
    const upd = this.upd ? `updates(limit: ${this.upd.limit}${this.upd.page ? `, page: ${this.upd.page}` : ""}) { id body text_body created_at creator { id name } }` : "";
    const r = await gql(`query ($i: [ID!]) { items(ids: $i) { id name updated_at created_at group { id title } column_values(ids: ${JSON.stringify(ids)}) { ${FRAG} } ${upd} } }`, { i: [this.id] });
    const raw = r.items?.[0];
    if (!raw) return null;
    await prepararPessoas([raw]);
    return montarItem(this.map, raw, this.cols);
  }
  update(obj) {
    return {
      execute: async () => {
        const { name, cv } = payload(this.map, obj);
        if (name !== void 0) cv.name = name;
        if (!Object.keys(cv).length) return { id: this.id };
        await gql(`mutation ($b: ID!, $i: ID!, $v: JSON!) { change_multiple_column_values(board_id: $b, item_id: $i, column_values: $v, create_labels_if_missing: false) { id } }`, { b: this.boardId, i: this.id, v: JSON.stringify(cv) });
        return { id: this.id };
      }
    };
  }
  create(obj) {
    return {
      execute: async () => {
        const { name, cv } = payload(this.map, obj);
        const r = await gql(`mutation ($b: ID!, $n: String!, $v: JSON) { create_item(board_id: $b, item_name: $n, column_values: $v) { id name } }`, { b: this.boardId, n: name ?? "Novo item", v: JSON.stringify(cv) });
        return { id: String(r.create_item.id), name: r.create_item.name };
      }
    };
  }
  delete() {
    return { execute: async () => {
      await gql("mutation ($i: ID!) { delete_item(item_id: $i) { id } }", { i: this.id });
      return { id: this.id };
    } };
  }
  post() {
    return {
      create: (body) => ({
        execute: async () => {
          const r = await gql("mutation ($i: ID!, $b: String!) { create_update(item_id: $i, body: $b) { id } }", { i: this.id, b: body });
          return { id: String(r.create_update.id) };
        }
      })
    };
  }
};
var Board = class {
  constructor(boardId) {
    this.boardId = boardId;
    this.map = MAPS[boardId] ?? {};
  }
  boardId;
  map;
  items() {
    return new ItemsQuery(this.boardId, this.map);
  }
  item(id2) {
    return new ItemRef(this.boardId, this.map, id2 === void 0 ? void 0 : String(id2));
  }
  executeGraphQL(query, variables = {}) {
    return gql(query, variables);
  }
  get users() {
    const boardId = this.boardId;
    return {
      me: () => ({ execute: async () => {
        const ctx = currentCtx();
        return ctx?.userId ? { id: ctx.userId } : null;
      } }),
      where: (w) => ({
        withPagination: (p) => ({
          execute: async () => (await gql("query ($n: String, $l: Int, $p: Int) { users(name: $n, limit: $l, page: $p) { id name } }", { n: w.name ?? null, l: p.limit ?? 20, p: (p.page ?? 0) + 1 })).users ?? []
        })
      }),
      boardSubscribers: () => ({
        execute: async () => (await gql("query ($b: [ID!]) { boards(ids: $b) { subscribers { id name } } }", { b: [boardId] })).boards?.[0]?.subscribers ?? []
      })
    };
  }
};
var Board0201ProjetosEmPlanejamentoBoard = class extends Board {
  constructor() {
    super("18412010674");
  }
};
var MapaDeGerentesDeProjetoBoard = class extends Board {
  constructor() {
    super("18422833691");
  }
};

// src/generated/lib/grupos.ts
var GROUP_ESTEIRA = "topics";
var GROUP_HISTORICO = "group_mm333d5m";
var GRUPO_CADASTRO_MAPA = "group_mm5efwsh";

// server/apiClient.ts
async function getServerApiClient() {
  return { client: { request: (query, variables = {}) => gql(query, variables) } };
}

// src/generated/lib/links.ts
var BOARD_ID = "18412010674";

// src/generated/server/base-dados.ts
var CAMPOS_SUB = 'cursor items { id subitems { column_values(ids: ["status"]) { text } } }';
async function lerAvanco() {
  const { client } = await getServerApiClient();
  const mapa = /* @__PURE__ */ new Map();
  const somar = (pg2) => {
    for (const it of pg2?.items ?? []) {
      const st = (it.subitems ?? []).map((s) => (s.column_values[0]?.text ?? "").trim());
      const validos = st.filter((t) => t !== "Despriorizado");
      const concluidos = validos.filter((t) => t === "Conclu\xEDdo").length;
      mapa.set(String(it.id), { concluidos, total: validos.length, pct: validos.length ? Math.round(concluidos / validos.length * 100) : null });
    }
  };
  const r = await client.request(
    `query($b:[ID!]){ boards(ids:$b){ items_page(limit:100){ ${CAMPOS_SUB} } } }`,
    { b: [String(BOARD_ID)] }
  );
  let pg = r.boards?.[0]?.items_page;
  somar(pg);
  while (pg?.cursor) {
    const n = await client.request(
      `query($c:String!){ next_items_page(limit:100, cursor:$c){ ${CAMPOS_SUB} } }`,
      { c: pg.cursor }
    );
    pg = n.next_items_page;
    somar(pg);
  }
  return mapa;
}
var COLUMNS = [
  "gerente",
  "gerente1",
  "statusPlanejamento",
  "statusSgi",
  "status",
  "pontoFocal",
  "vignciaContratual",
  "eixo",
  "tipoPlanejamento",
  "prioridade",
  "uf",
  "cliente",
  "cdigoProjeto",
  "quadroDoPlanejamento",
  "painelSgi",
  "planilhaPlanejamento",
  "incioPlanejamento",
  "dataValidaoSgi",
  "msRefernciaResultado",
  "calcPrazoDeConcluso",
  "prazoDeConcluso",
  "conclusoDoPlanejamento",
  "resultadoConclusoPlanejamento",
  "tempoDePlanejamento",
  "calcPrazoRegistroSgi",
  "prazoRegistroSgi",
  "conclusoRegistroSgi",
  "resultadoSgi",
  "tempoRegistroSgi",
  "prazoDimensionamento",
  "conclusoDoDimensionamento",
  "diasDimensionamento",
  "io211NoPrazo",
  "dimensionamentoConcludo",
  "valorDoContrato",
  "equipeOr",
  "equipePlan",
  "oradoInsumos",
  "planejadoInsumos",
  "oradoTotal",
  "planejadoTotal",
  "rSaldoEquipe",
  "SaldoEquipe",
  "rSaldoInsumos",
  "SaldoInsumos",
  "rSaldoTotal",
  "SaldoTotal",
  "radarMonitoramento",
  "alocaoDeEquipe",
  "it11",
  "it12",
  "it13",
  "it14",
  // Alocação de Gerentes
  "statusProspeco",
  "dataDeAssinatura",
  "faixaDeComplexidadeEspelho",
  "ltimoProdutoPrevisto",
  "alocaoGerente",
  "statusHistricoDeProjetos",
  "prazoIncioExecuo",
  "prazoTrminoExecuo"
];
async function buscarBase() {
  const board = new Board0201ProjetosEmPlanejamentoBoard();
  const first = await board.items().withColumns([...COLUMNS]).where({ group: [GROUP_ESTEIRA, GROUP_HISTORICO] }).orderBy({ column: "name", direction: "asc" }).withPagination({ limit: 500 }).execute();
  const items = [...first?.items ?? []];
  let cursor = first?.cursor ?? null;
  while (cursor) {
    const next = await board.items().withColumns([...COLUMNS]).withPagination({ limit: 500, cursor }).execute();
    items.push(...next?.items ?? []);
    cursor = next?.cursor ?? null;
  }
  return items;
}
var TTL_AVANCO_MS = 5 * 60 * 1e3;
var cacheAvanco = null;
var avancoEmVoo = null;
async function obterAvanco(force) {
  if (!force && cacheAvanco && Date.now() - cacheAvanco.at < TTL_AVANCO_MS) return cacheAvanco.dados;
  if (!avancoEmVoo) {
    avancoEmVoo = lerAvanco().then((m) => {
      cacheAvanco = { at: Date.now(), dados: Object.fromEntries(m) };
      return cacheAvanco.dados;
    }).finally(() => {
      avancoEmVoo = null;
    });
  }
  if (cacheAvanco && !force) return cacheAvanco.dados;
  return avancoEmVoo;
}
var TTL_MS = 60 * 1e3;
var cache2 = null;
var emVoo = null;
var versao = 0;
var sujo = false;
var frescos = /* @__PURE__ */ new Map();
function invalidarBase() {
  versao++;
  sujo = true;
}
function recarregar() {
  if (emVoo && emVoo.v === versao) return emVoo.p;
  const v0 = versao;
  const p = buscarBase().then((items) => {
    if (versao !== v0) return items;
    const merged = items.map((i) => {
      const f = frescos.get(i.id);
      return f && f.v > v0 ? f.item : i;
    });
    for (const [id2, f] of frescos) if (f.v <= v0) frescos.delete(id2);
    cache2 = { at: Date.now(), items: merged };
    sujo = false;
    return merged;
  }).finally(() => {
    if (emVoo?.p === p) emVoo = null;
  });
  emVoo = { v: v0, p };
  return p;
}
async function obterBase(force) {
  if (!force && !sujo && cache2) {
    if (Date.now() - cache2.at > TTL_MS) {
      recarregar().catch((e) => console.error("Revalida\xE7\xE3o da base 02.01 falhou", e));
    }
    return { items: cache2.items, atualizadoEm: new Date(cache2.at).toISOString() };
  }
  const v = versao;
  let items = await recarregar();
  if (versao !== v) items = await recarregar();
  return { items, atualizadoEm: new Date(cache2?.at ?? Date.now()).toISOString() };
}
async function relerItem(id2) {
  const v = versao;
  const fresh = await new Board0201ProjetosEmPlanejamentoBoard().item(id2).withColumns([...COLUMNS]).execute();
  if (fresh) {
    frescos.set(fresh.id, { v, item: fresh });
    if (cache2) cache2 = { ...cache2, items: cache2.items.map((i) => i.id === fresh.id ? fresh : i) };
  }
  return fresh;
}

// src/generated/server/alocacao.ts
var id = external_exports.string().min(1).max(64);
var dia = external_exports.string().regex(/^\d{4}-\d{2}-\d{2}$/);
var diaOuVazio = external_exports.union([dia, external_exports.literal("")]);
var TIPOS_AJUSTE = ["temperatura", "complexidade", "capacidade", "eixos", "desativado"];
var rot = external_exports.object({
  descricao: external_exports.string().max(600).optional(),
  nomes: external_exports.record(external_exports.string(), external_exports.string().max(300)).optional()
}).optional();
var nomeDe = (r, alvoId) => r?.nomes?.[alvoId] ?? alvoId;
var TIPO_PROJ = { novo: "Novo", reforco: "Refor\xE7o", troca: "Troca" };
async function todos(ref) {
  const out = [];
  let page = await ref.getPage();
  out.push(...page.docs);
  let guard = 0;
  while (page.cursor && guard++ < 50) {
    page = await ref.startAfter(page.cursor).getPage();
    out.push(...page.docs);
  }
  return out;
}
async function lerNucleo() {
  const [ajustes, comentarios, projecoes] = await Promise.all([
    todos(db.collection(alocAjustes).limit(1e3)),
    todos(db.collection(alocComentarios).limit(1e3)),
    todos(db.collection(alocProjecoes).limit(1e3))
  ]);
  return { ajustes, comentarios, projecoes };
}
var getAlocacao = createServerFn({ method: "GET" }).validator(external_exports.object({}).optional()).handler(async () => {
  const [nucleo, historico, importPendentes] = await Promise.all([
    lerNucleo(),
    todos(db.collection(alocHistorico).limit(1e3)),
    todos(db.collection(alocImportPendentes).limit(1e3))
  ]);
  return { ...nucleo, historico, importPendentes };
});
async function upsertAjuste(reg, data, alvo) {
  const existentes = await db.collection(alocAjustes).where("tipo", "==", data.tipo).where("alvoId", "==", data.alvoId).get();
  const doc = { ...data, ...reg.a };
  const [primeiro, ...extras] = existentes;
  await Promise.all(extras.map((e) => reg.remove(alocAjustes, e.id, alvo, e.data)));
  return primeiro ? reg.set(alocAjustes, primeiro.id, doc, alvo, primeiro.data) : reg.add(alocAjustes, doc, alvo);
}
async function apagarAjustes(reg, tipo, alvoId, alvo) {
  const ex = await db.collection(alocAjustes).where("tipo", "==", tipo).where("alvoId", "==", alvoId).get();
  await Promise.all(ex.map((e) => reg.remove(alocAjustes, e.id, alvo, e.data)));
  return ex.length;
}
var salvarAjuste = createServerFn({ method: "POST" }).validator((d) => external_exports.object({
  tipo: external_exports.enum(TIPOS_AJUSTE),
  alvoId: id,
  valor: external_exports.string().max(60),
  valores: external_exports.array(external_exports.string().min(1).max(80)).max(20),
  rot
}).parse(d)).handler(async ({ data }) => {
  const { rot: r, ...x } = data;
  const reg = new Registro(await autoria());
  const alvo = nomeDe(r, x.alvoId);
  await upsertAjuste(reg, x, alvo);
  const desc = r?.descricao ?? (x.tipo === "desativado" ? `Desativado: ${alvo}` : `${AJUSTE_LABEL[x.tipo]} de ${alvo}: \u2192 ${x.valor || x.valores.join(", ") || "\u2014"}`);
  return { acao: await reg.salvar(x.tipo === "desativado" ? "desativar" : "ajuste", desc) };
});
var removerAjuste = createServerFn({ method: "POST" }).validator((d) => external_exports.object({ tipo: external_exports.enum(TIPOS_AJUSTE), alvoId: id, rot }).parse(d)).handler(async ({ data }) => {
  const reg = new Registro(await autoria());
  const alvo = nomeDe(data.rot, data.alvoId);
  const removidos = await apagarAjustes(reg, data.tipo, data.alvoId, alvo);
  const desc = data.rot?.descricao ?? (data.tipo === "desativado" ? `Reativado: ${alvo}` : `${AJUSTE_LABEL[data.tipo]} de ${alvo}: \u2192 calculado`);
  return { removidos, acao: await reg.salvar(data.tipo === "desativado" ? "reativar" : "voltar_calculado", desc) };
});
var ajustesEmMassa = createServerFn({ method: "POST" }).validator((d) => external_exports.object({
  definir: external_exports.array(external_exports.object({ tipo: external_exports.enum(TIPOS_AJUSTE), alvoId: id, valor: external_exports.string().max(60) })).max(1e3),
  remover: external_exports.array(external_exports.object({ tipo: external_exports.enum(TIPOS_AJUSTE), alvoId: id })).max(1e3),
  rot
}).parse(d)).handler(async ({ data }) => {
  const reg = new Registro(await autoria());
  const tarefas = [
    ...data.definir.map((x) => () => upsertAjuste(reg, { ...x, valores: [] }, nomeDe(data.rot, x.alvoId))),
    ...data.remover.map((x) => () => apagarAjustes(reg, x.tipo, x.alvoId, nomeDe(data.rot, x.alvoId)))
  ];
  for (let i = 0; i < tarefas.length; i += 10) await Promise.all(tarefas.slice(i, i + 10).map((t) => t()));
  const alvos = new Set([...data.definir, ...data.remover].map((x) => x.alvoId)).size;
  const acao = await reg.salvar("massa", data.rot?.descricao ?? `A\xE7\xE3o em massa: ${alvos} item(ns)`, { itens: alvos });
  return { definidos: data.definir.length, removidos: data.remover.length, acao };
});
var salvarComentario = createServerFn({ method: "POST" }).validator((d) => external_exports.object({
  escopo: external_exports.enum(["gerente", "projeto"]),
  alvoId: id,
  gerenteId: external_exports.string().max(64),
  texto: external_exports.string().max(2e3),
  rot
}).parse(d)).handler(async ({ data }) => {
  const { rot: r, ...x } = data;
  const reg = new Registro(await autoria());
  const alvo = nomeDe(r, x.alvoId);
  const existentes = await db.collection(alocComentarios).where("escopo", "==", x.escopo).where("alvoId", "==", x.alvoId).where("gerenteId", "==", x.gerenteId).get();
  const texto = x.texto.trim();
  if (!texto) {
    await Promise.all(existentes.map((e) => reg.remove(alocComentarios, e.id, alvo, e.data)));
  } else {
    const [primeiro, ...extras] = existentes;
    await Promise.all(extras.map((e) => reg.remove(alocComentarios, e.id, alvo, e.data)));
    const doc = { ...x, texto, ...reg.a };
    if (primeiro) await reg.set(alocComentarios, primeiro.id, doc, alvo, primeiro.data);
    else await reg.add(alocComentarios, doc, alvo);
  }
  return { acao: await reg.salvar("comentario", r?.descricao ?? `Coment\xE1rio em ${alvo}${texto ? "" : " removido"}`) };
});
var projecaoInput = external_exports.object({
  projetoId: id,
  projetoNome: external_exports.string().max(300),
  destinoTipo: external_exports.enum(["gerente", "cdpe", "novo", "externo"]),
  gerenteId: external_exports.string().max(64),
  gerenteNome: external_exports.string().max(200),
  tipo: external_exports.enum(["novo", "reforco", "troca"])
});
var adicionarProjecao = createServerFn({ method: "POST" }).validator((d) => projecaoInput.extend({ substituirId: external_exports.string().max(64).optional() }).parse(d)).handler(async ({ data }) => {
  const reg = new Registro(await autoria());
  const { substituirId, ...x } = data;
  if (x.destinoTipo === "novo") {
    x.gerenteId = "novo";
    x.gerenteNome = "Novo gerente";
  }
  const col3 = db.collection(alocProjecoes);
  const alvo = `${x.projetoNome} \u2192 ${x.gerenteNome || "CDPE"}`;
  const antiga = substituirId ? await col3.doc(substituirId).get() : null;
  const desc = antiga ? `Troca de proje\xE7\xE3o em ${x.projetoNome}: ${antiga.data.gerenteNome || "CDPE"} \u2192 ${x.gerenteNome || "CDPE"} (${TIPO_PROJ[x.tipo]})` : `Proje\xE7\xE3o (${TIPO_PROJ[x.tipo]}): ${alvo}`;
  const tipoAcao = antiga ? "trocar_projecao" : "projetar";
  const chave = (e) => e.destinoTipo === "cdpe" || e.destinoTipo === "novo" ? e.destinoTipo : `${e.destinoTipo}:${e.gerenteId}`;
  const existentes = (await col3.where("projetoId", "==", x.projetoId).get()).filter((e) => e.id !== substituirId);
  const dup = existentes.find((e) => chave(e.data) === chave(x) && e.data.status === "Pendente");
  if (dup) {
    if (dup.data.tipo !== x.tipo) await reg.update(alocProjecoes, dup.id, { tipo: x.tipo }, alvo, dup.data);
    if (antiga) await reg.remove(alocProjecoes, antiga.id, alvo, antiga.data);
    return { doc: dup, acao: await reg.salvar(tipoAcao, desc) };
  }
  let aguardandoDe = 0;
  if (x.destinoTipo === "gerente") {
    const doGerente = (await col3.where("gerenteId", "==", x.gerenteId).get()).filter((e) => e.id !== substituirId && e.data.destinoTipo === "gerente" && e.data.projetoId !== x.projetoId);
    const pendentes2 = new Set(doGerente.filter((e) => e.data.status === "Pendente").map((e) => e.data.projetoId));
    const validadas = doGerente.filter((e) => e.data.status === "Validada" && !pendentes2.has(e.data.projetoId));
    let aguardando = 0;
    if (validadas.length) {
      const { items } = await obterBase(false);
      const porId = new Map(items.map((i) => [i.id, i]));
      aguardando = new Set(validadas.filter((e) => {
        const p = porId.get(e.data.projetoId);
        return !!p && !(p.gerente?.linkedItems ?? []).some((li) => String(li.id) === x.gerenteId);
      }).map((e) => e.data.projetoId)).size;
    }
    aguardandoDe = aguardando;
    if (pendentes2.size + aguardando >= 3) {
      throw new Error(`Este gerente j\xE1 tem 3 projetos destino (limite)${aguardando ? ` \u2014 inclui ${aguardando} validado(s) aguardando sincronizar com o 02.01` : ""}.`);
    }
  }
  const novo = await reg.add(alocProjecoes, { ...x, status: "Pendente", ...reg.a, validadoPor: "", validadoEm: "" }, alvo);
  if (x.destinoTipo === "gerente") {
    const pend = (await col3.where("gerenteId", "==", x.gerenteId).get()).filter((e) => e.id !== substituirId && e.data.destinoTipo === "gerente" && e.data.status === "Pendente");
    const primeiro = /* @__PURE__ */ new Map();
    for (const e of pend) {
      const em = e.createdAt ?? 0;
      const atual = primeiro.get(e.data.projetoId);
      if (!atual || em < atual.em || em === atual.em && e.id < atual.id) primeiro.set(e.data.projetoId, { em, id: e.id });
    }
    const ordem = [...primeiro.entries()].sort((a, b) => a[1].em - b[1].em || a[1].id.localeCompare(b[1].id)).map(([pid]) => pid);
    if (ordem.length + aguardandoDe > 3 && ordem.indexOf(x.projetoId) >= Math.max(0, 3 - aguardandoDe)) {
      await col3.doc(novo.id).delete();
      throw new Error(`Este gerente j\xE1 tem 3 projetos destino (limite)${aguardandoDe ? ` \u2014 inclui ${aguardandoDe} validado(s) aguardando sincronizar com o 02.01` : ""}.`);
    }
  }
  if (antiga) await reg.remove(alocProjecoes, antiga.id, alvo, antiga.data);
  return { doc: novo, acao: await reg.salvar(tipoAcao, desc) };
});
var removerProjecao = createServerFn({ method: "POST" }).validator((d) => external_exports.object({ id }).parse(d)).handler(async ({ data }) => {
  const reg = new Registro(await autoria());
  const doc = await db.collection(alocProjecoes).doc(data.id).get();
  if (!doc) return { acao: null };
  const alvo = `${doc.data.projetoNome} \u2192 ${doc.data.gerenteNome || "CDPE"}`;
  await reg.remove(alocProjecoes, doc.id, alvo, doc.data);
  return { acao: await reg.salvar("remover_projecao", `Proje\xE7\xE3o removida: ${alvo}`) };
});
var statusProjecoes = createServerFn({ method: "POST" }).validator((d) => external_exports.object({ ids: external_exports.array(id).min(1).max(50), status: external_exports.enum(["Pendente", "Validada"]) }).parse(d)).handler(async ({ data }) => {
  const reg = new Registro(await autoria());
  const col3 = db.collection(alocProjecoes);
  const extra = data.status === "Validada" ? { validadoPor: reg.a.autor, validadoEm: reg.a.em } : { validadoPor: "", validadoEm: "" };
  const docs = (await Promise.all(data.ids.map((i) => col3.doc(i).get()))).flatMap((d) => d ? [d] : []);
  await Promise.all(docs.map((d) => reg.update(alocProjecoes, d.id, { status: data.status, ...extra }, `${d.data.projetoNome} \u2192 ${d.data.gerenteNome || "CDPE"}`, d.data)));
  const projetos = [...new Set(docs.map((d) => d.data.projetoNome))].join("; ");
  const gerentes = [...new Set(docs.map((d) => d.data.gerenteNome || "CDPE"))].join(", ");
  const desc = data.status === "Validada" ? `Validada: ${projetos} \u2192 ${gerentes}` : `Status voltou a Pendente: ${projetos} (${gerentes})`;
  return { atualizados: docs.length, acao: await reg.salvar(data.status === "Validada" ? "validar" : "desfazer_status", desc) };
});
var historicoInput = external_exports.object({
  gerenteId: external_exports.string().max(64),
  gerenteNome: external_exports.string().min(1).max(200),
  projetoNome: external_exports.string().trim().min(1).max(300),
  eixo: external_exports.string().max(80),
  inicio: diaOuVazio,
  fim: diaOuVazio
});
var salvarHistorico = createServerFn({ method: "POST" }).validator((d) => historicoInput.extend({ id: external_exports.string().max(64).optional() }).parse(d)).handler(async ({ data }) => {
  const reg = new Registro(await autoria());
  const { id: docId, ...x } = data;
  const alvo = `${x.projetoNome} (${x.gerenteNome})`;
  if (docId) await reg.set(alocHistorico, docId, { ...x, ...reg.a }, alvo);
  else await reg.add(alocHistorico, { ...x, ...reg.a }, alvo);
  const acao = await reg.salvar(docId ? "historico_editar" : "historico_adicionar", `Hist\xF3rico de ${x.gerenteNome}: ${x.projetoNome} ${docId ? "editado" : "adicionado"}`);
  return { acao };
});
var removerHistorico = createServerFn({ method: "POST" }).validator((d) => external_exports.object({ id }).parse(d)).handler(async ({ data }) => {
  const reg = new Registro(await autoria());
  const doc = await db.collection(alocHistorico).doc(data.id).get();
  if (!doc) return { acao: null };
  await reg.remove(alocHistorico, doc.id, `${doc.data.projetoNome} (${doc.data.gerenteNome})`, doc.data);
  return { acao: await reg.salvar("historico_remover", `Hist\xF3rico de ${doc.data.gerenteNome}: ${doc.data.projetoNome} removido`) };
});
var importarTemperaturas = createServerFn({ method: "POST" }).validator((d) => external_exports.object({
  atualizar: external_exports.array(external_exports.object({ projetoId: id, temp: external_exports.string().min(1).max(60) })).max(500),
  // Each pending line is validated on its own (see handler): a bad line never rejects the whole batch.
  pendentes: external_exports.array(external_exports.unknown()).max(500),
  rot
}).parse(d)).handler(async ({ data }) => {
  const reg = new Registro(await autoria());
  for (const u of data.atualizar) await upsertAjuste(reg, { tipo: "temperatura", alvoId: u.projetoId, valor: u.temp, valores: [] }, nomeDe(data.rot, u.projetoId));
  const corta = (n) => external_exports.string().transform((s) => s.trim().slice(0, n));
  const linha = external_exports.object({ nomeRelatorio: corta(400).pipe(external_exports.string().min(1)), etapa: corta(200), temp: corta(60) });
  const validas = data.pendentes.map((p) => linha.safeParse(p)).flatMap((r) => r.success ? [r.data] : []);
  const antigos = await todos(db.collection(alocImportPendentes).limit(1e3));
  await Promise.all(antigos.map((p) => reg.remove(alocImportPendentes, p.id, `Pendente: ${p.data.nomeRelatorio}`, p.data)));
  for (const p of validas) await reg.add(alocImportPendentes, { ...p, ...reg.a }, `Pendente: ${p.nomeRelatorio}`);
  const acao = await reg.salvar(
    "importacao",
    data.rot?.descricao ?? `Importa\xE7\xE3o de PDF: ${data.atualizar.length} temperatura(s), ${validas.length} pendente(s) (lista anterior de ${antigos.length} substitu\xEDda)`,
    { itens: data.atualizar.length + validas.length }
  );
  return { atualizados: data.atualizar.length, pendentes: validas.length, rejeitados: data.pendentes.length - validas.length, acao };
});
var removerImportPendente = createServerFn({ method: "POST" }).validator((d) => external_exports.object({ id }).parse(d)).handler(async ({ data }) => {
  const reg = new Registro(await autoria());
  const doc = await db.collection(alocImportPendentes).doc(data.id).get();
  if (!doc) return { acao: null };
  await reg.remove(alocImportPendentes, doc.id, `Pendente: ${doc.data.nomeRelatorio}`, doc.data);
  return { acao: await reg.salvar("descartar_pendente", `Pendente descartado: ${doc.data.nomeRelatorio}`) };
});
var diasRegra = external_exports.number().int().min(1).max(3650);
var regraInput = external_exports.object({ curtoDias: diasRegra, medioDias: diasRegra, longoDias: diasRegra }).refine((r) => r.curtoDias < r.medioDias && r.medioDias < r.longoDias, { message: "As faixas devem ser crescentes: Curto < M\xE9dio < Longo." });
var getRegraCapacidade = createServerFn({ method: "GET" }).validator(external_exports.object({}).optional()).handler(async () => {
  const [doc] = await db.collection(alocRegraCapacidade).limit(1).get();
  return doc ? { curtoDias: doc.data.curtoDias, medioDias: doc.data.medioDias, longoDias: doc.data.longoDias } : null;
});
var salvarRegraCapacidade = createServerFn({ method: "POST" }).validator((d) => regraInput.parse(d)).handler(async ({ data }) => {
  const reg = new Registro(await autoria());
  const [existente] = await db.collection(alocRegraCapacidade).limit(1).get();
  const doc = { ...data, ...reg.a };
  const alvo = "Regra de capacidade";
  if (existente) await reg.set(alocRegraCapacidade, existente.id, doc, alvo, existente.data);
  else await reg.add(alocRegraCapacidade, doc, alvo);
  const desc = `Regra de capacidade: Curto at\xE9 ${data.curtoDias} d \xB7 M\xE9dio at\xE9 ${data.medioDias} d \xB7 Longo at\xE9 ${data.longoDias} d`;
  return { acao: await reg.salvar("regra_capacidade", desc) };
});
var resetRegraCapacidade = createServerFn({ method: "POST" }).validator(external_exports.object({}).optional()).handler(async () => {
  const reg = new Registro(await autoria());
  const existentes = await db.collection(alocRegraCapacidade).limit(10).get();
  await Promise.all(existentes.map((e) => reg.remove(alocRegraCapacidade, e.id, "Regra de capacidade", e.data)));
  return { acao: await reg.salvar("regra_capacidade", "Regra de capacidade: voltou ao padr\xE3o (30 / 60 / 90 dias)") };
});

// src/generated/server/mapa.ts
var mapa_exports = {};
__export(mapa_exports, {
  getGerentesRelacao: () => getGerentesRelacao,
  getMapaGerentes: () => getMapaGerentes
});

// src/generated/lib/nomes.ts
function normNome(s) {
  return (s ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s+/g, " ").trim();
}

// src/generated/server/gerentes-cadastro.ts
var TTL_MS2 = 10 * 60 * 1e3;
var cache3 = null;
async function listarGerentesCadastro(force = false) {
  if (!force && cache3 && Date.now() - cache3.at < TTL_MS2) return cache3.value;
  const board = new MapaDeGerentesDeProjetoBoard();
  const first = await board.items().withColumns(["atividadeAtual"]).where({ group: [GRUPO_CADASTRO_MAPA] }).withPagination({ limit: 500 }).execute();
  const items = [...first?.items ?? []];
  let cursor = first?.cursor ?? null;
  while (cursor) {
    const next = await board.items().withColumns(["atividadeAtual"]).withPagination({ limit: 500, cursor }).execute();
    items.push(...next?.items ?? []);
    cursor = next?.cursor ?? null;
  }
  const value = items.filter((i) => i.group?.id === GRUPO_CADASTRO_MAPA && normNome(i.atividadeAtual) === "gerente").map((i) => ({ id: String(i.id), name: i.name?.trim() ?? "" })).filter((g) => g.name).sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));
  cache3 = { at: Date.now(), value };
  return value;
}
async function gerentesValidos(ids) {
  let validos = new Set((await listarGerentesCadastro()).map((g) => g.id));
  if (ids.some((id2) => !validos.has(id2))) validos = new Set((await listarGerentesCadastro(true)).map((g) => g.id));
  return validos;
}

// src/generated/server/mapa-dados.ts
var COLS = [
  "perfil",
  "certificaoPmi",
  "processoDeQualificao",
  "status",
  "atividadeAtual",
  "statusProjeto",
  "projetosGerenciados",
  "alocaoNoProjeto",
  "fimAtuao",
  "sadaDoProjeto",
  "perodoNoProjeto",
  "compexidadeDoProjeto",
  "avDesempenho",
  "totalProjetos",
  "email",
  "local"
];
var iso = (v) => {
  if (!v) return null;
  if (v instanceof Date) return Number.isNaN(v.getTime()) ? null : v.toISOString().slice(0, 10);
  const s = String(v).trim();
  return /^\d{4}-\d{2}-\d{2}/.test(s) ? s.slice(0, 10) : null;
};
var num = (v) => typeof v === "number" && Number.isFinite(v) ? v : null;
var media = (v) => {
  const n = v.filter((x) => x !== null);
  return n.length ? n.reduce((a, b) => a + b, 0) / n.length : null;
};
async function montarMapa() {
  const board = new MapaDeGerentesDeProjetoBoard();
  const first = await board.items().withColumns([...COLS]).withPagination({ limit: 500 }).execute();
  const items = [...first?.items ?? []];
  let cursor = first?.cursor ?? null;
  while (cursor) {
    const next = await board.items().withColumns([...COLS]).withPagination({ limit: 500, cursor }).execute();
    items.push(...next?.items ?? []);
    cursor = next?.cursor ?? null;
  }
  const cadastro = items.filter((i) => i.group?.id === GRUPO_CADASTRO_MAPA);
  const alocacoes = items.filter((i) => i.group?.id !== GRUPO_CADASTRO_MAPA);
  const hoje = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const aloPorNome = /* @__PURE__ */ new Map();
  for (const a of alocacoes) {
    const k = normNome(a.group?.title);
    if (k) aloPorNome.set(k, [...aloPorNome.get(k) ?? [], a]);
  }
  const montar = (c, nome, alos) => {
    const fimAlos = alos.map((a) => iso(a.fimAtuao?.to ?? a.fimAtuao?.from) ?? iso(a.sadaDoProjeto)).filter((d) => !!d).sort();
    const fim = iso(c?.fimAtuao?.to ?? c?.fimAtuao?.from) ?? fimAlos.find((d) => d >= hoje) ?? fimAlos[fimAlos.length - 1] ?? null;
    const projetoIds = /* @__PURE__ */ new Set();
    for (const x of [c, ...alos]) for (const li of x?.projetosGerenciados?.linkedItems ?? []) projetoIds.add(String(li.id));
    return {
      id: c?.id ?? `grupo:${normNome(nome)}`,
      nome,
      nomeNorm: normNome(nome),
      cadastrado: !!c,
      perfil: c?.perfil ?? [],
      pmi: c?.certificaoPmi ?? [],
      qualificacao: c?.processoDeQualificao ?? [],
      statusQualificacao: c?.status ?? null,
      atividadeAtual: c?.atividadeAtual ?? null,
      email: c?.email?.email ?? null,
      local: c?.local?.city || c?.local?.address || null,
      fimAtuacao: fim,
      desempenho: num(c?.avDesempenho) ?? media(alos.map((a) => num(a.avDesempenho))),
      complexidade: num(c?.compexidadeDoProjeto) ?? media(alos.map((a) => num(a.compexidadeDoProjeto))),
      totalProjetosMapa: c?.totalProjetos && c.totalProjetos !== "null" ? c.totalProjetos : null,
      itemIds: [c?.id, ...alos.map((a) => a.id)].filter((x) => !!x),
      projetoIds: [...projetoIds],
      alocacoes: alos.map((a) => ({
        id: a.id,
        nome: a.name,
        statusProjeto: a.statusProjeto ?? null,
        projetoIds: (a.projetosGerenciados?.linkedItems ?? []).map((li) => String(li.id)),
        fim: iso(a.fimAtuao?.to ?? a.fimAtuao?.from),
        inicio: iso(a.fimAtuao?.from),
        projetoNomes: (a.projetosGerenciados?.linkedItems ?? []).map((li) => li.name ?? "").filter(Boolean),
        saida: iso(a.sadaDoProjeto),
        periodo: a.perodoNoProjeto && a.perodoNoProjeto !== "null" ? a.perodoNoProjeto : null
      }))
    };
  };
  const gerentes = cadastro.map((c) => montar(c, c.name, aloPorNome.get(normNome(c.name)) ?? []));
  const conhecidos = new Set(gerentes.map((g) => g.nomeNorm));
  for (const [k, alos] of aloPorNome) {
    if (!conhecidos.has(k)) gerentes.push(montar(null, alos[0]?.group?.title ?? k, alos));
  }
  gerentes.sort((a, b) => a.nome.localeCompare(b.nome, "pt-BR"));
  return {
    gerentes,
    resumo: { cadastro: cadastro.length, alocacoes: alocacoes.length, grupos: aloPorNome.size }
  };
}
var TTL_MAPA_MS = 60 * 1e3;
var mapaCache = null;
var mapaEmVoo = null;
var mapaVersao = 0;
var mapaSujo = false;
function invalidarMapa() {
  mapaVersao++;
  mapaSujo = true;
}
function recarregarMapa() {
  if (mapaEmVoo && mapaEmVoo.v === mapaVersao) return mapaEmVoo.p;
  const v0 = mapaVersao;
  const p = montarMapa().then((value) => {
    if (mapaVersao === v0) {
      mapaCache = { at: Date.now(), value };
      mapaSujo = false;
    }
    return value;
  }).finally(() => {
    if (mapaEmVoo?.p === p) mapaEmVoo = null;
  });
  mapaEmVoo = { v: v0, p };
  return p;
}
async function obterMapa(force) {
  if (!force && !mapaSujo && mapaCache) {
    if (Date.now() - mapaCache.at > TTL_MAPA_MS) {
      recarregarMapa().catch((e) => console.error("Revalida\xE7\xE3o do Mapa de Gerentes falhou", e));
    }
    return mapaCache.value;
  }
  return recarregarMapa();
}

// src/generated/server/mapa.ts
var getGerentesRelacao = createServerFn({ method: "POST" }).validator((d) => external_exports.object({ force: external_exports.boolean().optional() }).parse(d ?? {})).handler(async ({ data }) => {
  return { gerentes: await listarGerentesCadastro(!!data.force) };
});
var getMapaGerentes = createServerFn({ method: "POST" }).validator((d) => external_exports.object({ force: external_exports.boolean().optional() }).parse(d ?? {})).handler(async ({ data }) => obterMapa(!!data?.force));

// src/generated/server/opcoes-edicao.ts
var opcoes_edicao_exports = {};
__export(opcoes_edicao_exports, {
  getOpcoesEdicao: () => getOpcoesEdicao
});

// src/generated/lib/board-options.ts
var OPT = {
  statusPlanejamento: [
    "Em andamento",
    "Em replanejamento",
    "Em revis\xE3o",
    "Planejado aguardando assinatura",
    "Instrumento Conclu\xEDdo",
    "Finalizado (Plan + SGI)",
    "Pausado",
    "Novo Cadastro - 30 a 45 dias",
    "Novo Cadastro - 45 a 60 dias",
    "Despriorizado",
    "Sem planejamento [ANTIGOS]"
  ],
  statusSgi: [
    "N\xE3o Iniciado",
    "Aguardando planejamento",
    "Aguardando cadastro no SGI",
    "Em registro no SGI",
    "Em valida\xE7\xE3o no SGI",
    "Validado no SGI",
    "TAP Reprovado",
    "Pausado",
    "Despriorizado",
    "Sem planejamento [ANTIGOS]"
  ],
  prioridade: ["Cr\xEDtico", "Alta", "M\xE9dia", "Baixa", "N\xE3o"],
  radarMonitoramento: ["Alta Prob. de Repactua\xE7\xE3o", "Crono Produtos Pactuado", "Crono Produtos em Constru\xE7\xE3o"],
  alocaoDeEquipe: ["Equipe alocada", "Sem equipe", "N\xE3o preenchido", "Verificar"],
  dimensionamentoConcludo: ["Conclu\xEDdo", "N\xE3o conclu\xEDdo"],
  eixo: [
    "Gest\xE3o Estrat\xE9gica",
    "Alfabetiza\xE7\xE3o",
    "Gest\xE3o para a aprendizagem",
    "Gest\xE3o p\xFAblica",
    "Educa\xE7\xE3o profissional e tecnol\xF3gica",
    "Educa\xE7\xE3o de jovens e adultos",
    "Forma\xE7\xE3o continuada",
    "Pesquisas e estudos"
  ],
  uf: [
    "AC",
    "AL",
    "AP",
    "AM",
    "BA",
    "CE",
    "DF",
    "ES",
    "GO",
    "MA",
    "MT",
    "MS",
    "MG",
    "PA",
    "PB",
    "PR",
    "PE",
    "PI",
    "RJ",
    "RN",
    "RS",
    "RO",
    "RR",
    "SC",
    "SP",
    "SE",
    "TO",
    "BR",
    "INT"
  ],
  tipoPlanejamento: ["Revis\xE3o", "Antigo Sem Planejamento", "Novo Contrato", "Planejamento antigo", "Novo Aditivo"],
  gerente1: [
    "Victor Martins Feitosa",
    "Leonardo Milhomem Rezende",
    "Adriana Matos Seidel",
    "Ana Angela de Medeiros Sousa",
    "Bruna Luisa Martins Barbosa",
    "Bruno de Toledo Martins",
    "Camila Nolasco dos Passos",
    "Caroline Almeida Martins",
    "Catherine de Sa Paixao Teixeira",
    "Claudia Maria Micheluci Petri",
    "Gabriel Guedes Gama de Lima",
    "Isabelle dos Santos Neles",
    "Ives Nahama Gomes",
    "Jaana Flavia Fernandes Nogueira",
    "Joseph Razouk Junior",
    "Juliana Mattedi Dalvi",
    "Kate Dayana Rodrigues de Abreu",
    "Luiz Felipe Espinola",
    "Mariana Holanda Carvalho Fireman",
    "Mariana Ribeiro do Nascimento",
    "Nathalia de Paula Vieira",
    "Rafael Gotti Guimaraes",
    "Rafaela Caruline Rodrigues",
    "Raquel Breda dos Santos",
    "Renata Tenorio de Melo",
    "Ricardo dos Santos Batista",
    "Tamires Matos de Paula Goncalves",
    "Thales Henrique Pereira",
    "Tullia Maria Ribeiro Oliveira Erseni",
    "Vinicius Evangelista da Costa",
    "Roberta Fernanda Cesar Correia de Albuquerque Santana",
    "Vivyane Caldeira",
    "Daniela Ribeiro Guarieiro",
    "Kheitt Lamas",
    "Tatiana Barcelos",
    "Layla Nayara Gomes da Silva",
    "Luana Galeno",
    "Bruna dos Santos Lersch",
    "Isabella Nogueira",
    "Roberto Rocha Leandro",
    "Gustavo Wei",
    "Tullio Monteiro Prota",
    "Fabio dos Anjos",
    "Umberto Bezerra Neto",
    "Adirce Senna",
    "Vitor Knobl Moneo",
    "camil",
    "Aline Bocamino"
  ].sort((a, b) => a.localeCompare(b, "pt-BR"))
};

// src/generated/server/opcoes-edicao.ts
var BOARD_ID2 = "18412010674";
var STATUS_COLS = {
  statusPlanejamento: "color_mm3axm14",
  statusSgi: "color_mm34f2he",
  prioridade: "color_mm33f6am",
  radarMonitoramento: "color_mm3zcq9z",
  alocaoDeEquipe: "color_mm766rs9",
  dimensionamentoConcludo: "color_mm7y8hwt"
};
var DROPDOWN_COLS = {
  eixo: "dropdown_mm38v0xw",
  uf: "dropdown_mm3815pa",
  tipoPlanejamento: "dropdown_mm3a5hsg",
  gerente1: "dropdown_mm6v1tw6"
};
var TTL_MS3 = 10 * 60 * 1e3;
var cache4 = null;
var asObj = (v) => v && typeof v === "object" ? v : {};
function parseSettings(raw) {
  if (typeof raw === "string") {
    try {
      return asObj(JSON.parse(raw));
    } catch {
      return {};
    }
  }
  return asObj(raw);
}
function deactivatedIds(s) {
  const d = s.deactivated_labels;
  return new Set(Array.isArray(d) ? d.map((x) => String(typeof x === "object" && x ? asObj(x).id : x)) : []);
}
function statusLabels(s) {
  const off = deactivatedIds(s);
  const labels = s.labels;
  if (Array.isArray(labels)) {
    return labels.map((l) => asObj(l)).filter((l) => !l.is_deactivated && !off.has(String(l.id))).map((l) => ({ name: String(l.label ?? l.name ?? "").trim(), pos: Number(l.index ?? l.position ?? 0) })).filter((l) => l.name).sort((a, b) => a.pos - b.pos).map((l) => l.name);
  }
  const map = asObj(labels);
  const pos = asObj(s.labels_positions_v2);
  return Object.entries(map).filter(([id2, name]) => typeof name === "string" && name.trim() && !off.has(id2)).map(([id2, name]) => ({ name: String(name).trim(), pos: Number(pos[id2] ?? id2) })).sort((a, b) => a.pos - b.pos).map((l) => l.name);
}
function dropdownLabels(s) {
  const off = deactivatedIds(s);
  const labels = Array.isArray(s.labels) ? s.labels : [];
  const names = labels.map((l) => asObj(l)).filter((l) => !l.is_deactivated && !off.has(String(l.id))).map((l) => String(l.name ?? l.label ?? "").trim()).filter(Boolean);
  return [...new Set(names)].sort((a, b) => a.localeCompare(b, "pt-BR"));
}
async function lerColunas(field) {
  const board = new Board0201ProjetosEmPlanejamentoBoard();
  const ids = [...Object.values(STATUS_COLS), ...Object.values(DROPDOWN_COLS)];
  const query = `query ($board: [ID!], $cols: [String]) { boards(ids: $board) { columns(ids: $cols) { id type ${field} } } }`;
  const res = await board.executeGraphQL(query, { board: [BOARD_ID2], cols: ids });
  const cols = res?.boards?.[0]?.columns ?? [];
  const byId = new Map(cols.map((c) => {
    const o = asObj(c);
    return [String(o.id), parseSettings(o[field])];
  }));
  if (!byId.size) throw new Error("Configura\xE7\xE3o das colunas n\xE3o retornada.");
  return byId;
}
async function carregar() {
  let byId;
  try {
    byId = await lerColunas("settings_str");
  } catch (e) {
    console.error("Leitura via settings_str falhou; tentando settings", e);
    byId = await lerColunas("settings");
  }
  const out = {};
  for (const [k, id2] of Object.entries(STATUS_COLS)) {
    const v = statusLabels(byId.get(id2) ?? {});
    out[k] = v.length ? v : OPT[k];
  }
  for (const [k, id2] of Object.entries(DROPDOWN_COLS)) {
    const v = dropdownLabels(byId.get(id2) ?? {});
    out[k] = v.length ? v : [...OPT[k]].sort((a, b) => a.localeCompare(b, "pt-BR"));
  }
  return out;
}
var getOpcoesEdicao = createServerFn({ method: "POST" }).validator((d) => external_exports.object({ force: external_exports.boolean().optional() }).parse(d ?? {})).handler(async ({ data }) => {
  if (!data.force && cache4 && Date.now() - cache4.at < TTL_MS3) {
    return { fonte: "quadro", opts: cache4.value, atualizadoEm: new Date(cache4.at).toISOString() };
  }
  try {
    const value = await carregar();
    cache4 = { at: Date.now(), value };
    return { fonte: "quadro", opts: value, atualizadoEm: new Date(cache4.at).toISOString() };
  } catch (e) {
    console.error("Falha ao ler op\xE7\xF5es das colunas do quadro 02.01", e);
    const local = { ...OPT, gerente1: OPT.gerente1 };
    return { fonte: "local", opts: local, atualizadoEm: null };
  }
});

// src/generated/server/projetos.ts
var projetos_exports = {};
__export(projetos_exports, {
  changesSchema: () => changesSchema,
  getAvanco: () => getAvanco,
  getBase: () => getBase,
  getMe: () => getMe,
  gravarAlocacao: () => gravarAlocacao,
  relerProjeto: () => relerProjeto,
  updateProjeto: () => updateProjeto
});
var getBase = createServerFn({ method: "POST" }).validator((d) => external_exports.object({ force: external_exports.boolean().optional() }).parse(d ?? {})).handler(async ({ data }) => {
  return obterBase(!!data.force);
});
var getAvanco = createServerFn({ method: "POST" }).validator((d) => external_exports.object({ force: external_exports.boolean().optional() }).parse(d ?? {})).handler(async ({ data }) => obterAvanco(!!data.force));
var getMe = createServerFn({ method: "GET" }).validator(external_exports.object({}).optional()).handler(async () => {
  try {
    const me = await new Board0201ProjetosEmPlanejamentoBoard().users.me().execute();
    return { id: me?.id ? String(me.id) : null };
  } catch (e) {
    console.error("N\xE3o foi poss\xEDvel identificar o usu\xE1rio atual", e);
    return { id: null };
  }
});
var statusField = external_exports.string().min(1).nullable().optional();
var dateField = external_exports.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().optional();
var numField = external_exports.number().finite().nullable().optional();
var ddField = external_exports.array(external_exports.string().min(1)).optional();
var changesSchema = external_exports.object({
  statusPlanejamento: statusField,
  statusSgi: statusField,
  prioridade: statusField,
  radarMonitoramento: statusField,
  alocaoDeEquipe: statusField,
  dimensionamentoConcludo: statusField,
  incioPlanejamento: dateField,
  conclusoDoPlanejamento: dateField,
  conclusoRegistroSgi: dateField,
  conclusoDoDimensionamento: dateField,
  dataValidaoSgi: dateField,
  /** Alocação Gerente — written by the Validação step of "Alocação de Gerentes". */
  alocaoGerente: dateField,
  valorDoContrato: numField,
  equipeOr: numField,
  equipePlan: numField,
  oradoInsumos: numField,
  planejadoInsumos: numField,
  oradoTotal: numField,
  planejadoTotal: numField,
  eixo: ddField,
  uf: ddField,
  tipoPlanejamento: ddField,
  gerente1: ddField,
  /** "Gerente" relation → items of the Mapa de Gerentes (written on 02.01 only). */
  gerente: external_exports.object({ linkedItems: external_exports.array(external_exports.object({ id: external_exports.string().regex(/^\d+$/) })).max(5) }).nullable().optional()
}).strict();
var relerProjeto = createServerFn({ method: "POST" }).validator((d) => external_exports.object({ id: external_exports.string().regex(/^\d+$/) }).parse(d)).handler(async ({ data }) => ({ item: await relerItem(data.id) }));
var updateProjeto = createServerFn({ method: "POST" }).validator((d) => external_exports.object({ id: external_exports.string().min(1), changes: changesSchema }).parse(d)).handler(async ({ data }) => {
  const board = new Board0201ProjetosEmPlanejamentoBoard();
  const { gerente, ...outros } = data.changes;
  let resto = Object.fromEntries(Object.entries(outros).filter(([, v]) => v !== void 0));
  if (!Object.keys(resto).length && gerente === void 0) throw new Error("Nenhuma altera\xE7\xE3o para salvar.");
  let erroRelacao = null;
  let ddMantido = false;
  if (gerente !== void 0) {
    try {
      const ids = gerente?.linkedItems.map((i) => i.id) ?? [];
      if (ids.length) {
        const validos = await gerentesValidos(ids);
        if (ids.some((id2) => !validos.has(id2))) {
          erroRelacao = "O gerente escolhido n\xE3o est\xE1 no grupo \u201CGerentes\u201D do Mapa com Atividade Atual = GERENTE.";
        }
      }
      if (!erroRelacao) {
        await board.item(data.id).update({ gerente }).execute();
        invalidarBase();
        invalidarMapa();
      }
    } catch (e) {
      console.error("Falha ao gravar a rela\xE7\xE3o Gerente", e);
      erroRelacao = "O monday recusou a grava\xE7\xE3o do v\xEDnculo com o Mapa de Gerentes. Verifique sua permiss\xE3o no quadro 02.01 e se o item do gerente ainda existe.";
    }
    if (erroRelacao && resto.gerente1 !== void 0) {
      const { gerente1: _ignorado, ...semDd } = resto;
      void _ignorado;
      resto = semDd;
      ddMantido = true;
    }
  }
  if (Object.keys(resto).length) {
    try {
      await board.item(data.id).update(resto).execute();
    } finally {
      invalidarBase();
    }
  }
  const fresh = await relerItem(data.id);
  if (!fresh) throw new Error("Item salvo, mas n\xE3o foi poss\xEDvel recarreg\xE1-lo do quadro.");
  return { item: fresh, erroRelacao, ddMantido, outrosGravados: Object.keys(resto).length };
});
var gravarAlocacao = createServerFn({ method: "POST" }).validator((d) => external_exports.object({
  id: external_exports.string().min(1),
  gerenteIds: external_exports.array(external_exports.string().regex(/^\d+$/)).min(1).max(3),
  labels: external_exports.array(external_exports.string().trim().min(1)).min(1).max(3),
  data: external_exports.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  /** substituir = novo/troca (relation becomes the projected managers); adicionar = reforço (added to the current ones). */
  modo: external_exports.enum(["substituir", "adicionar"])
}).parse(d)).handler(async ({ data }) => {
  const validos = await gerentesValidos(data.gerenteIds);
  if (data.gerenteIds.some((id2) => !validos.has(id2))) {
    throw new Error("Um dos gerentes n\xE3o est\xE1 no grupo \u201CGerentes\u201D do Mapa com Atividade Atual = GERENTE. Nada foi gravado.");
  }
  const board = new Board0201ProjetosEmPlanejamentoBoard();
  let ids = [...new Set(data.gerenteIds)];
  let labels = [...new Set(data.labels)];
  if (data.modo === "adicionar") {
    const atual = await board.item(data.id).withColumns(["gerente", "gerente1"]).execute();
    const idsAtuais = (atual?.gerente?.linkedItems ?? []).map((li) => String(li.id));
    ids = [.../* @__PURE__ */ new Set([...idsAtuais, ...ids])];
    const norm2 = (s) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toLowerCase();
    const porNorm = /* @__PURE__ */ new Map();
    for (const l of [...atual?.gerente1 ?? [], ...labels]) if (l.trim() && !porNorm.has(norm2(l))) porNorm.set(norm2(l), l.trim());
    labels = [...porNorm.values()];
  }
  if (ids.length > 3 || labels.length > 3) {
    throw new Error(`O projeto ficaria com ${Math.max(ids.length, labels.length)} gerentes \u2014 o m\xE1ximo \xE9 3. Nada foi gravado.`);
  }
  let avisoDropdown = null;
  try {
    try {
      await escreverComNovosRotulos(data.id, ids, labels, data.data);
    } catch (e1) {
      console.error("Escrita com cria\xE7\xE3o de r\xF3tulos falhou; tentando a escrita padr\xE3o", data.id, e1);
      try {
        await board.item(data.id).update({ gerente: { linkedItems: ids.map((id2) => ({ id: id2 })) }, gerente1: labels, alocaoGerente: data.data }).execute();
      } catch (e2) {
        console.error("Escrita padr\xE3o falhou; gravando s\xF3 rela\xE7\xE3o + Aloca\xE7\xE3o Gerente", data.id, e2);
        await board.item(data.id).update({ gerente: { linkedItems: ids.map((id2) => ({ id: id2 })) }, alocaoGerente: data.data }).execute();
        avisoDropdown = "O dropdown \u201CGerente\u201D n\xE3o foi atualizado (r\xF3tulo inexistente ou sem permiss\xE3o para criar). Rela\xE7\xE3o e Aloca\xE7\xE3o Gerente foram gravadas.";
      }
    }
  } catch (e) {
    console.error("Falha ao gravar a valida\xE7\xE3o no 02.01", data.id, e);
    throw new Error("O monday recusou a grava\xE7\xE3o (Gerente, dropdown e Aloca\xE7\xE3o Gerente). Nada foi gravado neste projeto.");
  } finally {
    invalidarBase();
    invalidarMapa();
  }
  let item = null;
  try {
    item = await relerItem(data.id);
  } catch (e) {
    console.error("Valida\xE7\xE3o gravada, mas o item n\xE3o foi relido", e);
  }
  return { item, avisoDropdown };
});
var COL_REL_GERENTE = "board_relation_mm5egrbf";
var COL_DD_GERENTE = "dropdown_mm6v1tw6";
var COL_ALOC_GERENTE = "date_mm33vrwt";
async function escreverComNovosRotulos(itemId, gerenteIds, labels, dataIso) {
  const api = await getServerApiClient();
  const valores = {
    [COL_REL_GERENTE]: { item_ids: gerenteIds.map(Number) },
    [COL_DD_GERENTE]: { labels },
    [COL_ALOC_GERENTE]: { date: dataIso }
  };
  await api.client.request(
    `mutation ($board: ID!, $item: ID!, $values: JSON!) {
      change_multiple_column_values(board_id: $board, item_id: $item, column_values: $values, create_labels_if_missing: true) { id }
    }`,
    { board: BOARD_ID, item: itemId, values: JSON.stringify(valores) }
  );
}

// src/generated/server/snapshots.ts
var snapshots_exports = {};
__export(snapshots_exports, {
  gravarSnapshot: () => gravarSnapshot,
  listarSnapshots: () => listarSnapshots
});
var metricas = external_exports.object({
  semana: external_exports.string().regex(/^\d{4}-W\d{2}$/),
  inicioSemana: external_exports.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  emPlanejamento: external_exports.number().int().min(0).max(1e5),
  pctNoPrazo: external_exports.number().min(0).max(100).nullable(),
  saldoTotal: external_exports.number().finite(),
  saldoInsumo: external_exports.number().finite(),
  saldoEquipe: external_exports.number().finite(),
  mediaAtivosPorGerente: external_exports.number().min(0).max(1e3).nullable()
});
var listarSnapshots = createServerFn({ method: "GET" }).validator(external_exports.object({}).optional()).handler(async () => {
  const out = [];
  let page = await db.collection(snapshotsSemanais).orderBy("semana", "asc").limit(200).getPage();
  out.push(...page.docs);
  for (let i = 0; page.cursor && i < 10; i++) {
    page = await db.collection(snapshotsSemanais).orderBy("semana", "asc").limit(200).startAfter(page.cursor).getPage();
    out.push(...page.docs);
  }
  return out.map((d) => d.data);
});
var gravarSnapshot = createServerFn({ method: "POST" }).validator((d) => metricas.parse(d)).handler(async ({ data }) => {
  const col3 = db.collection(snapshotsSemanais);
  const [atual, ...extras] = await col3.where("semana", "==", data.semana).get();
  await Promise.all(extras.map((e) => col3.doc(e.id).delete()));
  const doc = { ...data, em: (/* @__PURE__ */ new Date()).toISOString() };
  if (atual) await col3.doc(atual.id).set(doc);
  else await col3.add(doc);
  return { ok: true };
});

// server/registry.ts
var MODULES = {
  "acoes": acoes_exports,
  "alocacao": alocacao_exports,
  "mapa": mapa_exports,
  "opcoes-edicao": opcoes_edicao_exports,
  "projetos": projetos_exports,
  "snapshots": snapshots_exports
};

// server/index.ts
var FNS = /* @__PURE__ */ new Map();
for (const [mod, exp] of Object.entries(MODULES)) {
  for (const [name, v] of Object.entries(exp)) {
    if (typeof v === "function" && v.__serverFn) FNS.set(`${mod}:${name}`, v);
  }
}
var PUBLIC = import_node_path.default.join(__dirname, "public");
var MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".mjs": "text/javascript", ".css": "text/css", ".png": "image/png", ".svg": "image/svg+xml", ".json": "application/json", ".woff2": "font/woff2" };
function b64url(buf) {
  return buf.toString("base64").replace(/=+$/, "").replace(/\+/g, "-").replace(/\//g, "_");
}
function verifySession(token) {
  const secret = process.env.CLIENT_SECRET;
  if (!secret || !token) return null;
  const parts = token.replace(/^Bearer\s+/i, "").split(".");
  if (parts.length !== 3) return null;
  const sig = b64url((0, import_node_crypto4.createHmac)("sha256", secret).update(`${parts[0]}.${parts[1]}`).digest());
  const a = Buffer.from(sig), b = Buffer.from(parts[2]);
  if (a.length !== b.length || !(0, import_node_crypto4.timingSafeEqual)(a, b)) return null;
  try {
    const p = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
    if (p.exp && p.exp * 1e3 < Date.now()) return null;
    const d = p.dat ?? p;
    if (!d.user_id) return null;
    lembrarCliente(d.client_id, d.account_id);
    return { userId: String(d.user_id), accountId: String(d.account_id ?? ""), isAdmin: d.is_admin === true, isGuest: d.is_guest === true || d.user_kind === "guest" };
  } catch {
    return null;
  }
}
function send(res, status, body) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(body));
}
async function readBody(req, max = 60 * 1024 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > max) throw new Error("Envio grande demais.");
    chunks.push(c);
  }
  return Buffer.concat(chunks).toString("utf8");
}
function zodMessage(e) {
  const issues = e?.issues;
  if (!Array.isArray(issues)) return null;
  return "Dados inv\xE1lidos: " + issues.slice(0, 3).map((i) => `${(i.path ?? []).join(".")}: ${i.message}`).join("; ");
}
var server = import_node_http.default.createServer(async (req, res) => {
  const url = new URL(req.url ?? "/", "http://x");
  const p = url.pathname;
  try {
    if (req.method === "POST" && p.startsWith("/_fn/")) {
      const id2 = decodeURIComponent(p.slice(5));
      const fn = FNS.get(id2);
      if (!fn) return send(res, 404, { ok: false, error: `Fun\xE7\xE3o n\xE3o encontrada: ${id2}` });
      const ctx = verifySession(String(req.headers.authorization ?? ""));
      if (!ctx) return send(res, 401, { ok: false, error: "Sess\xE3o do monday inv\xE1lida ou expirada. Recarregue a p\xE1gina." });
      const body = JSON.parse(await readBody(req) || "{}");
      const callId = String(req.headers["x-call-id"] ?? "");
      if (/^[a-f0-9]{16,64}$/.test(callId)) ctx.callId = callId;
      try {
        const result = await reqCtx.run(ctx, () => fn.run(body?.data ?? void 0));
        return send(res, 200, { ok: true, result: result ?? null });
      } catch (e) {
        const msg = zodMessage(e) ?? (e instanceof Error ? e.message : String(e));
        console.error(`[fn ${id2}]`, msg);
        return send(res, 200, { ok: false, error: msg.slice(0, 1e3) });
      } finally {
        ctx.encerrada = true;
      }
    }
    if (req.method === "POST" && (p === "/_mut/pendentes" || p === "/_mut/resultado")) {
      const ctx = verifySession(String(req.headers.authorization ?? ""));
      if (!ctx) return send(res, 401, { ok: false, error: "Sess\xE3o do monday inv\xE1lida ou expirada. Recarregue a p\xE1gina." });
      const b = JSON.parse(await readBody(req, 20 * 1024 * 1024) || "{}");
      if (p === "/_mut/pendentes") {
        const callId = String(b?.callId ?? "");
        if (!/^[a-f0-9]{16,64}$/.test(callId)) return send(res, 400, { ok: false });
        return send(res, 200, { ok: true, result: await pendentes(callId, ctx.userId) });
      }
      await registrarResultado(String(b?.id ?? ""), ctx.userId, b?.resposta ?? null, b?.erro);
      return send(res, 200, { ok: true });
    }
    if (p.startsWith("/mndy-cronjob/") || p.startsWith("/cron/")) {
      const job = p.split("/").filter(Boolean)[1] ?? "";
      if (p.startsWith("/cron/") && (!process.env.CRON_KEY || req.headers["x-cron-key"] !== process.env.CRON_KEY)) return send(res, 401, { ok: false });
      const out = await startJob(job).catch((e) => ({ error: String(e?.message ?? e) }));
      return send(res, 200, { ok: true, result: out });
    }
    if (req.method === "GET" && p === "/oauth/start") return await oauthStart(req, res);
    if (req.method === "GET" && p === "/oauth/callback") return await oauthCallback(req, res, url);
    if (req.method === "GET" && p === "/oauth/status") return await oauthStatus(res);
    if (p === "/health") return send(res, 200, { ok: true });
    const rel = p === "/" ? "index.html" : import_node_path.default.normalize(p).replace(/^([/\\])+/, "");
    const file = import_node_path.default.join(PUBLIC, rel);
    if (!file.startsWith(PUBLIC)) return send(res, 404, { ok: false });
    try {
      const data = await (0, import_promises.readFile)(file);
      res.writeHead(200, { "Content-Type": MIME[import_node_path.default.extname(file)] ?? "application/octet-stream", "Cache-Control": rel === "index.html" ? "no-store" : "public, max-age=31536000, immutable" });
      return res.end(data);
    } catch {
      const html = await (0, import_promises.readFile)(import_node_path.default.join(PUBLIC, "index.html"));
      res.writeHead(200, { "Content-Type": MIME[".html"], "Cache-Control": "no-store" });
      return res.end(html);
    }
  } catch (e) {
    console.error("[server]", e);
    if (!res.headersSent) send(res, 500, { ok: false, error: e instanceof Error ? e.message : "Erro no servidor." });
  }
});
server.requestTimeout = 0;
server.headersTimeout = 12e4;
server.listen(Number(process.env.PORT) || 8080, () => console.log(`servidor no ar (${FNS.size} fun\xE7\xF5es)`));
